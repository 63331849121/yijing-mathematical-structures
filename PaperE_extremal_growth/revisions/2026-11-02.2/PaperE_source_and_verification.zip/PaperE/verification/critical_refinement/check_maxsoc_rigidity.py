"""Independent finite ordinary-CE and action-obstruction controls for E_Q.

The default execution is read-only. --report exclusively creates a new JSON.
All test matrices have F2 entries, so their ranks remain the same over F4.
Two additional genuine F4 semilinear-lift scenarios test nonbinary
coefficients and reject an intentionally omitted Frobenius twist.
These are finite controls of the stated interfaces, not a general proof.
"""
import argparse
from itertools import combinations
import json
from pathlib import Path
import platform


def rank(vectors):
    pivots = {}
    for vector in vectors:
        while vector:
            bit = vector.bit_length() - 1
            if bit in pivots:
                vector ^= pivots[bit]
            else:
                pivots[bit] = vector
                break
    return len(pivots)


def apply(columns, vector):
    out = 0
    while vector:
        bit = (vector & -vector).bit_length() - 1
        vector &= vector - 1
        out ^= columns[bit]
    return out


def matrix_rows(columns, out_dimension):
    return [sum(((column >> output) & 1) << source
                for source, column in enumerate(columns))
            for output in range(out_dimension)]


def ce_differential(actions, degree, dimension):
    source = list(combinations(range(len(actions)), degree))
    target = list(combinations(range(len(actions)), degree + 1))
    target_index = {indices: i for i, indices in enumerate(target)}
    columns = []
    for indices in source:
        for basis in range(dimension):
            column = 0
            for extra in range(len(actions)):
                if extra not in indices:
                    combined = tuple(sorted((*indices, extra)))
                    column ^= actions[extra][basis] << (dimension * target_index[combined])
            columns.append(column)
    return columns


def module(d, h, q_vectors):
    masks = [mask for mask in range(1 << d) if mask & ~1]
    index = {mask: i for i, mask in enumerate(masks)}
    w0, dimension = len(masks), len(masks) + h
    actions = []
    for i in range(d):
        columns = [0] * dimension
        for mask, at in index.items():
            if not mask & (1 << i):
                columns[at] = 1 << index[mask | (1 << i)]
            elif i > 0 and mask == (1 << i):
                columns[at] = q_vectors[i - 1] << w0
        actions.append(columns)
    return actions, index, w0, dimension


def obstruction_space(actions, index, w0, dimension):
    """Solve Hom_R(K,E_Q), socle-zero, T beta=delta A simultaneously.

    Unknowns b_i=T(y_i) determine the entire map, because T kills Z.
    Relations are the actual minimal K presentation, not an assumed
    polynomial form for T. Auxiliary A_i are arbitrary core one-cochains.
    """
    d = len(actions)
    action_rows = [matrix_rows(action, dimension) for action in actions]
    nb = (d - 1) * dimension
    b_offset = lambda i: (i - 1) * dimension
    a_offset = lambda i: nb + i * dimension
    relation_rows = []
    for i in range(1, d):
        relation_rows.extend(row << b_offset(i) for row in action_rows[i])
    for i, j in combinations(range(1, d), 2):
        relation_rows.extend((left << b_offset(j)) ^ (right << b_offset(i))
                             for left, right in zip(action_rows[i], action_rows[j]))
    # tau = product_{j != 1} t_j y_1. Impose T(tau)=0 explicitly.
    terminal = [1 << i for i in range(dimension)]
    for j in range(d):
        if j != 1:
            terminal = [apply(actions[j], column) for column in terminal]
    relation_rows.extend(row << b_offset(1) for row in matrix_rows(terminal, dimension))
    raw_dimension = nb - rank(relation_rows)

    combined_rows = list(relation_rows)
    for i in range(1, d):
        for output in range(dimension):
            combined_rows.append((1 << (b_offset(i) + output))
                                 ^ (action_rows[0][output] << a_offset(i))
                                 ^ (action_rows[i][output] << a_offset(0)))
    for i, j in combinations(range(1, d), 2):
        combined_rows.extend((left << a_offset(j)) ^ (right << a_offset(i))
                             for left, right in zip(action_rows[i], action_rows[j]))
    d1 = ce_differential(actions, 1, dimension)
    admissible_dimension = nb - rank(combined_rows) + rank(d1)
    return raw_dimension, admissible_dimension


def f4_multiply(left, right):
    """F4={0,1,omega,omega+1}, omega^2=omega+1."""
    product = 0
    for bit in range(2):
        if (right >> bit) & 1:
            product ^= left << bit
    if product & 4:
        product ^= 7
    return product


def f4_apply(columns, vector):
    out = [0] * len(columns[0])
    for coefficient, column in zip(vector, columns):
        if coefficient:
            out = [entry ^ f4_multiply(coefficient, image)
                   for entry, image in zip(out, column)]
    return out


def f4_rank(columns):
    rows = [list(row) for row in zip(*columns)]
    pivot_row = 0
    for column in range(len(columns)):
        pivot = next((i for i in range(pivot_row, len(rows)) if rows[i][column]), None)
        if pivot is None:
            continue
        rows[pivot_row], rows[pivot] = rows[pivot], rows[pivot_row]
        inverse = f4_multiply(rows[pivot_row][column], rows[pivot_row][column])
        rows[pivot_row] = [f4_multiply(inverse, value) for value in rows[pivot_row]]
        for i in range(len(rows)):
            if i != pivot_row and rows[i][column]:
                coefficient = rows[i][column]
                rows[i] = [left ^ f4_multiply(coefficient, right)
                           for left, right in zip(rows[i], rows[pivot_row])]
        pivot_row += 1
        if pivot_row == len(rows):
            break
    return pivot_row


def f4_semilinear_lift(matrix_m, matrix_c):
    """Construct the proposed lift from its presentation generators.

    Repeated-action central corrections on nonsingleton monomials are
    retained. Thus this tests the complete semilinear map, not only
    the diagonal generator relation.
    """
    d, h = 4, 2
    bit_actions, index, w0, dimension = module(d, h, [1, 2, 0])
    actions = [[[((column >> row) & 1) for row in range(dimension)]
                for column in action] for action in bit_actions]
    sigma_actions = [actions[0]]
    for source in range(d - 1):
        transformed = []
        for basis in range(dimension):
            column = [0] * dimension
            for target in range(d - 1):
                coefficient = matrix_m[target][source]
                column = [left ^ f4_multiply(coefficient, right)
                          for left, right in zip(column, actions[target + 1][basis])]
            transformed.append(column)
        sigma_actions.append(transformed)
    phi = []
    for mask in index:
        positive = next(i for i in range(1, d) if mask & (1 << i))
        image = [0] * dimension
        for target in range(d - 1):
            image[index[1 << (target + 1)]] ^= matrix_m[target][positive - 1]
        for variable in range(d):
            if variable != positive and mask & (1 << variable):
                image = f4_apply(sigma_actions[variable], image)
        phi.append(image)
    for source in range(h):
        image = [0] * dimension
        for target in range(h):
            image[w0 + target] = matrix_c[target][source]
        phi.append(image)
    failures = []
    for generator in range(d):
        for basis in range(dimension):
            left = f4_apply(phi, actions[generator][basis])
            right = f4_apply(sigma_actions[generator], phi[basis])
            if left != right:
                failures.append(dict(generator=generator, basis=basis,
                                     phi_ti=left, sigma_ti_phi=right))
    central_correction = any(any(column[w0:])
                             for column in phi[:w0])
    return dict(rank=f4_rank(phi), dimension=dimension,
                generator_relation_checks=d*dimension,
                relation_failures=len(failures),
                first_failure=failures[0] if failures else None,
                nonzero_central_correction_on_K=central_correction)


def check_f4_semilinear_scenarios():
    scenarios = [
        ("omega_diagonal", [[2, 0, 0], [0, 1, 0], [0, 0, 1]],
         [[3, 0], [0, 1]], [[2, 0], [0, 1]]),
        ("omega_shear_in_rank_two_image", [[1, 2, 0], [0, 1, 0], [0, 0, 1]],
         [[1, 3], [0, 1]], [[1, 2], [0, 1]]),
    ]
    results = []
    assert f4_multiply(2, 2) == 3
    assert f4_multiply(2, 3) == 1
    for name, matrix_m, correct_c, deliberately_wrong_c in scenarios:
        positive = f4_semilinear_lift(matrix_m, correct_c)
        negative = f4_semilinear_lift(matrix_m, deliberately_wrong_c)
        assert positive["rank"] == positive["dimension"]
        assert positive["relation_failures"] == 0
        assert negative["rank"] == negative["dimension"]
        assert negative["relation_failures"] > 0
        if "shear" in name:
            assert positive["nonzero_central_correction_on_K"]
        results.append(dict(name=name, field="F4; omega=2, omega^2=3",
                            d=4, h=2, rank_Q=2, M=matrix_m,
                            correct_C=correct_c, wrong_C_without_Frobenius=deliberately_wrong_c,
                            positive_lift=positive,
                            negative_control_rejected=negative, status="PASS"))
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path,
                        help="Exclusively create a new report; existing files are not overwritten.")
    args = parser.parse_args()
    cases = [
        (4, 1, [0, 0, 0]), (4, 1, [1, 0, 0]),
        (4, 1, [1, 1, 1]), (4, 2, [0, 0, 0]),
        (4, 2, [1, 0, 0]), (4, 2, [1, 2, 3]),
        (4, 3, [1, 2, 4]), (4, 3, [3, 5, 6]),
        (5, 1, [1, 1, 0, 1]), (5, 2, [1, 2, 3, 1]),
        (5, 3, [1, 2, 4, 7]), (5, 3, [0, 0, 0, 0]),
        (4, 6, [1, 2, 4]), (4, 6, [1, 1, 1]),
        (5, 7, [1, 2, 4, 8]), (5, 7, [0, 0, 0, 0]),
    ]
    results = []
    for d, h, q_vectors in cases:
        actions, index, w0, dimension = module(d, h, q_vectors)
        assert len(q_vectors) == d - 1
        assert all(vector < (1 << h) for vector in q_vectors)
        for action in actions:
            assert all(apply(action, column) == 0 for column in action)
        for left, right in combinations(actions, 2):
            assert all(apply(left, right[j]) == apply(right, left[j]) for j in range(dimension))
        differentials = [ce_differential(actions, degree, dimension) for degree in range(3)]
        assert all(apply(differentials[1], column) == 0 for column in differentials[0])
        assert all(apply(differentials[2], column) == 0 for column in differentials[1])
        ranks = list(map(rank, differentials))
        c_d = d * (d - 1) // 2
        cohomology = [dimension - ranks[0], d * dimension - ranks[0] - ranks[1],
                      c_d * dimension - ranks[1] - ranks[2]]
        assert cohomology == [h + 1, d + 1 + h * d, d + c_d + h * c_d]
        pairs = list(combinations(range(d), 2))
        central = [1 << (pair * dimension + w0 + z)
                   for pair in range(c_d) for z in range(h)]
        central_injection_rank = rank([*differentials[1], *central]) - ranks[1]
        assert central_injection_rank == h * c_d
        central_star = [1 << (pairs.index((0, i)) * dimension + w0 + z)
                        for i in range(1, d) for z in range(h)]
        obstruction_rank = rank([*differentials[1], *central_star]) - ranks[1]
        assert obstruction_rank == h * (d - 1)
        raw, admissible = obstruction_space(actions, index, w0, dimension)
        assert raw == w0 - 1 + h * (d - 1)
        assert admissible == w0 - 1
        record = dict(d=d, h=h, q_vectors=q_vectors, rank_Q=rank(q_vectors),
                      H0_H1_H2=cohomology, central_H2_injection_rank=central_injection_rank,
                      independent_Jacobi_obstruction_rank=obstruction_rank,
                      raw_socle_zero_End_dimension=raw,
                      admissible_socle_zero_action_dimension=admissible,
                      polynomial_dimension_after_core_subtraction=admissible-d,
                      expected_D=(1 << d)-d-3, status="PASS")
        results.append(record)
        print(json.dumps(record))
    f4_results = check_f4_semilinear_scenarios()
    report = dict(status="PASS", cases=len(results)+len(f4_results), python=platform.python_version(),
                  scope="Finite ordinary-CE, central injection and socle-zero action-obstruction controls for E_Q",
                  field="F2 rank controls plus genuine nonbinary F4 semilinear and negative controls",
                  independent_controls=results, f4_semilinear_controls=f4_results)
    if args.report is not None:
        with args.report.open("x", encoding="utf-8") as stream:
            json.dump(report, stream, indent=2)
            stream.write("\n")
    print(json.dumps(dict(status="PASS", cases=len(results)+len(f4_results),
                         socle_action_cases=len(results), genuine_F4_scenarios=len(f4_results),
                         report=str(args.report) if args.report else None)))


if __name__ == "__main__":
    main()

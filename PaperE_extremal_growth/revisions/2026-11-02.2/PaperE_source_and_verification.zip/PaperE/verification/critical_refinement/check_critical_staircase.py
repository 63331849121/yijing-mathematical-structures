"""Independent exact algebra controls for the critical staircase.

These controls verify symbolic census identities and integer optimization;
they do not enumerate Lie algebras or replace the cited census proofs.
Default execution is read-only. --report exclusively creates a new JSON.
"""
import argparse
from fractions import Fraction
import json
from math import ceil
from pathlib import Path
import platform
import sympy as sp


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path,
                        help="Exclusively create a new report; an existing report is never overwritten.")
    args = parser.parse_args()
    d, n, r, h, t, x = sp.symbols("d n r h T x")
    choose2 = lambda value: value * (value - 1) / 2
    s = r - h
    v_h = s * n - 3 * s + (h - 1) * choose2(d + s)
    v_0 = r * n - 3 * r - choose2(d + r)
    central_lower = (s * n + h * choose2(d + s) - s**2 / 2
                     - d * (s + h) - choose2(d) - h**2 - sp.Rational(5, 2) * s - 3)
    expansion = (h * (-n + choose2(d + r)) - h * (h - 1) * (d + r)
                 + h**3 / 2 + sp.Rational(5, 2) * h)
    remainder = (h * (x**2 / 2 - sp.Rational(1, 8))
                 - h * (h - 1) * (x + sp.Rational(1, 2))
                 + h**3 / 2 + sp.Rational(5, 2) * h)
    f = h * x - h * (h - 1)
    critical_substitution = {r: t - d + sp.Rational(1, 2) + x, n: t**2 / 2}
    identities = {
        "coupled_family_lower_equals_Vh_minus_dh_h2_3": central_lower - (v_h - d * h - h**2 - 3),
        "exact_Vh_minus_V0": v_h - v_0 - expansion,
        "critical_remainder": (v_h - v_0).subs(critical_substitution) - t * f - remainder,
        "adjacent_increment": f.subs(h, h + 1) - f - (x - 2 * h),
        "concave_square": f - ((x + 1)**2 / 4 - (h - (x + 1) / 2)**2),
        "principal_V0_expansion": v_0 - (r*n-r**2/2-d*r-sp.Rational(5, 2)*r-choose2(d)),
    }
    for name, expression in identities.items():
        assert sp.expand(expression) == 0, name

    optimization_checks = increment_checks = 0
    for numerator in range(-128, 257):
        offset = Fraction(numerator, 8)
        values = {defect: defect * offset - defect * (defect - 1) for defect in range(81)}
        maximum = max(values.values())
        actual = [defect for defect, value in values.items() if value == maximum]
        if offset < 0:
            expected = [0]
        elif (offset / 2).denominator == 1:
            expected = [int(offset / 2), int(offset / 2) + 1]
        else:
            expected = [ceil(offset / 2)]
        assert actual == expected, (offset, actual, expected)
        optimization_checks += 1
        for defect in range(80):
            assert values[defect + 1] - values[defect] == offset - 2 * defect
            increment_checks += 1

    # Exact odd-d controls of the intermediate h tail, including h=O(d).
    # This is a numerical audit of the algebraic estimate, not its proof.
    tail_checks = 0
    for dimension in range(15, 42, 2):
        t_value = 1 << ((dimension + 1) // 2)
        n_value = 1 << dimension
        for numerator in range(-32, 33):
            offset = Fraction(numerator, 4)
            surplus = t_value - dimension + Fraction(1, 2) + offset
            for defect in range(18, dimension + 13):
                extra = surplus - defect
                c = lambda z: z * (z - 1) / 2
                v_actual = extra*n_value - 3*extra + (defect-1)*c(dimension+extra)
                v_principal = surplus*n_value - 3*surplus - c(dimension+surplus)
                assert v_actual - v_principal <= -Fraction(1, 4)*t_value*defect**2
                tail_checks += 1

    report = dict(status="PASS", python=platform.python_version(), sympy=sp.__version__,
                  scope="Symbolic census identities and exact rational integer-optimization controls; no Lie-algebra enumeration",
                  symbolic_identities=list(identities), symbolic_identity_count=len(identities),
                  discrete_optimization_checks=optimization_checks,
                  adjacent_increment_checks=increment_checks,
                  rational_intermediate_tail_checks=tail_checks,
                  boundary_caution="Density-one requires a limiting interior offset or endpoint distance times T/d tending to infinity; ties give two-branch support only")
    if args.report is not None:
        with args.report.open("x", encoding="utf-8") as stream:
            json.dump(report, stream, indent=2)
            stream.write("\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()

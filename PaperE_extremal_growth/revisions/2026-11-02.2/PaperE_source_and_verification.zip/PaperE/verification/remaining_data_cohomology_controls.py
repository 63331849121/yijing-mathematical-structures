"""Exact low-degree cochain controls, not orbit enumeration.

All entries are 0/1, so the ranks over F2 and F4 agree.  General exactness is
proved using the tensor-periodic resolution in remaining_data_agent.txt.
"""
from pathlib import Path
from itertools import combinations
import json

def rank(vectors):
    pivots={}
    for value in vectors:
        while value:
            bit=value.bit_length()-1
            if bit in pivots: value ^= pivots[bit]
            else:
                pivots[bit]=value
                break
    return len(pivots)

results=[]
for s in range(2,6):
    masks=list(range(1,1<<s)); w=len(masks)
    index={mask:i for i,mask in enumerate(masks)}
    pairs=list(combinations(range(s),2))
    labels=[('b',i) for i in range(s)]+[('a',i,j) for i,j in pairs]
    offset={label:q*w for q,label in enumerate(labels)}
    def variable(label,mask): return 1 << (offset[label]+index[mask])
    def multiply(i,label):
        values=[0]*w
        for mask in masks:
            if not mask & (1<<i):
                values[index[mask|(1<<i)]] ^= variable(label,mask)
        return values
    def add(*items): return [sum_xor(entry) for entry in zip(*items)]
    def sum_xor(items):
        value=0
        for item in items: value ^= item
        return value
    rows=[]
    for i in range(s): rows.extend(multiply(i,('b',i)))
    for i,j in pairs:
        rows.extend(add(multiply(i,('b',j)),multiply(j,('a',i,j))))
        rows.extend(add(multiply(j,('b',i)),multiply(i,('a',i,j))))
    for i,j,k in combinations(range(s),3):
        rows.extend(add(multiply(i,('a',j,k)),multiply(j,('a',i,k)),multiply(k,('a',i,j))))
    rows=[r for r in rows if r]
    c2=len(labels)*w
    d2rank=rank(rows)
    boundaries=[]
    classes=[]
    def boundary(i,mask):
        value=0
        if not mask & (1<<i): value ^= variable(('b',i),mask|(1<<i))
        for j in range(s):
            if i==j or mask & (1<<j): continue
            a,b=sorted((i,j));value ^= variable(('a',a,b),mask|(1<<j))
        return value
    for i in range(s):
        for mask in masks: boundaries.append(boundary(i,mask))
        classes.append(boundary(i,0))
    d1rank=rank(boundaries)
    for v in boundaries+classes:
        assert all((v&r).bit_count()%2==0 for r in rows)
    cycle_dim=c2-d2rank
    assert cycle_dim-d1rank==s
    assert rank(boundaries+classes)==cycle_dim
    d0=[]
    for mask in masks:
        value=0
        for i in range(s):
            if not mask&(1<<i): value ^= 1 << (i*w+index[mask|(1<<i)])
        d0.append(value)
    d0rank=rank(d0)
    h1=s*w-d1rank-d0rank
    assert h1==1
    results.append({'s':s,'J_dimension':w,'C2_dimension':c2,'d2_rank':d2rank,
                    'd1_rank':d1rank,'H2_dimension':s,'H1_dimension':h1,
                    'constant_connecting_classes_span_H2':True})

path=Path(__file__).with_suffix('.json')
path.write_text(json.dumps({'status':'PASS','scope':'low-degree exact rank controls; no parameter orbit enumeration','results':results},indent=2),encoding='utf-8')
print(path.read_text(encoding='utf-8'))

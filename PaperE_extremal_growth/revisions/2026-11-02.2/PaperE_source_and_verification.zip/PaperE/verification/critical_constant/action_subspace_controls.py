"""Independent exact F4 controls for quotient-action normalization.

Actual square-zero R-modules include K, J, R, K+trivial factors and
K plus a nonsemisimple two-dimensional factor. This is a finite control
of the presentation interface, not a proof of the asymptotic threshold.
"""
from pathlib import Path
from itertools import combinations,product
from math import comb
import random,json,time

HERE=Path(__file__).resolve().parent

# Individual replay defaults to no persistent output. The unified runner
# supplies an explicit fresh report path inside its isolated output copy.
def _report_cli():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--report', type=Path,
                       help='Write a detailed JSON report to a new file; never overwrite.')
    group.add_argument('--no-write', action='store_true',
                       help='Print summary only, without writing a JSON report (default).')
    args = parser.parse_args()
    if args.report is not None:
        args.report = args.report.resolve()
        if args.report.exists():
            parser.error('--report must name a new file; an existing report is never overwritten')
    return args

_REPORT_ARGS = _report_cli() if __name__ == '__main__' else None

def _write_report(report):
    if _REPORT_ARGS is None or _REPORT_ARGS.report is None:
        return
    target = _REPORT_ARGS.report
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2))


RNG=random.Random(202610302129)
M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2));INV=(0,1,3,2)

def terms(v):
    while v:
        j=((v&-v).bit_length()-1)//2;c=(v>>(2*j))&3
        yield j,c;v&=~(3<<(2*j))

def scale(c,v):
    if not c:return 0
    if c==1:return v
    return sum(M[c][a]<<(2*j) for j,a in terms(v))

def linear(coeffs,vectors):
    out=0
    for j,c in terms(coeffs):out^=scale(c,vectors[j])
    return out

def rref(vectors):
    rows=list(vectors);s=len(rows);C=[1<<(2*i) for i in range(s)]
    current=0
    while current<s:
        choices=[((((v&-v).bit_length()-1)//2),i) for i,v in enumerate(rows) if i>=current and v]
        if not choices:break
        pivot,j=min(choices)
        rows[current],rows[j]=rows[j],rows[current];C[current],C[j]=C[j],C[current]
        c=(rows[current]>>(2*pivot))&3
        rows[current]=scale(INV[c],rows[current]);C[current]=scale(INV[c],C[current])
        for i in range(s):
            if i==current:continue
            c=(rows[i]>>(2*pivot))&3
            if c:rows[i]^=scale(c,rows[current]);C[i]^=scale(c,C[current])
        current+=1
    return rows,C,current

def quotient(v,core_rows):
    for p in core_rows:
        j=((p&-p).bit_length()-1)//2;c=(v>>(2*j))&3
        if c:v^=scale(c,p)
    return v

def normalize(T,P):
    core,_,d=rref(P);assert d==len(P)
    Q=[quotient(t,core) for t in T]
    standard,C,rank=rref(Q)
    assert rref(C)[2]==len(T)
    assert all(quotient(linear(row,T),core)==target for row,target in zip(C,standard))
    return standard,rank

def apply(A,v):return linear(v,A)

def compose(A,B):return [apply(A,v) for v in B]

def flatten(A):
    n=len(A)
    return sum(col<<(2*n*j) for j,col in enumerate(A))

def unflatten(value,n):return [(value>>(2*n*j))&((1<<(2*n))-1) for j in range(n)]

def binary_rank(rows):
    piv={}
    for v in rows:
        while v:
            i=v.bit_length()-1
            if i in piv:v^=piv[i]
            else:piv[i]=v;break
    return len(piv)

def end_dimension(P):
    n=len(P[0]);rows=[]
    for A in P:
        for a in range(n):
            for b in range(n):
                eq=0
                for c in range(n):
                    if (A[c]>>(2*a))&3:eq^=1<<(b*n+c)
                    if (A[b]>>(2*c))&3:eq^=1<<(c*n+a)
                rows.append(eq)
    return n*n-binary_rank(rows)

def module(d,kind):
    if kind in ('K','K+k','K+k2','K+N2'):masks=list(range(2,1<<d))
    elif kind=='J':masks=list(range(1,1<<d))
    elif kind=='R':masks=list(range(1<<d))
    else:raise ValueError(kind)
    ix={mask:i for i,mask in enumerate(masks)}
    extra=1 if kind=='K+k' else 2 if kind in ('K+k2','K+N2') else 0
    n=len(masks)+extra;P=[]
    for i in range(d):
        cols=[0]*n
        for mask,j in ix.items():
            if not(mask&(1<<i)):cols[j]=1<<(2*ix[mask|(1<<i)])
        if kind=='K+N2' and i in (0,1):cols[-2]=1<<(2*(n-1))
        P.append(cols)
    h=n-((1<<d)-2)
    F=[0]*n
    if extra:
        # A genuine non-polynomial R-endomorphism into the core socle.
        F[len(masks)]=1<<(2*ix[(1<<d)-1])
    return P,h,F

def validate_actions(P,actions):
    n=len(P[0])
    for T in actions:
        assert compose(T,T)==[0]*n
        assert all(compose(T,A)==compose(A,T) for A in P)
    assert all(compose(T,U)==compose(U,T) for T,U in combinations(actions,2))

def actual_modules():
    records=[]
    for d,kind in ((4,'K'),(4,'J'),(4,'R'),(4,'K+k'),(4,'K+k2'),(4,'K+N2'),(5,'K'),(5,'J')):
        P,h,F=module(d,kind);n=len(P[0]);pflat=[flatten(A) for A in P]
        assert rref(pflat)[2]==d
        end=end_dimension(P);bound=(1<<d)-2+h*d+h*h
        assert end<=bound
        high=[compose(P[i],P[j]) for i,j in combinations(range(d),2)]
        if any(F):high.append(F)
        generators=P+high
        for case in range(6):
            s=3+(case&1)
            actions=[]
            for a in range(s):
                c=[RNG.randrange(4) for _ in generators]
                coeff=sum(x<<(2*j) for j,x in enumerate(c))
                actions.append(unflatten(linear(coeff,[flatten(A) for A in generators]),n))
            if case==0:actions=[high[0]]+[P[a%d] for a in range(s-1)]
            if case==1:actions[-1]=actions[0][:]
            validate_actions(P,actions)
            T=[flatten(A) for A in actions]
            standard,rank=normalize(T,pflat)
            C=[1<<(2*a) for a in range(s)]
            for _ in range(2*s):
                a,b=RNG.sample(range(s),2);C[a]^=scale(RNG.randrange(1,4),C[b])
            assert rref(C)[2]==s
            mixed=[linear(row,T)^linear(sum(RNG.randrange(4)<<(2*i) for i in range(d)),pflat) for row in C]
            standard2,rank2=normalize(mixed,pflat)
            assert standard==standard2 and rank==rank2
            validate_actions(P,[unflatten(v,n) for v in standard])
            records.append({'d':d,'module':kind,'defect':h,'s':s,'action_rank_mod_core':rank,
                'module_dimension':n,'End_dimension':end,'proven_End_bound':bound,'status':'PASS'})
    return records

def exhaustive_small_quotient():
    P,_,_=module(2,'R');n=len(P[0]);Id=[1<<(2*i) for i in range(n)]
    top=compose(P[0],P[1]);endquotient=[flatten(Id),flatten(top)]
    vectors=[linear(a|(b<<2),endquotient) for a,b in product(range(4),repeat=2)]
    classes={}
    for T in product(vectors,repeat=2):
        normal,rank=normalize(T,[flatten(A) for A in P]);classes[tuple(normal)]=rank
    counts={rank:sum(r==rank for r in classes.values()) for rank in range(3)}
    assert counts=={0:1,1:5,2:1}
    return {'module':'regular square-zero ring in two variables','field':4,
            'ordered_pairs':len(vectors)**2,'normalized_subspaces_by_rank':counts,
            'note':'Includes inadmissible square-nonzero actions, as allowed by an upper covering census.','status':'PASS'}

def bookkeeping():
    count=0
    for d in range(4,22):
        n=1<<d;D=n-d-3;C=comb(d,2)
        for r in range(1,min(D//2,70)+1):
            lower2=2*r*n-r*r-2*d*r-2*C-5*r-6
            Z=2*d*d+3*d*r+2*r+6
            for h in range(1,r+1):
                s=r-h
                E=s*(n-2)+(2*h+1)*C+d*(h*h+2*s*h+1)+s*h*h+r+comb(s,2)*(h+1)-s*s
                # The prefactor logarithm is <=(r+1)/2 for q>=4.
                lhs2=2*E+(r+1)-lower2
                rhs2=h*(-2*n+r*r-h*h+2*Z)
                assert lhs2<=rhs2,(d,r,h,lhs2,rhs2)
                assert 2*s<=(n-2)+h*d+h*h-d
                count+=1
    return {'exact_branch_cases':count,'status':'PASS'}

if __name__=='__main__':
    start=time.monotonic();records=actual_modules()
    report={'status':'PASS','module_cases':records,'small_quotient':exhaustive_small_quotient(),
        'bookkeeping':bookkeeping(),'seconds':round(time.monotonic()-start,3),
        'scope':'Exact finite module/action presentation controls; no asymptotic or literature priority inferred from samples.'}
    _write_report(report)
    print(json.dumps({'status':'PASS','module_cases':len(records),'small_pairs':report['small_quotient']['ordered_pairs'],
                      'branch_cases':report['bookkeeping']['exact_branch_cases'],'seconds':report['seconds']}))

"""Finite controls for all fixed surplus: multi-direction cocycles and shears.

The field/vector helpers extend the previous r=1 checker. All cochain,
group-action and pure-shear constructions below are rebuilt for r>=2.
No canonical verification program or construction generator is imported.
"""
from pathlib import Path
from itertools import combinations
import json, random, time

HERE=Path(__file__).resolve().parent

# Individual replay defaults to no persistent output. The unified runner
# supplies an explicit fresh report path inside its isolated output copy.
def _report_cli():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--report', type=Path,
                       help='Write a detailed JSON report to a new file; never overwrite.')
    group.add_argument('--no-write', action='store_true',
                       help='Print summary only, without writing a JSON report (default).')
    args = parser.parse_args()
    if args.report is not None:
        args.report = args.report.resolve()
        if args.report.exists():
            parser.error('--report must name a new file; an existing report is never overwritten')
    return args

_REPORT_ARGS = _report_cli() if __name__ == '__main__' else None

def _write_report(report):
    if _REPORT_ARGS is None or _REPORT_ARGS.report is None:
        return
    target = _REPORT_ARGS.report
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2))


RNG=random.Random(202610311083)
M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
INV=(0,1,3,2)

def vadd(a,b): return [x^y for x,y in zip(a,b)]
def scale(c,a):return [M[c][x] for x in a]

class Echelon:
    def __init__(self):self.rows={}
    def add(self,v):
        v=v[:]
        while any(v):
            j=next(i for i,x in enumerate(v) if x)
            if j in self.rows:
                v=vadd(v,scale(v[j],self.rows[j]))
            else:
                self.rows[j]=scale(INV[v[j]],v)
                return True
        return False
    def reduce(self,v):
        v=v[:]
        for j in sorted(self.rows):
            if v[j]:v=vadd(v,scale(v[j],self.rows[j]))
        return v
    def rank(self):return len(self.rows)

def matmul(A,B):
    out=[[0]*len(B[0]) for _ in A]
    for i in range(len(A)):
        for j in range(len(B[0])):
            for k in range(len(B)):out[i][j]^=M[A[i][k]][B[k][j]]
    return out

def invert(A):
    n=len(A);B=[row[:]+[int(i==j) for j in range(n)] for i,row in enumerate(A)]
    for j in range(n):
        i=next(i for i in range(j,n) if B[i][j]);B[j],B[i]=B[i],B[j]
        B[j]=scale(INV[B[j][j]],B[j])
        for i in range(n):
            if i!=j and B[i][j]:B[i]=vadd(B[i],scale(B[i][j],B[j]))
    return [row[n:] for row in B]

def random_gl(n):
    A=[[int(i==j) for j in range(n)] for i in range(n)]
    for _ in range(3*n):
        i,j=RNG.sample(range(n),2);c=RNG.randrange(1,4)
        A[i]=vadd(A[i],scale(c,A[j]))
    for i in range(n):A[i]=scale(RNG.randrange(1,4),A[i])
    return A

class Ring:
    def __init__(self,d):
        self.d=d;self.n=1<<d;self.z=self.n-2;self.tau=self.n-1
        self.K=[s for s in range(self.n) if s&self.z]
        self.P=[s for s in range(self.n) if s.bit_count()>=2 and s not in(self.z,self.tau)]
        self.zero=[0]*self.n
        self.t=[self.mono(1<<i) for i in range(d)]
    def mono(self,s,c=1):
        out=self.zero[:];out[s]=c;return out
    def mul(self,a,b):
        out=self.zero[:]
        for s,x in enumerate(a):
            if x:
                for t,y in enumerate(b):
                    if y and not s&t:out[s|t]^=M[x][y]
        return out
    def Q(self,p):
        p=p[:];p[self.z]=p[self.tau]=0;return p
    def eval(self,p,images):
        out=self.zero[:]
        for s,c in enumerate(p):
            if c:
                term=self.mono(0,c)
                for i in range(self.d):
                    if s>>i&1:term=self.mul(term,images[i])
                out=vadd(out,term)
        return out
    def parameter(self):
        out=self.zero[:]
        for s in self.P:out[s]=RNG.randrange(4)
        return out
    def divide_p(self,p):
        a=[self.zero[:] for _ in range(self.d)]
        for s,c in enumerate(p):
            if c:
                i=next(i for i in range(1,self.d) if s>>i&1)
                a[i][s^(1<<i)]^=c
        out=self.zero[:]
        for i in range(self.d):out=vadd(out,self.mul(self.t[i],a[i]))
        assert out==p
        return a


def flatten(R,b):return [b[e][s] for e in sorted(b) for s in R.K]

def zeros(R,n):return {e:R.zero[:] for e in combinations(range(n),2)}

def core_basis(R):
    d=R.d;pairs=list(combinations(range(d),2));out=[];names=[]
    b=zeros(R,d)
    for i in range(1,d):b[(0,i)]=R.t[i]
    out.append(b);names.append('eta')
    for j in range(1,d):
        b=zeros(R,d)
        for i,k in pairs:
            if i>=1:
                if i==j:b[(i,k)]=R.mul(R.t[0],R.t[k])
                if k==j:b[(i,k)]=R.mul(R.t[0],R.t[i])
        out.append(b);names.append('kappa'+str(j))
    for i,j in pairs:
        b=zeros(R,d);b[(i,j)]=R.mono(R.tau^(1<<i)^(1<<j))
        out.append(b);names.append('lambda'+str((i,j)))
    return names,out

def build_basis(R,p):
    d=R.d;r=len(p);n=d+r;aa=[R.divide_p(pa) for pa in p]
    names,core=core_basis(R);out=[]
    for b in core:
        full=zeros(R,n)
        for e in b:full[e]=b[e][:]
        for a in range(r):
            for i in range(d):
                for j in range(d):
                    if i!=j:full[(i,d+a)]=vadd(full[(i,d+a)],R.mul(aa[a][j],b[tuple(sorted((i,j)))]))
        for a,c in combinations(range(r),2):
            for i,j in combinations(range(d),2):
                coeff=vadd(R.mul(aa[a][i],aa[c][j]),R.mul(aa[c][i],aa[a][j]))
                full[(d+a,d+c)]=vadd(full[(d+a,d+c)],R.mul(coeff,b[(i,j)]))
        out.append(full)
    zetas=[]
    zetas.append([R.zero[:] if i==0 else R.mul(R.t[0],R.t[i]) for i in range(d)])
    for j in range(d):zetas.append([R.mono(R.tau^(1<<j)) if i==j else R.zero[:] for i in range(d)])
    for a in range(r):
        for j,zeta in enumerate(zetas):
            full=zeros(R,n)
            for i in range(d):full[(i,d+a)]=zeta[i][:]
            for c in range(r):
                if c!=a:
                    key=tuple(sorted((d+a,d+c)))
                    for i in range(d):full[key]=vadd(full[key],R.mul(aa[c][i],zeta[i]))
            out.append(full);names.append(f'mixed_{a}_{j}')
    for a,c in combinations(range(r),2):
        full=zeros(R,n);full[(d+a,d+c)]=R.mono(R.tau)
        out.append(full);names.append(f'socle_pair_{a}_{c}')
    return names,out

def differential(R,actions,b):
    out=[]
    for i,j,k in combinations(range(len(actions)),3):
        val=vadd(vadd(R.mul(actions[i],b[(j,k)]),R.mul(actions[j],b[(i,k)])),R.mul(actions[k],b[(i,j)]))
        out.extend(val[s] for s in R.K)
    return out

def coboundaries(R,p):
    actions=R.t+p;n=len(actions);out=[]
    for j in range(n):
        for s in R.K:
            w=R.mono(s);b=zeros(R,n)
            for i,k in combinations(range(n),2):
                if j==i:b[(i,k)]=vadd(b[(i,k)],R.mul(actions[k],w))
                if j==k:b[(i,k)]=vadd(b[(i,k)],R.mul(actions[i],w))
            out.append(flatten(R,b))
    return out

def check_complete(R,p):
    r=len(p);n=R.d+r;actions=R.t+p
    names,basis=build_basis(R,p);boundaries=Echelon();full=Echelon()
    for b in coboundaries(R,p):boundaries.add(b);full.add(b)
    for b in basis:
        assert not any(differential(R,actions,b)), 'not closed'
        assert full.add(flatten(R,b)), 'H2 dependent'
    d2=Echelon()
    for e in combinations(range(n),2):
        for s in R.K:
            b=zeros(R,n);b[e]=R.mono(s);d2.add(differential(R,actions,b))
    closed=n*(n-1)//2*len(R.K)-d2.rank()
    expected=R.d+R.d*(R.d-1)//2+r*(R.d+1)+r*(r-1)//2
    assert len(basis)==expected and full.rank()==closed
    z1=n*len(R.K)-boundaries.rank();h1=z1-(len(R.K)-1)
    assert h1==R.d+1+r
    return names,basis,boundaries,{'H2':len(basis),'H1':h1,'Z1':z1,'closed':closed,'boundaries':boundaries.rank(),'d2_rank':d2.rank()}

def random_group(R,r):
    d=R.d;B=[[0]*d for _ in range(d)];B[0][0]=RNG.randrange(1,4)
    MH=random_gl(d-1)
    for i in range(1,d):
        B[i][0]=RNG.randrange(4)
        for j in range(1,d):B[i][j]=MH[i-1][j-1]
    alpha=[[RNG.randrange(4) for _ in range(d)] for _ in range(r)]
    return B,alpha,random_gl(r)

def full_matrix(g):
    B,alpha,Delta=g;r=len(Delta)
    return [row+[0]*r for row in B]+[a+row for a,row in zip(alpha,Delta)]

def compose(g2,g1):
    A=matmul(full_matrix(g2),full_matrix(g1));d=len(g1[0])
    return [row[:d] for row in A[:d]],[row[:d] for row in A[d:]],[row[d:] for row in A[d:]]

def poly_matrix(A,p):
    out=[]
    for row in A:
        value=[0]*len(p[0])
        for c,pa in zip(row,p):value=vadd(value,scale(c,pa))
        out.append(value)
    return out

def transform_parameters(R,p,g):
    B,alpha,Delta=g;r=len(p);ell=[]
    for i in range(R.d):
        value=R.zero[:]
        for j in range(R.d):value=vadd(value,scale(B[j][i],R.t[j]))
        ell.append(value)
    Dinverse=invert([list(row) for row in zip(*Delta)])
    q=[R.zero[:] for _ in range(r)]
    for _ in range(R.d+3):
        images=[vadd(ell[i],poly_matrix([[alpha[a][i] for a in range(r)]],q)[0]) for i in range(R.d)]
        new=poly_matrix(Dinverse,[R.Q(R.eval(pa,images)) for pa in p])
        if new==q:break
        q=new
    else:raise AssertionError('nonlinear contraction failed')
    assert poly_matrix([list(row) for row in zip(*Delta)],q)==[R.Q(R.eval(pa,images)) for pa in p]
    assert all(not x for S,x in enumerate(R.eval(R.mono(R.z),images)) if S not in (R.z,R.tau))
    return q,images

def transform_cocycle(R,b,g,images):
    inverse=invert(full_matrix(g));n=len(inverse);out=zeros(R,n)
    for i,j in combinations(range(n),2):
        value=R.zero[:]
        for a,c in combinations(range(n),2):
            coefficient=M[inverse[a][i]][inverse[c][j]]^M[inverse[c][i]][inverse[a][j]]
            if coefficient:value=vadd(value,scale(coefficient,b[(a,c)]))
        out[(i,j)]=scale(g[0][0][0],R.eval(value,images))
    return out

def tuple_rank(R,p):
    E=Echelon()
    for pa in p:E.add([pa[S] for S in R.P])
    return E.rank()

def selected_ce_controls():
    records=[]
    for d,r,cases in ((4,2,4),(4,3,2),(5,2,2)):
        R=Ring(d)
        for case in range(cases):
            p=[R.parameter() for _ in range(r)]
            if case==0:p=[R.zero[:] for _ in range(r)]
            elif case==1 and d==4 and r==2:p[1]=scale(2,p[0])
            _,basis,bound,rec=check_complete(R,p)
            g1=random_group(R,r);g2=random_group(R,r);g=compose(g2,g1)
            p1,im1=transform_parameters(R,p,g1);p2,im2=transform_parameters(R,p1,g2);p3,im3=transform_parameters(R,p,g)
            assert p2==p3 and tuple_rank(R,p)==tuple_rank(R,p3)
            _,target,targetbound,_=check_complete(R,p3)
            etazero=Echelon()
            for v in coboundaries(R,p3):etazero.add(v)
            for b in target[1:]:etazero.add(flatten(R,b))
            unit=[RNG.randrange(4) for _ in range(R.n)];unit[0]=1;unit[R.z]=unit[R.tau]=0
            for j,b in enumerate(basis):
                first=transform_cocycle(R,b,g1,im1)
                composed=transform_cocycle(R,first,g2,im2)
                direct=transform_cocycle(R,b,g,im3)
                assert not any(differential(R,R.t+p3,direct))
                diff=flatten(R,{e:vadd(composed[e],direct[e]) for e in direct})
                assert not any(targetbound.reduce(diff)), 'composition changed cohomology'
                remainder=flatten(R,{e:vadd(direct[e],target[0][e] if j==0 else R.zero) for e in direct})
                assert not any(etazero.reduce(remainder)), 'eta changed'
                unitdiff=flatten(R,{e:vadd(R.mul(unit,b[e]),b[e]) for e in b})
                assert not any(bound.reduce(unitdiff)), 'principal unit nontrivial'
            rec.update(d=d,r=r,case=case,parameter_rank=tuple_rank(R,p),all_H2_basis_composition='PASS',eta_normalization='PASS',principal_units='PASS',status='PASS')
            records.append(rec)
    return records

def coeffs_active(R,p,k):
    out={T:R.zero[:] for T in range(1<<k)};active=(1<<k)-1
    for S,c in enumerate(p):out[S&active][S&~active]^=c
    return out

def project_active_zero(R,p,k):
    active=(1<<k)-1
    return [0 if S&active else c for S,c in enumerate(p)]

def pure_projected_equation(R,p,k):
    images=[vadd(R.t[i],p[i]) if i<k else R.t[i] for i in range(R.d)]
    full=[project_active_zero(R,vadd(R.eval(pa,images),pa),k) for pa in p]
    a=[project_active_zero(R,pa,k) for pa in p]
    expanded=[]
    for pa in p:
        coefficients=coeffs_active(R,pa,k);value=R.zero[:]
        for T in range(1,1<<k):
            term=R.mono(0)
            for i in range(k):
                if T>>i&1:term=R.mul(term,a[i])
            value=vadd(value,R.mul(term,coefficients[T]))
        expanded.append(value)
    assert full==expanded
    return full,a

def derivative(R,p,i):
    out=R.zero[:]
    for S,c in enumerate(p):
        if S>>i&1:out[S^(1<<i)]^=c
    return out

def pure_controls():
    records=[]
    R=Ring(5)
    p=[vadd(R.mono(3),R.mono(21)),vadd(R.mono(12),R.mono(22))]
    product=R.Q(R.mul(p[0],p[1]));assert any(product)
    images=[vadd(R.t[i],p[i]) if i<2 else R.t[i] for i in range(R.d)]
    exact=R.Q(vadd(R.eval(p[0],images),p[0]));truncated=R.zero[:]
    for i in range(2):truncated=vadd(truncated,R.mul(p[i],derivative(R,p[0],i)))
    nonlinear=R.Q(vadd(exact,truncated));assert any(nonlinear)
    records.append({'d':5,'r':2,'rank_alpha':2,'nonzero_p1_p2':True,'higher_cross_term_survives_mod_I':True,'support':[S for S,c in enumerate(nonlinear) if c],'status':'PASS'})
    for d,r,k in ((5,2,2),(6,2,2),(6,3,3),(7,3,2)):
        R=Ring(d)
        p=[R.parameter() for _ in range(r)]
        # Make a_0 have an actual quadratic coefficient in remaining variables.
        mask=(1<<k)|(1<<(k+1));p[0][mask]=1
        before,a=pure_projected_equation(R,p,k)
        cols=[];m=d-k
        for S in range(R.n):
            if not S or S&((1<<k)-1):continue
            altered=[pa[:] for pa in p];altered[0][S|1]^=1
            after,_=pure_projected_equation(R,altered,k)
            diff=vadd(after[0],before[0])
            expected=R.mul(a[0],R.mono(S))
            assert diff==expected, 'conditional coefficient did not give multiplier'
            cols.append([c for T,c in enumerate(diff) if not T&((1<<k)-1)])
        E=Echelon()
        for col in cols:E.add(col)
        assert E.rank()>=2**(m-2)-1
        records.append({'d':d,'r':r,'rank_alpha':k,'remaining_variables':m,'conditional_rank':E.rank(),
                        'rank_lower_bound':2**(m-2)-1,'full_projected_cross_terms':'PASS','status':'PASS'})
    return records

def group_order(n):
    result=1
    for j in range(n):result*=4**n-4**j
    return result

def bookkeeping():
    for d in range(4,16):
        C=d*(d-1)//2;D=2**d-d-3
        for r in range(1,min(5,D)+1):
            f=(r+1)*d+C+r+r*(r-1)//2-1
            assert f-(r*d+d-1)==C+r+r*(r-1)//2
            # r=1 exactly recovers the existing numerator/group expression.
            if r==1:
                frames=4**D-1
                old_numerator=frames*4**(C+1)
                old_denominator=9*group_order(d-1)
                generic_numerator=frames*4**f
                generic_denominator=3*4**(d+d-1)*group_order(d-1)*group_order(1)
                assert old_numerator*generic_denominator==generic_numerator*old_denominator
    return {'status':'PASS','d_range':[4,15],'r_range':[1,5],'r1_specialization':'exact'}

if __name__=='__main__':
    started=time.monotonic()
    ce=selected_ce_controls();pure=pure_controls();book=bookkeeping()
    out={'status':'PASS','cohomology_records':ce,'pure_shear_records':pure,'bookkeeping':book,
         'seconds':round(time.monotonic()-started,3),
         'scope':'Standalone generalized CE control using finite-field helpers from the earlier r1 checker, with freshly built complete multi-direction cochains, full group actions/composition, principal units and projected pure-shear cross terms. No canonical verifier imports. These selected controls do not prove the uniform theorems.'}
    _write_report(out)
    print(json.dumps({'status':'PASS','CE_cases':len(ce),'pure_cases':len(pure),'seconds':out['seconds']}))

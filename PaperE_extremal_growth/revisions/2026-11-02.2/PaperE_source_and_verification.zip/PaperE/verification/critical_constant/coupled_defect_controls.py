"""Independent controls of the coupled K-plus-central derived defect.

Reconstructs actual F4 brackets from all Koszul components. Checks the
principal-unit lift by its explicit homotopy and on all Lie basis pairs.
No canonical construction/checker is imported. Uniform counting is proved
in writing separately; these selected finite models are interface controls.
"""
from pathlib import Path
from itertools import combinations
import random,json,time

HERE=Path(__file__).resolve().parent

# Individual replay defaults to no persistent output. The unified runner
# supplies an explicit fresh report path inside its isolated output copy.
def _report_cli():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--report', type=Path,
                       help='Write a detailed JSON report to a new file; never overwrite.')
    group.add_argument('--no-write', action='store_true',
                       help='Print summary only, without writing a JSON report (default).')
    args = parser.parse_args()
    if args.report is not None:
        args.report = args.report.resolve()
        if args.report.exists():
            parser.error('--report must name a new file; an existing report is never overwritten')
    return args

_REPORT_ARGS = _report_cli() if __name__ == '__main__' else None

def _write_report(report):
    if _REPORT_ARGS is None or _REPORT_ARGS.report is None:
        return
    target = _REPORT_ARGS.report
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2))


RNG=random.Random(202610302211)
M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
INV=(0,1,3,2)

def terms(v):
    while v:
        j=((v&-v).bit_length()-1)//2;c=(v>>(2*j))&3
        yield j,c;v&=~(3<<(2*j))

def scale(c,v):
    if c==1:return v
    if not c:return 0
    return sum(M[c][a]<<(2*j) for j,a in terms(v))

def basis(vectors):
    piv={}
    for v in vectors:
        while v:
            j=(v.bit_length()-1)//2;c=(v>>(2*j))&3
            if j in piv:v^=scale(c,piv[j])
            else:piv[j]=scale(INV[c],v);break
    return list(piv.values())

def add(*polys):
    out={}
    for p in polys:
        for S,c in p.items():
            out[S]=out.get(S,0)^c
            if not out[S]:del out[S]
    return out

def ps(c,p):return {S:M[c][a] for S,a in p.items() if M[c][a]}

def mul(p,q):
    out={}
    for S,c in p.items():
        for T,a in q.items():
            if not(S&T):
                U=S|T;out[U]=out.get(U,0)^M[c][a]
                if not out[U]:del out[U]
    return out

def enc(p):return sum(c<<(2*S) for S,c in p.items())

def split_polynomial(p,d):
    result=[{} for _ in range(d)]
    for S,c in p.items():
        bit=S&-S;i=bit.bit_length()-1
        result[i][S^bit]=c
    return result

class Model:
    def __init__(self,d,s,zero_gamma=False):
        self.d=d;self.s=s;self.N=1<<d;self.tau=self.N-1
        self.K=list(range(2,self.N));self.U=d+s;self.w0=len(self.K)
        self.ix={S:self.U+j for j,S in enumerate(self.K)}
        self.z=self.U+self.w0;self.n=self.z+1
        self.t=[{1<<i:1} for i in range(d)]
        masks=[S for S in range(self.N) if S.bit_count()>=2 and S not in(self.N-2,self.N-1)]
        self.p=[{3:1},{12:1}]
        while len(self.p)<s:
            p={S:c for S in masks if (c:=RNG.randrange(4))}
            if len(basis([enc(v) for v in self.p+[p]]))==len(self.p)+1:self.p.append(p)
        if RNG.randrange(2):
            for j in range(s):
                p=add(self.p[j],{S:c for S in masks if (c:=RNG.randrange(4))})
                trial=self.p[:];trial[j]=p
                if len(basis([enc(v) for v in trial]))==s:self.p=trial
        assert len(basis([enc(v) for v in self.t+self.p]))==self.U
        self.actions=self.t+self.p
        self.div=[]
        for p in self.p:
            row=[{} for _ in range(d)]
            for S,c in p.items():
                H=S&~1;bit=H&-H;i=bit.bit_length()-1
                row[i][S^bit]=c
            assert add(*(mul(self.t[i],row[i]) for i in range(d)))==p
            self.div.append(row)
        b={}
        kappa=[0]+[RNG.randrange(4) for _ in range(d-1)]
        for i,j in combinations(range(d),2):
            lam=RNG.randrange(4)
            base=self.t[j] if i==0 else add(ps(kappa[i],mul(self.t[0],self.t[j])),ps(kappa[j],mul(self.t[0],self.t[i])))
            b[i,j]=add(base,{self.tau^((1<<i)|(1<<j)):lam} if lam else {})
        def bc(i,j):return {} if i==j else b[min(i,j),max(i,j)]
        zeta=[]
        for a in range(s):
            eps=RNG.randrange(4);rho=[RNG.randrange(4) for _ in range(d)]
            zeta.append([add(ps(eps,mul(self.t[0],self.t[i])) if i else {},
                             {self.tau^(1<<i):rho[i]} if rho[i] else {}) for i in range(d)])
        self.beta=dict(b);self.gamma={}
        for i in range(d):
            for a in range(s):
                self.beta[i,d+a]=add(*(mul(self.div[a][j],bc(i,j)) for j in range(d)),zeta[a][i])
        for a,bx in combinations(range(s),2):
            value={}
            for i,j in combinations(range(d),2):
                coeff=add(mul(self.div[a][i],self.div[bx][j]),mul(self.div[bx][i],self.div[a][j]))
                value=add(value,mul(coeff,bc(i,j)))
            for i in range(d):
                value=add(value,mul(self.div[a][i],zeta[bx][i]),mul(self.div[bx][i],zeta[a][i]))
            chi=RNG.randrange(4)
            if chi:value=add(value,{self.tau:chi})
            self.beta[d+a,d+bx]=value
            self.gamma[d+a,d+bx]=0 if zero_gamma else (1 if (a,bx)==(0,1) else RNG.randrange(4))
        self.T=[[0]*self.n for _ in range(self.n)]
        for (i,j),p in self.beta.items():
            v=self.wp(p)^((self.gamma.get((i,j),0))<<(2*self.z))
            self.T[i][j]=self.T[j][i]=v
        for i,A in enumerate(self.actions):
            for S in self.K:
                v=self.wp(mul(A,{S:1}));j=self.ix[S]
                self.T[i][j]=self.T[j][i]=v
    def wp(self,p):
        assert all(S in self.ix for S in p),p
        return sum(c<<(2*self.ix[S]) for S,c in p.items())
    def br(self,v,w):
        out=0
        for i,c in terms(v):
            for j,a in terms(w):out^=scale(M[c][a],self.T[i][j])
        return out
    def lower(self):
        layer=basis(self.T[i][j] for i,j in combinations(range(self.n),2));dims=[self.n,len(layer)]
        while layer:
            layer=basis(self.br(1<<(2*i),v) for i in range(self.n) for v in layer)
            dims.append(len(layer));assert len(dims)<self.n+2
        return dims
    def principal_lift(self):
        u={S:c for S in range(self.N) if S not in(self.N-2,self.N-1) and (c:=RNG.randrange(4))};u[0]=1
        # Force a linear term, which a top-degree-only control would miss.
        u[1]=1
        div=split_polynomial({S:c for S,c in u.items() if S},self.d)
        f=[]
        for x in range(self.U):
            value={}
            for i in range(self.d):
                b={} if i==x else self.beta[min(i,x),max(i,x)]
                value=add(value,mul(div[i],b))
            f.append(value)
        for i,j in combinations(range(self.U),2):
            lhs=add(mul(self.actions[i],f[j]),mul(self.actions[j],f[i]))
            assert lhs==mul({S:c for S,c in u.items() if S},self.beta[i,j])
        images=[(1<<(2*i))^self.wp(f[i]) for i in range(self.U)]
        images += [self.wp(mul(u,{S:1})) for S in self.K]+[1<<(2*self.z)]
        assert len(basis(images))==self.n
        for i,j in combinations(range(self.n),2):
            transported=0
            for k,c in terms(self.T[i][j]):transported^=scale(c,images[k])
            assert self.br(images[i],images[j])==transported
        return True
    def module_blocks(self):
        v=RNG.randrange(4);ell={1<<i:RNG.randrange(4) for i in range(1,self.d)}
        c=RNG.randrange(1,4)
        u={S:a for S in range(self.N) if S not in(self.N-2,self.N-1) and (a:=RNG.randrange(4))};u[0]=RNG.randrange(1,4)
        w_basis=[{S:1} for S in self.K]
        local=lambda p,z=0:sum(a<<(2*self.K.index(S)) for S,a in p.items())^(z<<(2*self.w0))
        columns=[local(mul(u,p),next(iter(ell.get(S,0) for S in p))) for p in w_basis]
        columns.append(local({self.tau:v} if v else {},c))
        assert len(basis(columns))==self.w0+1
        # A projection onto a trivial graph summand in K+trivial: all core
        # and extra operators kill its image, as used by indecomposability.
        graph=local({self.tau:v} if v else {},1)
        assert all(not mul(A,{self.tau:v}) for A in self.actions)
        for j,S in enumerate(self.K):
            projected=scale(ell.get(S,0),graph)
            coefficient=next((a for k,a in terms(projected) if k==self.w0),0)
            # ell(tau)=0, so projecting the graph once more is unchanged.
            assert scale(coefficient,graph)==projected
        return True

def main():
    started=time.monotonic();records=[]
    for d,s,cases in ((4,2,3),(4,3,3),(5,2,2),(5,3,2)):
        for case in range(cases):
            A=Model(d,s)
            for i,j,k in combinations(range(A.n),3):
                assert not(A.br(1<<(2*i),A.T[j][k])^A.br(1<<(2*j),A.T[k][i])^A.br(1<<(2*k),A.T[i][j]))
            dims=A.lower();assert dims[1]==A.w0+1 and len(dims)-1==d+1
            assert all(A.principal_lift() for _ in range(3))
            assert all(A.module_blocks() for _ in range(4))
            records.append({'d':d,'extra_quotient':s,'total_surplus':s+1,'dimension':A.n,
                'derived_dimension':dims[1],'lower_central_dimensions':dims,
                'cross_product_nonzero':bool(mul(A.p[0],A.p[1])),
                'principal_unit_actual_Lie_lifts':3,'module_block_and_trivial_graph_checks':4,'status':'PASS'})
    # Negative control: gamma=0 leaves the appended central coordinate
    # outside the derived ideal. It must not be counted as defect one.
    negative=Model(4,2,True);assert negative.lower()[1]==negative.w0
    assert any(r['cross_product_nonzero'] for r in records)
    result={'status':'PASS','records':records,'negative_zero_gamma':'PASS',
        'scope':'Selected real F4 coupled Lie models, full mixed cocycles, explicit principal-unit Lie isomorphisms and module graph controls. General counting/indecomposability is proved separately.',
        'seconds':round(time.monotonic()-started,3)}
    _write_report(result)
    print(json.dumps({'status':'PASS','models':len(records),'actual_principal_unit_lifts':3*len(records),'seconds':result['seconds']}))

if __name__=='__main__':main()

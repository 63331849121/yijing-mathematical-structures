"""Fresh adversarial controls: no previous checker/PASS result is imported.

Direct ring arithmetic, independently assembled ordinary Lie kernel equations,
actual binary lifts and block compositions. Finite controls only, not Lean.
"""
from pathlib import Path
from itertools import combinations
import json,random

M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))

def X(values):
    v=0
    for x in values:v^=x
    return v

def rank(rows):
    piv={}
    for r in rows:
        while r:
            b=r.bit_length()-1
            if b in piv:r^=piv[b]
            else:piv[b]=r;break
    return len(piv)

class R:
    def __init__(self,s):
        self.s=s;self.N=1<<s;self.top=self.N-1
        self.J=list(range(1,self.N));self.A=list(range(1,self.top))
        self.t=[1<<(2*(1<<i)) for i in range(s)]
        self.tau=1<<(2*self.top)
        self.taui=[1<<(2*(self.top^(1<<i))) for i in range(s)]
    def terms(self,x):
        for a in range(self.N):
            c=(x>>(2*a))&3
            if c:yield a,c
    def scale(self,x,c):return sum(M[c][v]<<(2*a) for a,v in self.terms(x))
    def mul(self,x,y):
        out=0
        for a,c in self.terms(x):
            for b,d in self.terms(y):
                if a&b==0:out^=M[c][d]<<(2*(a|b))
        return out
    def pr(self,x):return x&((1<<(2*self.top))-1)
    def coef(self,x,a):return (x>>(2*a))&3

def equations_audit(s,p):
    ring=R(s);w=ring.N-1
    masks=[ring.A]+[ring.J]*(s+1)
    off=[0]
    for block in masks:off.append(off[-1]+len(block))
    nv=off[-1]
    def constraint(terms):
        rows=[0]*(2*w)
        for known,block in terms:
            for j,mask in enumerate(masks[block]):
                image=ring.mul(known,1<<(2*mask))
                for target,c in ring.terms(image):
                    assert target
                    for ib in [0,1]:
                        v=M[c][1<<ib]
                        for ob in [0,1]:
                            if v&(1<<ob):rows[2*(target-1)+ob]^=1<<(2*(off[block]+j)+ib)
        return rows
    rows=[]
    for i,j in combinations(range(s),2):
        rows+=constraint([(ring.t[i],j+1),(ring.t[j],i+1)])
    for i in range(s):rows+=constraint([(ring.t[i],0),(ring.t[i],s+1),(p,i+1)])
    def encode(a,z,lam,zeta):
        hs=[ring.mul(t,z)^ring.scale(ring.taui[i],lam[i]) for i,t in enumerate(ring.t)]
        hv=a^ring.mul(p,z)^ring.scale(ring.tau,zeta)
        values=[a]+hs+[hv]
        return sum(ring.coef(value,mask)<<(2*(off[i]+j)) for i,(value,block) in enumerate(zip(values,masks)) for j,mask in enumerate(block))
    columns=[]
    for mask in ring.A:columns.append(encode(1<<(2*mask),0,[0]*s,0))
    for mask in range(ring.top):columns.append(encode(0,1<<(2*mask),[0]*s,0))
    for i in range(s):
        lam=[0]*s;lam[i]=1;columns.append(encode(0,0,lam,0))
    columns.append(encode(0,0,[0]*s,1))
    d=2**(s+1)+s-2
    assert len(columns)==d
    packed_low=sum(1<<(2*i) for i in range(nv))
    def omega(x):
        lo=x&packed_low;hi=(x>>1)&packed_low
        return hi|((lo^hi)<<1)
    binary_columns=columns+[omega(c) for c in columns]
    assert rank(binary_columns)==2*d
    assert all((row&col).bit_count()%2==0 for row in rows for col in binary_columns)
    measured=2*nv-rank(rows)
    assert measured==2*d
    return {'s':s,'binary_unknowns':2*nv,'constraint_rank':rank(rows),'kernel_dimension_over_F4':measured//2,
            'all_parameter_directions_independent_and_exhaustive':True}

class Model:
    def __init__(self,s,p):
        self.R=R(s);self.s=s;self.p=p;self.qbits=2*(s+1);self.n=2*(s+(1<<s))
    def unpack(self,x):return [(x>>(2*i))&3 for i in range(self.s)],(x>>(2*self.s))&3,(x>>self.qbits)<<2
    def pack(self,A,V,z):return sum(a<<(2*i) for i,a in enumerate(A))|(V<<(2*self.s))|((z>>2)<<self.qbits)
    def f(self,x):
        A,V,z=self.unpack(x);r=self.R
        a=X(r.scale(t,c) for t,c in zip(r.t,A))^r.scale(self.p,V)
        return self.pack([M[2][c] for c in A],M[2][V],r.scale(z,2)^r.mul(a,z^V))
    def restricted(self,x):
        A,V,z=self.unpack(x);r=self.R
        a=X(r.scale(t,c) for t,c in zip(r.t,A))^r.scale(self.p,V)
        return self.pack([0]*self.s,0,r.mul(a,z^V))
    def aux(self,x,par,lift=True):
        a,z,lam,zeta=par;A,V,w=self.unpack(x);r=self.R
        hi=[r.mul(t,z)^r.scale(r.taui[i],lam[i]) for i,t in enumerate(r.t)]
        hv=a^r.mul(self.p,z)^r.scale(r.tau,zeta)
        out=r.mul(1^a,w)^X(r.scale(h,c) for h,c in zip(hi,A))^r.scale(hv,V)
        if lift:out^=r.scale(r.tau,X(M[lam[i]][M[A[i]][A[i]]] for i in range(self.s)))
        return self.pack(A,V,out)
    def mulpar(self,left,right):
        a,z,lam,zeta=left;ap,zp,lamp,zetap=right;r=self.R
        correction=X(r.scale(r.taui[i],M[lamp[i]][r.coef(a,1<<i)]) for i in range(self.s))
        return (r.pr(a^ap^r.mul(a,ap)),r.pr(z^zp^r.mul(a,zp)^correction),
                [x^y for x,y in zip(lam,lamp)],zeta^zetap^r.coef(r.mul(a,ap),r.top))

def points2(n):
    yield 0
    for i in range(n):yield 1<<i
    for i,j in combinations(range(n),2):yield (1<<i)^(1<<j)

def random_par(r,rng):
    a=sum(rng.randrange(4)<<(2*i) for i in r.A)
    z=sum(rng.randrange(4)<<(2*i) for i in range(r.top))
    return a,z,[rng.randrange(4) for _ in range(r.s)],rng.randrange(4)

def main():
    out={'status':'PASS','scope':'Fresh finite adversarial controls; independent equations and actual transforms; no prior checker results imported; not Lean.'}
    rng=random.Random(20261101);linear=[];tests=[]
    for s in range(2,6):
        r=R(s)
        ps=[0]
        if s>=3:ps+=[1<<(2*3),2<<(2*3)]
        if s>=4:ps+=[(1<<(2*3))^(1<<(2*12))]
        for p in ps:linear.append(equations_audit(s,p))
    for s in [2,3,4]:
        r=R(s);p=X(rng.randrange(4)<<(2*i) for i in r.J if 2<=i.bit_count()<s)
        model=Model(s,p);basis=[1<<i for i in range(model.n)];points=list(points2(model.n))
        for _ in range(12):
            left=random_par(r,rng);right=random_par(r,rng);composed=model.mulpar(left,right)
            assert rank([model.aux(e,left) for e in basis])==model.n
            for e in basis:
                assert model.aux(model.aux(e,right),left)==model.aux(e,composed)
            for x in points:
                assert model.aux(model.f(x),left)==model.f(model.aux(x,left))
            a,z,lam,zeta=left
            for i in range(s):
                ei=1<<(2*i)
                D=model.restricted(model.aux(ei,left,False))^model.aux(model.restricted(ei),left,False)
                assert D==model.pack([0]*s,0,r.scale(r.tau,lam[i]))
                if lam[i]:assert model.aux(model.f(ei),left,False)!=model.f(model.aux(ei,left,False))
            v=1<<(2*s)
            assert model.restricted(model.aux(v,left,False))^model.aux(model.restricted(v),left,False)==0
            squared=model.mulpar(left,left);fourth=model.mulpar(squared,squared)
            assert all(model.aux(e,fourth)==e for e in basis)
            tests.append({'s':s,'weight_at_most_two_inputs':len(points),'unique_antiscalar_correction_checked':True,'group_law_on_full_binary_basis':True})
        par=(r.t[0],1,[0]*s,0)
        assert any(model.aux(model.aux(e,par),par)!=e for e in basis)
        assert all(model.aux(model.aux(model.aux(model.aux(e,par),par),par),par)==e for e in basis)
        theta=r.scale(r.tau,2);source=Model(s,p^theta)
        def shear(x):
            A,V,z=source.unpack(x)
            return source.pack(A,V,z^r.scale(theta,M[V][V]))
        for x in points:assert shear(source.f(x))==model.f(shear(x))
    out['ordinary_kernel_equation_controls']=linear
    out['binary_lift_and_group_law_controls']=tests
    out['targeted_boundaries']={'extra_lambda_directions':'necessary: omitting the forced antiscalar correction fails commutation when lambda_i != 0',
                               'kernel_exponent':'order-four witness checked for s2,3,4; all sampled fourth powers identity',
                               'socle_parameter_shear':'omega times top-coefficient differences checked for s2,3,4',
                               'degree_scope':'commutator residual is binary quadratic, so all weight<=2 points are lossless for each sampled linear transform'}
    path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':out['status'],'kernel_matrix_cases':len(linear),'actual_lift_cases':len(tests)},ensure_ascii=False))

if __name__=='__main__':main()

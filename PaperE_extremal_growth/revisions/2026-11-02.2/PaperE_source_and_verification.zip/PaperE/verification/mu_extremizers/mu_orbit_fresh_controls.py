"""Fresh bounded tests of the proposed ordinary mu-equality orbit action.

No other agent's program/data are imported. We test radical-pair actions,
the five d=4 symmetric-matrix strata, and the divided-Pfaffian character.
"""
from pathlib import Path
from itertools import combinations,product
from collections import deque
from functools import lru_cache
import random,json

P=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2)); INV=(0,1,3,2)
def xx(values):
    r=0
    for x in values:r^=x
    return r
def power(x,n):
    if not x:
        assert n>=0
        return int(n==0)
    n%=3;r=1
    for _ in range(n):r=P[r][x]
    return r
def eye(n):return [[int(i==j) for j in range(n)] for i in range(n)]
def transpose(a):return list(map(list,zip(*a)))
def matmul(a,b):return [[xx(P[x][y] for x,y in zip(row,col)) for col in zip(*b)] for row in a]
def matvec(a,v):return [xx(P[x][y] for x,y in zip(row,v)) for row in a]
def scale(a,c):return [[P[x][c] for x in row] for row in a]
def inverse(a):
    n=len(a);a=[r[:] for r in a];b=eye(n);det=1
    for j in range(n):
        k=next((k for k in range(j,n) if a[k][j]),None)
        assert k is not None
        a[j],a[k]=a[k],a[j];b[j],b[k]=b[k],b[j]
        pivot=a[j][j];det=P[det][pivot];z=INV[pivot]
        a[j]=[P[z][x] for x in a[j]];b[j]=[P[z][x] for x in b[j]]
        for i in range(n):
            if i==j or not a[i][j]:continue
            z=a[i][j];a[i]=[x^P[z][y] for x,y in zip(a[i],a[j])];b[i]=[x^P[z][y] for x,y in zip(b[i],b[j])]
    return b,det
def rank(a):
    a=[r[:] for r in a];m=len(a);n=len(a[0]);r=0
    for j in range(n):
        k=next((k for k in range(r,m) if a[k][j]),None)
        if k is None:continue
        a[r],a[k]=a[k],a[r];z=INV[a[r][j]];a[r]=[P[z][v] for v in a[r]]
        for i in range(m):
            if i!=r and a[i][j]:
                z=a[i][j];a[i]=[v^P[z][w] for v,w in zip(a[i],a[r])]
        r+=1
    return r
def code(v):return sum(x<<(2*i) for i,x in enumerate(v))
def uncode(x,n):return [(x>>(2*i))&3 for i in range(n)]
def linear(x,columns,n):
    out=0
    for i,c in enumerate(uncode(x,len(columns))):
        if c:out^=code([P[c][z] for z in uncode(columns[i],n)])
    return out
def affine_orbits(n,gens):
    remaining=set(range(4**n));orbs=[]
    while remaining:
        start=min(remaining);o={start};q=deque([start])
        while q:
            x=q.popleft()
            for cols,shift in gens:
                y=linear(x,cols,n)^shift
                if y not in o:o.add(y);q.append(y)
        assert o<=remaining
        remaining-=o;orbs.append(o)
    return orbs
def gl_generators(n):
    ans=[]
    for i in range(n):
        for j in range(n):
            if i==j:continue
            for c in [1,2]:
                a=eye(n);a[i][j]=c;ans.append(a)
        a=eye(n);a[i][i]=2;ans.append(a)
    return ans

def radical_pair(n,r):
    matrices=[(D,1) for D in gl_generators(n)]+[(eye(n),2)]
    gs=[]
    for D,rho in matrices:
        Di,det=inverse(D);L=transpose(Di)
        f=P[power(rho,2-r)][INV[det]];g=P[power(rho,-r)][INV[det]]
        cols=[]
        for j in range(2*n):
            v=[int(i==j%n) for i in range(n)]
            w=[P[f if j<n else g][z] for z in matvec(L,v)]
            cols.append(code(w+[0]*n if j<n else [0]*n+w))
        gs.append((cols,0))
    orbs=affine_orbits(2*n,gs)
    expect=4 if n==1 else 7 if n==2 and r%3==1 else 5
    assert len(orbs)==expect,(n,r,list(map(len,orbs)))
    if n==2 and r%3==1:
        for orb in orbs:
            deltas={xx([P[v[0]][v[3]],P[v[1]][v[2]]]) for v in map(lambda z:uncode(z,4),orb)}
            assert len(deltas)==1
    return {'radical_dimension':n,'r_mod3':r%3,'pair_orbits':len(orbs),'orbit_sizes':sorted(map(len,orbs))}

def D_of_S(S):
    a,b,c=[S[i][i] for i in range(3)]
    return [[0,c,b],[c,0,a],[b,a,0]]
def symmetric_action(S,M,a,w):
    Mi,det=inverse(M);L=transpose(Mi)
    f=P[P[a][a]][INV[det]]
    target=scale(matmul(matmul(M,S),transpose(M)),f)
    L2=[[P[x][x] for x in row] for row in L]
    linearpart=scale(L2,det)
    shift=matvec(linearpart,matvec(D_of_S(S),[P[x][x] for x in w]))
    cols=[code([linearpart[i][j] for i in range(3)]) for j in range(3)]
    return target,(cols,code(shift))
def symmetric_strata():
    counts={'zero':0,'alternating_rank2':0,'nonalternating_rank1':0,'nonalternating_rank2':0,'nonalternating_rank3':0}
    for z in range(4**6):
        a=uncode(z,6);S=[[a[0],a[3],a[4]],[a[3],a[1],a[5]],[a[4],a[5],a[2]]]
        r=rank(S)
        typ='zero' if not r else 'alternating_rank2' if not(a[0] or a[1] or a[2]) else f'nonalternating_rank{r}'
        counts[typ]+=1
    assert list(counts.values())==[1,63,63,945,3024]
    representatives={'zero':[[0]*3 for _ in range(3)],'alternating_rank2':[[0,1,0],[1,0,0],[0,0,0]]}
    for r in [1,2,3]:representatives[f'nonalternating_rank{r}']=[[int(i==j and i<r) for j in range(3)] for i in range(3)]
    records=[];mass=0
    for typ,S in representatives.items():
        pars=[]
        if typ=='zero':pars=[(M,1,[0]*3) for M in gl_generators(3)]
        elif typ=='alternating_rank2':
            for A in gl_generators(2):
                M=eye(3)
                for i in range(2):
                    for j in range(2):M[i][j]=A[i][j]
                pars.append((M,1,[0]*3))
            for i in [0,1]:
                for c in [1,2]:
                    M=eye(3);M[i][2]=c;pars.append((M,1,[0]*3))
            M=eye(3);M[2][2]=3;pars.append((M,2,[0]*3))
        else:
            for i in range(3):
                for c in [1,2]:
                    w=[0]*3;w[i]=c;pars.append((eye(3),1,w))
            pars.append(([[3*int(i==j) for j in range(3)] for i in range(3)],2,[0]*3))
        gens=[]
        for M,a,w in pars:
            target,g=symmetric_action(S,M,a,w);assert target==S
            gens.append(g)
        orbs=affine_orbits(3,gens);sizes=sorted(map(len,orbs))
        expected=[1,63] if typ=='zero' else [1,3,60] if typ=='alternating_rank2' else [16,48]
        assert sizes==expected,(typ,sizes)
        if typ.startswith('nonalternating'):
            u=[S[i][i] for i in range(3)]
            residue_sets=[{xx(P[u[i]][v[i]] for i in range(3)) for v in map(lambda z:uncode(z,3),orb)} for orb in orbs]
            assert {frozenset(x) for x in residue_sets}=={frozenset([0]),frozenset([1,2,3])}
        elif typ=='alternating_rank2':
            for orb in orbs:
                incidence={any(matvec(S,[P[c][c] for c in uncode(z,3)])) for z in orb}
                assert len(incidence)==1
        full=[counts[typ]*z for z in sizes];mass+=sum(full)
        records.append({'stratum':typ,'symmetric_matrices':counts[typ],'fixed_S_q_orbit_sizes':sizes,'full_orbit_sizes':full})
    assert mass==4**9
    return {'symmetric_matrices_scanned':4**6,'q_parameters_per_fixed_S':64,'total_orbits':sum(len(x['full_orbit_sizes']) for x in records),'strata':records,'mass':mass}

def pfaffian_I(b,kappa,ell):
    m=len(b);full=(1<<m)-1
    @lru_cache(None)
    def pf(mask):
        if not mask:return 1
        first=mask&-mask;i=first.bit_length()-1;rest=mask^first
        value=0
        for j in range(i+1,m):
            if rest&(1<<j):value^=P[b[i][j]][pf(rest^(1<<j))]
        return value
    return xx(P[P[kappa[i]][ell[j]]^P[kappa[j]][ell[i]]][pf(full^(1<<i)^(1<<j))] for i,j in combinations(range(m),2))
def random_GL(n,rng):
    A=eye(n)
    for _ in range(4*n):
        i,j=rng.sample(range(n),2);z=rng.randrange(1,4)
        A[i]=[x^P[z][y] for x,y in zip(A[i],A[j])]
        z=rng.randrange(1,4);A[i]=[P[z][x] for x in A[i]]
    return A
def pfaffian_tests():
    rng=random.Random(20261031);records=[]
    for r in [1,2,4]:
        m=2*r+2;changed=False
        b=[[0]*m for _ in range(m)]
        for i in range(r):b[2*i][2*i+1]=b[2*i+1][2*i]=1
        for j in range(12):
            A=random_GL(m,rng);a=rng.randrange(1,4)
            if r==2 and j==0:A=eye(m);a=2
            Ai,det=inverse(A);L=transpose(Ai)
            k=[0]*m;k[-2]=1;e=[0]*m;e[-1]=1+j%3
            w=[rng.randrange(4) for _ in range(m)]
            source=pfaffian_I(b,k,e)
            assert source==e[-1]!=0
            chi=P[a][P[det][det]]
            bp=scale(matmul(matmul(L,b),transpose(L)),chi)
            kp=[P[P[a][a]][x] for x in matvec(L,k)]
            ee=[x^y for x,y in zip(e,matvec(b,w))]
            ep=[P[P[det][det]][x] for x in matvec(L,ee)]
            target=pfaffian_I(bp,kp,ep)
            character=P[power(a,r+2)][power(det,2*r+1)]
            assert target==P[character][source]
            if r%3==1:assert target==source
            else:changed|=target!=source
        if r%3!=1:assert changed
        records.append({'r':r,'c':2*r+4,'random_full_parabolic_tests':12,'absolute_invariant':r%3==1,'relative_character_checked':True})
    return records

def main():
    report={'status':'PASS','scope':'Fresh bounded orbit controls, not imported from the module agent. Paper proofs handle all dimensions; no Lean claim.',
            'radical_pair_controls':[radical_pair(n,r) for n in [1,2,3] for r in [0,1,2]],
            'd4_symmetric_model_controls':symmetric_strata(),
            'divided_pfaffian_character_controls':pfaffian_tests()}
    path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()

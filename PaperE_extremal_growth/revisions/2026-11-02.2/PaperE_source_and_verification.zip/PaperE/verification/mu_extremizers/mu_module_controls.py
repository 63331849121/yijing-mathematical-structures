"""Small exact gate for unrestricted metabelian extremal modules.

Rebuilds the universal presentation in d=4 and independently checks the
ordinary Lie-cohomology complex for M=D(R/(tau_j)). No orbit enumeration.
"""
from pathlib import Path
from itertools import combinations
from math import comb
import random,json

HERE=Path(__file__).resolve().parent
rng=random.Random(20261030)
MUL=[[0,0,0,0],[0,1,2,3],[0,2,3,1],[0,3,1,2]]
INV=[0,1,3,2]

def rank2(vectors):
    piv={}
    for v in vectors:
        while v:
            i=v.bit_length()-1
            if i in piv:v^=piv[i]
            else:piv[i]=v;break
    return len(piv)

def rank4(vectors,ncols):
    even=sum(1<<(2*i) for i in range(ncols));odd=even<<1
    def times(c,v):
        if c==1:return v
        if c==0:return 0
        lo=v&even;hi=(v&odd)>>1;out=hi^((lo^hi)<<1)
        return out if c==2 else out^v
    piv={}
    for v in vectors:
        while v:
            i=((v&-v).bit_length()-1)//2;c=(v>>(2*i))&3
            if i in piv:v^=times(c,piv[i])
            else:piv[i]=times(INV[c],v);break
    return len(piv)

def pack_pair(v,n):
    a,b=v
    return sum((((a>>i)&1)|(((b>>i)&1)<<1))<<(2*i) for i in range(n))

class Universal:
    def __init__(self,d):
        self.d=d;self.edges=list(combinations(range(d),2))
        self.raw=[(m,e) for m in range(1<<d) for e in self.edges]
        ix={v:i for i,v in enumerate(self.raw)};self.piv={}
        for triple in combinations(range(d),3):
            for m in range(1<<d):
                v=0
                for i in triple:
                    if not(m&(1<<i)):
                        e=tuple(j for j in triple if j!=i)
                        v^=1<<ix[m|(1<<i),e]
                while v:
                    i=v.bit_length()-1
                    if i in self.piv:v^=self.piv[i]
                    else:self.piv[i]=v;break
        self.free=[i for i in range(len(self.raw)) if i not in self.piv]
        self.n=len(self.free);self.free_index={j:i for i,j in enumerate(self.free)}
        self.actions=[]
        for i in range(d):
            cols=[]
            for j in self.free:
                mask,e=self.raw[j]
                v=0 if mask&(1<<i) else self.reduce(1<<ix[mask|(1<<i),e])
                cols.append(sum(((v>>raw)&1)<<k for k,raw in enumerate(self.free)))
            self.actions.append(cols)
        assert self.n==(d-1)*(1<<d)+(d-1)*(d-2)//2
    def reduce(self,v):
        for i in sorted(self.piv,reverse=True):
            if (v>>i)&1:v^=self.piv[i]
        return v
    def dual_action(self,i,phi):
        lo,hi=phi
        return (sum(((lo&v).bit_count()&1)<<j for j,v in enumerate(self.actions[i])),
                sum(((hi&v).bit_count()&1)<<j for j,v in enumerate(self.actions[i])))
    def contract(self,mask,phi):
        for i in range(self.d):
            if mask&(1<<i):phi=self.dual_action(i,phi)
        return phi

u=Universal(4);d=4;top=(1<<d)-1;j=0;zmask=top^(1<<j)
top_indices=[];lower=[]
for k,raw in enumerate(u.free):
    mask,edge=u.raw[raw]
    if mask.bit_count()==d-1:top_indices.append(k)
    else:lower.append(k)
target=tuple(2 if i==j else 1 for i in range(d))
lam_indices=[k for k in top_indices if tuple(((u.raw[u.free[k]][0]>>i)&1)+(i in u.raw[u.free[k]][1]) for i in range(d))==target]
assert len(lam_indices)==1
lam=(1<<lam_indices[0],0)
phis=[lam]
for k in lower:
    for c in [1,2,3]:phis.append((lam[0]^((c&1)<<k),lam[1]^(((c>>1)&1)<<k)))
for _ in range(20):
    lo,hi=lam
    for k in lower:
        c=rng.randrange(4);lo^=(c&1)<<k;hi^=((c>>1)&1)<<k
    phis.append((lo,hi))
for phi in phis:
    cons=[u.contract(S,phi) for S in range(1<<d)]
    assert cons[zmask]==(0,0) and cons[top]==(0,0)
    assert rank4([pack_pair(v,u.n) for v in cons],u.n)==(1<<d)-2

def kernel_columns(columns):
    piv={};ker=[]
    for j,col in enumerate(columns):
        v=col;rel=1<<j
        while v:
            i=v.bit_length()-1
            if i in piv:
                w,r=piv[i];v^=w;rel^=r
            else:piv[i]=(v,rel);break
        if not v:ker.append(rel)
    return ker

cohom=[]
for d in [4,5]:
    top=(1<<d)-1;j=0;zmask=top^(1<<j)
    qb=[m for m in range(1<<d) if m not in [zmask,top]];ix={m:i for i,m in enumerate(qb)};w=len(qb)
    P=[]
    for i in range(d):
        P.append([1<<ix[m^(1<<i)] if m&(1<<i) and (m^(1<<i)) in ix else 0 for m in qb])
    pairs=list(combinations(range(d),2));triples=list(combinations(range(d),3));pairix={e:i for i,e in enumerate(pairs)}
    delta0=[sum(P[i][m]<<(w*i) for i in range(d)) for m in range(w)]
    delta1=[]
    for i in range(d):
        for m in range(w):
            col=0
            for e,idx in pairix.items():
                if i in e:
                    k=e[0] if e[1]==i else e[1];col^=P[k][m]<<(w*idx)
            delta1.append(col)
    delta2=[]
    for e in pairs:
        for m in range(w):
            col=0
            for idx,tr in enumerate(triples):
                if set(e)<=set(tr):
                    k=next(i for i in tr if i not in e);col^=P[k][m]<<(w*idx)
            delta2.append(col)
    r0,r1,r2=rank2(delta0),rank2(delta1),rank2(delta2)
    h1=d*w-r1-r0;h2=comb(d,2)*w-r2-r1
    assert h1==d+1 and h2==comb(d,2)+d
    for col in delta1:
        out=0
        while col:
            low=col&-col;out^=delta2[low.bit_length()-1];col^=low
        assert out==0
    ker=kernel_columns(delta2)
    eta_edge=pairix[(0,1)];eta_mask=top^(1<<1)
    eta_bit=eta_edge*w+ix[eta_mask]
    assert any((c>>eta_bit)&1 for c in ker)
    top_monomials=[top^(1<<i) for i in range(1,d)]
    for c in ker:
        eta=(c>>eta_bit)&1
        for e,idx in pairix.items():
            for i,mask in enumerate(top_monomials,start=1):
                actual=(c>>(idx*w+ix[mask]))&1
                expected=eta if e==(0,i) else 0
                assert actual==expected,(d,e,i)
    assert all(not((c>>eta_bit)&1) for c in delta1)
    cohom.append({'d':d,'module_dimension':w,'ordinary_CE_ranks':[r0,r1,r2],
        'H1_dimension':h1,'H2_dimension':h2,'Z2_dimension':len(ker),
        'terminal_eta_nonzero_on_H2':True,'all_Z2_basis_have_star_top_pattern':True,
        'normalized_eta_slice_dimension':h2-1})

out={'status':'PASS','universal_d4':{'dimension':u.n,'top_dimension':len(top_indices),
    'lower_dimension':len(lower),'perturbations_checked':len(phis),'all_minimal_contraction_rank':14,
    'all_annihilated_by_two_dimensional_top_ideal':True},'ordinary_cohomology':cohom,
    'scope':'Finite controls corroborate the separate general module and Koszul arguments; no parameter orbit enumeration.'}
(HERE/'mu_module_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))

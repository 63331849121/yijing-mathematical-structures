"""Exact F4 controls for the true ordinary-CE parabolic action.

This is independent finite verification, not the proof of the general formulas.
The source module is the augmentation ideal in the last d-1 variables.
"""
from pathlib import Path
from itertools import combinations
from math import comb
import random, json
from collections import deque

HERE=Path(__file__).resolve().parent
MUL=[[0,0,0,0],[0,1,2,3],[0,2,3,1],[0,3,1,2]]
INV=[0,1,3,2]
rng=random.Random(2026103031)

def vmul(c,v):
    if not c:return [0]*len(v)
    return [MUL[c][x] for x in v]
def mmul(A,B):
    C=[[0]*len(B[0]) for _ in A]
    for i in range(len(A)):
        for k in range(len(B)):
            for j in range(len(B[0])):C[i][j]^=MUL[A[i][k]][B[k][j]]
    return C
def transpose(A):return [list(x) for x in zip(*A)]
def identity(n):return [[int(i==j) for j in range(n)] for i in range(n)]
def inverse(A):
    n=len(A);B=[row[:]+e for row,e in zip(A,identity(n))]
    for j in range(n):
        k=next((k for k in range(j,n) if B[k][j]),None)
        if k is None:raise ValueError('singular')
        B[j],B[k]=B[k],B[j];B[j]=vmul(INV[B[j][j]],B[j])
        for k in range(n):
            if k!=j and B[k][j]:
                C=vmul(B[k][j],B[j]);B[k]=[x^y for x,y in zip(B[k],C)]
    return [row[n:] for row in B]
def det(A):
    A=[row[:] for row in A];out=1
    for j in range(len(A)):
        k=next((k for k in range(j,len(A)) if A[k][j]),None)
        if k is None:return 0
        A[j],A[k]=A[k],A[j];out=MUL[out][A[j][j]]
        A[j]=vmul(INV[A[j][j]],A[j])
        for k in range(j+1,len(A)):
            C=vmul(A[k][j],A[j]);A[k]=[x^y for x,y in zip(A[k],C)]
    return out
def exterior2(A):
    edges=list(combinations(range(len(A)),2))
    return [[MUL[A[i][k]][A[j][l]]^MUL[A[i][l]][A[j][k]] for k,l in edges] for i,j in edges]
def mv(A,v):return [sum4(MUL[x][y] for x,y in zip(row,v)) for row in A]
def sum4(xs):
    a=0
    for x in xs:a^=x
    return a
def random_gl(n):
    while True:
        A=[[rng.randrange(4) for _ in range(n)] for _ in range(n)]
        if det(A):return A
def random_parabolic(d):
    M=random_gl(d-1);a=rng.randrange(1,4);v=[rng.randrange(4) for _ in range(d-1)]
    return [[a]+[0]*(d-1)]+[[v[i]]+M[i] for i in range(d-1)]

class CE:
    def __init__(self,d):
        self.d=d;self.top=(1<<d)-1;self.edges=list(combinations(range(d),2));self.eix={e:i for i,e in enumerate(self.edges)}
        self.mons=[S for S in range(1<<d) if S&~1];self.ix={S:i for i,S in enumerate(self.mons)}
        self.w=len(self.mons);self.n=self.w*len(self.edges);self.even=sum(1<<(2*i) for i in range(self.n));self.piv={}
        self.boundaries=[]
        for i in range(d):
            for S in self.mons:
                col=0
                for e,k in self.eix.items():
                    if i in e:
                        j=e[0] if e[1]==i else e[1]
                        if not(S&(1<<j)):col^=1<<(2*(self.w*k+self.ix[S|(1<<j)]))
                self.boundaries.append(col)
                self.add(col,0)
        self.boundary_rank=len(self.piv)
        eta=0
        for i in range(1,d):eta^=self.term((0,i),1<<i)
        self.reps=[eta]
        for h in range(1,d):
            col=0
            for i,j in self.edges:
                if i and i==h:col^=self.term((i,j),(1<<0)|(1<<j))
                if i and j==h:col^=self.term((i,j),(1<<0)|(1<<i))
            self.reps.append(col)
        for i,j in self.edges:self.reps.append(self.term((i,j),self.top^(1<<i)^(1<<j)))
        self.hdim=len(self.reps)
        for j,col in enumerate(self.reps):
            old=len(self.piv);self.add(col,1<<(2*j));assert len(self.piv)==old+1
        assert len(self.piv)==self.boundary_rank+comb(d,2)+d
    def scalar(self,c,v):
        if c==0:return 0
        if c==1:return v
        lo=v&self.even;hi=(v>>1)&self.even;v2=hi^((lo^hi)<<1)
        return v2 if c==2 else v2^v
    def add(self,v,label):
        while v:
            p=((v&-v).bit_length()-1)//2;c=(v>>(2*p))&3
            if p in self.piv:
                r,z=self.piv[p];v^=self.scalar(c,r);label^=self.scalar(c,z)
            else:
                self.piv[p]=(self.scalar(INV[c],v),self.scalar(INV[c],label));return
        assert label==0
    def project(self,v):
        label=0
        while v:
            p=((v&-v).bit_length()-1)//2;c=(v>>(2*p))&3
            assert p in self.piv,('not represented',self.d,p)
            r,z=self.piv[p];v^=self.scalar(c,r);label^=self.scalar(c,z)
        return [(label>>(2*i))&3 for i in range(self.hdim)]
    def term(self,e,S,c=1):return c<<(2*(self.w*self.eix[e]+self.ix[S]))
    def combine(self,pars):
        out=0
        for c,v in zip(pars,self.reps):out^=self.scalar(c,v)
        return out
    def sigma(self,B):
        ans=[]
        for S in self.mons:
            p={0:1}
            for j in range(self.d):
                if S&(1<<j):
                    q={}
                    for T,c in p.items():
                        for i in range(self.d):
                            if B[i][j] and not(T&(1<<i)):
                                U=T|(1<<i);q[U]=q.get(U,0)^MUL[c][B[i][j]]
                    p={T:c for T,c in q.items() if c}
            assert all(T in self.ix for T in p)
            ans.append(p)
        return ans
    def action(self,B,cochain):
        Bi=inverse(B);Q=exterior2(Bi);sig=self.sigma(B);out=0;a=B[0][0]
        for olde in range(len(self.edges)):
            for oldm in range(self.w):
                c=(cochain>>(2*(olde*self.w+oldm)))&3
                if c:
                    for newe in range(len(self.edges)):
                        q=Q[olde][newe]
                        if q:
                            for S,s in sig[oldm].items():
                                z=MUL[a][MUL[c][MUL[q][s]]]
                                out^=z<<(2*(newe*self.w+self.ix[S]))
        return out
    def predicted(self,B,pars):
        a=B[0][0];M=[row[1:] for row in B[1:]]
        kappa=mv(transpose(inverse(M)),pars[1:self.d]);kappa=vmul(MUL[a][a],kappa)
        C=exterior2(transpose(inverse(B)));C=[[MUL[x][x] for x in row] for row in C]
        lam=vmul(MUL[a][det(B)],mv(C,pars[self.d:]))
        return [pars[0]]+kappa+lam

summary=[]
for d in [4,5,6]:
    ce=CE(d);tests=0
    if d>=5:
        for k in range(45):
            B=random_parabolic(d);pars=[rng.randrange(4) for _ in range(ce.hdim)]
            actual=ce.project(ce.action(B,ce.combine(pars)));pred=ce.predicted(B,pars)
            assert actual==pred,(d,k,B,actual,pred)
            tests+=1
    summary.append({'d':d,'H2_basis_size':ce.hdim,'boundary_rank':ce.boundary_rank,'random_full_action_checks':tests})

ce=CE(4);B=identity(4);B[2][1]=1
pars=[0]*ce.hdim;pars[4+ce.eix[(2,3)]]=1
actual=ce.project(ce.action(B,ce.combine(pars)))
assert actual[3]==1 and actual[4+ce.eix[(1,3)]]==1 and actual[4+ce.eix[(2,3)]]==1
collision={'B':B,'lambda23_image_coordinates_eta_kappa_lambda':actual,'extra_kappa3':True}

def d4_to_Sq(pars):
    S=[[0]*3 for _ in range(3)]
    S[0][0]=pars[4+ce.eix[(2,3)]];S[1][1]=pars[4+ce.eix[(1,3)]];S[2][2]=pars[4+ce.eix[(1,2)]]
    S[1][2]=S[2][1]=pars[1];S[0][2]=S[2][0]=pars[2];S[0][1]=S[1][0]=pars[3]
    q=[pars[4+ce.eix[(0,i)]] for i in range(1,4)]
    return S,q
def d4_from_Sq(S,q,eta):
    pars=[eta,S[1][2],S[0][2],S[0][1]]+[0]*6
    pars[4+ce.eix[(2,3)]]=S[0][0];pars[4+ce.eix[(1,3)]]=S[1][1];pars[4+ce.eix[(1,2)]]=S[2][2]
    for i in range(1,4):pars[4+ce.eix[(0,i)]]=q[i-1]
    return pars
d4_matrix_tests=0
for _ in range(100):
    B=random_parabolic(4);a=B[0][0];M=[r[1:] for r in B[1:]];v=[r[0] for r in B[1:]]
    pars=[rng.randrange(4) for _ in range(ce.hdim)];S,q=d4_to_Sq(pars)
    w=mv(inverse(M),v);w2=[MUL[x][x] for x in w]
    T=[[0,S[2][2],S[1][1]],[S[2][2],0,S[0][0]],[S[1][1],S[0][0],0]]
    q0=[x^y for x,y in zip(q,mv(T,w2))]
    Mi2=[[MUL[x][x] for x in row] for row in transpose(inverse(M))]
    qp=vmul(det(M),mv(Mi2,q0))
    Sp=mmul(mmul(M,S),transpose(M));sc=MUL[MUL[a][a]][INV[det(M)]]
    Sp=[vmul(sc,row) for row in Sp]
    pred=d4_from_Sq(Sp,qp,pars[0]);actual=ce.project(ce.action(B,ce.combine(pars)))
    assert actual==pred,(B,pars,actual,pred)
    d4_matrix_tests+=1

# Full exact d=4 orbit control: 4^9 = 262144 normalized H2 parameters.
# These generators generate the entire parabolic over F4, not only its prime subfield.
gens=[]
B=identity(4);B[0][0]=2;gens.append(B)
B=identity(4);B[1][1]=2;gens.append(B)
for i in range(1,4):
    for j in range(1,4):
        if i!=j:
            B=identity(4);B[i][j]=1;gens.append(B)
B=identity(4);B[1][0]=1;gens.append(B)
tables=[]
for B in gens:
    tab=[]
    for j in range(9):
        pars=[0]*10;pars[1+j]=1
        actual=ce.project(ce.action(B,ce.combine(pars)))[1:]
        tab.append([sum(MUL[c][x]<<(2*i) for i,x in enumerate(actual)) for c in range(4)])
    tables.append(tab)
seen=bytearray(4**9);orbit_rows=[]
for seed in range(4**9):
    if seen[seed]:continue
    seen[seed]=1;q=deque([seed]);count=0
    while q:
        x=q.popleft();count+=1
        digits=[(x>>(2*i))&3 for i in range(9)]
        for tab in tables:
            y=0
            for i,c in enumerate(digits):y^=tab[i][c]
            if not seen[y]:seen[y]=1;q.append(y)
    pars=[1]+[(seed>>(2*i))&3 for i in range(9)];S,q=d4_to_Sq(pars)
    # A tiny independent matrix rank calculation, including singular matrices.
    A=[row[:] for row in S];rank=0
    for j in range(3):
        k=next((k for k in range(rank,3) if A[k][j]),None)
        if k is None:continue
        A[rank],A[k]=A[k],A[rank];A[rank]=vmul(INV[A[rank][j]],A[rank])
        for k in range(3):
            if k!=rank:
                row=vmul(A[k][j],A[rank]);A[k]=[x^y for x,y in zip(A[k],row)]
        rank+=1
    if not rank:label='S=0;q='+('nonzero' if any(q) else 'zero')
    elif not any(S[i][i] for i in range(3)):
        sq=mv(S,[MUL[x][x] for x in q])
        label='S=alternating-rank2;q='+('outside-kernel' if any(sq) else ('nonzero-kernel' if any(q) else 'zero'))
    else:
        resid=sum4(MUL[S[i][i]][q[i]] for i in range(3))
        label=f'S=nonalternating-rank{rank};residue='+('nonzero' if resid else 'zero')
    orbit_rows.append({'label':label,'size':count,'representative':pars[1:]})
assert len(orbit_rows)==11 and len({row['label'] for row in orbit_rows})==11
assert sum(row['size'] for row in orbit_rows)==4**9

# Uniform classification's only delicate part is the weighted GL_z action on
# two radical covectors. Check all radical pairs in small z, including each
# residue of r modulo3 and the exceptional z=2 determinant strata.
radical_controls=[]
for r,z in [(0,4),(1,1),(2,1),(1,2),(2,2),(3,2),(4,2),(1,3),(2,3)]:
    dg=[]
    D=identity(z);D[0][0]=2;dg.append((1,D))
    for i in range(z):
        for j in range(z):
            if i!=j:
                D=identity(z);D[i][j]=1;dg.append((1,D))
    dg.append((2,identity(z)))
    lt=[]
    for rho,D in dg:
        e=det(D);Dit=transpose(inverse(D))
        def power(a,n):
            out=1
            for _ in range(n%3):out=MUL[out][a]
            return out
        t=MUL[power(rho,2-r)][INV[e]];u=MUL[power(rho,-r)][INV[e]]
        T=[[0]*(2*z) for _ in range(2*z)]
        for i in range(z):
            for j in range(z):T[i][j]=MUL[t][Dit[i][j]];T[z+i][z+j]=MUL[u][Dit[i][j]]
        tab=[]
        for j in range(2*z):tab.append([sum(MUL[c][T[i][j]]<<(2*i) for i in range(2*z)) for c in range(4)])
        lt.append(tab)
    vis=bytearray(4**(2*z));nr=0
    for seed in range(len(vis)):
        if vis[seed]:continue
        nr+=1;vis[seed]=1;q=deque([seed])
        while q:
            x=q.popleft();digits=[(x>>(2*i))&3 for i in range(2*z)]
            for tab in lt:
                y=0
                for i,c in enumerate(digits):y^=tab[i][c]
                if not vis[y]:vis[y]=1;q.append(y)
    expected=4 if z==1 else (7 if z==2 and r%3==1 else 5)
    assert nr==expected,(r,z,nr,expected)
    radical_controls.append({'r':r,'radical_dimension':z,'all_parameter_count':len(vis),'orbits':nr})

# In d=5 the rank-two stratum has a scalar invariant absent from rank/incidence.
# Omega=Frob(lambda) is read as (ell,b). I=kappa wedge ell wedge b in H dimension4.
ce=CE(5)
def wedge_invariant(pars):
    k=pars[1:5];lam=pars[5:];om=[MUL[x][x] for x in lam];o={e:c for e,c in zip(ce.edges,om)}
    ell=[o[(0,i)] for i in range(1,5)];ans=0
    for i,j in combinations(range(4),2):
        left=[x for x in range(4) if x not in (i,j)];u,v=left
        ans^=MUL[MUL[k[i]][ell[j]]^MUL[k[j]][ell[i]]][o[(u+1,v+1)]]
    return ans
invariant_tests=0
for _ in range(75):
    B=random_parabolic(5);pars=[rng.randrange(4) for _ in range(ce.hdim)];pars[0]=1
    for e in ce.edges:
        if e[0]:pars[5+ce.eix[e]]=int(e==(1,2))
    actual=ce.project(ce.action(B,ce.combine(pars)))
    assert wedge_invariant(actual)==wedge_invariant(pars)
    invariant_tests+=1
examples=[]
for c in [1,2,3]:
    pars=[0]*ce.hdim;pars[0]=1;pars[1+2]=1 # kappa=e3*
    pars[5+ce.eix[(0,4)]]=MUL[c][c] # ell=c e4*
    pars[5+ce.eix[(1,2)]]=1 # b=e1* wedge e2*
    assert wedge_invariant(pars)==c
    examples.append({'invariant':c,'normalized_parameters':pars})

out={'status':'PASS','ordinary_CE_action_checks':summary,'d4_natural_section_collision':collision,
    'd4_symmetric_matrix_covector_full_action_checks':d4_matrix_tests,
    'd4_complete_normalized_parameter_orbits':orbit_rows,
    'weighted_radical_pair_complete_orbit_controls':radical_controls,
    'd5_absolute_scalar_invariant_checks':invariant_tests,'three_identical_rank_incidence_examples':examples,
    'scope':'Exact finite controls for proofs supplied separately. No full orbit classification is inferred from sampling.'}
(HERE/'parabolic_action_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))

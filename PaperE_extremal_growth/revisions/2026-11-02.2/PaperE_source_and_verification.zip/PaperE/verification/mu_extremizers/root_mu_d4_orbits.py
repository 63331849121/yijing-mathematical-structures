"""Full d=4 orbit replay from independently rebuilt CE generator matrices."""
from pathlib import Path
import json,time
from root_mu_action_controls import CE,generators,MUL

HERE=Path(__file__).resolve().parent
started=time.monotonic();ce=CE(4);pc=ce.p
maps=[]
for name,B in generators(4):
    cols=[ce.coords(ce.transform(b,B)) for b in ce.basis]
    assert cols[0]==[1]+[0]*9
    packed=[sum(x<<(2*j) for j,x in enumerate(c[1:])) for c in cols[1:]]
    tables=[]
    for off in [0,3,6]:
        table=[]
        for bits in range(64):
            value=0
            for j in range(3):value^=pc.scale((bits>>(2*j))&3,packed[off+j])
            table.append(value)
        tables.append(table)
    maps.append((name,tables))

def rank(A):
    A=[row[:] for row in A];r=0
    for col in range(len(A[0])):
        j=next((j for j in range(r,len(A)) if A[j][col]),None)
        if j is None:continue
        A[r],A[j]=A[j],A[r];inv=[0,1,3,2][A[r][col]]
        A[r]=[MUL[inv][x] for x in A[r]]
        for j in range(len(A)):
            if j!=r:
                c=A[j][col];A[j]=[x^MUL[c][y] for x,y in zip(A[j],A[r])]
        r+=1
    return r

def kind(x):
    k1,k2,k3,l01,l02,l03,l12,l13,l23=[(x>>(2*i))&3 for i in range(9)]
    S=[[l23,k3,k2],[k3,l13,k1],[k2,k1,l12]];q=[l01,l02,l03]
    r=rank(S)
    if r==0:return ('zero',int(any(q)))
    if not any(S[i][i] for i in range(3)):
        qsq=[MUL[t][t] for t in q];v=[]
        for row in S:
            z=0
            for a,b in zip(row,qsq):z^=MUL[a][b]
            v.append(z)
        return ('alternating',0 if not any(q) else (2 if any(v) else 1))
    residue=0
    for i in range(3):residue^=MUL[S[i][i]][q[i]]
    return ('nonalternating',r,int(bool(residue)))

seen=bytearray(1<<18);orbits=[]
for seed in range(1<<18):
    if seen[seed]:continue
    queue=[seed];seen[seed]=1
    for value in queue:
        for name,(t0,t1,t2) in maps:
            target=t0[value&63]^t1[(value>>6)&63]^t2[(value>>12)&63]
            if not seen[target]:seen[target]=1;queue.append(target)
    orbits.append({'seed':seed,'classification':kind(seed),'size':len(queue)})
assert len(orbits)==11
assert len({tuple(o['classification']) for o in orbits})==11
assert sum(o['size'] for o in orbits)==4**9
out={'status':'PASS','method':'All 4^9 normalized cohomology parameters;16 full-parabolic generators obtained from independent actual CE action',
    'generator_count':len(maps),'orbits':orbits,'mass':sum(o['size'] for o in orbits),
    'elapsed_seconds':round(time.monotonic()-started,3)}
(HERE/'root_mu_d4_orbits.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False))

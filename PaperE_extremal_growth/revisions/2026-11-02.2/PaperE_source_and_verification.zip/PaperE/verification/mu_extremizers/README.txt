Authorship correction 2026-11-03: Baohua Li is the sole author of every Paper E version.
Controls for the metabelian equality classification
=================================================
Run the six Python programs listed in Appendix A.5 from this directory.
Python 3 standard library suffices. root_mu_d4_orbits.py imports the local
root_mu_action_controls.py; keep both files together.

Uniform module, CE, weighted orbit and Pfaffian proofs are in Appendix C.
Finite controls corroborate the actual action and endpoints. The d=4
262144-point orbit partition is exhaustive, not a sample. The general
all-class formula is proved by rank and radical-pair transitivity.
Random group-action controls do not replace those written proofs.
No proof-assistant formalization is claimed.

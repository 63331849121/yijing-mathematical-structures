"""Independent ordinary CE action controls for the metabelian minimum.

Uses the ideal K=(t1,...,t_{d-1}) in the square-zero ring, never imports
the agent's module controls. Computes actual cochains and legal boundaries.
"""
from pathlib import Path
from itertools import combinations
import json,random,time

HERE=Path(__file__).resolve().parent
MUL=[[0,0,0,0],[0,1,2,3],[0,2,3,1],[0,3,1,2]]
INV=[0,1,3,2]

def dot(a,b):
    z=0
    for x,y in zip(a,b):z^=MUL[x][y]
    return z

def inverse(A):
    n=len(A);m=[list(A[i])+[int(i==j) for j in range(n)] for i in range(n)]
    for i in range(n):
        j=next(j for j in range(i,n) if m[j][i]);m[i],m[j]=m[j],m[i]
        a=INV[m[i][i]];m[i]=[MUL[a][x] for x in m[i]]
        for j in range(n):
            if j!=i and m[j][i]:
                c=m[j][i];m[j]=[x^MUL[c][y] for x,y in zip(m[j],m[i])]
    return [r[n:] for r in m]

class Packed:
    def __init__(self,n):
        self.n=n;self.even=sum(1<<(2*i) for i in range(n))
    def scale(self,c,v):
        if c==0:return 0
        if c==1:return v
        lo=v&self.even;hi=(v>>1)&self.even
        w=hi^((lo^hi)<<1)
        return w if c==2 else w^v
    def entries(self,v):
        while v:
            low=v&-v;i=(low.bit_length()-1)//2;c=(v>>(2*i))&3
            yield i,c;v^=c<<(2*i)

class CE:
    def __init__(self,d):
        self.d=d;self.n=1<<d;self.top=self.n-1
        self.km=[m for m in range(self.n) if m not in (0,1)]
        self.pairs=list(combinations(range(d),2));self.pi={e:i for i,e in enumerate(self.pairs)}
        self.p=Packed(len(self.pairs)*self.n);self.r=Packed(self.n)
        self.piv={};self.boundary_rank=0
        for i in range(d):
            for mask in self.km:
                v=0
                for e,idx in self.pi.items():
                    if i in e:
                        other=e[1] if e[0]==i else e[0]
                        if not(mask&(1<<other)):v^=1<<(2*(idx*self.n+(mask|(1<<other))))
                if self.insert(v,0):self.boundary_rank+=1
        self.basis=[];self.names=['eta']+[f'kappa{i}' for i in range(1,d)]+[f'lambda{i}{j}' for i,j in self.pairs]
        base=0
        for i in range(1,d):base^=1<<(2*(self.pi[0,i]*self.n+(1<<i)))
        self.basis.append(base)
        for i in range(1,d):
            c=0
            for j in range(1,d):
                if j==i:continue
                e=tuple(sorted((i,j)));mask=1|(1<<j)
                c^=1<<(2*(self.pi[e]*self.n+mask))
            self.basis.append(c)
        for i,j in self.pairs:
            c=1<<(2*(self.pi[i,j]*self.n+(self.top^(1<<i)^(1<<j))))
            self.basis.append(c)
        assert len(self.basis)==d+d*(d-1)//2
        for i,b in enumerate(self.basis):
            assert self.closed(b)
            assert self.insert(b,1<<(2*i)),(d,self.names[i])

    def insert(self,v,coord):
        while v:
            idx=((v&-v).bit_length()-1)//2;c=(v>>(2*idx))&3
            if idx in self.piv:
                row,payload=self.piv[idx]
                v^=self.p.scale(c,row)
                coord^=self.p.scale(c,payload)
            else:
                self.piv[idx]=(self.p.scale(INV[c],v),self.p.scale(INV[c],coord));return True
        return False

    def coords(self,v):
        coord=0
        while v:
            idx=((v&-v).bit_length()-1)//2;c=(v>>(2*idx))&3
            assert idx in self.piv,(self.d,idx)
            row,payload=self.piv[idx];v^=self.p.scale(c,row);coord^=self.p.scale(c,payload)
        return [(coord>>(2*i))&3 for i in range(len(self.basis))]

    def action_t(self,i,v):
        out=0
        for mask,c in self.r.entries(v):
            if not(mask&(1<<i)):out^=c<<(2*(mask|(1<<i)))
        return out

    def closed(self,beta):
        for tr in combinations(range(self.d),3):
            v=0
            for i in tr:
                e=tuple(j for j in tr if j!=i);idx=self.pi[e]
                coeff=(beta>>(2*self.n*idx))&((1<<(2*self.n))-1)
                v^=self.action_t(i,coeff)
            if v:return False
        return True

    def ring_mul(self,u,v):
        out=0
        for i,a in self.r.entries(u):
            for j,b in self.r.entries(v):
                if not(i&j):out^=MUL[a][b]<<(2*(i|j))
        return out

    def substitution(self,B):
        images=[sum(B[j][i]<<(2*(1<<j)) for j in range(self.d)) for i in range(self.d)]
        result=[1]
        for mask in range(1,self.n):
            low=mask&-mask;i=low.bit_length()-1
            result.append(self.ring_mul(result[mask^low],images[i]))
        return result

    def transform(self,beta,B):
        assert all(B[0][i]==0 for i in range(1,self.d)) and B[0][0]
        inv=inverse(B);a=B[0][0];sigma=self.substitution(B)
        vals=[];maskring=(1<<(2*self.n))-1
        for e in self.pairs:
            coeff=(beta>>(2*self.n*self.pi[e]))&maskring;v=0
            for mask,c in self.r.entries(coeff):v^=self.r.scale(c,sigma[mask])
            vals.append(v)
        result=0
        for i,j in self.pairs:
            coeff=0
            for (r,s),v in zip(self.pairs,vals):
                c=MUL[inv[r][i]][inv[s][j]]^MUL[inv[s][i]][inv[r][j]]
                coeff^=self.r.scale(MUL[a][c],v)
            result^=coeff<<(2*self.n*self.pi[i,j])
        assert self.closed(result)
        return result

def generators(d):
    for i in range(1,d):
        for j in range(i+1,d):
            B=[[int(k==l) for l in range(d)] for k in range(d)]
            B[i],B[j]=B[j],B[i];yield f'swap{i}{j}',B
    for i in range(1,d):
        for j in range(1,d):
            if i==j:continue
            B=[[int(k==l) for l in range(d)] for k in range(d)];B[j][i]=1
            yield f'transvection{i}to{j}',B
    for i in range(d):
        B=[[int(k==l) for l in range(d)] for k in range(d)];B[i][i]=2
        yield f'scale{i}',B
    for i in range(1,d):
        B=[[int(k==l) for l in range(d)] for k in range(d)];B[i][0]=1
        yield f'shear0to{i}',B

def determinant(A):
    n=len(A);A=[r[:] for r in A];det=1
    for i in range(n):
        j=next(j for j in range(i,n) if A[j][i]);A[i],A[j]=A[j],A[i]
        p=A[i][i];det=MUL[det][p];u=INV[p]
        A[i]=[MUL[u][v] for v in A[i]]
        for j in range(i+1,n):
            c=A[j][i];A[j]=[x^MUL[c][y] for x,y in zip(A[j],A[i])]
    return det

def predicted(co,B,d):
    m=d-1;inv=inverse(B);a=B[0][0]
    out=[co[0]]
    for i in range(1,d):out.append(MUL[MUL[a][a]][dot([inv[j][i] for j in range(1,d)],co[1:d])])
    pairs=list(combinations(range(d),2));factor=MUL[a][determinant(B)]
    for i,j in pairs:
        value=0
        for (r,s),lam in zip(pairs,co[d:]):
            minor=MUL[inv[r][i]][inv[s][j]]^MUL[inv[s][i]][inv[r][j]]
            value^=MUL[MUL[minor][minor]][lam]
        out.append(MUL[factor][value])
    return out

def run():
    started=time.monotonic();report={'status':'PASS','scope':'Exact ordinary CE action matrices on a verified cohomology basis; no orbit enumeration.','dimensions':[]}
    for d in [4,5]:
        ce=CE(d);records=[];mix=[]
        for name,B in generators(d):
            columns=[ce.coords(ce.transform(b,B)) for b in ce.basis]
            assert all(c[0]==int(i==0) for i,c in enumerate(columns))
            if d>=5:
                for i,col in enumerate(columns):
                    unit=[int(i==j) for j in range(len(ce.basis))]
                    assert col==predicted(unit,B,d),(d,name,ce.names[i],col,predicted(unit,B,d))
            else:
                for i,col in enumerate(columns):
                    if i>=d and any(col[1:d]):mix.append({'generator':name,'input':ce.names[i],'image':{n:x for n,x in zip(ce.names,col) if x}})
            records.append({'name':name,'B':B,'cohomology_columns':columns})
        report['dimensions'].append({'d':d,'module_dimension':(1<<d)-2,'H2_dimension':len(ce.basis),
            'boundary_rank':ce.boundary_rank,'basis_names':ce.names,'generators':records,
            'nonsplit_lambda_to_kappa_examples':mix,'split_formula_checked':d>=5})
    report['elapsed_seconds']=round(time.monotonic()-started,3)
    (HERE/'root_mu_action_controls.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='dimensions'},ensure_ascii=False))
    for item in report['dimensions']:print(json.dumps({k:v for k,v in item.items() if k!='generators'},ensure_ascii=False))

if __name__=='__main__':run()

"""Finite independent controls for the all-s automorphism-kernel proof.

Standard library only. These controls corroborate, not replace, the proof.
"""
from pathlib import Path
from itertools import combinations
import json, random

HERE=Path(__file__).resolve().parent
MUL=[[0,0,0,0],[0,1,2,3],[0,2,3,1],[0,3,1,2]]
INV=[0,1,3,2]
rng=random.Random(20261030)

def add(a,b): return [x^y for x,y in zip(a,b)]
def scale(c,a): return [MUL[c][x] for x in a]
def mono(n,m,c=1):
    a=[0]*n;a[m]=c;return a
def mul(a,b):
    out=[0]*len(a)
    for i,x in enumerate(a):
        if not x: continue
        for j,y in enumerate(b):
            if y and not(i&j): out[i|j]^=MUL[x][y]
    return out
def cut(a):
    a=a[:];a[-1]=0;return a
def pack(a): return sum(x<<(2*i) for i,x in enumerate(a))

def rank4(rows,ncols):
    even=sum(1<<(2*i) for i in range(ncols))
    odd=even<<1
    def times(c,r):
        if c==1:return r
        if not c:return 0
        lo=r&even;hi=(r&odd)>>1
        wr=hi^((lo^hi)<<1)
        return wr if c==2 else wr^r
    piv={}
    for r in rows:
        while r:
            col=((r&-r).bit_length()-1)//2
            c=(r>>(2*col))&3
            if col in piv:r^=times(c,piv[col])
            else:
                piv[col]=times(INV[c],r);break
    return len(piv)

def parameters(s):
    n=1<<s
    a=[0]+[rng.randrange(4) for _ in range(n-2)]+[0]
    z=[rng.randrange(4) for _ in range(n-1)]+[0]
    return a,z,[rng.randrange(4) for _ in range(s)],rng.randrange(4)

def to_h(s,p,t):
    a,z,lam,zeta=t;n=1<<s;top=n-1
    hs=[add(mul(mono(n,1<<i),z),mono(n,top^(1<<i),lam[i])) for i in range(s)]
    hv=add(add(a,mul(p,z)),mono(n,top,zeta))
    return hs+[hv]

def constraints(s,p,a,hs):
    n=1<<s;zero=[0]*n
    for i,j in combinations(range(s),2):
        assert add(mul(mono(n,1<<i),hs[j]),mul(mono(n,1<<j),hs[i]))==zero
    for i in range(s):
        assert add(mul(mono(n,1<<i),add(a,hs[-1])),mul(p,hs[i]))==zero

def compose_params(s,left,right):
    a,z,lam,zz=left;b,w,mu,ww=right;n=1<<s;top=n-1
    ab=mul(a,b)
    aa=cut(add(add(a,b),ab))
    znew=add(add(z,w),mul(a,w))
    for i in range(s):
        znew[top^(1<<i)]^=MUL[mu[i]][a[1<<i]]
    return aa,cut(znew),[x^y for x,y in zip(lam,mu)],zz^ww^ab[top]

def linear_rank_control(s,p):
    n=1<<s;w=n-1
    pairs=list(combinations(range(s),2));mixed_offset=len(pairs)
    variables=[('a',0,m) for m in range(1,n-1)]
    variables += [('h',i,m) for i in range(s+1) for m in range(1,n)]
    rows=[0]*((len(pairs)+s)*w)
    def put(group,mask,col,c=1):
        if mask:rows[group*w+mask-1]^=c<<(2*col)
    for col,(kind,i,m) in enumerate(variables):
        if kind=='a' or i==s:
            for j in range(s):
                if not(m&(1<<j)):put(mixed_offset+j,m|(1<<j),col)
        else:
            for group,(j,k) in enumerate(pairs):
                if i==j and not(m&(1<<k)):put(group,m|(1<<k),col)
                if i==k and not(m&(1<<j)):put(group,m|(1<<j),col)
            for mask,c in enumerate(p):
                if c and not(mask&m):put(mixed_offset+i,mask|m,col,c)
    rank=rank4(rows,len(variables));dim=len(variables)-rank
    assert dim==2*w+s,(s,rank,dim)
    return {'unknowns':len(variables),'rank':rank,'kernel_dimension':dim}

def unpack_input(s,x):
    n=1<<s;coords=[(x>>(2*i))&3 for i in range(s+1+n-1)]
    return coords[:s],coords[s],[0]+coords[s+1:]
def pack_output(X,V,w):return pack(X+[V]+w[1:])
def F(s,p,x):
    X,V,w=unpack_input(s,x);n=1<<s
    P=scale(V,p)
    for i,c in enumerate(X):P[1<<i]^=c
    out=add(scale(2,w),add(mul(P,w),scale(V,P)))
    return pack_output([MUL[2][c] for c in X],MUL[2][V],out)
def S(s,p,t,x):
    X,V,w=unpack_input(s,x);n=1<<s;top=n-1
    a,z,lam,zeta=t;hs=to_h(s,p,t)
    out=add(w,mul(a,w))
    for i,c in enumerate(X):out=add(out,scale(c,hs[i]))
    out=add(out,scale(V,hs[-1]))
    for i,c in enumerate(X):out[top]^=MUL[lam[i]][MUL[c][c]]
    return pack_output(X,V,out)

report={'status':'PASS','linear_kernel_controls':[],'group_law_controls':[],'binary_commutation_controls':[]}
for s in range(2,6):
    n=1<<s
    choices=[('zero',[0]*n)]
    if s>=3:choices.append(('monomial',mono(n,3)))
    if s>=4:choices.append(('two_quad_terms',add(mono(n,3),mono(n,12,2))))
    if s>=3:
        p=[rng.randrange(4) if 2<=m.bit_count()<s else 0 for m in range(n)]
        choices.append(('mixed_F4_coefficients',p))
    for name,p in choices:
        r=linear_rank_control(s,p)
        report['linear_kernel_controls'].append({'s':s,'p_type':name,**r})
        for _ in range(40):
            t=parameters(s);u=parameters(s)
            h=to_h(s,p,t);k=to_h(s,p,u)
            constraints(s,p,t[0],h);constraints(s,p,u[0],k)
            comp=compose_params(s,t,u)
            hcomp=to_h(s,p,comp)
            expected=[add(add(a,b),mul(t[0],b)) for a,b in zip(h,k)]
            assert hcomp==expected,(s,name)
            aa=cut(add(add(t[0],u[0]),mul(t[0],u[0])))
            assert comp[0]==aa
            square=compose_params(s,t,t);fourth=compose_params(s,square,square)
            assert not any(fourth[0]+fourth[1]+fourth[2]+[fourth[3]])
        report['group_law_controls'].append({'s':s,'p_type':name,'random_compositions':40,'fourth_powers':40})
        if s<=4:
            nbits=2*(s+n)
            points=[0]+[1<<i for i in range(nbits)]+[(1<<i)|(1<<j) for i,j in combinations(range(nbits),2)]
            for _ in range(2):
                t=parameters(s)
                for x in points:
                    assert S(s,p,t,F(s,p,x))==F(s,p,S(s,p,t,x)),(s,name,x)
            report['binary_commutation_controls'].append({'s':s,'p_type':name,'linear_kernel_samples':2,'complete_degree_two_test_points':len(points)})
# The separate class-two boundary has a different quotient group.
p=[0,0];sections=0
for a in range(4):
 for b in range(4):
  for c in range(4):
   for d in range(4):
    det=MUL[a][d]^MUL[b][c]
    if not det:continue
    sections+=1
    def section(x):
        X,V,w=unpack_input(1,x);X=X[0]
        Y=MUL[a][X]^MUL[b][V];Z=MUL[c][X]^MUL[d][V]
        out=MUL[det][w[1]]^MUL[MUL[a][c]][MUL[X][X]]^MUL[MUL[b][d]][MUL[V][V]]
        return pack_output([Y],Z,[0,out])
    for x in range(64):assert section(F(1,p,x))==F(1,p,section(x))
assert sections==180
for a in range(4):
 for b in range(4):
    def translation(x):
        X,V,w=unpack_input(1,x)
        return pack_output(X,V,[0,w[1]^MUL[a][X[0]]^MUL[b][V]])
    for x in range(64):assert translation(F(1,p,x))==F(1,p,translation(x))
report['class_two_boundary']={'field':4,'binary_dimension':6,'all_GL2_sections':180,'all_kernel_translations':16,'inputs_per_map':64,'centralizer_order':2880,'status':'PASS'}
(HERE/'automorphism_kernel_controls.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))

"""Independent exact finite controls of the new canonical family.

No old construction or generator is imported. Field arithmetic is F2[w]/
(w^2+w+1). Parameter polynomials use fixed square-zero ring monomials.
The checks are not Lean formalizations and do not replace all-s proofs.
"""
from itertools import combinations,product
from pathlib import Path
import json, random, time

MUL=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
INV=(0,1,3,2)
OMEGA=2

def xor(items):
    out=0
    for value in items: out ^= value
    return out

def binary_basis(values):
    pivots={}
    for value in values:
        while value:
            bit=value.bit_length()-1
            if bit in pivots: value ^= pivots[bit]
            else:
                pivots[bit]=value
                break
    return list(pivots.values())

def rank(values): return len(binary_basis(values))

def weight_points(n,bound):
    yield 0
    for k in range(1,bound+1):
        for items in combinations(range(n),k):
            yield sum(1<<i for i in items)

class Ring:
    def __init__(self,s):
        self.s=s;self.size=1<<s;self.top=self.size-1
        self.low=sum(1<<(2*i) for i in range(self.size))
        self.variables=[1<<(2*(1<<i)) for i in range(s)]
        self.J_basis=[1<<(2*i) for i in range(1,self.size)]
    def scale(self,a,c):
        if c==0:return 0
        if c==1:return a
        lo=a&self.low;hi=(a>>1)&self.low
        omega=hi|((lo^hi)<<1)
        return omega if c==2 else omega^a
    def terms(self,a):
        while a:
            mask=(a.bit_length()-1)//2
            coefficient=(a>>(2*mask))&3
            yield mask,coefficient
            a ^= coefficient<<(2*mask)
    def mul(self,a,b):
        out=0
        bt=list(self.terms(b))
        for i,c in self.terms(a):
            for j,d in bt:
                if not i&j: out ^= MUL[c][d]<<(2*(i|j))
        return out
    def linear_map(self,a,images):
        return xor(self.scale(images[i],c) for i,c in self.terms(a))
    def substitution(self,columns):
        images=[1]+[0]*(self.size-1)
        for mask in range(1,self.size):
            bit=mask&-mask;i=bit.bit_length()-1
            images[mask]=self.mul(images[mask^bit],columns[i])
        return images

class Canonical:
    def __init__(self,s,p):
        self.s=s;self.R=Ring(s);self.p=p
        self.jdim=(1<<s)-1;self.qdim=s+1
        self.n=2*(self.qdim+self.jdim)
        self.qbits=2*self.qdim
        assert (p&3)==0
        self.products=[self.R.mul(p,1<<(2*i)) for i in range(1<<s)]
        self.tproducts=[[self.R.mul(t,1<<(2*i)) for i in range(1<<s)] for t in self.R.variables]
        self.core_mask=(1<<(2*s))-1
    def pack(self,X,V,z):
        return sum(x<<(2*i) for i,x in enumerate(X)) | (V<<(2*self.s)) | ((z>>2)<<self.qbits)
    def unpack(self,u):
        X=[(u>>(2*i))&3 for i in range(self.s)]
        V=(u>>(2*self.s))&3
        z=(u>>self.qbits)<<2
        return X,V,z
    def f(self,u):
        X,V,z=self.unpack(u);R=self.R
        tX=xor(R.scale(R.variables[i],a) for i,a in enumerate(X))
        tz=0;pz=0
        for mask,b in R.terms(z):
            pz ^= R.scale(self.products[mask],b)
            for i,a in enumerate(X):
                if a: tz ^= R.scale(self.tproducts[i][mask],MUL[a][b])
        newz=R.scale(z,OMEGA)^tz^R.scale(pz,V)^R.scale(tX,V)^R.scale(self.p,MUL[V][V])
        return self.pack([MUL[OMEGA][a] for a in X],MUL[OMEGA][V],newz)
    def invariants(self):
        n=self.n
        f_basis=[self.f(1<<i) for i in range(n)]
        table=[[0]*n for _ in range(n)]
        for i,j in combinations(range(n),2):
            value=self.f((1<<i)^(1<<j))^f_basis[i]^f_basis[j]
            table[i][j]=table[j][i]=value
        def bracket(a,b):
            value=0
            while a:
                bit=a&-a;i=bit.bit_length()-1;a^=bit
                bb=b
                while bb:
                    bit2=bb&-bb;j=bit2.bit_length()-1;bb^=bit2
                    value ^= table[i][j]
            return value
        ambient=[1<<i for i in range(n)]
        derived=binary_basis(table[i][j] for i,j in combinations(range(n),2))
        lower=[n,len(derived)];layer=derived
        while layer:
            layer=binary_basis(bracket(a,b) for a in ambient for b in layer)
            lower.append(len(layer))
            assert len(lower)<=self.s+3
        center_columns=[sum(table[i][j]<<(j*n) for j in range(n)) for i in range(n)]
        center=n-rank(center_columns)
        w_basis=[1<<i for i in range(self.qbits,n)]
        quotient_basis=[1<<i for i in range(self.qbits)]
        common_columns=[sum(bracket(a,b)<<(i*n) for i,a in enumerate(quotient_basis)) for b in w_basis]
        common=len(w_basis)-rank(common_columns)
        v=1<<(2*self.s)
        p_rank=rank(bracket(v,w) for w in w_basis)
        action_columns=[sum(bracket(a,b)<<(j*n) for j,b in enumerate(w_basis)) for a in quotient_basis]
        action_rank=rank(action_columns)
        expected=[n]+[2*sum(__import__('math').comb(self.s,j) for j in range(k-1,self.s+1)) for k in range(2,self.s+2)]+[0]
        assert lower==expected,(self.s,self.p,lower,expected)
        assert center==common==2
        assert self.n==2**(self.s+1)+2*(self.s+1)-2
        assert derived==[] or len(derived)==2*((1<<self.s)-1)
        # The full Lie table comes from polarization, rather than importing a
        # claimed bracket. Its Jacobi equations on basis triples are complete.
        for i,j,k in combinations(range(n),3):
            assert bracket(1<<i,table[j][k])^bracket(1<<j,table[k][i])^bracket(1<<k,table[i][j])==0
        assert len(lower)-1==self.s+1
        return {'n':n,'derived_dimension':len(derived),'lower_central_dimensions':lower,
                'nilpotency_class':len(lower)-1,'center_dimension':center,
                'common_action_kernel_in_W':common,'extra_action_binary_rank':p_rank,
                'action_image_binary_dimension':action_rank,'Jacobi_basis_checks':'PASS'}

def matrix_rank(matrix):
    a=[row[:] for row in matrix];n=len(a);r=0
    for j in range(n):
        pivot=next((i for i in range(r,n) if a[i][j]),None)
        if pivot is None:continue
        a[r],a[pivot]=a[pivot],a[r]
        scale=INV[a[r][j]];a[r]=[MUL[scale][x] for x in a[r]]
        for i in range(n):
            if i!=r and a[i][j]:
                c=a[i][j];a[i]=[x^MUL[c][y] for x,y in zip(a[i],a[r])]
        r+=1
    return r

def random_GL(s,rng):
    a=[[int(i==j) for j in range(s)] for i in range(s)]
    for _ in range(5*s):
        i,j=rng.sample(range(s),2);c=rng.randrange(1,4)
        a[i]=[x^MUL[c][y] for x,y in zip(a[i],a[j])]
        if rng.randrange(2):a[i]=[MUL[c][x] for x in a[i]]
    assert matrix_rank(a)==s
    return a

def polynomial(s,coefficients):
    return sum(c<<(2*mask) for mask,c in coefficients.items())

def residual_control(model,points):
    count=0
    for x in points:
        fx=model.f(x)
        assert model.f(fx)==(fx^x),(model.s,model.p,x)
        count+=1
    return count

def conjugacy_control(s,p,B,delta,top_coefficient):
    source=Canonical(s,p);R=source.R
    columns=[xor(R.scale(R.variables[j],B[j][i]) for j in range(s)) for i in range(s)]
    sigma=R.substitution(columns)
    theta=top_coefficient<<(2*R.top)
    transformed=R.linear_map(p,sigma)
    pp=R.scale(transformed^theta,INV[delta])
    target=Canonical(s,pp)
    def S(x):
        X,V,z=source.unpack(x)
        newX=[xor(MUL[B[j][i]][X[i]] for i in range(s)) for j in range(s)]
        newz=R.scale(R.linear_map(z,sigma),delta)^R.scale(theta,MUL[delta][MUL[V][V]])
        return target.pack(newX,MUL[delta][V],newz)
    columns_S=[S(1<<i) for i in range(source.n)]
    assert rank(columns_S)==source.n
    points=list(range(1<<source.n)) if s==2 else list(weight_points(source.n,2))
    for x in points:
        assert S(x)==xor(columns_S[i] for i in range(source.n) if x&(1<<i))
        assert S(source.f(x))==target.f(S(x)),(s,p,B,delta,top_coefficient,x)
    return {'s':s,'B':B,'delta':delta,'top_difference_coefficient':top_coefficient,
            'source_p_coefficients':{str(i):c for i,c in R.terms(p)},
            'target_p_coefficients':{str(i):c for i,c in R.terms(pp)},
            'tested_inputs':len(points),'scope':'entire domain' if s==2 else 'weight<=2; conjugacy residual has degree<=2',
            'invertible_binary_conjugacy':True}

def main():
    started=time.monotonic();out={'status':'PASS','field':'F4 with omega^2=omega+1',
        'scope':{'s2':'all 4096 inputs','s3':'all 64 canonical parameters; all inputs of binary weight<=4',
                 'reason_for_lossless_points':'Fp is binary quadratic; Fp^2+Fp+id has degree<=4 and zero constant term. Boolean Mobius inversion makes weight<=4 equivalent to all inputs for each tested map.',
                 'conjugacy':'independent seeded GL_s(F4), scalar and top-difference choices; quadratic residual checked losslessly',
                 'limits':'Finite parameter dimensions and conjugacies only; all-s construction/orbit proofs are separate written arguments. Not Lean.'}}
    model=Canonical(2,0)
    out['s2']={'parameters':1,'functional_identity_inputs':residual_control(model,range(1<<model.n)),
               'invariants':model.invariants()}
    masks=[mask for mask in range(1,8) if mask.bit_count()==2]
    points=list(weight_points(22,4));records=[]
    for coefficients in product(range(4),repeat=3):
        p=polynomial(3,dict(zip(masks,coefficients)));model=Canonical(3,p)
        npoints=residual_control(model,points)
        records.append({'p_coefficients_by_masks_3_5_6':list(coefficients),'tested_inputs':npoints,
                        'invariants':model.invariants()})
    out['s3']={'parameters':len(records),'inputs_per_parameter':len(points),'total_functional_identity_inputs':len(records)*len(points),'records':records}
    # Explicit action-rank controls separate parameters without orbit enumeration.
    named={
        'zero':polynomial(4,{}),
        'quadratic_rank2':polynomial(4,{3:1}),
        'quadratic_rank4':polynomial(4,{3:1,12:1}),
        'cubic':polynomial(4,{7:1})}
    examples={}
    for name,p in named.items():
        model=Canonical(4,p)
        examples[name]={'functional_identity_inputs':residual_control(model,weight_points(40,4)),
                        'invariants':model.invariants()}
    assert [examples[name]['invariants']['extra_action_binary_rank'] for name in named]==[0,6,10,2]
    out['s4_distinguished_examples']=examples
    out['inequivalence_scope']='The program computes the distinct ranks 0,6,10,2; their role as conjugacy invariants of the intrinsic extra quotient line is proved in the separate written orbit-necessity argument, not by a finite search for conjugacies.'
    rng=random.Random(20261030);cases=[]
    for s in [2,3,4]:
        R=Ring(s)
        parameter_masks=[mask for mask in range(1,1<<s) if 2<=mask.bit_count()<s]
        for k in range(8):
            p=polynomial(s,{mask:rng.randrange(4) for mask in parameter_masks})
            cases.append(conjugacy_control(s,p,random_GL(s,rng),rng.randrange(1,4),k%4))
    # Named scalar equivalence t1t2 <-> omega*t1t2.
    B=[[int(i==j) for j in range(3)] for i in range(3)]
    cases.append(conjugacy_control(3,polynomial(3,{3:1}),B,3,0))
    out['conjugacies']={'seed':20261030,'cases':cases,'top_difference_formula':'sigma(p)+delta*p_prime=theta in Soc(R); S(X,V,z)=(BX,delta*V,delta*sigma(z)+delta*theta*V^2)'}
    out['elapsed_seconds']=round(time.monotonic()-started,3)
    path=Path(__file__).with_suffix('.json')
    path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':out['status'],'s2_inputs':out['s2']['functional_identity_inputs'],
                      's3_parameters':64,'s3_inputs_each':len(points),'s4_examples':len(examples),
                      'conjugacy_cases':len(cases),'elapsed_seconds':out['elapsed_seconds']},ensure_ascii=False))

if __name__=='__main__':main()

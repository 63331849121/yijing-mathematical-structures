"""Independent finite interfaces for growing-surplus principal enumeration.

These controls verify actual F4 ring substitutions, displacement ranks and
the fixed-pair change of counting variables. They do not prove an asymptotic.
Default: print a summary, leave supplied reports unchanged. Use --report NEW.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction
import argparse,json,random,time

HERE=Path(__file__).resolve().parent
M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
INV=(0,1,3,2)

def add(a,b):return [x^y for x,y in zip(a,b)]
def scale(c,a):return [M[c][x] for x in a]
def gaussian(n,k,q=4):
    if k<0 or k>n:return 0
    a=b=1
    for j in range(k):a*=q**(n-j)-1;b*=q**(k-j)-1
    assert a%b==0
    return a//b

def rank(columns):
    piv={}
    for col in columns:
        v=col[:]
        for i in range(len(v)):
            x=v[i]
            if not x:continue
            if i in piv:v=add(v,scale(x,piv[i]))
            else:piv[i]=scale(INV[x],v);break
    return len(piv)

def binary_lift_rank(columns):
    # F4 multiplication on its F2 basis 1,omega gives a second,
    # bit-packed rank implementation with no F4 elimination.
    piv={}
    for col in columns:
        for scalar in (1,2):
            word=sum(M[scalar][c]<<(2*i) for i,c in enumerate(col))
            while word:
                bit=word.bit_length()-1
                if bit in piv:word^=piv[bit]
                else:piv[bit]=word;break
    assert len(piv)%2==0
    return len(piv)//2

def nullspace(columns):
    piv={};out=[];n=len(columns)
    for j,col in enumerate(columns):
        v=col[:];c=[int(i==j) for i in range(n)]
        for i in range(len(v)):
            x=v[i]
            if not x:continue
            if i in piv:
                w,b=piv[i];v=add(v,scale(x,w));c=add(c,scale(x,b))
            else:
                piv[i]=(scale(INV[x],v),scale(INV[x],c));break
        else:out.append(c)
    assert len(out)==n-rank(columns)
    return out

def coordinates(basis,v):
    piv={};n=len(basis)
    for j,col in enumerate(basis):
        a=col[:];c=[int(i==j) for i in range(n)]
        for i in range(len(a)):
            x=a[i]
            if not x:continue
            if i in piv:
                w,b=piv[i];a=add(a,scale(x,w));c=add(c,scale(x,b))
            else:piv[i]=(scale(INV[x],a),scale(INV[x],c));break
        else:raise AssertionError('Not an independent frame')
    a=v[:];c=[0]*n
    for i in range(len(a)):
        x=a[i]
        if not x:continue
        assert i in piv
        w,b=piv[i];a=add(a,scale(x,w));c=add(c,scale(x,b))
    assert not any(a)
    return c

class Ring:
    def __init__(self,d):
        self.d=d;self.n=1<<d;self.z=self.n-2;self.tau=self.n-1
        self.P=[s for s in range(self.n) if s.bit_count()>=2 and s not in (self.z,self.tau)]
    def mono(self,s,c=1):
        v=[0]*self.n;v[s]=c;return v
    def mul(self,a,b):
        v=[0]*self.n
        aa=[(s,c) for s,c in enumerate(a) if c]
        bb=[(s,c) for s,c in enumerate(b) if c]
        for s,c in aa:
            for t,e in bb:
                if not s&t:v[s|t]^=M[c][e]
        return v
    def pcoords(self,a):return [a[s] for s in self.P]
    def lift(self,a):
        v=[0]*self.n
        for s,c in zip(self.P,a):v[s]=c
        return v
    def images(self,us):
        gens=[add(self.mono(1<<i),us[i]) for i in range(self.d)]
        out=[None]*self.n;out[0]=self.mono(0)
        for s in range(1,self.n):
            b=s&-s;out[s]=self.mul(out[s^b],gens[b.bit_length()-1])
        return gens,out
    def apply(self,images,v):
        out=[0]*self.n
        for s,c in enumerate(v):
            if c:out=add(out,scale(c,images[s]))
        return out

def small_exhaustion():
    R=Ring(3);assert len(R.P)==2
    polynomials=[R.lift(list(c)) for c in product(range(4),repeat=2)]
    ranks={0:0,1:0,2:0};totals={1:Fraction(0),2:Fraction(0)}
    for ix in product(range(16),repeat=3):
        us=[polynomials[i] for i in ix];gens,images=R.images(us)
        for t in (R.z,R.tau):assert all(not c or j in (R.z,R.tau) for j,c in enumerate(images[t]))
        T=[R.pcoords(add(images[s],R.mono(s))) for s in R.P]
        assert rank(T)==0
        k=rank([R.pcoords(u) for u in us]);ranks[k]+=1
        if not k:continue
        for r in (1,2):totals[r]+=Fraction(gaussian(2-k,r-k),gaussian(2,r))
    assert sum(ranks.values())==4096 and ranks[0]==1
    for r,total in totals.items():assert total==4**(3*r)-1
    return {'d':3,'automorphisms_exhausted':4096,'displacement_ranks':ranks,
            'pure_fixed_sums':{str(r):int(v) for r,v in totals.items()},
            'purpose':'Actual substitutions, quotient preservation, and the exact Gaussian fixed-pair mass; this small case deliberately has nonfree actions.'}

def one_control(R,us,name):
    gens,images=R.images(us);d=R.d;n=R.n
    assert any(any(u) for u in us)
    for t in (R.z,R.tau):assert all(not c or j in (R.z,R.tau) for j,c in enumerate(images[t]))
    assert rank(images)==binary_lift_rank(images)==n
    T=[add(images[s],R.mono(s)) for s in range(n)]
    TP=[R.pcoords(T[s]) for s in R.P]
    j=min(s.bit_count() for u in us for s,c in enumerate(u) if c)
    full_rank=rank(T);p_rank=rank(TP);k=rank([R.pcoords(u) for u in us])
    assert full_rank==binary_lift_rank(T)
    assert p_rank==binary_lift_rank(TP)
    assert full_rank>=2**(d-j-1)
    assert p_rank>=max(0,2**(d-j-1)-d-3)
    chosen=next(u for u in us if any(c and s.bit_count()==j for s,c in enumerate(u)))
    multcols=[R.mul(chosen,R.mono(s)) for s in range(n)]
    mult_rank=rank(multcols);assert mult_rank==binary_lift_rank(multcols)
    assert mult_rank>=2**(d-j)
    basis_samples=list(range(n)) if d<=5 else sorted({0,n-1,*range(min(n,16)),1<<(d-1),n//2+1})
    commutators=0
    for i in range(d):
        bit=1<<i
        for s in basis_samples:
            left=[0]*n if s&bit else T[s|bit]
            actual=add(left,R.mul(gens[i],T[s]))
            assert actual==R.mul(us[i],R.mono(s));commutators+=1
    U=[R.pcoords(u) for u in us]
    active=[u for u in U if any(u)]
    Ufixed=all(not any(R.pcoords(add(R.apply(images,u),u))) for u in us)
    frame_control=None
    if Ufixed:
        basis=[]
        for col in active:
            if rank(basis+[col])>len(basis):basis.append(col)
        target=min(len(R.P),k+1)
        for col in nullspace(TP):
            if len(basis)==target:break
            if rank(basis+[col])>len(basis):basis.append(col)
        assert len(basis)==target
        for col in basis:assert not any(R.pcoords(add(R.apply(images,R.lift(col)),R.lift(col))))
        alphas=[coordinates(basis,u) for u in U]
        for i,coef in enumerate(alphas):
            rebuilt=[0]*len(R.P)
            for c,p in zip(coef,basis):rebuilt=add(rebuilt,scale(c,p))
            assert rebuilt==U[i]
        frame_control={'r':target,'unique_alpha_recovered':True,'fixed_frame_checked':True}
    return {'name':name,'d':d,'order':j,'displacement_rank':k,'full_difference_rank':full_rank,
            'principal_difference_rank':p_rank,'multiplier_rank':mult_rank,
            'full_commutator_basis_checks':commutators,'independent_binary_rank_checks':4,
            'frame_pair':frame_control}

def selected_controls():
    out=[];rng=random.Random(912303)
    for d in (4,5,7,8):
        R=Ring(d)
        for j in (2, min(3,d-1)):
            S=(1<<j)-1
            assert S in R.P
            us=[[0]*R.n for _ in range(d)];us[d-1][S]=2
            out.append(one_control(R,us,f'single-order{j}'))
        ell=R.mono(1,2)
        us=[R.mul(R.mono(1<<i),ell) for i in range(d)]
        out.append(one_control(R,us,'radial-quadratic'))
        us=[]
        for i in range(d):
            u=[0]*R.n
            for S in rng.sample(R.P,min(4,len(R.P))):u[S]=rng.randrange(1,4)
            us.append(u)
        out.append(one_control(R,us,'seeded-mixed'))
    return out

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group()
    group.add_argument('--report',type=Path)
    group.add_argument('--no-write',action='store_true')
    args=parser.parse_args()
    if args.report is not None and args.report.exists():parser.error('--report must be new')
    started=time.monotonic();small=small_exhaustion();controls=selected_controls()
    result={'status':'PASS','small_exhaustion':small,'matrix_controls':controls,
            'matrix_control_count':len(controls),'seconds':round(time.monotonic()-started,3),
            'scope':'Finite exact F4 interfaces, including deliberately nonfree small cases. Uniform stabilizer bounds and asymptotics require the general proof.'}
    if args.report is not None:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        with args.report.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items() if k!='matrix_controls'}))

if __name__=='__main__':main()

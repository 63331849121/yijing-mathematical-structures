"""Independent controls of higher coupled central derived defects.

The GF4 ring helpers and ordinary-cocycle reconstruction extend the
previous one-defect research control. This script is self-contained;
there is no runtime import from any canonical constructor or checker.

Reconstructs actual F4 brackets from all Koszul components. Checks the
principal-unit lift by its explicit homotopy and on all Lie basis pairs.
No canonical construction/checker is imported. Uniform counting is proved
in writing separately; these selected finite models are interface controls.
"""
from pathlib import Path
from itertools import combinations
import random,json,time

HERE=Path(__file__).resolve().parent
RNG=random.Random(202610302355)
M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
INV=(0,1,3,2)

def terms(v):
    while v:
        j=((v&-v).bit_length()-1)//2;c=(v>>(2*j))&3
        yield j,c;v&=~(3<<(2*j))

def scale(c,v):
    if c==1:return v
    if not c:return 0
    return sum(M[c][a]<<(2*j) for j,a in terms(v))

def basis(vectors):
    piv={}
    for v in vectors:
        while v:
            j=(v.bit_length()-1)//2;c=(v>>(2*j))&3
            if j in piv:v^=scale(c,piv[j])
            else:piv[j]=scale(INV[c],v);break
    return list(piv.values())

def add(*polys):
    out={}
    for p in polys:
        for S,c in p.items():
            out[S]=out.get(S,0)^c
            if not out[S]:del out[S]
    return out

def ps(c,p):return {S:M[c][a] for S,a in p.items() if M[c][a]}

def mul(p,q):
    out={}
    for S,c in p.items():
        for T,a in q.items():
            if not(S&T):
                U=S|T;out[U]=out.get(U,0)^M[c][a]
                if not out[U]:del out[U]
    return out

def enc(p):return sum(c<<(2*S) for S,c in p.items())

def split_polynomial(p,d):
    result=[{} for _ in range(d)]
    for S,c in p.items():
        bit=S&-S;i=bit.bit_length()-1
        result[i][S^bit]=c
    return result

class Model:
    def __init__(self,d,s,h,gamma_rank=None):
        self.d=d;self.s=s;self.h=h;self.N=1<<d;self.tau=self.N-1
        self.K=list(range(2,self.N));self.U=d+s;self.w0=len(self.K)
        self.ix={S:self.U+j for j,S in enumerate(self.K)}
        self.z=self.U+self.w0;self.n=self.z+h
        self.t=[{1<<i:1} for i in range(d)]
        masks=[S for S in range(self.N) if S.bit_count()>=2 and S not in(self.N-2,self.N-1)]
        self.p=[{3:1},{12:1}][:s]
        while len(self.p)<s:
            p={S:c for S in masks if (c:=RNG.randrange(4))}
            if len(basis([enc(v) for v in self.p+[p]]))==len(self.p)+1:self.p.append(p)
        if RNG.randrange(2):
            for j in range(s):
                p=add(self.p[j],{S:c for S in masks if (c:=RNG.randrange(4))})
                trial=self.p[:];trial[j]=p
                if len(basis([enc(v) for v in trial]))==s:self.p=trial
        assert len(basis([enc(v) for v in self.t+self.p]))==self.U
        self.actions=self.t+self.p
        self.div=[]
        for p in self.p:
            row=[{} for _ in range(d)]
            for S,c in p.items():
                H=S&~1;bit=H&-H;i=bit.bit_length()-1
                row[i][S^bit]=c
            assert add(*(mul(self.t[i],row[i]) for i in range(d)))==p
            self.div.append(row)
        b={}
        kappa=[0]+[RNG.randrange(4) for _ in range(d-1)]
        for i,j in combinations(range(d),2):
            lam=RNG.randrange(4)
            base=self.t[j] if i==0 else add(ps(kappa[i],mul(self.t[0],self.t[j])),ps(kappa[j],mul(self.t[0],self.t[i])))
            b[i,j]=add(base,{self.tau^((1<<i)|(1<<j)):lam} if lam else {})
        def bc(i,j):return {} if i==j else b[min(i,j),max(i,j)]
        zeta=[]
        for a in range(s):
            eps=RNG.randrange(4);rho=[RNG.randrange(4) for _ in range(d)]
            zeta.append([add(ps(eps,mul(self.t[0],self.t[i])) if i else {},
                             {self.tau^(1<<i):rho[i]} if rho[i] else {}) for i in range(d)])
        self.beta=dict(b);self.gamma={}
        pairs=list(combinations(range(s),2))
        gamma_rank=h if gamma_rank is None else gamma_rank
        assert 0<=gamma_rank<=h
        gamma_columns=[1<<(2*j) for j in range(gamma_rank)]
        gamma_columns += [sum(RNG.randrange(4)<<(2*j) for j in range(gamma_rank))
                          for _ in range(len(pairs)-gamma_rank)]
        assert len(basis(gamma_columns))==gamma_rank
        self.gamma_rank=gamma_rank
        gamma_by_pair=dict(zip(pairs,gamma_columns))
        for i in range(d):
            for a in range(s):
                self.beta[i,d+a]=add(*(mul(self.div[a][j],bc(i,j)) for j in range(d)),zeta[a][i])
        for a,bx in combinations(range(s),2):
            value={}
            for i,j in combinations(range(d),2):
                coeff=add(mul(self.div[a][i],self.div[bx][j]),mul(self.div[bx][i],self.div[a][j]))
                value=add(value,mul(coeff,bc(i,j)))
            for i in range(d):
                value=add(value,mul(self.div[a][i],zeta[bx][i]),mul(self.div[bx][i],zeta[a][i]))
            chi=RNG.randrange(4)
            if chi:value=add(value,{self.tau:chi})
            self.beta[d+a,d+bx]=value
            self.gamma[d+a,d+bx]=gamma_by_pair[a,bx]
        # All nonstar pairs, not only extra/extra, can carry the
        # surjective central cocycle. Star values are arbitrary.
        nonstar=[(i,j) for i,j in combinations(range(self.U),2)
                 if not(i==0 and j<self.d)]
        assert gamma_rank<=h<=len(nonstar)
        values=[1<<(2*j) for j in range(gamma_rank)]
        values += [sum(RNG.randrange(4)<<(2*j) for j in range(gamma_rank))
                   for _ in range(len(nonstar)-gamma_rank)]
        self.gamma=dict(zip(nonstar,values))
        if gamma_rank and nonstar.index((1,2))>=gamma_rank:self.gamma[1,2]=1
        assert len(basis(self.gamma.values()))==gamma_rank
        for i in range(1,self.d):
            self.gamma[0,i]=sum(RNG.randrange(4)<<(2*j) for j in range(h))
        self.gamma[0,1]=1<<(2*(h-1))
        self.gamma_total_rank=len(basis(self.gamma.values()))
        assert all(S.bit_count()>=2 for pair,p in self.beta.items()
                   if pair in nonstar for S in p)
        self.T=[[0]*self.n for _ in range(self.n)]
        for (i,j),p in self.beta.items():
            v=self.wp(p)^((self.gamma.get((i,j),0))<<(2*self.z))
            self.T[i][j]=self.T[j][i]=v
        for i,A in enumerate(self.actions):
            for S in self.K:
                v=self.wp(mul(A,{S:1}));j=self.ix[S]
                self.T[i][j]=self.T[j][i]=v
    def wp(self,p):
        assert all(S in self.ix for S in p),p
        return sum(c<<(2*self.ix[S]) for S,c in p.items())
    def br(self,v,w):
        out=0
        for i,c in terms(v):
            for j,a in terms(w):out^=scale(M[c][a],self.T[i][j])
        return out
    def lower(self):
        layer=basis(self.T[i][j] for i,j in combinations(range(self.n),2));dims=[self.n,len(layer)]
        while layer:
            layer=basis(self.br(1<<(2*i),v) for i in range(self.n) for v in layer)
            dims.append(len(layer));assert len(dims)<self.n+2
        return dims
    def principal_lift(self):
        u={S:c for S in range(self.N) if S not in(self.N-2,self.N-1) and (c:=RNG.randrange(4))};u[0]=1
        # Force a linear term, which a top-degree-only control would miss.
        u[1]=1
        div=split_polynomial({S:c for S,c in u.items() if S},self.d)
        f=[]
        for x in range(self.U):
            value={}
            for i in range(self.d):
                b={} if i==x else self.beta[min(i,x),max(i,x)]
                value=add(value,mul(div[i],b))
            f.append(value)
        for i,j in combinations(range(self.U),2):
            lhs=add(mul(self.actions[i],f[j]),mul(self.actions[j],f[i]))
            assert lhs==mul({S:c for S,c in u.items() if S},self.beta[i,j])
        images=[(1<<(2*i))^self.wp(f[i]) for i in range(self.U)]
        images += [self.wp(mul(u,{S:1})) for S in self.K]+[1<<(2*(self.z+j)) for j in range(self.h)]
        assert len(basis(images))==self.n
        for i,j in combinations(range(self.n),2):
            transported=0
            for k,c in terms(self.T[i][j]):transported^=scale(c,images[k])
            assert self.br(images[i],images[j])==transported
        return True
    def module_blocks(self):
        # Arbitrary invertible R-module blocks. Their transported Lie
        # cocycles need not stay in the selected zero-core-Z slice.
        h=self.h;wdim=self.w0+h
        v=[RNG.randrange(4) for _ in range(h)]
        ell=[[RNG.randrange(4) for _ in range(self.d-1)] for _ in range(h)]
        C=[]
        while len(C)<h:
            col=sum(RNG.randrange(4)<<(2*j) for j in range(h))
            if len(basis(C+[col]))>len(C):C.append(col)
        u={S:a for S in range(self.N) if S not in(self.N-2,self.N-1) and (a:=RNG.randrange(4))}
        u[0]=RNG.randrange(1,4)
        def local(p,z=0):
            return sum(a<<(2*self.K.index(S)) for S,a in p.items())^(z<<(2*self.w0))
        def lam(S):
            if S.bit_count()!=1 or S==1:return 0
            i=S.bit_length()-2
            return sum(ell[j][i]<<(2*j) for j in range(h))
        columns=[local(mul(u,{S:1}),lam(S)) for S in self.K]
        columns += [local({self.tau:v[j]} if v[j] else {},C[j]) for j in range(h)]
        assert len(basis(columns))==wdim
        def apply(columns,w):
            out=0
            for j,c in terms(w):out^=scale(c,columns[j])
            return out
        def action(A,w):
            p={self.K[j]:c for j,c in terms(w) if j<self.w0}
            return local(mul(A,p))
        for A in self.actions:
            for j,col in enumerate(columns):
                assert action(A,col)==apply(columns,action(A,1<<(2*j)))
        # Transport the whole bracket and verify an actual Lie isomorphism.
        images=[1<<(2*i) for i in range(self.U)]
        images += [col<<(2*self.U) for col in columns]
        target=[row[:] for row in self.T]
        for i,j in combinations(range(self.U),2):
            target[i][j]=target[j][i]=apply(columns,self.T[i][j]>>(2*self.U))<<(2*self.U)
        def bracket(vv,ww):
            out=0
            for i,c in terms(vv):
                for j,a in terms(ww):out^=scale(M[c][a],target[i][j])
            return out
        for i,j in combinations(range(self.n),2):
            transported=0
            for k,c in terms(self.T[i][j]):transported^=scale(c,images[k])
            assert bracket(images[i],images[j])==transported
        # A graph of a trivial h-dimensional summand and an actual
        # idempotent projection onto it, as used by Krull--Schmidt.
        graphs=[local({self.tau:v[j]} if v[j] else {},1<<(2*j)) for j in range(h)]
        def project(w):
            z=w>>(2*self.w0)
            for j,c in terms(w):
                if j<self.w0:z^=scale(c,lam(self.K[j]))
            return apply(graphs,z)
        for j in range(wdim):
            projected=project(1<<(2*j))
            assert project(projected)==projected
            assert all(action(A,projected)==0 for A in self.actions)
        return True


def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group()
    group.add_argument('--no-write',action='store_true',help='Print summary only (default).')
    group.add_argument('--report',type=Path,help='Write full JSON to a new file; never overwrite.')
    args=parser.parse_args()
    if args.report is not None and args.report.exists():parser.error('--report must name a new file')
    started=time.monotonic();records=[]
    for d,s,h,cases in ((4,1,2,1),(4,1,3,1),(4,3,2,2),(4,3,3,2),(4,4,2,1),(5,3,2,1),(5,3,3,1)):
        for case in range(cases):
            A=Model(d,s,h)
            for i,j,k in combinations(range(A.n),3):
                assert not(A.br(1<<(2*i),A.T[j][k])^A.br(1<<(2*j),A.T[k][i])^A.br(1<<(2*k),A.T[i][j]))
            dims=A.lower();assert dims[1]==A.w0+h and len(dims)-1==d+1
            derived=basis(A.T[i][j] for i,j in combinations(range(A.n),2))
            for S in A.K:
                if S.bit_count()>=2:
                    assert len(basis(derived+[1<<(2*A.ix[S])]))==len(derived)
            assert all(len(basis(derived+[1<<(2*(A.z+j))]))==len(derived) for j in range(h))
            assert all(A.principal_lift() for _ in range(2))
            assert all(A.module_blocks() for _ in range(2))
            records.append({'d':d,'extra_quotient':s,'derived_defect':h,'total_surplus':s+h,
                'dimension':A.n,'derived_dimension':dims[1],'lower_central_dimensions':dims,
                'gamma_nonstar_rank':A.gamma_rank,'gamma_total_rank':A.gamma_total_rank,
                'star_gamma_nonzero':bool(A.gamma[0,1]),'core_nonstar_gamma_nonzero':bool(A.gamma[1,2]),
                'mixed_gamma_nonzero':any(A.gamma[i,j] for i in range(d) for j in range(d,A.U)),
                'pure_mK_generated':True,'pure_all_Z_generated':True,
                'cross_product_nonzero':len(A.p)>1 and bool(mul(A.p[0],A.p[1])),
                'principal_unit_actual_Lie_lifts':2,'module_blocks_actual_Lie_transports_and_graphs':2,'status':'PASS'})
    negative=[]
    for h in (2,3):
        A=Model(4,3,h,gamma_rank=h-1)
        dims=A.lower();assert dims[1]==A.w0+h-1 and A.gamma_total_rank==h
        derived=basis(A.T[i][j] for i,j in combinations(range(A.n),2))
        assert len(basis(derived+[1<<(2*(A.z+h-1))]))==len(derived)+1
        negative.append({'h':h,'gamma_nonstar_rank':h-1,'gamma_total_rank':h,
            'nonzero_star_does_not_repair_nonstar_deficiency':True,
            'actual_derived_dimension':dims[1],'expected':A.w0+h-1,'status':'PASS'})
    assert any(r['cross_product_nonzero'] for r in records)
    result={'status':'PASS','records':records,'rank_deficient_gamma_negative_controls':negative,
        'scope':'Selected h2/h3 real F4 Lie models, full ordinary Koszul cocycles, arbitrary nonzero star central values and surjective nonstar forms including core/mixed pairs, full Jacobi and actual lower series, pure mK and Z generation, principal-unit Lie lifts, general module-block Lie transports and trivial graph projections. No all-parameter or asymptotic extrapolation.',
        'provenance':'Self-contained extension of earlier one-defect GF4 ring and cocycle helpers; no runtime canonical imports.',
        'seconds':round(time.monotonic()-started,3)}
    if args.report is not None:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        with args.report.open('x',encoding='utf-8') as stream:stream.write(json.dumps(result,indent=2))
    print(json.dumps({'status':'PASS','models':len(records),'principal_unit_Lie_lifts':2*len(records),
        'module_block_Lie_transports_and_graphs':2*len(records),'negative_rank_controls':len(negative),'seconds':result['seconds']}))

if __name__=='__main__':main()

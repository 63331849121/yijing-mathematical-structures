"""Independent characteristic-two controls for the one-defect proof.

No paper or certificate files are imported or modified.  Ranks are exact over
F_2; all matrices have F_2 entries, so these ranks persist over every F_(2^a).
These controls check interfaces of the general proof, not its quantifiers.
"""
from itertools import combinations
from math import comb
import json
import argparse
from pathlib import Path
import platform


def rank(columns):
    pivots = {}
    for value in columns:
        while value:
            p = value.bit_length() - 1
            if p in pivots:
                value ^= pivots[p]
            else:
                pivots[p] = value
                break
    return len(pivots)


def kernel(columns):
    pivots, result = {}, []
    for j, value in enumerate(columns):
        relation = 1 << j
        while value:
            p = value.bit_length() - 1
            if p in pivots:
                v, r = pivots[p]
                value ^= v
                relation ^= r
            else:
                pivots[p] = value, relation
                break
        if not value:
            result.append(relation)
    return result


def apply(columns, value):
    result = 0
    while value:
        bit = value & -value
        result ^= columns[bit.bit_length() - 1]
        value ^= bit
    return result


def compose(left, right):
    return [apply(left, value) for value in right]


def make_module(d, kind):
    top = (1 << d) - 1
    monomials = list(range(1 if kind == 'J' else 2, 1 << d))
    basis = monomials + (['z'] if kind in ('S', 'E') else [])
    index = {a: j for j, a in enumerate(basis)}
    actions = []
    for i in range(d):
        cols = []
        for a in basis:
            if a == 'z':
                target = None
            elif not (a & (1 << i)):
                target = a | (1 << i)
            elif kind == 'E' and i == 1 and a == 2:
                target = 'z'
            else:
                target = None
            cols.append(0 if target is None else 1 << index[target])
        actions.append(cols)
    w = len(basis)
    zero = [0] * w
    for a in actions:
        assert compose(a, a) == zero
        for b in actions:
            assert compose(a, b) == compose(b, a)
    theta = zero.copy()
    if kind == 'S':
        theta[index['z']] = 1 << index[top]
    elif kind == 'E':
        theta[index[2]] = 1 << index[top ^ 2]
        theta[index['z']] = 1 << index[top]
    return basis, index, actions, theta


def differential(actions, degree):
    u, w = len(actions), len(actions[0])
    source = list(combinations(range(u), degree))
    target = list(combinations(range(u), degree + 1))
    row = {I: j for j, I in enumerate(target)}
    columns = []
    for I in source:
        for a in range(w):
            value = 0
            for i in range(u):
                if i not in I:
                    J = tuple(sorted(I + (i,)))
                    value ^= actions[i][a] << (w * row[J])
            columns.append(value)
    return columns


def cohomology(actions, operator=None):
    u, w = len(actions), len(actions[0])
    diffs = [differential(actions, j) for j in range(3)]
    out = []
    for j in range(3):
        boundaries = [] if j == 0 else diffs[j - 1]
        cycles = kernel(diffs[j])
        rb = rank(boundaries)
        item = {'dimension': len(cycles) - rb}
        if operator is not None:
            cochain_op = []
            for k in range(comb(u, j)):
                cochain_op.extend(value << (k * w) for value in operator)
            images = [apply(cochain_op, a) for a in cycles]
            item['operator_rank'] = rank(boundaries + images) - rb
        out.append(item)
    return out


def end_dimension(actions):
    w = len(actions[0])
    equations = []
    for p in actions:
        rows = [[c for c in range(w) if p[c] & (1 << a)]
                for a in range(w)]
        for a in range(w):
            for b in range(w):
                equation = 0
                for c in range(w):
                    if p[b] & (1 << c):
                        equation ^= 1 << (a * w + c)
                for c in rows[a]:
                    equation ^= 1 << (c * w + b)
                equations.append(equation)
    return w * w - rank(equations)


def check_n_classes(d, kind):
    basis, index, actions, _ = make_module(d, kind)
    w = len(basis)
    wedge2 = list(combinations(range(d), 2))
    b1 = differential(actions, 1)
    images = [1 << (w * wedge2.index((0, i)) + index['z'])
              for i in range(1, d)]
    independent = rank(b1 + images) - rank(b1)
    assert independent == d - 1
    return independent


def poly_action(actions, mask):
    w = len(actions[0])
    result = [1 << j for j in range(w)]
    for i in range(len(actions)):
        if mask & (1 << i):
            result = compose(actions[i], result)
    return result


def check_semilinear_lift(d):
    """Shear t_1 -> t_1+t_0t_2; all other t_i fixed."""
    basis, index, actions, _ = make_module(d, 'E')
    w = len(basis)
    sig_images = [{1 << i} for i in range(d)]
    sig_images[1].add(1 | 4)

    def multiply_poly(a, b):
        result = set()
        for x in a:
            for y in b:
                if x & y:
                    continue
                v = x | y
                if v in result:
                    result.remove(v)
                else:
                    result.add(v)
        return result

    def sigma_monomial(a):
        result = {0}
        for i in range(d):
            if a & (1 << i):
                result = multiply_poly(result, sig_images[i])
        return result

    def canonical_lift(poly):
        result = 0
        for a in poly:
            assert a in index
            result ^= 1 << index[a]
        return result

    sigma_actions = []
    for poly in sig_images:
        cols = [0] * w
        for monomial in poly:
            piece = poly_action(actions, monomial)
            cols = [a ^ b for a, b in zip(cols, piece)]
        sigma_actions.append(cols)

    lift = []
    for a in basis:
        if a == 'z':
            image = 1 << index['z']
        else:
            i = next(i for i in range(1, d) if a & (1 << i))
            image = canonical_lift(sig_images[i])
            for j in range(d):
                if j != i and a & (1 << j):
                    image = apply(sigma_actions[j], image)
        lift.append(image)
    assert rank(lift) == w
    for i in range(d):
        assert compose(lift, actions[i]) == compose(sigma_actions[i], lift)
    return {'dimension': w, 'lift_rank': rank(lift),
            'all_generator_intertwining_checks': True}


def check_f4_semilinear_lift(d):
    """Check t_1 -> t_1+omega*t_0*t_2 over F4, omega^2=omega+1.

    This control uses actual nonbinary coefficients, separately from the
    scalar-extension invariance of the F2 rank controls above.
    """
    basis, index, binary_actions, _ = make_module(d, 'E')
    w = len(basis)

    def mul(a, b):
        a0, a1, b0, b1 = a & 1, a >> 1, b & 1, b >> 1
        return ((a0*b0) ^ (a1*b1)) | (((a0*b1) ^ (a1*b0) ^ (a1*b1)) << 1)

    def add(a, b):
        return [x ^ y for x, y in zip(a, b)]

    def scale(a, x):
        return [mul(a, y) for y in x]

    def act(cols, x):
        out = [0] * w
        for a, col in zip(x, cols):
            if a:
                out = add(out, scale(a, col))
        return out

    def comp(a, b):
        return [act(a, col) for col in b]

    def field_rank(cols):
        pivots = {}
        for original in cols:
            col = original.copy()
            while any(col):
                p = max(i for i, x in enumerate(col) if x)
                if p in pivots:
                    col = add(col, scale(col[p], pivots[p]))
                else:
                    inverse = {1: 1, 2: 3, 3: 2}[col[p]]
                    pivots[p] = scale(inverse, col)
                    break
        return len(pivots)

    actions = [[[int(bool(col & (1 << j))) for j in range(w)]
                for col in action] for action in binary_actions]
    sig_images = [{1 << i: 1} for i in range(d)]
    sig_images[1][1 | 4] = 2

    def poly_multiply(a, b):
        result = {}
        for x, cx in a.items():
            for y, cy in b.items():
                if x & y:
                    continue
                target = x | y
                result[target] = result.get(target, 0) ^ mul(cx, cy)
                if not result[target]:
                    del result[target]
        return result

    def poly_operator(poly):
        out = [[0] * w for _ in range(w)]
        for mask, coefficient in poly.items():
            term = [[int(i == j) for i in range(w)] for j in range(w)]
            for i in range(d):
                if mask & (1 << i):
                    term = comp(actions[i], term)
            out = [add(a, scale(coefficient, b)) for a, b in zip(out, term)]
        return out

    sigma_actions = [poly_operator(poly) for poly in sig_images]
    lift = []
    for monomial in basis:
        if monomial == 'z':
            image = [int(a == 'z') for a in basis]
        else:
            generator = next(i for i in range(1, d) if monomial & (1 << i))
            image = [0] * w
            for mask, coefficient in sig_images[generator].items():
                image[index[mask]] ^= coefficient
            for i in range(d):
                if i != generator and monomial & (1 << i):
                    image = act(sigma_actions[i], image)
        lift.append(image)
    assert field_rank(lift) == w
    for i in range(d):
        assert comp(lift, actions[i]) == comp(sigma_actions[i], lift)
    # A nonzero omega coefficient really occurs in this matrix.
    assert any(2 in column or 3 in column for column in lift)
    return {'field': 'F4, omega^2=omega+1', 'increment': 'omega*t0*t2',
            'dimension': w, 'lift_rank': field_rank(lift),
            'all_generator_intertwining_checks': True}


def controls():
    records = {}
    for d in (4, 5):
        for kind in ('S', 'E', 'J'):
            basis, index, actions, theta = make_module(d, kind)
            core = cohomology(actions, theta if kind != 'J' else None)
            expected = ([2, 2*d+1, d+2*comb(d, 2)] if kind != 'J'
                        else [1, d+1, d+comb(d, 2)])
            assert [x['dimension'] for x in core] == expected
            item = {'module_dimension': len(basis), 'core_cohomology': core}
            if kind != 'J':
                assert [x['operator_rank'] for x in core] == [1, 0, 0]
                item['independent_N_star_classes'] = check_n_classes(d, kind)
            if d == 4:
                ed = end_dimension(actions)
                expected_ed = ((1 << d) - 2 + d if kind == 'E' else
                               (1 << d) - 1 if kind == 'J' else
                               (1 << d) + d - 1)
                assert ed == expected_ed, (kind, ed, expected_ed)
                item['endomorphism_dimension'] = ed
            records[f'd{d}_{kind}'] = item
        records[f'd{d}_semilinear'] = check_semilinear_lift(d)
    records['d4_F4_semilinear'] = check_f4_semilinear_lift(4)

    # Mixed-action controls: a polynomial direction coexists with Theta.
    d = 4
    for kind in ('S', 'E'):
        _, _, core_actions, theta = make_module(d, kind)
        w = len(theta)
        p = poly_action(core_actions, 1 | 4)
        for s in (1, 2, 3):
            pure = core_actions + [p] + [[0] * w for _ in range(s-1)]
            mixed = core_actions + [[a ^ b for a, b in zip(p, theta)]]
            mixed += [[0] * w for _ in range(s-1)]
            pure_h2 = cohomology(pure)[2]['dimension']
            mixed_h2 = cohomology(mixed)[2]['dimension']
            expected = d + 2*comb(d, 2) + s*(2*d+1) + 2*comb(s, 2)
            assert pure_h2 == expected
            assert mixed_h2 == expected - comb(s, 2)
            records[f'{kind}_s{s}_mixed'] = {
                'pure_H2': pure_h2, 'Theta_H2': mixed_h2,
                'loss': pure_h2 - mixed_h2}
    return records


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    result = controls()
    payload = {'status': 'PASS', 'field': 'F2',
               'scope': 'Exact F2 matrix ranks remain unchanged under extension to F_(2^a); '
                        'the separate d4_F4_semilinear check uses a genuine omega coefficient.',
               'python_version': platform.python_version(),
               'dependencies': 'Python standard library only',
               'checks': result}
    if args.report:
        with args.report.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(payload, indent=2) + '\n')
    print(json.dumps(payload, indent=2))

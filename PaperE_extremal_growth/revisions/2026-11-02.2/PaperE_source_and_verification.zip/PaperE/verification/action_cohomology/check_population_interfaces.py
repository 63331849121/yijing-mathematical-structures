"""Actual matrix controls for the general socle population bound.

Uses only the standard library.  Default: write nothing.  --report creates a
new JSON file and refuses to overwrite.  Finite controls do not replace the
uniform common-flag or cohomology proofs.
"""
from itertools import product, permutations
from math import comb, sqrt
from pathlib import Path
import argparse
import json
import platform


def rank(columns):
    pivots = {}
    for value in columns:
        while value:
            p = value.bit_length() - 1
            if p in pivots:
                value ^= pivots[p]
            else:
                pivots[p] = value
                break
    return len(pivots)


def apply(columns, value):
    out = 0
    while value:
        bit = value & -value
        out ^= columns[bit.bit_length() - 1]
        value ^= bit
    return out


def compose(left, right):
    return tuple(apply(left, col) for col in right)


def triangular_enumeration():
    records = {}
    previous = [1]
    for m in range(1, 6):
        positions = [(i, j) for j in range(m) for i in range(j)]
        counts = [0] * (m // 2 + 1)
        zero = (0,) * m
        for assignment in range(1 << len(positions)):
            cols = [0] * m
            for k, (i, j) in enumerate(positions):
                if assignment & (1 << k):
                    cols[j] ^= 1 << i
            if compose(cols, cols) == zero:
                counts[rank(cols)] += 1
        predicted = []
        for j in range(m // 2 + 1):
            keep = (1 << j) * (previous[j] if j < len(previous) else 0)
            increase = 0 if not j else ((1 << (m-j)) - (1 << (j-1))) * previous[j-1]
            predicted.append(keep + increase)
        assert counts == predicted
        for j, count in enumerate(counts):
            assert count <= comb(m, j) * (1 << (j * (m-j)))
        records[f'm{m}'] = {'all_triangular_matrices_examined': 1 << len(positions),
                             'actual_square_zero_counts_by_rank': counts,
                             'recurrence_matches_enumeration': True}
        previous = counts
    return records


def actual_common_flags():
    m = 3
    zero = (0,) * m
    # This enumerates all matrices, rather than matrices triangular in a
    # preselected flag; existence of a rational flag is the property tested.
    square_zero = [cols for cols in product(range(1 << m), repeat=m)
                   if compose(cols, cols) == zero]
    bases = [basis for basis in permutations(range(1, 1 << m), m)
             if rank(basis) == m]
    flags = []
    for basis in bases:
        spans = [{0}]
        for value in basis[:-1]:
            spans.append(spans[-1] | {x ^ value for x in spans[-1]})
        if spans not in flags:
            flags.append(spans)
    commuting_pairs = 0
    max_common_flag_choices = 0
    for a in square_zero:
        for b in square_zero:
            if compose(a, b) != compose(b, a):
                continue
            commuting_pairs += 1
            witnesses = 0
            for spans in flags:
                # The complete flag is F0=0, F1, F2, F3=k^3.
                all_spans = spans + [set(range(1 << m))]
                if all(apply(op, x) in all_spans[j-1]
                       for op in (a, b) for j in range(1, m+1)
                       for x in all_spans[j]):
                    witnesses += 1
            assert witnesses, (a, b)
            max_common_flag_choices = max(max_common_flag_choices, witnesses)
    assert len(flags) == 21
    return {'dimension': m, 'all_matrices_examined': 1 << (m*m),
            'square_zero_matrices': len(square_zero),
            'commuting_ordered_pairs_checked': commuting_pairs,
            'rational_complete_flags': len(flags),
            'every_pair_has_common_strict_flag': True,
            'max_common_flags_for_a_pair': max_common_flag_choices}


def grid_envelope():
    records = []
    g_steps, z_steps, x_steps = 200, 40, 40
    for alpha in (1.0, sqrt(2), 2.0, 4.0, 8.0):
        best, maximizer = float('-inf'), None
        for g in range(g_steps + 1):
            gamma = alpha * g / g_steps
            beta = alpha - gamma
            for z in range(z_steps + 1):
                zeta = beta * z / z_steps
                for x in range(x_steps + 1):
                    xi = zeta * x / (2*x_steps)
                    # Unreduced four-parameter upper exponent.
                    value = (gamma + beta*gamma*gamma/2
                             + gamma*(beta-zeta)*zeta
                             - (beta-zeta+xi)*gamma*gamma/2
                             + gamma*xi*(zeta-xi))
                    if value > best:
                        best = value
                        maximizer = (beta, gamma, zeta, xi)
        gamma_star = min(alpha, (alpha + sqrt(alpha*alpha+6))/3)
        beta_star = alpha - gamma_star
        exact = gamma_star + beta_star*gamma_star*gamma_star/2
        assert best <= exact + 1e-9
        assert exact - best <= alpha**3 / g_steps**2 + 1e-9
        assert abs(maximizer[1] - gamma_star) <= alpha / g_steps + 1e-9
        records.append({'alpha': alpha, 'full_objective_grid_max': best,
                        'grid_beta_gamma_zeta_xi': maximizer,
                        'proposed_maximum': exact,
                        'proposed_beta_gamma': [beta_star, gamma_star]})
    return {'gamma_grid_steps': g_steps, 'socle_grid_steps': z_steps,
            'rank_grid_steps': x_steps, 'records': records}


def controls():
    return {'status': 'PASS', 'field': 'F2 for exhaustive matrix controls',
            'scope': 'Actual triangular matrices and all commuting square-zero 3x3 pairs; '
                     'additional real-grid control of the full population objective. '
                     'No claim of proving uniform theorems by finite computation.',
            'python_version': platform.python_version(),
            'dependencies': 'Python standard library only',
            'triangular_counts': triangular_enumeration(),
            'rational_common_flags': actual_common_flags(),
            'continuous_envelope_grid': grid_envelope()}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    payload = controls()
    if args.report:
        with args.report.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(payload, indent=2) + '\n')
    print(json.dumps(payload, indent=2))

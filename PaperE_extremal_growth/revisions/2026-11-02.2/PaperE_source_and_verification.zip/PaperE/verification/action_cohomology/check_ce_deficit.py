"""Independent ordinary Chevalley--Eilenberg matrix controls.

All matrices have coefficients in F_2, hence the ranks are unchanged on
extension to any characteristic-two field, including the paper's F_4.
No previously saved paper certificate is used.
These controls cover split modules K plus a trivial h-space only; they
are independent finite checks, not a verification of the all-module proof.
The default run writes no files. --report uses exclusive creation.
"""
from itertools import combinations, product
import argparse
import json
from pathlib import Path
import platform


def rank(columns):
    pivots = {}
    for column in columns:
        while column:
            bit = column.bit_length() - 1
            if bit in pivots:
                column ^= pivots[bit]
            else:
                pivots[bit] = column
                break
    return len(pivots)


def apply(columns, vector):
    out = 0
    while vector:
        bit = (vector & -vector).bit_length() - 1
        vector &= vector - 1
        out ^= columns[bit]
    return out


def ce_differential(actions, degree, dimension):
    """Direct alternating-cochain differential for an abelian quotient."""
    quotient_dimension = len(actions)
    source = list(combinations(range(quotient_dimension), degree))
    target = list(combinations(range(quotient_dimension), degree + 1))
    target_index = {indices: i for i, indices in enumerate(target)}
    columns = []
    for indices in source:
        for basis in range(dimension):
            column = 0
            for extra in range(quotient_dimension):
                if extra in indices:
                    continue
                combined = tuple(sorted((*indices, extra)))
                column ^= actions[extra][basis] << (dimension * target_index[combined])
            columns.append(column)
    return columns


def module_actions(d, h, s, scenario):
    masks = [mask for mask in range(1 << d) if mask & ~1]
    index = {mask: i for i, mask in enumerate(masks)}
    dimension = len(masks) + h
    tau = index[(1 << d) - 1]

    def polynomial(mask):
        result = [0] * dimension
        for monomial, at in index.items():
            if not mask & monomial:
                result[at] = 1 << index[mask | monomial]
        return result

    actions = [polynomial(1 << i) for i in range(d)]
    degree_two = [sum(1 << i for i in indices) for indices in combinations(range(d), 2)]
    for a in range(s):
        action = polynomial(degree_two[a])
        if a == 0:
            if scenario == "nonzero_v":
                action[len(masks)] ^= 1 << tau
            elif scenario == "nonzero_C":
                assert h >= 2
                action[len(masks) + 1] ^= 1 << len(masks)
            elif scenario == "nonzero_C_and_v":
                assert h >= 2
                action[len(masks) + 1] ^= (1 << len(masks)) | (1 << tau)
        actions.append(action)
    socle_basis = [tau, *range(len(masks), dimension)]
    socle_projection = {basis: i for i, basis in enumerate(socle_basis)}
    residual = []
    for action in actions[d:]:
        columns = []
        for basis in socle_basis:
            image = action[basis]
            projected = sum(((image >> target) & 1) << out for target, out in socle_projection.items())
            assert image == sum(((projected >> out) & 1) << target for target, out in socle_projection.items())
            columns.append(projected)
        residual.append(columns)
    return actions, residual, dimension


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path,
                        help="Create a new JSON report; an existing path is never overwritten.")
    args = parser.parse_args()
    results = []
    for d, h, s in product([4], [1, 2], [2, 3]):
        scenarios = ["central", "nonzero_v"]
        if h >= 2:
            scenarios.extend(["nonzero_C", "nonzero_C_and_v"])
        for scenario in scenarios:
            actions, residual, dimension = module_actions(d, h, s, scenario)
            for action in actions:
                assert all(apply(action, image) == 0 for image in action)
            for left, right in combinations(actions, 2):
                assert all(apply(left, right[j]) == apply(right, left[j]) for j in range(dimension))
            rho = 0
            # F_2 coefficients suffice for these one-supported residual tuples;
            # all F_4 combinations are scalar multiples of the same matrix.
            for coefficients in product([0, 1], repeat=s):
                columns = [0] * (h + 1)
                for bit, action in zip(coefficients, residual):
                    if bit:
                        columns = [x ^ y for x, y in zip(columns, action)]
                rho = max(rho, rank(columns))
            d1 = ce_differential(actions, 1, dimension)
            d2 = ce_differential(actions, 2, dimension)
            assert all(apply(d2, column) == 0 for column in d1)
            r1, r2 = rank(d1), rank(d2)
            h2 = dimension * ((d + s) * (d + s - 1) // 2) - r1 - r2
            choose2 = lambda value: value * (value - 1) // 2
            a_bound = d + choose2(d) + s * (d + 1) + choose2(s) + h * choose2(d + s)
            target = a_bound - rho * choose2(s)
            assert h2 <= target
            record = dict(d=d, h=h, s=s, scenario=scenario, dimension_W=dimension,
                          rank_d1=r1, rank_d2=r2, H2=h2, rho=rho,
                          A=a_bound, proposed_upper=target, slack=target-h2,
                          square_zero=True, commuting=True, d2_d1_zero=True)
            results.append(record)
            print(json.dumps(record))
    report = dict(status="PASS", cases=len(results), python=platform.python_version(),
                  field="F2 coefficients; same ranks over F4",
                  scope="Independent finite split-module K plus trivial h-space controls; not the all-module theorem",
                  independent_controls=results)
    if args.report is not None:
        with args.report.open("x", encoding="utf-8") as stream:
            json.dump(report, stream, indent=2)
            stream.write("\n")
    print(json.dumps(dict(status="PASS", cases=len(results),
                         report=str(args.report) if args.report is not None else None,
                         scope=report["scope"])))


if __name__ == "__main__":
    main()

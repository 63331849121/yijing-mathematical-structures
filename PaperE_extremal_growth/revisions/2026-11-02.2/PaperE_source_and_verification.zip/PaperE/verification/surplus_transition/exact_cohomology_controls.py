"""Independent exact GF4 controls for the entire minimal-derived r=1 layer.

Builds ordinary CE matrices and all cocycle representatives afresh.
Checks full-coordinate substitutions and composition modulo coboundaries.
No imports from canonical verification or theorem construction programs.
"""
from pathlib import Path
from itertools import combinations
import json, random, time

HERE=Path(__file__).resolve().parent
RNG=random.Random(202610301977)
M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
INV=(0,1,3,2)

def vadd(a,b): return [x^y for x,y in zip(a,b)]
def scale(c,a):return [M[c][x] for x in a]

class Echelon:
    def __init__(self):self.rows={}
    def add(self,v):
        v=v[:]
        while any(v):
            j=next(i for i,x in enumerate(v) if x)
            if j in self.rows:
                v=vadd(v,scale(v[j],self.rows[j]))
            else:
                self.rows[j]=scale(INV[v[j]],v)
                return True
        return False
    def reduce(self,v):
        v=v[:]
        for j in sorted(self.rows):
            if v[j]:v=vadd(v,scale(v[j],self.rows[j]))
        return v
    def rank(self):return len(self.rows)

def matmul(A,B):
    out=[[0]*len(B[0]) for _ in A]
    for i in range(len(A)):
        for j in range(len(B[0])):
            for k in range(len(B)):out[i][j]^=M[A[i][k]][B[k][j]]
    return out

def invert(A):
    n=len(A);B=[row[:]+[int(i==j) for j in range(n)] for i,row in enumerate(A)]
    for j in range(n):
        i=next(i for i in range(j,n) if B[i][j]);B[j],B[i]=B[i],B[j]
        B[j]=scale(INV[B[j][j]],B[j])
        for i in range(n):
            if i!=j and B[i][j]:B[i]=vadd(B[i],scale(B[i][j],B[j]))
    return [row[n:] for row in B]

def random_gl(n):
    A=[[int(i==j) for j in range(n)] for i in range(n)]
    for _ in range(3*n):
        i,j=RNG.sample(range(n),2);c=RNG.randrange(1,4)
        A[i]=vadd(A[i],scale(c,A[j]))
    for i in range(n):A[i]=scale(RNG.randrange(1,4),A[i])
    return A

class Ring:
    def __init__(self,d):
        self.d=d;self.n=1<<d;self.z=self.n-2;self.tau=self.n-1
        self.K=[s for s in range(self.n) if s&self.z]
        self.P=[s for s in range(self.n) if s.bit_count()>=2 and s not in(self.z,self.tau)]
        self.zero=[0]*self.n
        self.t=[self.mono(1<<i) for i in range(d)]
    def mono(self,s,c=1):
        out=self.zero[:];out[s]=c;return out
    def mul(self,a,b):
        out=self.zero[:]
        for s,x in enumerate(a):
            if x:
                for t,y in enumerate(b):
                    if y and not s&t:out[s|t]^=M[x][y]
        return out
    def Q(self,p):
        p=p[:];p[self.z]=p[self.tau]=0;return p
    def eval(self,p,images):
        out=self.zero[:]
        for s,c in enumerate(p):
            if c:
                term=self.mono(0,c)
                for i in range(self.d):
                    if s>>i&1:term=self.mul(term,images[i])
                out=vadd(out,term)
        return out
    def parameter(self):
        out=self.zero[:]
        for s in self.P:out[s]=RNG.randrange(4)
        return out
    def divide_p(self,p):
        a=[self.zero[:] for _ in range(self.d)]
        for s,c in enumerate(p):
            if c:
                i=next(i for i in range(1,self.d) if s>>i&1)
                a[i][s^(1<<i)]^=c
        out=self.zero[:]
        for i in range(self.d):out=vadd(out,self.mul(self.t[i],a[i]))
        assert out==p
        return a

def flatten(R,b):return [b[e][s] for e in sorted(b) for s in R.K]
def unflatten(R,vec):
    pairs=list(combinations(range(R.d+1),2));b={};k=0
    for e in pairs:
        v=R.zero[:]
        for s in R.K:v[s]=vec[k];k+=1
        b[e]=v
    return b

def build_basis(R,p):
    d=R.d;a=R.divide_p(p);pairs=list(combinations(range(d),2))
    core=[];names=[]
    b={e:R.zero[:] for e in pairs}
    for i in range(1,d):b[(0,i)]=R.t[i]
    core.append(b);names.append('eta')
    for j in range(1,d):
        b={e:R.zero[:] for e in pairs}
        for i,k in pairs:
            if i>=1:
                if i==j:b[(i,k)]=R.mul(R.t[0],R.t[k])
                if k==j:b[(i,k)]=R.mul(R.t[0],R.t[i])
        core.append(b);names.append('kappa'+str(j))
    for i,j in pairs:
        b={e:R.zero[:] for e in pairs};b[(i,j)]=R.mono(R.tau^(1<<i)^(1<<j))
        core.append(b);names.append('lambda'+str((i,j)))
    basis=[]
    for b in core:
        full={e:poly[:] for e,poly in b.items()}
        for i in range(d):
            value=R.zero[:]
            for j in range(d):
                if i!=j:value=vadd(value,R.mul(a[j],b[tuple(sorted((i,j)))]))
            full[(i,d)]=value
        basis.append(full)
    extra=[(R.zero[:] if i==0 else R.mul(R.t[0],R.t[i])) for i in range(d)]
    for j in range(-1,d):
        full={e:R.zero[:] for e in combinations(range(d+1),2)}
        for i in range(d):full[(i,d)]=extra[i] if j==-1 else R.mono(R.tau^(1<<j)) if i==j else R.zero[:]
        basis.append(full);names.append('epsilon' if j==-1 else 'rho'+str(j))
    return names,basis

def differential(R,actions,b):
    out=[]
    for i,j,k in combinations(range(len(actions)),3):
        val=vadd(vadd(R.mul(actions[i],b[(j,k)]),R.mul(actions[j],b[(i,k)])),R.mul(actions[k],b[(i,j)]))
        out.extend(val[s] for s in R.K)
    return out

def coboundaries(R,p):
    actions=R.t+[p];n=len(actions);out=[]
    for j in range(n):
        for s in R.K:
            w=R.mono(s);b={}
            for i,k in combinations(range(n),2):
                value=R.zero[:]
                if j==i:value=vadd(value,R.mul(actions[k],w))
                if j==k:value=vadd(value,R.mul(actions[i],w))
                b[(i,k)]=value
            out.append(flatten(R,b))
    return out

def check_complete(R,p):
    names,basis=build_basis(R,p);actions=R.t+[p]
    boundaries=Echelon()
    for v in coboundaries(R,p):boundaries.add(v)
    full=Echelon()
    for v in coboundaries(R,p):full.add(v)
    for b in basis:
        assert not any(differential(R,actions,b))
        assert full.add(flatten(R,b)),'dependent H2 representative'
    d2=Echelon();n=R.d+1
    for e in combinations(range(n),2):
        for s in R.K:
            b={key:R.zero[:] for key in combinations(range(n),2)};b[e]=R.mono(s)
            d2.add(differential(R,actions,b))
    closed_dim=len(list(combinations(range(n),2)))*len(R.K)-d2.rank()
    assert full.rank()==closed_dim
    assert len(basis)==2*R.d+R.d*(R.d-1)//2+1
    z1=(R.d+1)*len(R.K)-boundaries.rank()
    h1=z1-(len(R.K)-1)
    assert h1==R.d+2
    return names,basis,boundaries,{'H2':len(basis),'H1':h1,'Z1':z1,'boundaries':boundaries.rank(),'closed':closed_dim,'d2_rank':d2.rank()}

def random_group(R):
    d=R.d;B=[[0]*d for _ in range(d)];B[0][0]=RNG.randrange(1,4)
    MH=random_gl(d-1)
    for i in range(1,d):
        B[i][0]=RNG.randrange(4)
        for j in range(1,d):B[i][j]=MH[i-1][j-1]
    alpha=[RNG.randrange(4) for _ in range(d)];delta=RNG.randrange(1,4)
    return B,alpha,delta

def full_matrix(g):
    B,alpha,delta=g;d=len(B)
    return [row+[0] for row in B]+[alpha+[delta]]

def compose(g2,g1):
    A=matmul(full_matrix(g2),full_matrix(g1));d=len(A)-1
    return [row[:d] for row in A[:d]],A[d][:d],A[d][d]

def transform_parameter(R,p,g):
    B,alpha,delta=g;ell=[]
    for i in range(R.d):
        val=R.zero[:]
        for j in range(R.d):val=vadd(val,scale(B[j][i],R.t[j]))
        ell.append(val)
    p1=R.zero[:]
    for iteration in range(R.d+2):
        images=[vadd(ell[i],scale(alpha[i],p1)) for i in range(R.d)]
        new=scale(INV[delta],R.Q(R.eval(p,images)))
        if new==p1:break
        p1=new
    else:raise AssertionError('implicit equation failed to stabilize')
    assert all(not p1[s] for s in range(R.n) if s not in R.P)
    images=[vadd(ell[i],scale(alpha[i],p1)) for i in range(R.d)]
    assert R.Q(R.eval(p,images))==scale(delta,p1)
    assert all(not x for s,x in enumerate(R.eval(R.mono(R.z),images)) if s not in(R.z,R.tau))
    return p1,images

def transform_cocycle(R,b,g,images):
    Ainv=invert(full_matrix(g));n=R.d+1;out={}
    for i,j in combinations(range(n),2):
        value=R.zero[:]
        for a,k in combinations(range(n),2):
            coefficient=M[Ainv[a][i]][Ainv[k][j]]^M[Ainv[k][i]][Ainv[a][j]]
            if coefficient:value=vadd(value,scale(coefficient,b[(a,k)]))
        out[(i,j)]=scale(g[0][0][0],R.eval(value,images))
    return out

def main():
    started=time.monotonic();records=[]
    # d=4 includes the exceptional overlap of core kappa/lambda degrees.
    for d,cases in ((4,7),(5,5)):
        R=Ring(d)
        for case in range(cases):
            p=R.parameter() if case else R.zero[:]
            names,basis,boundaries,rec=check_complete(R,p)
            g1=random_group(R);g2=random_group(R);g=compose(g2,g1)
            p1,im1=transform_parameter(R,p,g1);p2,im2=transform_parameter(R,p1,g2);p3,im3=transform_parameter(R,p,g)
            assert p2==p3
            _,basis2,bound2,targetrec=check_complete(R,p2)
            targetfull=Echelon()
            for b in coboundaries(R,p2):targetfull.add(b)
            for b in basis2[1:]:targetfull.add(flatten(R,b))
            for j,b in enumerate(basis):
                b1=transform_cocycle(R,b,g1,im1)
                b12=transform_cocycle(R,b1,g2,im2)
                b3=transform_cocycle(R,b,g,im3)
                assert not any(differential(R,R.t+[p2],b3))
                diff=flatten(R,{key:vadd(b12[key],b3[key]) for key in b3})
                assert not any(bound2.reduce(diff)), 'composition differed nontrivially in H2'
                # eta is exactly preserved, including the p=0 boundary.
                subtract=flatten(R,{key:vadd(b3[key],basis2[0][key] if j==0 else R.zero) for key in b3})
                assert not any(targetfull.reduce(subtract)), 'eta normalization failed'
                # Every principal unit acts trivially on ordinary H2.
                unit=[RNG.randrange(4) for _ in range(R.n)];unit[0]=1
                unit[R.z]=unit[R.tau]=0
                unitdiff={key:vadd(R.mul(unit,b[key]),b[key]) for key in b}
                assert not any(boundaries.reduce(flatten(R,unitdiff)))
            rec.update(d=d,case=case,parameter_nonzero=any(p),all_H2_basis_composition='PASS',eta_normalization='PASS')
            records.append(rec)
    out={'status':'PASS','records':records,'seconds':time.monotonic()-started,
         'scope':'Independent exact GF4 CE ranks, complete cocycle bases and full quotient-group composition modulo coboundaries for selected parameters d4,5; not a generic-freeness or counting-asymptotic proof.'}
    (HERE/'exact_cohomology_controls.json').write_text(json.dumps(out,indent=2),encoding='utf8')
    print(json.dumps(out))

if __name__=='__main__':main()

"""Independent controls for the characteristic-quotient counting interface.

Rebuilds actual Lie brackets over F4, including all 64 three-input/one-
central-coordinate tensors at d=4, selected larger core models, and two
arbitrary changes of basis mixing core and added coordinates. The general
asymptotic proof is separate; these checks do not prove it or its priority.
"""
from pathlib import Path
from itertools import combinations
from math import comb, isqrt
from fractions import Fraction
import json, random, time

HERE = Path(__file__).resolve().parent
RNG = random.Random(202610301817)


def fm(a,b):
    out=0
    while b:
        if b&1:out^=a
        b>>=1;a<<=1
        if a&4:a^=7
    return out


M=[[fm(a,b) for b in range(4)] for a in range(4)]
INV=[0,1,3,2]


def terms(v):
    while v:
        j=((v&-v).bit_length()-1)//2
        c=(v>>(2*j))&3
        yield j,c
        v&=~(3<<(2*j))


def scale(c,v):
    if c==0:return 0
    if c==1:return v
    out=0
    for j,a in terms(v):out|=M[c][a]<<(2*j)
    return out


def basis(vectors):
    piv={}
    for v in vectors:
        while v:
            j=(v.bit_length()-1)//2;c=(v>>(2*j))&3
            if j in piv:v^=scale(c,piv[j])
            else:
                piv[j]=scale(INV[c],v);break
    return [piv[j] for j in sorted(piv)]


class Algebra:
    def __init__(self,table):self.T=table;self.n=len(table)
    def br_basis(self,i,v):
        out=0
        for j,c in terms(v):out^=scale(c,self.T[i][j])
        return out
    def br(self,v,w):
        out=0
        for i,c in terms(v):out^=scale(c,self.br_basis(i,w))
        return out
    def lower(self):
        layer=basis(self.T[i][j] for i,j in combinations(range(self.n),2))
        layers=[[1<<(2*i) for i in range(self.n)],layer]
        while layer:
            layer=basis(self.br_basis(i,v) for i in range(self.n) for v in layer)
            layers.append(layer)
            assert len(layers)<self.n+2
        return layers
    def validate(self):
        for i,j,k in combinations(range(self.n),3):
            assert (self.br_basis(i,self.T[j][k])^
                    self.br_basis(j,self.T[k][i])^
                    self.br_basis(k,self.T[i][j]))==0
        layers=self.lower();W=layers[1]
        assert all(self.br(v,w)==0 for v,w in combinations(W,2))
        for i in range(self.n):
            assert all(self.br_basis(i,self.br_basis(i,v))==0 for v in W)
        # Restricted adjoints commute on W by Jacobi and [W,W]=0.
        # Their individual square-zero equations hence imply the strong
        # identity for every F4-linear combination, not only basis inputs.
        return layers


def make_model(d,u,w,tensor):
    masks=list(range(2,1<<d));ix={S:d+j for j,S in enumerate(masks)}
    core=d+len(masks);n=core+u+w
    T=[[0]*n for _ in range(n)]
    def put(i,j,v):T[i][j]=v;T[j][i]=v
    for i in range(1,d):put(0,i,1<<(2*ix[1<<i]))
    for i in range(d):
        for S in masks:
            if not(S&(1<<i)):put(i,ix[S],1<<(2*ix[S|(1<<i)]))
    pairs=list(combinations(range(u),2))
    for (i,j),coeffs in zip(pairs,tensor):
        put(core+i,core+j,sum(c<<(2*(core+u+a)) for a,c in enumerate(coeffs)))
    return Algebra(T),core,masks,ix


def tensor_rank(tensor):
    return len(basis(sum(c<<(2*j) for j,c in enumerate(row)) for row in tensor))


def mixed_change(A):
    """Apply a full invertible coordinate change, not a block-preserving one."""
    n=A.n;columns=[1<<(2*i) for i in range(n)]
    for _ in range(2*n):
        i,j=RNG.sample(range(n),2)
        columns[j]^=scale(RNG.randrange(1,4),columns[i])
    columns[0],columns[-1]=columns[-1],columns[0]
    piv={}
    for j,v in enumerate(columns):
        tag=1<<(2*j)
        while v:
            p=(v.bit_length()-1)//2;c=(v>>(2*p))&3
            if p in piv:
                v^=scale(c,piv[p][0]);tag^=scale(c,piv[p][1])
            else:
                inv=INV[c];piv[p]=(scale(inv,v),scale(inv,tag));break
        assert v
    assert len(piv)==n
    def coordinates(v):
        out=0
        while v:
            p=(v.bit_length()-1)//2;c=(v>>(2*p))&3
            v^=scale(c,piv[p][0]);out^=scale(c,piv[p][1])
        return out
    assert all(coordinates(v)==1<<(2*j) for j,v in enumerate(columns))
    T=[[0]*n for _ in range(n)]
    for i,j in combinations(range(n),2):
        T[i][j]=coordinates(A.br(columns[i],columns[j]));T[j][i]=T[i][j]
    return Algebra(T),columns


def check_model(d,u,w,tensor,change=False):
    A,core,masks,ix=make_model(d,u,w,tensor)
    layers=A.validate();dims=list(map(len,layers));rank_b=tensor_rank(tensor)
    expected=[A.n,(1<<d)-2+rank_b]
    expected.extend(sum(comb(d,k) for k in range(j-1,d+1)) for j in range(3,d+2))
    expected.append(0)
    assert dims==expected,(d,u,w,dims,expected)
    expected_g3=[1<<(2*ix[S]) for S in masks if S.bit_count()>=2]
    assert len(basis(layers[2]+expected_g3))==len(expected_g3)==len(layers[2])
    assert all(v>>(2*core)==0 for v in layers[2])
    quotient_dim=A.n-len(layers[2])
    assert quotient_dim==u+w+2*d-1
    # Read every added tensor entry directly from the characteristic quotient.
    # Gamma_3 lies in the old core, so no central added coordinate is lost.
    recovered=[]
    for i,j in combinations(range(u),2):
        value=A.T[core+i][core+j]
        assert value&((1<<(2*(core+u)))-1)==0
        recovered.append([(value>>(2*(core+u+a)))&3 for a in range(w)])
    assert recovered==tensor
    changed=False
    if change:
        B,columns=mixed_change(A);bl=B.lower()
        assert list(map(len,bl))==dims
        transported=[]
        for v in bl[2]:
            out=0
            for j,c in terms(v):out^=scale(c,columns[j])
            transported.append(out)
        assert len(basis(transported+layers[2]))==len(layers[2])
        changed=True
    return {'d':d,'two_step_input':u,'two_step_central':w,'tensor_rank':rank_b,
            'full_dimension':A.n,'lower_central_dimensions':dims,
            'characteristic_quotient_dimension':quotient_dim,
            'labelled_tensor_recovered':True,'mixed_coordinate_check':changed,
            'status':'PASS'}


def arithmetic_controls():
    branches=0
    for d in range(4,25):
        n=1<<d;C=comb(d,2);w0=n-2
        for r in range(1,65):
            lower=r*n-d*d-2*d*r-r*r-3*r-1
            T=3*C+d*d+5*d*r+3*r*r+2*r+2
            for h in range(1,r+1):
                s=r-h
                F=(2*h+1)*C+d*(h*h+2*s*h+s+1)+s*h*h+r+comb(s,2)*(h+1)
                # log_q(h+1)<=h/2; use doubled integer exponents.
                assert 2*(s*w0+F-lower)+h<=-2*h*(w0-T)
                branches+=1
    growth=0
    for d in range(16,71):
        n=1<<d;root=isqrt(n);C=comb(d,2)
        rs={1,2,root//2,root,root+1,2*root,n,3*n}
        for r in sorted(rs):
            upper=r*(n-2)+(2*r+1)*C+(r*r+r+1)*d+(3*r**3+r)//2+r
            assert upper<=5*(r*n+r**3)
            if r*r<=n:
                assert r<=n-d-3
                lower=r*n-d*d-2*d*r-r*r-3*r-1
            else:
                u=2*r//3;w=r-u;m=r+2*d-1
                lower=w*comb(u,2)-m*m
            assert 54*lower>=r*n+r**3
            growth+=1
    products=0
    for q in (4,8,16):
        prod=Fraction(1)
        for j in range(1,33):
            prod*=1-Fraction(1,q**j)
            assert prod>=Fraction(2,3)
            products+=1
    return {'branch_exponent_checks':branches,'uniform_growth_checks':growth,
            'exact_product_checks':products,'status':'PASS'}


def main():
    started=time.monotonic();records=[];signatures=set()
    for code in range(64):
        tensor=[[(code>>(2*j))&3] for j in range(3)]
        rec=check_model(4,3,1,tensor,change=(code==1))
        signatures.add(tuple(tuple(row) for row in tensor));records.append(rec)
    assert len(signatures)==64
    for d,u,w,count in ((4,4,2,8),(5,3,2,6),(6,3,1,2)):
        for j in range(count):
            tensor=[[RNG.randrange(4) for _ in range(w)] for _ in combinations(range(u),2)]
            records.append(check_model(d,u,w,tensor,change=(d==5 and j==0)))
    out={'status':'PASS','field':'F4; X^2+X+1',
         'model_count':len(records),'exhaustive_small_tensor_count':64,
         'mixed_coordinate_checks':sum(r['mixed_coordinate_check'] for r in records),
         'records':records,'arithmetic':arithmetic_controls(),
         'scope':'Actual bracket, Jacobi, derived and lower central reconstruction; square-zero action on derived; characteristic quotient and labelled-tensor recovery; selected full coordinate changes. General asymptotic proof and priority are separate.',
         'seconds':round(time.monotonic()-started,3)}
    (HERE/'transition_quotient_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({key:out[key] for key in ('status','model_count','exhaustive_small_tensor_count','mixed_coordinate_checks','seconds')}))


if __name__=='__main__':main()

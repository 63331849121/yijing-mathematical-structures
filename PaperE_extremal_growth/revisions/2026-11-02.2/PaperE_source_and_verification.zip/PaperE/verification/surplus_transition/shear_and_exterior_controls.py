"""Independent finite controls for the r=1 stabilizer estimates.

Exhaustive F4 pure-shear fixed sets at d=4, exhaustive multiplier ranks
in three square-zero variables, and selected exterior fixed-rank checks
over F4/F8/F16. No construction or checker from the manuscript is imported.
These controls do not prove the asymptotic or replace the written argument.
"""
from pathlib import Path
from array import array
from itertools import product
from math import comb
import random,json,time

HERE=Path(__file__).resolve().parent
RNG=random.Random(202610302033)


class Field:
    def __init__(self,m,modulus):
        self.m=m;self.q=1<<m
        def mul(a,b):
            out=0
            while b:
                if b&1:out^=a
                b>>=1;a<<=1
                if a&self.q:a^=modulus
            return out
        self.M=[[mul(a,b) for b in range(self.q)] for a in range(self.q)]
        self.inv=[0]+[next(b for b in range(1,self.q) if self.M[a][b]==1) for a in range(1,self.q)]
    def terms(self,v):
        while v:
            j=((v&-v).bit_length()-1)//self.m
            c=(v>>(self.m*j))&(self.q-1)
            yield j,c
            v&=~((self.q-1)<<(self.m*j))
    def scale(self,c,v):
        if c==1:return v
        if not c:return 0
        return sum(self.M[c][a]<<(self.m*j) for j,a in self.terms(v))
    def rank(self,columns):
        piv={}
        for value in columns:
            while value:
                j=(value.bit_length()-1)//self.m
                c=(value>>(self.m*j))&(self.q-1)
                if j in piv:value^=self.scale(c,piv[j])
                else:
                    piv[j]=self.scale(self.inv[c],value)
                    break
        return len(piv)


F4=Field(2,7)


def bit_multipliers(d):
    n=1<<d
    table=[]
    for S in range(n):
        row=array('H',[0])*(1<<n)
        for value in range(1,1<<n):
            bit=value&-value;j=bit.bit_length()-1
            term=0 if S&j else 1<<(S|j)
            row[value]=row[value^bit]^term
        table.append(row)
    def mul(a,b):
        out=0
        while a:
            bit=a&-a;out^=table[bit.bit_length()-1][b];a^=bit
        return out
    return mul


def binary_vectors(masks):
    values=[0]
    for mask in masks:values += [value^(1<<mask) for value in values]
    return values


def derivative(v,i):
    out=0
    while v:
        bit=v&-v;mask=bit.bit_length()-1;v^=bit
        if mask&(1<<i):out^=1<<(mask^(1<<i))
    return out


def exhaustive_shears():
    d=4;n=1<<d;z=n-2;tau=n-1
    masks=[S for S in range(n) if S.bit_count()>=2 and S not in (z,tau)]
    assert len(masks)==9
    vectors=binary_vectors(masks);mul=bit_multipliers(d)
    outside=((1<<n)-1)^((1<<z)|(1<<tau))
    records=[]
    for i in (0,1):
        ds=[derivative(v,i) for v in vectors]
        same=[mul(v,dv) for v,dv in zip(vectors,ds)]
        fixed=0;nonlinear_witness=None
        for a,da,aa in zip(vectors,ds,same):
            for b,db,bb in zip(vectors,ds,same):
                real=aa^bb
                imag=mul(a,db)^mul(b,da)^bb
                if not ((real|imag)&outside):fixed+=1
                elif nonlinear_witness is None:nonlinear_witness=[a,b,real,imag]
        # Independently verify every p=a+t0*b using its S-decomposition.
        # This checks the direction changing outside the I-preserving class
        # as well as the direction which preserves I.
        for _ in range(256):
            a=RNG.choice(vectors);b=RNG.choice(vectors)
            da=derivative(a,i);db=derivative(b,i)
            lhs=(mul(a,da)^mul(b,db),mul(a,db)^mul(b,da)^mul(b,db))
            no_i_a=sum((1<<S) for S in range(n) if not(S&(1<<i)) and (a>>S)&1)
            no_i_b=sum((1<<S) for S in range(n) if not(S&(1<<i)) and (b>>S)&1)
            rhs=(mul(no_i_a,da)^mul(no_i_b,db),
                 mul(no_i_a,db)^mul(no_i_b,da)^mul(no_i_b,db))
            assert lhs==rhs
        records.append({'d':d,'direction':i,'parameters':len(vectors)**2,
                        'fixed_including_zero':fixed,'fixed_nonzero':fixed-1,
                        'nonlinear_witness':nonlinear_witness,'status':'PASS'})
    return records


def exhaustive_multiplier_ranks():
    m=3;n=1<<m;vectors=binary_vectors(list(range(1,n)))
    mul=bit_multipliers(m);counts={};total=0
    for a in vectors:
        for b in vectors:
            if not(a|b):continue
            support=[S for S in range(n) if ((a|b)>>S)&1]
            j=min(S.bit_count() for S in support)
            cols=[]
            for S in range(n):
                ra=mul(1<<S,a);rb=mul(1<<S,b)
                cols.append(sum((((ra>>T)&1)+2*((rb>>T)&1))<<(2*T) for T in range(n)))
            rank=F4.rank(cols)
            assert rank >= 2**(m-j),(a,b,j,rank)
            counts[f'lowest_degree_{j}_rank_{rank}']=counts.get(f'lowest_degree_{j}_rank_{rank}',0)+1
            total+=1
    assert total==4**(n-1)-1
    return {'variables':m,'nonzero_multipliers':total,'rank_strata':counts,'status':'PASS'}


def poly_mul(f, a,b):
    out=0
    for S,c in f.terms(a):
        for T,e in f.terms(b):
            if not(S&T):out^=f.M[c][e]<<(f.m*(S|T))
    return out


def exterior_controls():
    records=[]
    for f in (F4,Field(3,11),Field(4,19)):
        for d in (4,5,6):
            n=1<<d
            for kind in ('transvection','scalar','mixed'):
                B=[[int(i==j) for j in range(d)] for i in range(d)]
                if kind=='transvection':B[0][1]=1
                elif kind=='scalar':B=[[2*int(i==j) for j in range(d)] for i in range(d)]
                else:
                    for _ in range(2*d):
                        i,j=RNG.sample(range(d),2);c=RNG.randrange(1,f.q)
                        B[i]=[a^f.M[c][b] for a,b in zip(B[i],B[j])]
                delta=1 if kind=='transvection' else 2
                images=[sum(B[i][j]<<(f.m*(1<<i)) for i in range(d)) for j in range(d)]
                columns=[]
                for S in range(n):
                    value=1
                    for j in range(d):
                        if S&(1<<j):value=poly_mul(f,value,images[j])
                    columns.append(value^(delta<<(f.m*S)))
                rank=f.rank(columns)
                assert rank>=2**(d-2)
                # Full exterior identity and fixed-rank bound, independent
                # of the parabolic restriction used by the exact orbit model.
                v=1<<0
                for _ in range(12):
                    x=sum(RNG.randrange(f.q)<<(f.m*S) for S in range(n))
                    Ax=0
                    for S,c in f.terms(x):Ax^=f.scale(c,columns[S])
                    xv=poly_mul(f,x,1<<(f.m*v));Axv=0
                    for S,c in f.terms(xv):Axv^=f.scale(c,columns[S])
                    lhs=Axv^poly_mul(f,images[0],Ax)
                    rhs=f.scale(delta,poly_mul(f,images[0]^(1<<(f.m*v)),x))
                    assert lhs==rhs
                records.append({'q':f.q,'d':d,'linear_map':kind,
                    'full_exterior_rank':rank,'uniform_lower_bound':2**(d-2),'status':'PASS'})
    return records


if __name__=='__main__':
    started=time.monotonic()
    shear=exhaustive_shears()
    rank=exhaustive_multiplier_ranks()
    exterior=exterior_controls()
    report={'status':'PASS','exhaustive_pure_shears':shear,
        'multiplier_rank':rank,'exterior_cases':exterior,
        'scope':'Independent exact finite algebra controls, not an extrapolation or a formal proof of the uniform asymptotic.',
        'seconds':round(time.monotonic()-started,3)}
    (HERE/'shear_and_exterior_controls.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'status':'PASS','pure_shear_parameters':sum(x['parameters'] for x in shear),
        'nonzero_multipliers':rank['nonzero_multipliers'],'exterior_cases':len(exterior),
        'seconds':report['seconds']}))

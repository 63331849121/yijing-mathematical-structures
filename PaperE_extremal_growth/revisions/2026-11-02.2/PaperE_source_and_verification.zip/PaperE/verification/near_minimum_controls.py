"""Independent finite controls for the surplus-two family and recovery lemma.

No existing construction/checker is imported. General proofs are separate.
One class-five model is checked on every binary input of weight <=4;
composition has degree <=4, so that finite functional check is lossless.
Other records explicitly label selected parameters and randomized actions.
"""
from pathlib import Path
from itertools import combinations
from math import comb, prod
import json
import random
import time

HERE = Path(__file__).resolve().parent
RNG = random.Random(2026103097)


def field_mul(a, b):
    out = 0
    while b:
        if b & 1:
            out ^= a
        b >>= 1
        a <<= 1
        if a & 4:
            a ^= 7
    return out


MUL = [[field_mul(a,b) for b in range(4)] for a in range(4)]
INV = [0,1,3,2]


class Ring:
    def __init__(self, d):
        self.d = d
        self.n = 1 << d
        self.tau = self.n - 1
        self.z = self.tau ^ 1
        self.even = sum(1 << (2*i) for i in range(self.n))
        self.k_masks = [i for i in range(self.n) if i & ~1]
        self.a_masks = [i for i in range(self.n) if i not in (self.z,self.tau)]
        self.parameter_masks = [i for i in self.a_masks if i.bit_count() >= 2]
        self.i_bits = (3 << (2*self.z)) | (3 << (2*self.tau))
        self.t = [1 << (2*(1 << i)) for i in range(d)]

    def scale(self, a, p):
        if a == 0: return 0
        if a == 1: return p
        low = p & self.even
        high = (p >> 1) & self.even
        omega_p = high ^ ((low ^ high) << 1)
        return omega_p if a == 2 else omega_p ^ p

    def terms(self, p):
        while p:
            index = ((p & -p).bit_length()-1)//2
            a = (p >> (2*index)) & 3
            yield index, a
            p ^= a << (2*index)

    def mul(self, p, q):
        out = 0
        for i,a in self.terms(p):
            for j,b in self.terms(q):
                if not i & j:
                    out ^= MUL[a][b] << (2*(i|j))
        return out

    def quotient(self, p):
        return p & ~self.i_bits

    def derivative(self, p, i):
        out = 0
        for mask,a in self.terms(p):
            if mask & (1 << i):
                out ^= a << (2*(mask ^ (1 << i)))
        return out

    def substitute(self, p, images):
        out = 0
        for mask,a in self.terms(p):
            term = 1
            for i in range(self.d):
                if mask & (1 << i):
                    term = self.mul(term,images[i])
            out ^= self.scale(a,term)
        return out

    def sample_parameter(self):
        return sum(RNG.randrange(4) << (2*i) for i in self.parameter_masks)


def rank(vectors, ring):
    pivots = {}
    for vector in vectors:
        while vector:
            j = ((vector & -vector).bit_length()-1)//2
            a = (vector >> (2*j)) & 3
            if j in pivots:
                vector ^= ring.scale(a,pivots[j])
            else:
                pivots[j] = ring.scale(INV[a],vector)
                break
    return len(pivots)


def rank_binary(vectors):
    pivots = {}
    for vector in vectors:
        while vector:
            j = vector.bit_length()-1
            if j in pivots:
                vector ^= pivots[j]
            else:
                pivots[j] = vector
                break
    return len(pivots)


def invertible_matrix(d):
    # Product of elementary invertible matrices, with column convention.
    out = [[int(i==j) for j in range(d)] for i in range(d)]
    for _ in range(3*d):
        i,j = RNG.sample(range(d),2)
        a = RNG.randrange(1,4)
        for k in range(d):
            out[k][i] ^= MUL[a][out[k][j]]
    for i in range(d):
        a=RNG.randrange(1,4)
        for j in range(d): out[j][i]=MUL[a][out[j][i]]
    return out


def check_recovery(r, p):
    B = invertible_matrix(r.d)
    alpha = [RNG.randrange(4) for _ in range(r.d)]
    delta = RNG.randrange(1,4)
    ell = [sum(B[j][i] << (2*(1<<j)) for j in range(r.d))
           for i in range(r.d)]
    pp = r.quotient(r.substitute(p,ell))
    derivative = 0
    for i in range(r.d):
        derivative ^= r.scale(alpha[i],r.substitute(r.derivative(p,i),ell))
    derivative = r.quotient(derivative)
    assert derivative & 3 == 0 and r.quotient(r.mul(derivative,derivative)) == 0
    inverse = INV[delta] ^ r.scale(MUL[INV[delta]][INV[delta]],derivative)
    assert r.quotient(r.mul(delta ^ derivative,inverse)) == 1
    q = r.quotient(r.mul(inverse,pp))
    images = [ell[i] ^ r.scale(alpha[i],q) for i in range(r.d)]
    actual = r.quotient(r.substitute(p,images))
    assert actual == r.scale(delta,q)
    assert q == 0 or all(mask in r.parameter_masks for mask,_ in r.terms(q))
    return q


def action_and_shape(r, p):
    # Faithful action columns flattened over all basis elements of K.
    actions = r.t + [p]
    cols = []
    for a in actions:
        col=0
        for i,mask in enumerate(r.k_masks):
            col ^= r.mul(a,1 << (2*mask)) << (2*r.n*i)
        cols.append(col)
    large_ring = Ring((len(r.k_masks)*r.n).bit_length())
    # Avoid constructing a large auxiliary mask: rank scaling only needs
    # the packed even-position mask of these finite columns.
    large_ring.even = sum(1 << (2*i) for i in range(len(r.k_masks)*r.n))
    assert rank(cols,large_ring) == r.d + int(bool(p))
    # Intrinsic generation and the full lower central filtration.
    gamma = r.k_masks[:]
    dims = [2*(r.d+1+len(gamma)),2*len(gamma)]
    while gamma:
        generated = {mask | (1<<i) for mask in gamma for i in range(r.d)
                     if not mask & (1<<i)}
        # The new action cannot add smaller-degree terms than the core.
        for mask in gamma:
            product = r.mul(p,1 << (2*mask))
            assert all(support in generated for support,_ in r.terms(product))
        gamma = sorted(generated)
        dims.append(2*len(gamma))
    assert len(dims)-1 == r.d+1
    # In K the common kernel of the ti is exactly its unique top monomial.
    central_masks = [mask for mask in r.k_masks if all(mask & (1<<i) for i in range(r.d))]
    assert central_masks == [r.tau]
    # Jacobi on every distinct quotient-basis triple, including v.
    for i,j,k in combinations(range(r.d+1),3):
        def beta(a,b):
            if a > b: a,b=b,a
            return actions[b] if a==0 else 0
        assert r.mul(actions[i],beta(j,k)) ^ r.mul(actions[j],beta(i,k)) ^ r.mul(actions[k],beta(i,j)) == 0
    assert all(r.mul(a,a)==0 for a in actions)
    return dims


def map_function(r, p):
    shift = 2*(r.d+1)
    core_mask = (1 << shift)-1
    even_core = sum(1 << (2*i) for i in range(r.d+1))
    def f(x):
        core, w = x & core_mask, x >> shift
        a = core & 3
        b = r.scale((core >> (2*r.d)) & 3,p)
        for i in range(1,r.d):
            b ^= ((core >> (2*i)) & 3) << (2*(1<<i))
        action = r.scale(a,r.t[0]) ^ b
        z = r.scale(2,w) ^ r.mul(action,w) ^ r.scale(a,b)
        z ^= r.scale(MUL[a][a],r.mul(r.t[0],b))
        low,high = core & even_core,(core>>1)&even_core
        omega_core = high ^ ((low^high)<<1)
        return omega_core | (z << shift)
    basis = [1 << i for i in range(shift)]
    basis += [1 << (shift+2*mask+bit) for mask in r.k_masks for bit in (0,1)]
    return f,basis


def check_actual_polar(r,p,f,basis):
    # Reconstruct the ORIGINAL binary polar, rather than infer it from
    # the auxiliary cocycle or the proposed intrinsic dimensions.
    values = [f(e) for e in basis]
    width = basis[-1].bit_length()
    center_columns = [0]*len(basis)
    polar_values = []
    core_mask = (1 << (2*(r.d+1)))-1
    for i,j in combinations(range(len(basis)),2):
        value = f(basis[i]^basis[j]) ^ values[i] ^ values[j]
        assert value & core_mask == 0
        polar_values.append(value)
        center_columns[i] ^= value << (width*j)
        center_columns[j] ^= value << (width*i)
    assert rank_binary(polar_values) == 2*len(r.k_masks)
    center_dimension = len(basis)-rank_binary(center_columns)
    assert center_dimension == (2 if p else 4)
    return center_dimension


def check_nonrestrictable(r,p):
    # Independent matrix test: (ad e0)^2 must be outside the space of
    # inner derivations. Use the auxiliary Lie bracket, not the original
    # binary polar bracket, because the restricted-square assertion is on it.
    actions=r.t+[p]
    core=len(actions)
    w=len(r.k_masks)
    def beta(i,j):
        if i==j:return 0
        if i>j:i,j=j,i
        return actions[j] if i==0 else 0
    columns=[]
    for i in range(core):
        col=0
        for j in range(core):col ^= beta(i,j) << (2*r.n*j)
        for j,mask in enumerate(r.k_masks):
            col ^= r.mul(actions[i],1 << (2*mask)) << (2*r.n*(core+j))
        columns.append(col)
    for mask in r.k_masks:
        col=0
        for j in range(core):
            col ^= r.mul(actions[j],1 << (2*mask)) << (2*r.n*j)
        columns.append(col)
    target=0
    for j in range(core):target ^= r.mul(r.t[0],beta(0,j)) << (2*r.n*j)
    packed=Ring(((core+w)*r.n).bit_length())
    packed.even=sum(1 << (2*i) for i in range((core+w)*r.n))
    inner_rank=rank(columns,packed)
    assert inner_rank==core+w-(1 if p else 2)
    assert rank(columns+[target],packed)==inner_rank+1


def check_defect_cohomology(r):
    # Independently distinguish module Ext (diagonal constraints included)
    # from ordinary CE cohomology (alternating inputs only).
    d=r.d
    def matrices(masks,diagonal):
        width=len(masks);ix={mask:i for i,mask in enumerate(masks)}
        def action(i,mask):
            target=mask|(1<<i)
            if mask&(1<<i) or target not in ix:return 0
            return 1<<ix[target]
        delta0=[sum(action(i,mask)<<(width*i) for i in range(d)) for mask in masks]
        slots=[(i,i) for i in range(d)] if diagonal else []
        slots+=list(combinations(range(d),2))
        delta1=[]
        for i in range(d):
            for mask in masks:
                col=0
                for j,(a,b) in enumerate(slots):
                    if a==b==i:col ^= action(i,mask)<<(width*j)
                    elif a!=b and i in (a,b):
                        col ^= action(a if b==i else b,mask)<<(width*j)
                delta1.append(col)
        return width,action,delta0,delta1
    w,action,d0,d1=matrices(r.a_masks,True)
    ext1=d*w-rank_binary(d1)-rank_binary(d0)
    assert ext1==comb(d,2)
    w,action,d0,d1=matrices(r.k_masks,False)
    h1=d*w-rank_binary(d1)-rank_binary(d0)
    assert h1==d+1
    triples=list(combinations(range(d),3))
    d2=[]
    for pair in combinations(range(d),2):
        for mask in r.k_masks:
            col=0
            for j,triple in enumerate(triples):
                if set(pair)<=set(triple):
                    i=next(i for i in triple if i not in pair)
                    col ^= action(i,mask)<<(w*j)
            d2.append(col)
    h2=comb(d,2)*w-rank_binary(d2)-rank_binary(d1)
    assert h2==d+comb(d,2)
    return {'module_Ext1_k_RmodI':ext1,'ordinary_CE_H1_K':h1,
            'ordinary_CE_H2_K':h2,'one_defect_H2_upper_bound':h2+comb(d,2)}


if __name__ == '__main__':
    started = time.monotonic()
    records = []
    dense4 = None
    for d in (4,5,6):
        r = Ring(d)
        defect=check_defect_cohomology(r)
        assert len(r.parameter_masks) == 2**d-d-3
        parameters = [0, 1 << (2*3)]
        parameters += [r.sample_parameter() for _ in range(10)]
        recovery_tests = 0
        for p in parameters:
            dimensions = action_and_shape(r,p)
            f,basis = map_function(r,p)
            check_actual_polar(r,p,f,basis)
            check_nonrestrictable(r,p)
            for _ in range(40):
                x=0
                for e in basis:
                    if RNG.randrange(2): x ^= e
                assert f(f(x)) == f(x)^x
            for _ in range(8):
                check_recovery(r,p)
                recovery_tests += 1
        records.append({'d':d,'class':d+1,'binary_dimension':len(basis),
                        'parameter_dimension':len(r.parameter_masks),
                        'selected_parameters':len(parameters),
                        'lower_central_dimensions':dimensions,
                        'random_recovery_tests':recovery_tests,
                        'random_functional_tests':40*len(parameters),
                        'nonzero_parameter_center_binary_dimension':2,
                        'adjoint_square_not_inner_matrix_checks':len(parameters),
                        'defect_cohomology':defect,
                        'status':'PASS'})
        if d==4: dense4=parameters[-1]
        print(json.dumps(records[-1]),flush=True)
    r=Ring(4)
    f,basis=map_function(r,dense4)
    lossless=0
    for weight in range(5):
        for subset in combinations(basis,weight):
            x=0
            for e in subset:x^=e
            assert f(f(x)) == f(x)^x
            lossless+=1
        print(f'Lossless class-five functional check completed through weight {weight}',flush=True)
    assert lossless == sum(comb(38,j) for j in range(5))
    quantitative=[]
    for c in (5,6,7,8,10,12):
        d=c-1;D=2**d-d-3
        group=3*4**d*prod(4**d-4**j for j in range(d))
        lower=(4**D-1+group-1)//group
        quantitative.append({'class':c,'dimension':2**c+2*c-4,
                              'parameter_dimension':D,'quotient_group_order':group,
                              'proven_subfamily_class_count_lower_bound':lower})
    result={'status':'PASS','records':records,
            'lossless_selected_class5_identity':{'binary_dimension':38,
              'parameter_hex':hex(dense4),'tested_inputs':lossless,
              'method':'Every binary input of weight <=4; composition degree <=4'},
            'quantitative_bounds':quantitative,
            'scope':'Selected parameters and randomized recovery controls support the separate uniform proof; no full near-minimum classification is claimed.',
            'seconds':round(time.monotonic()-started,3)}
    (HERE/'near_minimum_controls.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)

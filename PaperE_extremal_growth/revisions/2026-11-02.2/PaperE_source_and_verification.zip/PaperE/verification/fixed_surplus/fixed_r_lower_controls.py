"""Independent fixed-r family and nilpotent-recovery controls.

No canonical checker is imported. Sparse square-free polynomials retain
ALL higher cross terms between different extra parameters. The tests
support the separate all-r proof; they do not classify parameter orbits.
"""
from pathlib import Path
from itertools import combinations
from math import prod,log
import random,json,time

HERE=Path(__file__).resolve().parent
M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2));INV=(0,1,3,2)
rng=random.Random(20261030166)

def add(a,b):
    out=dict(a)
    for s,c in b.items():
        out[s]=out.get(s,0)^c
        if not out[s]:del out[s]
    return out

def scale(c,a):return {s:M[c][v] for s,v in a.items() if M[c][v]}

def mul(a,b):
    out={}
    for s,c in a.items():
        for t,e in b.items():
            if not s&t:
                u=s|t;out[u]=out.get(u,0)^M[c][e]
                if not out[u]:del out[u]
    return out

def rank4(vectors):
    piv={}
    for row in vectors:
        row=dict(row)
        while row:
            s=min(row);a=row[s]
            if s in piv:row=add(row,scale(a,piv[s]))
            else:piv[s]=scale(INV[a],row);break
    return len(piv)

def inverse(matrix):
    n=len(matrix);a=[row[:]+[int(i==j) for j in range(n)] for i,row in enumerate(matrix)]
    for j in range(n):
        k=next(k for k in range(j,n) if a[k][j]);a[j],a[k]=a[k],a[j]
        a[j]=[M[INV[a[j][j]]][x] for x in a[j]]
        for k in range(n):
            if k!=j and a[k][j]:
                c=a[k][j];a[k]=[x^M[c][y] for x,y in zip(a[k],a[j])]
    return [row[n:] for row in a]

def gl(n):
    a=[[int(i==j) for j in range(n)] for i in range(n)]
    for _ in range(3*n):
        if n==1:break
        i,j=rng.sample(range(n),2);c=rng.randrange(1,4)
        for row in a:row[i]^=M[c][row[j]]
    for i in range(n):
        c=rng.randrange(1,4)
        for row in a:row[i]=M[c][row[i]]
    return a

class Ring:
    def __init__(self,d):
        self.d=d;self.n=1<<d;self.tau=self.n-1;self.z=self.tau^1
        self.t=[{1<<i:1} for i in range(d)]
        self.K=[s for s in range(self.n) if s&~1]
        self.parameter=[s for s in range(self.n) if s.bit_count()>=2 and s not in (self.z,self.tau)]
    def Q(self,p):return {s:c for s,c in p.items() if s not in (self.z,self.tau)}
    def parameter_poly(self):return {s:c for s in self.parameter if (c:=rng.randrange(4))}
    def frame(self,r):
        result=[]
        while len(result)<r:
            p=self.parameter_poly()
            if rank4(result+[p])==len(result)+1:result.append(p)
        return result
    def eval(self,p,images):
        out={}
        for mask,c in p.items():
            term={0:c}
            for i in range(self.d):
                if mask&(1<<i):term=self.Q(mul(term,images[i]))
            out=add(out,term)
        return self.Q(out)
    def valuation(self,vector):
        return min((s.bit_count() for p in vector for s in p),default=self.d+1)

def mat_apply(matrix,vector):
    result=[]
    for row in matrix:
        value={}
        for c,p in zip(row,vector):value=add(value,scale(c,p))
        result.append(value)
    return result

def build_recovery(R,p,B,alpha,delta):
    r=len(p)
    ell=[{1<<j:B[j][i] for j in range(R.d) if B[j][i]} for i in range(R.d)]
    dinv=inverse(delta)
    def P(q):
        images=[]
        for i in range(R.d):
            image=ell[i]
            for b in range(r):image=add(image,scale(alpha[b][i],q[b]))
            images.append(image)
        return [R.eval(pa,images) for pa in p]
    def F(q):return mat_apply(dinv,P(q))
    return P,F

def solve_fixed_point(R,F,r):
    q=[{} for _ in range(r)];valuations=[]
    for step in range(R.d+2):
        new=F(q);diff=[add(a,b) for a,b in zip(new,q)]
        valuations.append(R.valuation(diff))
        if new==q:return q,valuations
        q=new
    raise AssertionError('nilpotent contraction failed to stabilize')

def check_family(R,p):
    r=len(p);actions=R.t+p
    assert rank4([R.Q(a) for a in actions])==R.d+r
    def beta(i,j):
        if i==j:return {}
        if i>j:i,j=j,i
        return actions[j] if i==0 else {}
    for i,j,k in combinations(range(len(actions)),3):
        value=add(add(mul(actions[i],beta(j,k)),mul(actions[j],beta(i,k))),mul(actions[k],beta(i,j)))
        assert value=={}
    assert all(mul(a,a)=={} for a in actions)
    # No K basis vector can supply the t0 coefficient needed by compatibility.
    assert all(3 not in mul(R.t[1],{s:1}) for s in R.K)
    socle=[s for s in R.K if all(s&(1<<i) for i in range(R.d))]
    assert socle==[R.tau]
    def f(x):
        core,w=x;a=core[0];b={}
        for i in range(1,R.d):b=add(b,scale(core[i],R.t[i]))
        for j,pa in enumerate(p):b=add(b,scale(core[R.d+j],pa))
        action=add(scale(a,R.t[0]),b)
        new=add(add(scale(2,w),mul(action,w)),scale(a,b))
        new=add(new,scale(M[a][a],mul(R.t[0],b)))
        return ([M[2][v] for v in core],new)
    for _ in range(18):
        core=[rng.randrange(4) for _ in actions]
        w={s:c for s in R.K if (c:=rng.randrange(4))}
        fx=f((core,w));ffx=f(fx)
        assert ffx==([a^b for a,b in zip(fx[0],core)],add(fx[1],w))

def run(d,r,cases):
    R=Ring(d);assert len(R.parameter)==2**d-d-3 and r<=len(R.parameter)
    records=[]
    for case in range(cases):
        p=R.frame(r);check_family(R,p)
        B=gl(d);preserve_I=bool(case%2)
        if preserve_I:
            H=gl(d-1);a=rng.randrange(1,4)
            B=[[a]+[0]*(d-1)]+[[rng.randrange(4)]+row for row in H]
        alpha=[[rng.randrange(4) for _ in range(d)] for _ in range(r)]
        delta=gl(r);P,F=build_recovery(R,p,B,alpha,delta)
        target,vals=solve_fixed_point(R,F,r)
        assert mat_apply(delta,target)==P(target)
        assert all(set(pa)<=set(R.parameter) for pa in target)
        if preserve_I:assert rank4(target)==r
        # Compare arbitrary dense target tuples differing at EVERY available
        # filtration depth. Exact polynomial substitution includes cross terms.
        compared=0
        for s in range(2,d):
            masks=[t for t in R.parameter if t.bit_count()==s]
            if not masks:continue
            q=[R.parameter_poly() for _ in range(r)];q2=[dict(a) for a in q]
            b=rng.randrange(r);mask=rng.choice(masks)
            q2[b]=add(q2[b],{mask:rng.randrange(1,4)})
            difference=[add(a,b) for a,b in zip(q,q2)]
            assert R.valuation(difference)==s
            output_difference=[add(a,b) for a,b in zip(F(q),F(q2))]
            assert R.valuation(output_difference)>=s+1
            compared+=1
        records.append({'fixed_point_steps':len(vals),'difference_filtration_tests':compared})
    return {'d':d,'r':r,'class':d+1,'binary_dimension':2*((1<<d)+d+r-2),
            'parameter_dimension':len(R.parameter),'cases':cases,
            'all_mixed_Jacobi_and_functional_controls':'PASS',
            'fixed_point_and_filtration_controls':'PASS','records':records,'status':'PASS'}

def cross_term_witness():
    R=Ring(5);p=[{3:1},{12:1}]
    B=[[int(i==j) for j in range(5)] for i in range(5)]
    alpha=[[1,0,0,0,0],[0,1,0,0,0]];delta=[[1,0],[0,1]]
    P,F=build_recovery(R,p,B,alpha,delta)
    target,vals=solve_fixed_point(R,F,2)
    assert target==[{3:1,13:1},{12:1}]
    # A false first-order Taylor truncation leads to a different fixed point.
    def truncated(q):
        return [add(add({3:1},mul({2:1},q[0])),mul({1:1},q[1])),{12:1}]
    wrong,_=solve_fixed_point(R,truncated,2)
    assert wrong==[{3:1,13:1,15:1},{12:1}] and F(wrong)!=wrong
    assert R.Q(mul(target[0],target[1]))=={15:1}
    return {'d':5,'r':2,'source':[{'t0*t1':1},{'t2*t3':1}],
            'true_q1':'t0*t1+t0*t2*t3',
            'false_linear_Taylor_q1':'t0*t1+t0*t2*t3+t0*t1*t2*t3',
            'nonzero_higher_cross_term':'t0*t1*t2*t3','status':'PASS'}

def count_data(c,r):
    d=c-1;D=2**d-d-3
    frames=prod(4**D-4**j for j in range(r))
    gd=prod(4**d-4**j for j in range(d))
    gr=prod(4**r-4**j for j in range(r))
    denominator=4**(d*r)*gd*gr
    lower=(frames+denominator-1)//denominator
    return {'class':c,'r':r,'frame_log4':log(frames,4),
            'fiber_bound_log4':log(denominator,4),
            'proven_integer_lower_bound':str(lower)}

if __name__=='__main__':
    started=time.monotonic()
    records=[run(4,2,6),run(5,2,6),run(5,3,4),run(6,4,3),run(6,2,4)]
    witness=cross_term_witness()
    for d in (4,5,6):
        assert 4**d*prod(4**d-4**j for j in range(d))*3==4**d*prod(4**d-4**j for j in range(d))*prod(4-4**j for j in range(1))
    out={'status':'PASS','records':records,'higher_cross_term_witness':witness,
         'counts':[count_data(c,r) for c in (7,8) for r in (1,2,3,4)],
         'seconds':round(time.monotonic()-started,3),
         'scope':'Independent selected finite controls support the separate all-r proof; no sufficiency of arbitrary quotient matrices or orbit classification is claimed.'}
    (HERE/'fixed_r_lower_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out))

from fractions import Fraction
from math import comb,prod
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
checks=0
for r in range(1,16):
    for d in (4,5,8,12):
        w0=2**d-2;C=comb(d,2)
        coarse=r*w0+(2*r+1)*C+(r*r+r+1)*d+r**3+r+comb(r,2)*(r+1)
        for h in range(r+1):
            s=r-h
            raw=h*C+d*h*h+h+s*(w0+h*d+h*h)+d+(h+1)*C+s*((h+1)*d+1)+comb(s,2)*(h+1)
            target=s*w0+(2*h+1)*C+d*(h*h+2*s*h+s+1)+s*h*h+r+comb(s,2)*(h+1)
            assert raw==target and target<=coarse
            for t in range(h+1):
                a=h-t
                module=d*(t*t+a*a)+t*C+a*(t*d+1)
                assert module<=h*C+d*h*h+h
            checks+=1

def power4(e):return Fraction(4**e) if e>=0 else Fraction(1,4**(-e))
ratios=[]
for d in range(4,10):
    D=2**d-d-3;gd=prod(4**d-4**j for j in range(d))
    eta=3*power4(d*d+d+2-2**(d-2))
    Nupper=Fraction(4**(D+1),3*gd)*(1+eta)
    lower=Fraction((4**D-1)*(4**D-4),4**(2*d)*gd*180)
    ratio=Nupper/lower
    closed=60*(1+eta)*power4(-2**d+3*d+4)/((1-power4(-D))*(1-power4(1-D)))
    assert ratio==closed
    ratios.append({'d':d,'class':d+1,'compatibility_proportion_upper':min(1.0,float(ratio))})
out={'status':'PASS','exponent_cases':checks,'exact_fraction_rarity_checks':len(ratios),
     'ratios':ratios,'scope':'Exact arithmetic bookkeeping, not an independent proof of module estimates.'}
(HERE/'count_bookkeeping_checks.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))

"""Independent sparse-polynomial controls over F4, F8 and F16.

Tests the pure Lie formulation; no binary orbit-map claim is made over F8.
Rebuilds field arithmetic and nonlinear vector recovery without importing
the manuscript's existing construction or verification programs.
"""
from pathlib import Path
from itertools import combinations
import json,random,time

HERE=Path(__file__).resolve().parent
RNG=random.Random(20261030113)


class Field:
    def __init__(self,modulus):
        self.modulus=modulus;self.q=1<<(modulus.bit_length()-1)
    def mul(self,a,b):
        value=0
        while b:
            if b&1:value^=a
            b>>=1;a<<=1
            if a&self.q:a^=self.modulus
        return value
    def power(self,a,n):
        value=1
        while n:
            if n&1:value=self.mul(value,a)
            a=self.mul(a,a);n>>=1
        return value
    def inv(self,a):
        assert a
        return self.power(a,self.q-2)


class Ring:
    def __init__(self,d,field):
        self.d=d;self.f=field;self.top=(1<<d)-1;self.z=self.top^1
        self.k=[m for m in range(1<<d) if m&~1]
        self.parameters=[m for m in range(1<<d) if m.bit_count()>=2 and m not in (self.z,self.top)]
        self.t=[{1<<i:1} for i in range(d)]
    def add(self,*polynomials):
        out={}
        for p in polynomials:
            for m,a in p.items():
                out[m]=out.get(m,0)^a
                if not out[m]:del out[m]
        return out
    def scale(self,a,p):return {m:self.f.mul(a,b) for m,b in p.items()} if a else {}
    def mul(self,p,q):
        out={}
        for i,a in p.items():
            for j,b in q.items():
                if not i&j:
                    m=i|j;out[m]=out.get(m,0)^self.f.mul(a,b)
                    if not out[m]:del out[m]
        return out
    def reduce(self,p):return {m:a for m,a in p.items() if m not in (self.z,self.top)}
    def sub(self,p,images):
        out={}
        for mask,a in p.items():
            term={0:a}
            for i in range(self.d):
                if mask&(1<<i):term=self.mul(term,images[i])
            out=self.add(out,term)
        return self.reduce(out)
    def valuation(self,p):return min((m.bit_count() for m in p),default=self.d+1)


def invert(matrix,f):
    n=len(matrix);a=[row[:]+[int(i==j) for j in range(n)] for i,row in enumerate(matrix)]
    for i in range(n):
        j=next(j for j in range(i,n) if a[j][i]);a[i],a[j]=a[j],a[i]
        b=f.inv(a[i][i]);a[i]=[f.mul(b,x) for x in a[i]]
        for j in range(n):
            if j!=i and a[j][i]:
                b=a[j][i];a[j]=[x^f.mul(b,y) for x,y in zip(a[j],a[i])]
    return [row[n:] for row in a]


def random_gl(n,f):
    a=[[int(i==j) for j in range(n)] for i in range(n)]
    for _ in range(3*n):
        i,j=RNG.sample(range(n),2);b=RNG.randrange(1,f.q)
        for k in range(n):a[k][i]^=f.mul(b,a[k][j])
    return a


def sparse_rank(vectors,f):
    pivots={}
    for row in vectors:
        row=dict(row)
        while row:
            i=min(row);a=row[i]
            if i not in pivots:
                b=f.inv(a);pivots[i]={j:f.mul(b,x) for j,x in row.items()};break
            for j,b in pivots[i].items():
                row[j]=row.get(j,0)^f.mul(a,b)
                if not row[j]:del row[j]
    return len(pivots)


def check_configuration(d,r,f):
    ring=Ring(d,f);D=len(ring.parameters)
    frame=[]
    for i in range(r):
        p={ring.parameters[i]:1}
        for m in ring.parameters[r:]:
            a=RNG.randrange(f.q)
            if a:p[m]=a
        frame.append(p)
    assert sparse_rank(frame,f)==r
    actions=ring.t+frame
    def beta(i,j):
        if i>j:i,j=j,i
        return actions[j] if i==0 and j else {}
    for a in actions:assert not ring.mul(a,a)
    for i,j,k in combinations(range(d+r),3):
        assert not ring.add(ring.mul(actions[i],beta(j,k)),
                            ring.mul(actions[j],beta(i,k)),ring.mul(actions[k],beta(i,j)))
    # Build every inner adjoint matrix and an adjoint square independently.
    km=ring.k;ix={m:i for i,m in enumerate(km)};width=len(km);core=d+r
    inner=[]
    for a in range(core+width):
        col={}
        for b in range(core+width):
            value=(beta(a,b) if a<core and b<core else
                   ring.mul(actions[a],{km[b-core]:1}) if a<core else
                   ring.mul(actions[b],{km[a-core]:1}) if b<core else {})
            for mask,v in value.items():col[b*width+ix[mask]]=v
        inner.append(col)
    target={}
    for b in range(core):
        for mask,v in ring.mul(ring.t[0],beta(0,b)).items():target[b*width+ix[mask]]=v
    assert sparse_rank(inner,f)==core+width-1
    assert sparse_rank(inner+[target],f)==core+width
    B=random_gl(d,f);delta=random_gl(r,f)
    dt=[list(row) for row in zip(*delta)];di=invert(dt,f)
    alpha=[[RNG.randrange(f.q) for _ in range(r)] for _ in range(d)]
    ell=[{1<<j:B[j][i] for j in range(d) if B[j][i]} for i in range(d)]
    def apply(qs):
        images=[ring.add(ell[i],*(ring.scale(alpha[i][a],qs[a]) for a in range(r))) for i in range(d)]
        values=[ring.sub(p,images) for p in frame]
        return [ring.add(*(ring.scale(di[a][b],values[b]) for b in range(r))) for a in range(r)]
    q0=[{} for _ in range(r)]
    q1=[]
    for _ in range(r):
        p={}
        for mask in range(1,1<<d):
            if mask in (ring.z,ring.top):continue
            a=RNG.randrange(f.q)
            if a:p[mask]=a
        q1.append(p)
    for _ in range(d+2):
        old=min(ring.valuation(ring.add(a,b)) for a,b in zip(q0,q1))
        q0,q1=apply(q0),apply(q1)
        new=min(ring.valuation(ring.add(a,b)) for a,b in zip(q0,q1))
        assert new>=min(old+1,d+1)
    assert q0==q1 and apply(q0)==q0
    # Scalar coefficient separation used in 3-Engel equivalence.
    scalar=next(a for a in range(2,f.q) if f.mul(a,a)^a)
    assert f.mul(scalar,scalar)^scalar
    return {'q':f.q,'d':d,'surplus':r,'parameter_dimension':D,
            'lie_dimension':(1<<d)+d-2+r,'jacobi_triples':len(list(combinations(range(d+r),3))),
            'inner_rank':core+width-1,'center_dimension':1,'adjoint_square_not_inner':True,
            'nonlinear_vector_recovery':'PASS','engel_scalar_separation':True,'status':'PASS'}


if __name__=='__main__':
    started=time.monotonic();records=[]
    for modulus in (0b111,0b1011,0b10011):
        f=Field(modulus)
        for a in range(1,f.q):assert f.mul(a,f.inv(a))==1
        for d,r in ((4,2),(4,3),(5,2)):
            result=check_configuration(d,r,f);records.append(result)
            print(json.dumps(result),flush=True)
    report={'status':'PASS','records':records,'seconds':round(time.monotonic()-started,3),
            'scope':'Selected ordinary Lie families and exact field/rank/implicit-recovery controls over F4,F8,F16; no binary map over F8 is asserted; uniform theorems have separate proofs.'}
    (HERE/'finite_field_scope_controls.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report),flush=True)

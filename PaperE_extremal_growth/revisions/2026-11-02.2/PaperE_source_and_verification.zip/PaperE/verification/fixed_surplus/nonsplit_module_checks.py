"""Independent r=2 module-bound controls, including nonsplit extensions.

The matrices have F2 coefficients; their ranks over every characteristic-two
field are identical. No manuscript checker is imported.
"""
from pathlib import Path
from itertools import combinations
from math import comb
import json,random,time

HERE=Path(__file__).resolve().parent
RNG=random.Random(202610309827)

def rank(vectors):
    piv={}
    for v in vectors:
        while v:
            p=v.bit_length()-1
            if p in piv:v^=piv[p]
            else:piv[p]=v;break
    return len(piv)

def apply(T,v):
    result=0
    while v:
        b=v&-v;result^=T[b.bit_length()-1];v^=b
    return result

def mono_module(d,masks):
    ix={S:i for i,S in enumerate(masks)}
    return [[0 if S&(1<<i) or (S|(1<<i)) not in ix else 1<<ix[S|(1<<i)]
             for S in masks] for i in range(d)]

def direct_sum(P,Q):
    n=len(P[0]);m=len(Q[0])
    return [a+[v<<n for v in b] for a,b in zip(P,Q)]

def kernel(rows,width):
    piv={}
    for v in rows:
        while v:
            p=v.bit_length()-1
            if p in piv:v^=piv[p]
            else:piv[p]=v;break
    basis=[]
    for j in range(width):
        if j in piv:continue
        v=1<<j
        for p in sorted(piv):
            if (piv[p]&v).bit_count()%2:v^=1<<p
        basis.append(v)
    assert all(not((row&v).bit_count()%2) for row in rows for v in basis)
    return basis

def dual_extension(P,h):
    # 0 -> k^h -> W -> K ->0, obtained from genuinely nonzero extension
    # directions among lambda_i:K->k satisfying the square/cross equations.
    d=len(P);n=len(P[0]);rows=[]
    for i in range(d):
        for col in range(n):rows.append(P[i][col]<<(i*n))
    for i,j in combinations(range(d),2):
        for col in range(n):rows.append((P[j][col]<<(i*n))^(P[i][col]<<(j*n)))
    basis=kernel(rows,d*n)
    lambdas=[]
    for _ in range(h):
        v=0
        for b in basis:
            if RNG.randrange(2):v^=b
        lambdas.append(v)
    result=[]
    for i,T in enumerate(P):
        block=[]
        for col,value in enumerate(T):
            for a,lam in enumerate(lambdas):
                value^=((lam>>(i*n+col))&1)<<(n+a)
            block.append(value)
        result.append(block+[0]*h)
    return result

def ordinary_ce(P):
    d=len(P);n=len(P[0]);pairs=list(combinations(range(d),2));triples=list(combinations(range(d),3))
    d0=[sum(P[i][j]<<(n*i) for i in range(d)) for j in range(n)]
    d1=[]
    for i in range(d):
        for col in range(n):
            v=0
            for e,(a,b) in enumerate(pairs):
                if i==a:v^=P[b][col]<<(n*e)
                if i==b:v^=P[a][col]<<(n*e)
            d1.append(v)
    d2=[]
    for edge in pairs:
        for col in range(n):
            v=0
            for j,tr in enumerate(triples):
                if set(edge)<=set(tr):
                    i=next(i for i in tr if i not in edge)
                    v^=P[i][col]<<(n*j)
            d2.append(v)
    return n-rank(d0),d*n-rank(d1)-rank(d0),len(pairs)*n-rank(d2)-rank(d1)

def module_ext1(P):
    d=len(P);n=len(P[0]);pairs=list(combinations(range(d),2))
    d0=[sum(P[i][j]<<(n*i) for i in range(d)) for j in range(n)]
    d1=[]
    for i in range(d):
        for col in range(n):
            v=P[i][col]<<(n*i)
            for e,(a,b) in enumerate(pairs):
                if i==a:v^=P[b][col]<<(n*(d+e))
                if i==b:v^=P[a][col]<<(n*(d+e))
            d1.append(v)
    return d*n-rank(d1)-rank(d0)

def end_dimension(P):
    d=len(P);n=len(P[0]);rows=[]
    for a in range(n):
        for b in range(n):
            v=0
            for i,T in enumerate(P):
                base=i*n*n
                v^=T[a]<<(base+b*n)
                for col,value in enumerate(T):
                    if value&(1<<b):v^=1<<(base+col*n+a)
            rows.append(v)
    return n*n-rank(rows)

def check(name,d,h,P):
    n=len(P[0]);w0=(1<<d)-2
    assert n==w0+h
    for i in range(d):
        assert all(apply(P[i],v)==0 for v in P[i])
    for i,j in combinations(range(d),2):
        assert all(apply(P[i],P[j][col])==apply(P[j],P[i][col]) for col in range(n))
    soc,h1,h2=ordinary_ce(P)
    end=end_dimension(P)
    ext=module_ext1(P)
    bounds={'End':w0+h*d+h*h,'socle':h+1,'CE_H1':(h+1)*d+1,
            'CE_H2':d+(h+1)*comb(d,2),'module_Ext1_k_W':h*d+1}
    values={'End':end,'socle':soc,'CE_H1':h1,'CE_H2':h2,'module_Ext1_k_W':ext}
    assert all(values[key]<=bounds[key] for key in values),(name,values,bounds)
    return {'module':name,'d':d,'defect':h,'dimensions':values,'proven_bounds':bounds,'status':'PASS'}

if __name__=='__main__':
    start=time.monotonic();records=[]
    for d in(4,5):
        n=1<<d
        K=mono_module(d,[S for S in range(n) if S not in(0,1)])
        J=mono_module(d,list(range(1,n)))
        R=mono_module(d,list(range(n)))
        trivial=[[0] for _ in range(d)]
        small2=[[0,1 if i in(0,d-1) else 0] for i in range(d)]
        choices=[('K',0,K),('split_K_plus_k',1,direct_sum(K,trivial)),
                 ('nonsplit_J',1,J),('split_K_plus_k2',2,direct_sum(direct_sum(K,trivial),trivial)),
                 ('J_plus_k',2,direct_sum(J,trivial)),('nonsplit_R',2,R),
                 ('K_plus_nonsimple_length2',2,direct_sum(K,small2))]
        choices += [(f'central_extension_h{h}_sample{j}',h,dual_extension(K,h))
                    for h in(1,2) for j in range(4)]
        for name,h,P in choices:
            records.append(check(name,d,h,P))
        assert records[-1]['status']=='PASS'
    result={'status':'PASS','records':records,'scope':'Selected filtered modules including nonsplit extensions; independent exact matrices over F2 (same ranks over F4). General proof is separate.',
            'seconds':round(time.monotonic()-start,3)}
    (HERE/'nonsplit_module_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'status':'PASS','module_count':len(records),'seconds':result['seconds']}))

Authorship correction 2026-11-03: Baohua Li is the sole author of every Paper E version.
Complete critical partition controls
====================================
Run from the project directory:
  python verification/run_replay.py --full-partition-only --output-dir replay_new
The four programs use the standard library; general_residual imports only
the supplied first_defect helper. All assertions run in an isolated copy.
No master manuscript or other-paper source is needed.
See ../../INTEGRATION_NOTES.txt for theorem-to-proof-to-control mapping.
Fresh merge logs: ../replay_merge/new_controls/; two inherited interface
reports and MERGE_REPLAY.json are in ../replay_merge/.
These are finite interface controls, not unlabelled Lie enumeration,
an effective asymptotic cutoff, formalization, or external certification.

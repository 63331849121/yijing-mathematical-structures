"""Focused matrix controls for the general residual group, not a type census.

Reuses only the previous round's bit-linear-algebra primitives. The general
modules, End constraints and residual maps are reconstructed here.
"""
from pathlib import Path
from itertools import combinations
from fractions import Fraction
from math import prod
import runpy
import json

HERE = Path(__file__).resolve().parent
primitives = runpy.run_path(str(HERE / 'check_first_defect_fibers.py'), run_name='fiber_primitives')
apply_map = primitives['apply_map']
insert = primitives['insert']
kernel = primitives['kernel']


def module(d, h, u):
    masks = [a for a in range(1 << d) if a & ~1]
    index = {a: i for i, a in enumerate(masks)}
    z0, w = len(masks), len(masks) + h
    tau = index[(1 << d) - 1]
    operators = []
    for i in range(d):
        p = []
        for mask in masks:
            if 1 <= i <= u and mask == (1 << i):
                p.append(1 << (z0 + i - 1))
            elif mask & (1 << i):
                p.append(0)
            else:
                p.append(1 << index[mask | (1 << i)])
        operators.append(p + [0] * h)
    thetas = []
    for j in range(h):
        t = [0] * w
        t[z0 + j] = 1 << tau
        if j < u:
            t[index[1 << (j + 1)]] = 1 << index[((1 << d) - 1) ^ (1 << (j + 1))]
        thetas.append(t)
    ns = []
    for i in range(1, d):
        for j in range(h):
            t = [0] * w
            t[index[1 << i]] = 1 << (z0 + j)
            ns.append(t)
    ds = []
    for j in range(u, h):
        for i in range(h):
            t = [0] * w
            t[z0 + j] = 1 << (z0 + i)
            ds.append(t)
    return masks, index, operators, thetas, ns, ds


def end_control(d, h, u):
    masks, index, ps, ts, ns, ds = module(d, h, u)
    w = len(masks) + h
    equations_pivots = {}
    for row in range(w):
        for column in range(w):
            v = 0
            for i in range(d):
                for j in range(w):
                    if ps[i][j] == (1 << column):
                        v ^= 1 << ((i * w + j) * w + row)
                v ^= ps[i][row] << ((i * w + column) * w)
            insert(v, equations_pivots)
    full_dimension = w * w - len(equations_pivots)
    predicted = (1 << d) - 2 + h * (d - 1) + h + h * (h - u)
    assert full_dimension == predicted
    maps = []
    # Faithful polynomial A=R/I, including its scalar.
    positive_product = (1 << d) - 2
    for mask in range(1 << d):
        if mask in (positive_product, positive_product | 1):
            continue
        cols = []
        for j in range(w):
            v = 1 << j
            for i in range(d):
                if mask & (1 << i):
                    v = apply_map(ps[i], v)
            cols.append(v)
        maps.append(cols)
    maps += ts + ns + ds
    pvt = {}
    for t in maps:
        for p in ps:
            for j in range(w):
                assert apply_map(t, p[j]) == apply_map(p, t[j])
        vector = sum(col << (j * w) for j, col in enumerate(t))
        assert insert(vector, pvt)
    assert len(pvt) == predicted
    return {'d': d, 'h': h, 'rank_Q': u, 'End_dimension': full_dimension,
            'displayed_End_basis_complete': True}


def ce_control(d, h, u, s):
    masks, index, ps, ts, ns, ds = module(d, h, u)
    w, n = len(masks) + h, d + s
    for a in range(s):
        i = 1 + a % (d - 1)
        ps.append([apply_map(ps[0], ps[i][j]) for j in range(w)])
    pairs = list(combinations(range(n), 2))
    pair_index = {p: i for i, p in enumerate(pairs)}
    triples = list(combinations(range(n), 3))
    d1 = []
    for j in range(n):
        for b in range(w):
            v = 0
            for i in range(n):
                if i != j:
                    v ^= ps[i][b] << (pair_index[tuple(sorted((i, j)))] * w)
            d1.append(v)
    d2 = [0] * (w * len(pairs))
    for row, (i, j, k) in enumerate(triples):
        for a, pair in ((i, (j, k)), (j, (i, k)), (k, (i, j))):
            offset = pair_index[pair] * w
            for b in range(w):
                d2[offset + b] ^= ps[a][b] << (row * w)
    boundaries = {}
    for v in d1:
        assert apply_map(d2, v) == 0
        insert(v, boundaries)
    cycles = kernel(d2)
    Cd, Cs, CN = d * (d - 1) // 2, s * (s - 1) // 2, n * (n - 1) // 2
    H2 = len(cycles) - len(boundaries)
    assert H2 == d + Cd + s * (d + 1) + Cs + h * CN

    def induced_rank(t):
        pvt = dict(boundaries)
        before = len(pvt)
        for cycle in cycles:
            image = 0
            for pair in range(len(pairs)):
                v = (cycle >> (pair * w)) & ((1 << w) - 1)
                image ^= apply_map(t, v) << (pair * w)
            assert apply_map(d2, image) == 0
            insert(image, pvt)
        return len(pvt) - before

    # Every nonzero functional ell has rank Cs, independent of rank Q.
    for functional in range(1, 1 << h):
        t = [0] * w
        for i in range(h):
            if functional & (1 << i):
                t = [a ^ b for a, b in zip(t, ts[i])]
        assert induced_rank(t) == Cs
    # D detects the free central complement; it cannot be discarded as a unit.
    for t in ds:
        assert induced_rank(t) == CN
    return {'d': d, 'h': h, 'rank_Q': u, 's': s, 'H2_dimension': H2,
            'nonzero_socle_functionals_checked': (1 << h) - 1,
            'each_theta_rank': Cs, 'complement_maps_checked': len(ds)}


def gl(q, t):
    return prod(q ** t - q ** j for j in range(t))


def qpower(q, e):
    return Fraction(q ** e) if e >= 0 else Fraction(1, q ** (-e))


def P(q, t):
    return prod((1 - Fraction(1, q ** i)) for i in range(1, t + 1))


def formula_controls():
    checks = 0
    for q in (4, 8):
        for d in range(5, 10):
            m, n = d - 1, 1 << d
            D = n - d - 3
            for h in range(0, min(4, m)):
                for r in range(h + 3, h + 8):
                    s = r - h
                    Cd, Cs, CN = d * (d - 1) // 2, s * (s - 1) // 2, (d + s) * (d + s - 1) // 2
                    Ns = prod(q ** D - q ** j for j in range(s))
                    Hh = q ** (h * (m - h)) * gl(q, h) * gl(q, m - h)
                    principal = Fraction(Ns, (q - 1) * Hh * gl(q, s)) * qpower(q, Cd + s + Cs + h * CN - h * d)
                    Vh = s * n - 3 * s + (h - 1) * CN
                    Ah = d + Cd + s * (d + 1) + Cs + h * CN
                    U = h * Cd + d * h * h + h + Ah + s * (n - 2 + h * m - s)
                    assert U - Vh == (h + 2) * Cd + d * h * h + h + d + s * (h * m + 2 * d + 1)
                    other = qpower(q, Vh + m - h * (h + 1)) * prod(1 - Fraction(q ** j, q ** D) for j in range(s)) / ((q - 1) * P(q, s) * P(q, h) * P(q, m - h))
                    assert principal == other
                    for u in range(h + 1):
                        t = h - u
                        Hu = q ** (u * (m - u)) * gl(q, u) * gl(q, m - u)
                        ratio = Fraction(Hh, Hu * q ** (u * t) * gl(q, t))
                        expected = qpower(q, -t * (m - u)) * P(q, h) * P(q, m - h) / (P(q, u) * P(q, m - u) * P(q, t))
                        assert ratio == expected
                    if h + 1 <= m:
                        sh = s - 1
                        Nn = d + sh
                        Csh, CNn = sh * (sh - 1) // 2, Nn * (Nn - 1) // 2
                        Hnext = q ** ((h + 1) * (m - h - 1)) * gl(q, h + 1) * gl(q, m - h - 1)
                        next_value = Fraction(Ns, (q ** D - q ** sh) * (q - 1) * Hnext * gl(q, sh)) * qpower(q, Cd + sh + Csh + (h + 1) * CNn - (h + 1) * d)
                        leading = qpower(q, -n + CN - h * (d + s) + 1 - h) / (1 - Fraction(1, q ** (h + 1)))
                        finite_factor = (1 - Fraction(1, q ** s)) * (1 - Fraction(1, q ** (m - h))) / (1 - Fraction(q ** sh, q ** D))
                        assert next_value / principal == leading * finite_factor
                        if d % 2:
                            T = 1 << ((d + 1) // 2)
                            delta = Fraction(r + d - T, 1) - Fraction(1, 2) - 2 * h
                            exact_score = -n + CN - h * (d + s) + 1 - h
                            expanded = T * delta + delta * delta / 2 + Fraction(7, 8) - Fraction(h * (h + 3), 2)
                            assert exact_score == expanded
                    checks += 1
    return checks


def residual_orbits():
    reports = []
    # Full rank Q: exact Burnside expression, including deficient Gamma.
    for h in (1, 2, 3):
        for C in (1, 2, 3):
            unseen = set(range(1 << ((h + 1) * C)))
            orbits = 0
            while unseen:
                point = next(iter(unseen))
                theta = point & ((1 << C) - 1)
                gamma = [(point >> ((j + 1) * C)) & ((1 << C) - 1) for j in range(h)]
                orbit = set()
                for ell in range(1 << h):
                    new_theta = theta
                    for j in range(h):
                        if ell & (1 << j):
                            new_theta ^= gamma[j]
                    orbit.add((point ^ theta) | new_theta)
                unseen -= orbit
                orbits += 1
            expected = qpower(2, (h + 1) * C - h) * (1 + Fraction((1 << h) - 1, 1 << C))
            assert orbits == expected
            reports.append({'h': h, 'C_s_model': C, 'exact_orbits': orbits})
    return reports


def complement_orbits():
    reports = []
    for u in (0, 1, 2):
        matrices = [(a, b) for a in (1, 2, 3) for b in (1, 2, 3) if a != b
                    and (u == 0 or a == 1) and (u < 2 or b == 2)]
        for C in (2, 3):
            gammas = []
            for number in range(1 << (2 * C)):
                columns = tuple((number >> (2 * i)) & 3 for i in range(C))
                pvt = {}
                for col in columns:
                    insert(col, pvt)
                if len(pvt) == 2:
                    gammas.append(columns)
            unseen = {(theta, gamma) for theta in range(1 << C) for gamma in gammas}
            number_orbits = 0
            while unseen:
                theta, gamma = next(iter(unseen))
                orbit = set()
                for matrix in matrices:
                    for ell in range(4):
                        shift = sum((((ell & g).bit_count() % 2) << i) for i, g in enumerate(gamma))
                        orbit.add((theta ^ shift, tuple(apply_map(matrix, g) for g in gamma)))
                assert len(orbit) == len(matrices) * 4
                unseen -= orbit
                number_orbits += 1
            assert number_orbits == len(gammas) * (1 << C) // (len(matrices) * 4)
            reports.append({'h': 2, 'rank_Q': u, 'form_dimension': C,
                            'residual_group_order': len(matrices) * 4,
                            'surjective_orbits': number_orbits, 'all_surjective_orbits_free': True})
    return reports


def main():
    ends = [end_control(d, h, u) for d in (4, 5) for h in (2, 3) for u in range(h + 1)]
    ce = [ce_control(d, h, u, s) for d in (4, 5) for h in (2, 3) for u in range(h + 1) for s in (0, 2, 3)]
    report = {'status': 'PASS', 'End_controls': ends, 'CE_controls': ce,
              'exact_formula_checks': formula_controls(), 'residual_orbit_controls': residual_orbits(),
              'complement_group_orbit_controls': complement_orbits(),
              'scope': 'General residual-module and CE interfaces only; no unlabelled Lie enumeration or global finite-d claim.'}
    (HERE / 'general_residual_controls.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'End_cases': len(ends), 'CE_cases': len(ce),
                      'formula_checks': report['exact_formula_checks'], 'residual_orbit_cases': len(report['residual_orbit_controls']),
                      'complement_orbit_cases': len(report['complement_group_orbit_controls'])}))


if __name__ == '__main__':
    main()

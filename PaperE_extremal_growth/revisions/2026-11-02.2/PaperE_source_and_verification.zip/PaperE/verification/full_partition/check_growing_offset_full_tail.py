"""Exact interface controls for the growing-offset whole-layer theorem.

Checks polynomial identities, analytic upper-budget substitutions and actual
integer surplus families; it never enumerates Lie types or proves a cutoff.
"""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json

HERE = Path(__file__).resolve().parent


def delta_raw(d, n, r, h):
    return (h ** 3 / F(2) - (r + d - 1) * h * h
            + h * (-n + r * r / 2 + (2 * d - F(1, 2)) * r + d * d - 2 * d + F(5, 2))
            + r * (2 * d + 1) + d * d - d + 1)


def delta_centered(d, T, x, h):
    return (T * (-h * h + (d + x) * h + 2 * d + 1)
            + h ** 3 / F(2) - (x - F(1, 2)) * h * h
            + h * (x * x / 2 + d * x - F(d * d, 2) - d + F(19, 8))
            + (2 * d + 1) * x - d * d - d + F(3, 2))


def polynomial_and_budget_controls():
    checks = 0
    budgets = []
    for d in (65, 129, 257, 513):
        n, T = 1 << d, 1 << ((d + 1) // 2)
        H = isqrt(n) // (d * d)
        X = F(H, 4)
        positive_cost = (F(d, H) + F(1, 4) + F(2 * d + 1, H * H) + F(1, 8)
                         + (X + F(1, 2)) / T
                         + (F(H * H, 32) + F(d * H, 4) + F(19, 8)) / (T * H)
                         + ((2 * d + 1) * X + F(3, 2)) / (T * H * H))
        assert positive_cost < F(1, 2)
        for x in (-X, -X / 2, F(0), X / 2, X):
            r = T - d + F(1, 2) + x
            for h in (F(H), F(2 * H), r / 10, r / 5):
                assert H <= h <= r / 5
                assert h <= F(T, 4)
                old = delta_raw(d, n, r, h)
                new = delta_centered(d, T, x, h)
                assert old == new
                assert new <= -F(T, 2) * h * h
                checks += 1
        budgets.append({'d': d, 'H_bit_length': H.bit_length(),
                        'positive_cost_upper': str(positive_cost),
                        'less_than_one_half': True})
    return checks, budgets


def qpower(q, exponent):
    return F(q ** exponent) if exponent >= 0 else F(1, q ** (-exponent))


def correction(q, D, r, h):
    s = r - h
    return ((1 - F(1, q ** s)) /
            ((1 - F(1, q ** (h + 1))) * (1 - F(q ** (s - 1), q ** D))))


def exponent(d, n, r, h):
    N = d + r - h
    return -n + N * (N - 1) // 2 - h * N + 1 - h


def log_concavity_controls():
    checks = 0
    for q in (4, 8):
        for d in range(4, 9):
            n, D = 1 << d, (1 << d) - d - 3
            for r in range(4, min(D, 13)):
                for h in range(r - 2):
                    N = d + r - h
                    assert exponent(d, n, r, h + 1) - exponent(d, n, r, h) == -2 * N + h + 1
                    assert correction(q, D, r, h + 1) <= correction(q, D, r, h)
                    checks += 1
    return checks


def integer_family_controls():
    reports = []
    for d in (64, 65, 128, 129, 256, 257):
        n = 1 << d
        floor_T = isqrt(2 * n)
        H, m = isqrt(n) // (d * d), d - 1
        for k in range(-3, 4):
            r, j = floor_T + d - 2 + 2 * k, m + k
            assert 0 <= j < H
            # |x| <= H/4 follows without approximating sqrt(2n).
            assert F(2 * j + 1, 1) <= F(H, 4)
            e_left, e_right = exponent(d, n, r, j - 1), exponent(d, n, r, j)
            # Stronger integer inequalities absorb a bounded product logarithm.
            assert 3 * (e_left - 2) >= floor_T + 1
            assert -3 * (e_right + 2) >= floor_T + 1
            reports.append({'d': d, 'k': k, 'typical_h': j,
                            'inside_growing_offset_window': True,
                            'opposite_adjacent_signs_with_T_over_3_margin': True})
    return reports


def macro_gap_controls():
    checked = 0
    # At alpha=sqrt(2), divide the profile by alpha, so all values are rational.
    for denominator in range(5, 46):
        for numerator in range(denominator + 1):
            t = F(numerator, denominator)
            if t < F(1, 5):
                continue
            gamma = 1 - t
            if t <= F(1, 3):
                psi_over_alpha = gamma + t * gamma * gamma
            else:
                psi_over_alpha = gamma + 2 * (t * t * gamma / 3 + t * gamma * gamma / 6 + gamma ** 3 / 12)
            assert 1 - psi_over_alpha >= F(9, 125)
            checked += 1
    return checked


def main():
    identities, budgets = polynomial_and_budget_controls()
    log_controls = log_concavity_controls()
    families = integer_family_controls()
    report = {
        'status': 'PASS', 'centered_cubic_and_tail_controls': identities,
        'tail_positive_budget_cases': budgets,
        'exact_adjacent_log_concavity_controls': log_controls,
        'actual_integer_family_controls': families,
        'macro_profile_gap_controls': macro_gap_controls(),
        'scope': 'Exact polynomial/product controls and integer surplus families, not an isomorphism enumeration.',
        'not_certified_by_finite_checks': [
            'the all-module covering and its inherited error constant',
            'uniform arbitrary-rank structural recovery',
            'an effective starting class', 'external independent review or global priority',
        ],
    }
    (HERE / 'growing_offset_tail_controls.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'centered_cubic_controls': identities,
                      'adjacent_controls': log_controls, 'integer_family_cases': len(families),
                      'macro_gap_cases': report['macro_profile_gap_controls']}))


if __name__ == '__main__':
    main()

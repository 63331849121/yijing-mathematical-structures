"""Exact controls for rank-census normalization and uniform error budgets.

No Lie-type enumeration. The asymptotic theorem is proved in note 11;
the finite margins below omit the inherited unspecified logarithmic constant.
"""
from fractions import Fraction
from math import prod, isqrt
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent


def gl(q, t):
    return prod(q ** t - q ** j for j in range(t))


def rank_count(q, h, m, u):
    if u == 0:
        return 1
    numerator = prod((q ** h - q ** i) * (q ** m - q ** i) for i in range(u))
    denominator = gl(q, u)
    assert numerator % denominator == 0
    return numerator // denominator


def P(q, t):
    return prod(1 - Fraction(1, q ** i) for i in range(1, t + 1))


def qpower(q, exponent):
    return Fraction(q ** exponent) if exponent >= 0 else Fraction(1, q ** (-exponent))


def census_controls():
    count = 0
    adjacent = 0
    for q in (2, 4, 8):
        for m in range(3, 10):
            for h in range(0, m + 5):
                terms = []
                for u in range(min(h, m) + 1):
                    Hu = q ** (u * (m - u)) * gl(q, u) * gl(q, m - u)
                    vertical = q ** (u * (h - u)) * gl(q, h - u)
                    term = Fraction(1, Hu * vertical)
                    rank = rank_count(q, h, m, u)
                    assert term == Fraction(rank, gl(q, m) * gl(q, h))
                    terms.append(term)
                assert sum(terms) == Fraction(q ** (h * m), gl(q, m) * gl(q, h))
                assert sum(rank_count(q, h, m, u) for u in range(min(h, m) + 1)) == q ** (h * m)
                max_dimension, gap = max(h, m), abs(h - m)
                maximum_rank_probability = Fraction(rank_count(q, h, m, min(h, m)), q ** (h * m))
                assert maximum_rank_probability == P(q, max_dimension) / P(q, gap)
                # Check the classical corank probabilities from product formulas.
                ell = min(h, m)
                for t in range(ell + 1):
                    probability = Fraction(rank_count(q, h, m, ell - t), q ** (h * m))
                    expected = qpower(q, -t * (gap + t)) * P(q, h) * P(q, m) / (P(q, ell - t) * P(q, t) * P(q, gap + t))
                    assert probability == expected
                for s in (3, 5):
                    d, n = m + 1, 1 << (m + 1)
                    Cd, Cs, CN = d * (d - 1) // 2, s * (s - 1) // 2, (d + s) * (d + s - 1) // 2
                    Ah = d + Cd + s * (d + 1) + Cs + h * CN
                    F = Ah - 1 - h * m
                    Vh = s * n - 3 * s + (h - 1) * CN
                    total_exponent = s * (n - d - 3) + F - d * s - m - h + h * m - m * m - h * h - s * s
                    assert total_exponent == Vh + m - h * (h + 1)
                    # Adjacent total-rank main term, unlike a full-row-rank slice,
                    # must remain nonzero across h=m.
                    r, sh = s + h, s - 1
                    Nn = d + sh
                    Vnext = sh * n - 3 * sh + h * (Nn * (Nn - 1) // 2)
                    exponent_difference = Vnext - Vh - 2 * h - 2
                    assert exponent_difference == -n + CN - h * (d + s) + 1 - h
                    denominator_ratio = P(q, s) * P(q, h) / (P(q, s - 1) * P(q, h + 1))
                    assert denominator_ratio == (1 - Fraction(1, q ** s)) / (1 - Fraction(1, q ** (h + 1)))
                    assert denominator_ratio > 0
                    adjacent += 1
                count += 1
    return count, adjacent


def error_budgets():
    out = []
    # Even d makes sqrt(n) integral. Here a=1/2, b=3.
    for d in (64, 128, 256, 512, 1024):
        n, m = 1 << d, d - 1
        root = isqrt(n)
        H = root // (d * d)
        lower_s, upper_s = root // 2 - H, 3 * root
        Cs_lower = lower_s * (lower_s - 1) // 2
        Cd = d * (d - 1) // 2
        # Uniform positive cost, including the most negative main correction.
        positive = (H + 2) * Cd + d * H * H + H + d + upper_s * (H * m + 2 * d + 1) + H * (H + 1)
        bad_margin = Fraction(lower_s * lower_s, 16) - positive
        fiber_margin = Cs_lower - H * H - 2 * H
        D = n - d - 3
        deficient_margin = D - (upper_s * d + 2 * upper_s + m + H + m * m + H * H)
        rho_lower = root // 2 - d - 3
        # Safe upper exponents of the pure/nonpure frame sums, ignoring only
        # polynomial prefactors, which are at most q^(O(d)).
        pure_exponent = d * (upper_s + d) - (lower_s - d) * rho_lower
        second_exponent = upper_s + d - n // 3
        B_exponent = d * d + upper_s * d + upper_s * upper_s + 1 - lower_s * (n // 4) + upper_s * (d + 3)
        delta_exponent = upper_s * d + 2 * upper_s - 1 - D
        if d >= 256:
            assert bad_margin > Fraction(n, 1024)
            assert fiber_margin > Fraction(n, 16)
            assert deficient_margin > Fraction(n, 2)
            assert max(pure_exponent, second_exponent, B_exponent, delta_exponent) < -Fraction(n, 32)
        out.append({
            'd': d, 'H_bit_length': H.bit_length(),
            'bad_margin_over_n': str(bad_margin / n),
            'fiber_margin_over_n': str(Fraction(fiber_margin, n)),
            'deficient_margin_over_n': str(Fraction(deficient_margin, n)),
            'frame_largest_core_exponent_over_n': str(Fraction(max(pure_exponent, second_exponent, B_exponent, delta_exponent), n)),
            'core_budget_positive': bad_margin > 0,
        })
    return out


def main():
    cases, adjacent = census_controls()
    report = {
        'status': 'PASS', 'rank_census_parameter_cases': cases,
        'adjacent_exponent_and_product_controls': adjacent,
        'uniform_error_budget_controls': error_budgets(),
        'scope': 'Exact rank-census identities and error-budget polynomials; no Lie-type census and no certified effective cutoff.',
        'not_verified_by_computation': [
            'inherited arbitrary-module covering theorem',
            'arbitrary-d End and semilinear recovery',
            'the unspecified inherited O_q(log r) constant',
            'global novelty or external peer review',
        ],
    }
    (HERE / 'growing_defect_rank_census_controls.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'rank_census_cases': cases,
                      'adjacent_controls': adjacent, 'error_budget_cases': len(report['uniform_error_budget_controls'])}))


if __name__ == '__main__':
    main()

"""Independent literal module/CE controls; no inherited cohomology helper.

Ranks of 0/1 matrices over F2 equal their ranks after extension to Fq.
Finite checks are auxiliary to the general orbit proof in note 05.
"""
from itertools import combinations
from math import prod
from pathlib import Path
from fractions import Fraction
import json

HERE = Path(__file__).resolve().parent


def reduce_vector(v, pivots):
    while v:
        i = v.bit_length() - 1
        if i not in pivots:
            break
        v ^= pivots[i]
    return v


def insert(v, pivots):
    v = reduce_vector(v, pivots)
    if v:
        pivots[v.bit_length() - 1] = v
        return True
    return False


def kernel(columns):
    pivots = {}
    out = []
    for j, col in enumerate(columns):
        v, word = col, 1 << j
        while v:
            i = v.bit_length() - 1
            if i not in pivots:
                pivots[i] = (v, word)
                break
            old, old_word = pivots[i]
            v ^= old
            word ^= old_word
        if not v:
            out.append(word)
    return out


def apply_map(columns, vector):
    out = 0
    while vector:
        bit = vector & -vector
        out ^= columns[bit.bit_length() - 1]
        vector ^= bit
    return out


def module(d, split):
    masks = [a for a in range(1 << d) if a & ~1]
    index = {a: i for i, a in enumerate(masks)}
    w, z = len(masks) + 1, len(masks)
    tau = index[(1 << d) - 1]
    operators = []
    for i in range(d):
        cols = []
        for a in masks:
            if not split and i == 1 and a == 2:
                cols.append(1 << z)
            elif a & (1 << i):
                cols.append(0)
            else:
                cols.append(1 << index[a | (1 << i)])
        operators.append(cols + [0])
    theta = [0] * w
    theta[z] = 1 << tau
    if not split:
        theta[index[2]] = 1 << index[((1 << d) - 1) ^ 2]
    ns = []
    for i in range(1, d):
        cols = [0] * w
        cols[index[1 << i]] = 1 << z
        ns.append(cols)
    return masks, index, operators, theta, ns


def ce_case(d, s, split):
    masks, index, operators, theta, ns = module(d, split)
    w = len(masks) + 1
    # Nonzero independent polynomial actions, not only zero-action examples.
    for a in range(s):
        polynomial = [(1 << 0) | (1 << (1 + a % (d - 1)))]
        cols = []
        for b in range(w):
            value = 0
            for mask in polynomial:
                v = 1 << b
                for i in range(d):
                    if mask & (1 << i):
                        v = apply_map(operators[i], v)
                value ^= v
            cols.append(value)
        operators.append(cols)
    n = d + s
    pairs = list(combinations(range(n), 2))
    pair_index = {p: i for i, p in enumerate(pairs)}
    triples = list(combinations(range(n), 3))

    # Check square-zero, commuting actions and R-linearity independently.
    for p in operators:
        for b in range(w):
            assert apply_map(p, p[b]) == 0
    for p, q in combinations(operators, 2):
        for b in range(w):
            assert apply_map(p, q[b]) == apply_map(q, p[b])
    for t in [theta] + ns:
        for p in operators:
            for b in range(w):
                assert apply_map(t, p[b]) == apply_map(p, t[b])

    d1 = [0] * (n * w)
    for j in range(n):
        for b in range(w):
            value = 0
            for a in range(n):
                if a != j:
                    value ^= operators[a][b] << (pair_index[tuple(sorted((a, j)))] * w)
            d1[j * w + b] = value
    d2 = [0] * (len(pairs) * w)
    for row, (i, j, k) in enumerate(triples):
        for a, pair in ((i, (j, k)), (j, (i, k)), (k, (i, j))):
            offset = pair_index[pair] * w
            for b in range(w):
                d2[offset + b] ^= operators[a][b] << (row * w)
    boundaries = {}
    for col in d1:
        assert apply_map(d2, col) == 0
        insert(col, boundaries)
    cycles = kernel(d2)

    def induced_rank(t):
        pivots = dict(boundaries)
        before = len(pivots)
        for cycle in cycles:
            image = 0
            for p in range(len(pairs)):
                block = (cycle >> (p * w)) & ((1 << w) - 1)
                image ^= apply_map(t, block) << (p * w)
            assert apply_map(d2, image) == 0
            insert(image, pivots)
        return len(pivots) - before

    h2 = len(cycles) - len(boundaries)
    expected_h2 = d + d * (d - 1) + s * (2 * d + 1) + s * (s - 1)
    assert h2 == expected_h2
    theta_rank = induced_rank(theta)
    assert theta_rank == s * (s - 1) // 2
    combined_n = [0] * w
    for p in ns:
        combined_n = [a ^ b for a, b in zip(combined_n, p)]
    assert induced_rank(combined_n) == 1
    # Distinct N_i yield independent images of the literal star cycle.
    star = 0
    for i in range(1, d):
        star ^= 1 << (pair_index[(0, i)] * w + index[1 << i])
    # Core star by itself is not a cycle with nonzero extra actions;
    # independence is checked at s=0, without assuming a cocycle correction.
    if s == 0:
        assert apply_map(d2, star) == 0
        pvt = dict(boundaries)
        before = len(pvt)
        for t in ns:
            image = 0
            for p in range(len(pairs)):
                block = (star >> (p * w)) & ((1 << w) - 1)
                image ^= apply_map(t, block) << (p * w)
            insert(image, pvt)
        assert len(pvt) - before == d - 1
    return {
        'd': d, 's': s, 'split': split, 'module_dimension': w,
        'H2_dimension': h2, 'theta_H2_rank': theta_rank,
        'nonzero_N_H2_rank': induced_rank(combined_n),
        'polynomial_extra_actions': s,
    }


def gl(q, t):
    return prod(q ** t - q ** j for j in range(t))


def gf4_mul(a, b):
    # F4=F2[w]/(w^2+w+1), represented by 0,1,w,w+1.
    out = 0
    while b:
        if b & 1:
            out ^= a
        a <<= 1
        if a & 4:
            a ^= 7
        b >>= 1
    return out


def rank4(columns, rows):
    pivots = {}
    for column in columns:
        v = list(column)
        while any(v):
            j = next(i for i in range(rows) if v[i])
            if j not in pivots:
                inv = next(a for a in (1, 2, 3) if gf4_mul(a, v[j]) == 1)
                pivots[j] = [gf4_mul(inv, a) for a in v]
                break
            scale = v[j]
            v = [a ^ gf4_mul(scale, b) for a, b in zip(v, pivots[j])]
    return len(pivots)


def semilinear_checks(d):
    masks, index, p, _, _ = module(d, False)
    w, z = len(masks) + 1, len(masks)

    def add(a, b):
        out = dict(a)
        for key, value in b.items():
            out[key] = out.get(key, 0) ^ value
            if not out[key]:
                del out[key]
        return out

    def ring_mul(a, b):
        out = {}
        for i, x in a.items():
            for j, y in b.items():
                if not i & j:
                    out = add(out, {i | j: gf4_mul(x, y)})
        return out

    def action(poly, v):
        out = [0] * w
        for mask, coeff in poly.items():
            current = list(v)
            for i in range(d):
                if mask & (1 << i):
                    nxt = [0] * w
                    for j, value in enumerate(current):
                        if value:
                            b = p[i][j]
                            if b:
                                nxt[b.bit_length() - 1] ^= value
                    current = nxt
            out = [a ^ gf4_mul(coeff, b) for a, b in zip(out, current)]
        return out

    # Includes nonbinary a, lambda, b; an H_Q transvection; nonlinear terms.
    sigma = [{1 << i: 1} for i in range(d)]
    sigma[0] = {1: 2, 2: 1, 2 | 4: 3}
    sigma[1] = {2: 2, 4: 1, 1 | 8: 2}
    sigma[2] = {4: 1, 8: 2}
    phi = []
    for mask in masks:
        j = next(i for i in range(1, d) if mask & (1 << i))
        image = [0] * w
        for a, coeff in sigma[j].items():
            image[index[a]] ^= coeff
        for i in range(d):
            if i != j and mask & (1 << i):
                image = action(sigma[i], image)
        phi.append(image)
    zimage = [0] * w
    zimage[z] = gf4_mul(2, 2)  # lambda^2, rather than lambda
    phi.append(zimage)

    def linear_image(v):
        out = [0] * w
        for j, value in enumerate(v):
            if value:
                out = [a ^ gf4_mul(value, b) for a, b in zip(out, phi[j])]
        return out

    for i in range(d):
        assert ring_mul(sigma[i], sigma[i]) == {}
        for j in range(w):
            lhs = [0] * w
            if p[i][j]:
                lhs = phi[p[i][j].bit_length() - 1]
            assert lhs == action(sigma[i], phi[j])
    assert rank4(phi, w) == w
    # Deliberately replacing Frobenius by the untwisted lambda must fail.
    bad_zimage = [0] * w
    bad_zimage[z] = 2
    assert bad_zimage != action(sigma[1], phi[index[2]])
    return {'d': d, 'field': 4, 'semilinear_rank': w,
            'intertwining_equations': d * w,
            'nonbinary_diagonal_Frobenius_required': True}


def nonlifting_control():
    d = 4
    masks, index, p, _, _ = module(d, False)
    w = len(masks) + 1
    permutation = [0, 2, 1, 3]  # sends ker Q to a different hyperplane
    columns = []
    for row in range(w):
        for column in range(w):
            equations = 0
            for i in range(d):
                for j in range(w):
                    # F P_i contributes at row if P_i(e_j)=e_column.
                    if p[i][j] == (1 << column):
                        equations ^= 1 << ((i * w + j) * w + row)
                # P_sigma(i) F contributes only at input column.
                equations ^= p[permutation[i]][row] << ((i * w + column) * w)
            columns.append(equations)
    hom = kernel(columns)
    top = [index[1 << i] for i in range(1, d)]
    for f in hom:
        for i in top:
            for j in top:
                assert not (f >> (i * w + j)) & 1
    return {'d': d, 'nonpreserving_hyperplane_swap': True,
            'semilinear_Hom_dimension': len(hom), 'all_Hom_maps_zero_on_module_top': True}


def arithmetic_controls():
    checks = 0
    for q in (4, 8, 16):
        for d in range(4, 10):
            m, n = d - 1, 1 << d
            D = n - d - 3
            H = q ** (m - 1) * (q - 1) * gl(q, m - 1)
            assert Fraction(gl(q, m), H) == Fraction(q ** m - 1, q - 1)
            for s in range(2, min(7, D - 1)):
                F = d * (d - 1) + s * (2 * d + 1) + s * (s - 1)
                Ns = prod(q ** D - q ** j for j in range(s))
                Ne = Fraction(Ns * q ** (F - d * s - d), (q - 1) * H * gl(q, s))
                Nsplit = Fraction(Ns * q ** (F - d * s - d), (q - 1) ** 2 * gl(q, m) * gl(q, s))
                assert Ne / Nsplit == q ** m - 1
                r = s + 1
                Nb = Fraction(Ns * (q ** D - q ** s) * q ** (d * (d - 1) // 2 + r + r * (r - 1) // 2),
                              (q - 1) * gl(q, m) * gl(q, r))
                exponent = -n + (d + r) * (d + r - 1) // 2 + 2
                qpower = Fraction(q ** exponent) if exponent >= 0 else Fraction(1, q ** (-exponent))
                predicted = qpower * Fraction(q ** r - 1, q ** r) * Fraction(q ** m - 1, q ** m) / ((q - 1) * (1 - Fraction(q ** s, q ** D)))
                assert Ne / Nb == predicted
                checks += 1
    # Exhaustively check the residual additive orbit size in tiny fibers.
    orbit_checks = 0
    for q in (2,):
        for C in range(0, 5):
            unseen = set((theta, gamma) for theta in range(1 << C) for gamma in range(1 << C))
            orbits = 0
            while unseen:
                theta, gamma = next(iter(unseen))
                orbit = {(theta, gamma), (theta ^ gamma, gamma)}
                unseen -= orbit
                orbits += 1
            expected = Fraction(q ** (2 * C), q) * (1 + Fraction(q - 1, q ** C))
            assert orbits == expected
            orbit_checks += 1
    return checks, orbit_checks


def main():
    cases = [ce_case(d, s, split) for d in (4, 5, 6) for s in (0, 1, 2, 3) for split in (False, True)]
    formula_checks, orbit_checks = arithmetic_controls()
    semi = [semilinear_checks(d) for d in (4, 5, 6)]
    nonlift = nonlifting_control()
    report = {
        'status': 'PASS', 'literal_CE_cases': cases,
        'multiplicative_formula_checks': formula_checks,
        'tiny_residual_orbit_checks': orbit_checks,
        'nonbinary_semilinear_cases': semi,
        'nonlifting_hyperplane_control': nonlift,
        'scope': 'Fresh bit-linear algebra, independent of inherited helpers. No enumeration of unlabelled Lie types.',
        'not_certified_by_finite_checks': [
            'arbitrary-d complete semilinear recovery', 'uniform inherited stabilizer-sum estimates',
            'all-type exceptional-stratum control', 'global priority',
        ],
    }
    (HERE / 'first_defect_fiber_controls.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'literal_CE_cases': len(cases),
                      'multiplicative_formula_checks': formula_checks, 'tiny_residual_orbit_checks': orbit_checks,
                      'F4_semilinear_cases': len(semi), 'nonlifting_control': nonlift}))


if __name__ == '__main__':
    main()

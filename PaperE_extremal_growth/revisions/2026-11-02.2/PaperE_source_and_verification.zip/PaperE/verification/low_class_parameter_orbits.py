"""Bounded independent exterior-parameter orbit controls over F4.

The program does not traverse the 4^10 full s=4 parameter graph or enumerate
GL_4(F4). It scans 4096 quadratic parts, then at most 256 cubic parts in each
fixed quadratic stratum using explicit stabilizer generators.
"""
from itertools import combinations,product
from collections import deque
from pathlib import Path
import json

MUL=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
INV=(0,1,3,2)

def xor(values):
    z=0
    for v in values:z^=v
    return z

def scale_code(code,c,length):
    return sum(MUL[(code>>(2*i))&3][c]<<(2*i) for i in range(length))

def apply_linear(code,columns,length):
    return xor(scale_code(columns[i],(code>>(2*i))&3,length) for i in range(len(columns)))

def matrix_rank(rows):
    a=[list(r) for r in rows];m=len(a);n=len(a[0]);rank=0
    for j in range(n):
        k=next((k for k in range(rank,m) if a[k][j]),None)
        if k is None:continue
        a[k],a[rank]=a[rank],a[k]
        c=INV[a[rank][j]];a[rank]=[MUL[c][v] for v in a[rank]]
        for i in range(m):
            if i!=rank and a[i][j]:
                c=a[i][j];a[i]=[x^MUL[c][y] for x,y in zip(a[i],a[rank])]
        rank+=1
    return rank

def identity(s):return [[int(i==j) for j in range(s)] for i in range(s)]

def wedge_mul(a,b):
    result={}
    for i,c in a.items():
        for j,d in b.items():
            if i&j:continue
            mask=i|j;result[mask]=result.get(mask,0)^MUL[c][d]
    return {i:c for i,c in result.items() if c}

def masks_of_degree(s,d):
    return [sum(1<<i for i in items) for items in combinations(range(s),d)]

def wedge_action(matrix,d):
    s=len(matrix);masks=masks_of_degree(s,d);index={mask:i for i,mask in enumerate(masks)}
    columns=[]
    for mask in masks:
        image={0:1}
        for i in range(s):
            if mask&(1<<i):
                image=wedge_mul(image,{1<<j:matrix[j][i] for j in range(s) if matrix[j][i]})
        columns.append(sum(c<<(2*index[m]) for m,c in image.items()))
    return columns

def alternating_rank(code,s):
    a=[[0]*s for _ in range(s)]
    for k,(i,j) in enumerate(combinations(range(s),2)):
        a[i][j]=a[j][i]=(code>>(2*k))&3
    return matrix_rank(a)

def orbits(columns,length):
    remaining=set(range(4**length));answer=[]
    while remaining:
        start=min(remaining);orbit={start};queue=deque([start])
        while queue:
            x=queue.popleft()
            for g in columns:
                y=apply_linear(x,g,length)
                if y not in orbit:orbit.add(y);queue.append(y)
        assert orbit<=remaining
        remaining-=orbit;answer.append(orbit)
    return answer

def general_linear_generators(s):
    gens=[]
    for i in range(s):
        for j in range(s):
            if i==j:continue
            for c in [1,2]:
                a=identity(s);a[i][j]=c;gens.append(a)
        a=identity(s);a[i][i]=2;gens.append(a)
    return gens

def rank2_stabilizer():
    gens=[]
    for block in [[0,1],[2,3]]:
        for i,j in [(block[0],block[1]),(block[1],block[0])]:
            for c in [1,2]:
                a=identity(4);a[i][j]=c;gens.append(a)
        for i in block:
            a=identity(4);a[i][i]=2;gens.append(a)
    for i in [0,1]:
        for j in [2,3]:
            for c in [1,2]:
                a=identity(4);a[i][j]=c;gens.append(a)
    return gens

def rank4_symplectic_transvections():
    gens=[]
    partner=[1,0,3,2]
    for v in product(range(4),repeat=4):
        if not any(v):continue
        a=identity(4)
        for i in range(4):
            for j in range(4):a[i][j]^=MUL[v[i]][v[partner[j]]]
        gens.append(a)
    return gens

def fixed_alpha_orbits(alpha,gens):
    actions=[]
    for a in gens:
        assert matrix_rank(a)==4
        image=apply_linear(alpha,wedge_action(a,2),6)
        pivot=next(i for i in range(6) if (alpha>>(2*i))&3)
        delta=MUL[(image>>(2*pivot))&3][INV[(alpha>>(2*pivot))&3]]
        assert delta and image==scale_code(alpha,delta,6)
        action=[scale_code(x,INV[delta],4) for x in wedge_action(a,3)]
        actions.append(action)
    return orbits(actions,4)

def simple_rank_formula_control(s,r):
    size=1<<s;pairs=[(2*i,2*i+1) for i in range(r)]
    images=[]
    for mask in range(1,size):
        image=0
        for i,j in pairs:
            support=(1<<i)|(1<<j)
            if not mask&support:image^=1<<(mask|support)
        images.append(image)
    pivots={}
    for x in images:
        while x:
            bit=x.bit_length()-1
            if bit in pivots:x^=pivots[bit]
            else:pivots[bit]=x;break
    measured=len(pivots)
    predicted=(1<<(s-1))-(1<<(s-r-1))-1
    assert measured==predicted
    return {'s':s,'alternating_rank':2*r,'multiplication_rank_on_J_over_F4':measured}

def main():
    counts={0:0,2:0,4:0}
    for alpha in range(4**6):counts[alternating_rank(alpha,4)]+=1
    assert counts=={0:1,2:1071,4:3024}
    alpha2=1 # t1*t2
    alpha4=1|(1<<(2*5)) # t1*t2+t3*t4
    o2=fixed_alpha_orbits(alpha2,rank2_stabilizer())
    o4=fixed_alpha_orbits(alpha4,rank4_symplectic_transvections())
    o0=orbits([wedge_action(a,3) for a in general_linear_generators(4)],4)
    assert sorted(map(len,o0))==[1,255]
    assert sorted(map(len,o2))==[1,15,240]
    assert sorted(map(len,o4))==[1,255]
    # Cubic basis order is t123,t124,t134,t234.
    representatives=[
        ('zero',0,0,1),
        ('pure_cubic',0,1,255),
        ('rank2_pure',alpha2,0,1071),
        ('rank2_incident_cubic',alpha2,1,1071*15),
        ('rank2_nonincident_cubic',alpha2,1<<(2*2),1071*240),
        ('rank4_pure',alpha4,0,3024),
        ('rank4_nonzero_cubic',alpha4,1<<(2*2),3024*255)]
    for label,a,b,count in representatives:
        lookup=o0 if a==0 else o2 if a==alpha2 else o4
        orbit=next(o for o in lookup if b in o)
        assert len(orbit)*counts[alternating_rank(a,4)]==count
    assert sum(x[3] for x in representatives)==4**10
    s3=orbits([wedge_action(a,2) for a in general_linear_generators(3)],3)
    assert sorted(map(len,s3))==[1,63]
    report={'status':'PASS','s2_parameter_orbits':1,'s3_parameter_orbits':2,
            's3_orbit_sizes':sorted(map(len,s3)),
            's4_quadratic_parts_scanned':4**6,
            's4_quadratic_rank_counts':counts,
            's4_fixed_alpha_cubic_orbit_sizes':{'rank0':sorted(map(len,o0)),
                                              'rank2':sorted(map(len,o2)),
                                              'rank4':sorted(map(len,o4))},
            's4_parameter_orbits':7,
            's4_representatives':[{'label':label,'quadratic_code':a,'cubic_code':b,'full_orbit_size':count} for label,a,b,count in representatives],
            's4_mass_check':sum(x[3] for x in representatives),
            'scope':'4096 quadratic parts and 256 cubic parameters per fixed rank stratum; no enumeration of GL4 or the 1048576-point full parameter graph. The all-field proof is separate.',
            'pure_quadratic_multiplication_rank_checks':[simple_rank_formula_control(s,r) for s in range(3,9) for r in range(1,s//2+1)]}
    path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()

Authorship correction 2026-11-03: Baohua Li is the sole author of every Paper E version.
Independent verification materials for manuscript II
====================================================
From this project directory:
  python verification/run_replay.py --output-dir replay_core
  python verification/run_replay.py --no-write
  python verification/run_replay.py --extended --output-dir replay_extended

The runner uses an isolated copy and collects failures across tasks. Input
certificates and archived reports are not overwritten. Use a new report
directory for each run. Core and extended tasks are listed in REPLAY_TASKS.json.
The extended group contains the six additional controls listed in this paper's task specification.
All tables, certificate rows and local Python dependencies used by this entry
point are present here. No imports into the 209-page master are required.

The manuscript proves the general assertions and states where finite
calculations complete a proof step. Other finite checks are controls of
specified models. Existing reports retain their original scope and do not
claim that their entire contents were recomputed during the split.
INHERITED_INPUTS.json fingerprints the copied original files.
The fresh split replay is recorded separately in SPLIT_REPLAY.json.
This is exact computational verification, not proof-assistant formalization.

Dependencies: SymPy 1.14.0 plus the standard library.
Run --extended-only to replay only the additional expensive group.

Local critical-partition merge: four new controls plus two inherited interfaces
were freshly run; see replay_merge/MERGE_REPLAY.json. Use
--full-partition-only for only the new group. See full_partition/README.txt.

Local critical-partition merge: four new controls plus two inherited interfaces
were freshly run; see replay_merge/MERGE_REPLAY.json. Use
--full-partition-only for only the new group. See full_partition/README.txt.

Local critical-partition merge: four new controls plus two inherited interfaces
were freshly run; see replay_merge/MERGE_REPLAY.json. Use
--full-partition-only for only the new group. See full_partition/README.txt.

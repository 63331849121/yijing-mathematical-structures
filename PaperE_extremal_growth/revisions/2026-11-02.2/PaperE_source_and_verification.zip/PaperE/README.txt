Paper E (original G-II) / independent local revision / 84 pages / 2026-11-02
=======================================================================
Read PaperG_extremal_growth.pdf. Edit and compile the actual entry
PaperG_extremal_growth.tex in this directory. This local revision integrates
the complete critical partition and joint unlabelled-type rank law.
All supporting sources are supplied. No other paper or master is needed.
Use standard XeLaTeX twice, or build.ps1. The author-specific offline
cache helper is excluded from the portable ZIP.

Verification (Python; SymPy 1.14.0 for the inherited symbolic controls):
  python -m pip install -r verification/requirements.txt
  python verification/run_replay.py --full-partition-only --output-dir replay_new
The four new controls require only the standard library. The full default
runner includes 22 historical core tasks plus these four; --extended adds
the six separately listed extended tasks. --no-write uses temporary reports.
This merge freshly ran four new controls and two directly used inherited
interfaces; it did not rerun the historical entire suite. Fresh and inherited
reports retain separate scopes. See verification/replay_merge/ and
INTEGRATION_NOTES.txt for the result/finite-control correspondence.

DEPENDENCIES.json records the acyclic local proof chain and classical inputs.
manifest.json hashes every portable package input except itself.
The previous 80-page release and original local ZIP are preserved in the
E research merge archive. This 84-page revision is version 2026-11-02.2;
version DOI: 10.5281/zenodo.23881010. References distinguish public versions from local companion results.
The 209-page master remains frozen.

Current authors: Wencong Huang, Baohua Li. Wencong Huang joins from
this version; all earlier versions retain Baohua Li alone.
GitHub release: https://github.com/63331849121/yijing-mathematical-structures/releases/tag/paperE-v2026.11.02.2

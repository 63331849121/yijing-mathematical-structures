$ErrorActionPreference='Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
 if (Get-Command xelatex -ErrorAction SilentlyContinue) {
  1..2 | ForEach-Object {
   & xelatex -interaction=nonstopmode -halt-on-error PaperG_extremal_growth.tex
   if ($LASTEXITCODE -ne 0) { throw 'LaTeX compilation failed.' }
  }
 } elseif (Get-Command tectonic -ErrorAction SilentlyContinue) {
  & tectonic -X compile PaperG_extremal_growth.tex --untrusted --reruns 2
  if ($LASTEXITCODE -ne 0) { throw 'LaTeX compilation failed.' }
 } else { throw 'Install a standard XeLaTeX or Tectonic distribution.' }
} finally { Pop-Location }

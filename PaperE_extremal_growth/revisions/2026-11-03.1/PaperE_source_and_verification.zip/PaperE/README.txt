Authorship correction 2026-11-03: Baohua Li is the sole author of every Paper E version.
Paper E / 2026-11-03.1 / 91 pages / public preprint
Authors: Baohua Li.
Version DOI: 10.5281/zenodo.23903013
GitHub release: https://github.com/63331849121/yijing-mathematical-structures/releases/tag/paperE-v2026.11.03.1
Compile PaperG_extremal_growth.tex; see THEOREM_CONTROL_MAP.json, DEPENDENCIES.json,
and verification/README.txt. Eight relevant controls passed during this revision;
the entire historical suite was not rerun. Finite controls do not replace proofs.
that edition; earlier versions retain Baohua Li as sole author.

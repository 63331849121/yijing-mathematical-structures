"""Direct F4 algebra controls for the compatible J+Z family and frame recovery.
Finite controls support the written proof; no orbit enumeration is claimed.
"""
from pathlib import Path
from itertools import combinations
from random import Random
import json
HERE=Path(__file__).resolve().parent
T=[[0,0,0,0],[0,1,2,3],[0,2,3,1],[0,3,1,2]];INV={1:1,2:3,3:2}
def add(a,b):return [x^y for x,y in zip(a,b)]
def scale(c,a):return [T[c][x] for x in a]
def piv(vs):
    p={}
    for v in vs:
        v=v[:]
        for j in sorted(p):
            if v[j]:v=add(v,scale(v[j],p[j]))
        if any(v):
            j=next(j for j,x in enumerate(v) if x);p[j]=scale(INV[v[j]],v)
    return p
def invmat(A):
    n=len(A);A=[r[:]+[int(i==j) for j in range(n)] for i,r in enumerate(A)]
    for i in range(n):
        q=next(j for j in range(i,n) if A[j][i]);A[i],A[q]=A[q],A[i]
        A[i]=scale(INV[A[i][i]],A[i])
        for j in range(n):
            if i!=j and A[j][i]:A[j]=add(A[j],scale(A[j][i],A[i]))
    return [r[n:] for r in A]
def linear_combos(A,vectors):
    out=[]
    for row in A:
        v=[0]*len(vectors[0])
        for c,w in zip(row,vectors):v=add(v,scale(c,w))
        out.append(v)
    return out

rng=Random(20261103);cases=[]
for d,s,h in [(4,2,2),(4,3,3),(5,2,2),(5,3,3),(6,3,2)]:
    n=1<<d;top=n-1;z=h-1;N=d+s
    def mono(mask,c=1):
        v=[0]*n;v[mask]=c;return v
    def mul(a,b,quot=False):
        v=[0]*n
        for i,x in enumerate(a):
            if x:
                for j,y in enumerate(b):
                    if y and not i&j and (not quot or i|j!=top):v[i|j]^=T[x][y]
        return v
    def compose(f,vs):
        out=[0]*n
        for mask,c in enumerate(f):
            if c:
                v=mono(0,c)
                for i in range(d):
                    if mask>>i&1:v=mul(v,vs[i],True)
                out=add(out,v)
        out[top]=0;return out
    ps=[];masks=[a for a in range(n) if 2<=a.bit_count() and a!=top]
    for i in range(s):
        v=mono(masks[i])
        for j in range(i):v[masks[j]]=rng.randrange(4)
        ps.append(v)
    assert len(piv(ps))==s
    fs=[mono(1<<i) for i in range(d)]+ps
    ell=[int(i in [0,d]) for i in range(N)]
    pairs=list(combinations(range(N),2));pi={p:i for i,p in enumerate(pairs)}
    beta=[add(scale(ell[j],fs[i]),scale(ell[i],fs[j])) for i,j in pairs]
    gamma=[[rng.randrange(4) for _ in range(z)] for _ in pairs]
    for k,(i,j) in enumerate(combinations(range(d,N),2)):
        gamma[pi[i,j]]=[int(k==a) for a in range(z)] if k<z else [rng.randrange(4) for _ in range(z)]
    assert len(piv([gamma[pi[i,j]] for i,j in combinations(range(d,N),2)]))==z
    for i,j,k in combinations(range(N),3):
        assert not any(add(add(mul(fs[i],beta[pi[j,k]]),mul(fs[j],beta[pi[i,k]])),mul(fs[k],beta[pi[i,j]])))
    bs=[scale(ell[i],fs[i]) for i in range(N)]
    for i in range(N):
        assert not any(mul(fs[i],bs[i]))
        for j in range(N):
            if i!=j:assert mul(fs[i],bs[j])==mul(fs[j],beta[pi[tuple(sorted((i,j)))]] )
    gen=[mul(fs[i],mono(mask))[1:]+[0]*z for i in range(d) for mask in range(1,n)]
    gen += [v[1:]+g for v,g in zip(beta,gamma)]
    assert len(piv(gen))==n-1+z
    trans=[]
    for q in range(z):
        for i in range(d):
            vec=[]
            for a,b in pairs:
                c=(ell[b] if a==i else 0)^(ell[a] if b==i else 0)
                vec.extend([c if j==q else 0 for j in range(z)])
            trans.append(vec)
    assert len(piv(trans))==z*d
    chi=[row[0] for row in gamma];one=[[0]*n for _ in range(N)]
    for k,(i,j) in enumerate(pairs):
        if i<d:one[j]=add(one[j],mono(top^(1<<i),chi[k]))
    for k,(i,j) in enumerate(pairs):
        boundary=add(mul(fs[i],one[j]),mul(fs[j],one[i]))
        expected=mono(top,chi[k]) if i<d else [0]*n
        assert boundary==expected
    layer={j:mono(j) for j in range(1,n)}
    for step in range(1,d+1):
        pp=piv([mul(fs[i],v) for i in range(d) for v in layer.values()])
        layer=pp
        if step==d-1:assert len(layer)==1
    assert not layer
    # Nonlinear implicit recovery in A_J, with genuinely nonzero alpha.
    B=[[int(i==j) for j in range(d)] for i in range(d)]
    for k in range(d):B[k]=add(B[k],scale(2,B[(k+1)%d]))
    invmat(B)
    linear=linear_combos(B,[mono(1<<i) for i in range(d)])
    Delta=[[int(i==j) for j in range(s)] for i in range(s)]
    for k in range(s-1):Delta[k]=add(Delta[k],scale(3,Delta[k+1]))
    it=invmat([list(row) for row in zip(*Delta)])
    alpha=[[rng.randrange(4) for _ in range(s)] for _ in range(d)]
    def update(p):
        vs=[add(l,v) for l,v in zip(linear,linear_combos(alpha,p))]
        return linear_combos(it,[compose(f,vs) for f in ps])
    solutions=[]
    for seed in [[[0]*n for _ in range(s)],ps]:
        cur=seed
        for k in range(d+2):cur=update(cur)
        assert update(cur)==cur
        assert len(piv(cur))==s
        solutions.append(cur)
    assert solutions[0]==solutions[1]
    cases.append({'d':d,'s':s,'h':h,'actual_F4':True,'all_quotient_Jacobi':True,'all_restricted_basis_equations':True,'derived_generation_rank':n-1+z,'class':d+1,'two_seed_implicit_recovery_unique':True})

identities=0
for d in range(4,14):
    n=1<<d
    for s in [2,5,21,60]:
        for h in [1,2,5]:
            N=d+s;C=lambda x:x*(x-1)//2
            E=s*(n-d-2)+(h-1)*C(N)-N*N-(n-1)-(h-1)*(d+1)-(h-1)**2
            V=s*n-3*s+(h-1)*C(N)
            assert V+d-1-h*(h+1)-E==N*N+n+s*(d-1)+h*(d-2)-2
            identities+=1
def bpiv(vs):
    p={}
    for v in vs:
        while v:
            j=v.bit_length()-1
            if j in p:v^=p[j]
            else:p[j]=v;break
    return p
def bnull(rows,n):
    p=bpiv(rows);out=[]
    for j in range(n):
        if j in p:continue
        v=1<<j
        for k in sorted(p):
            if (p[k]&v).bit_count()%2:v^=1<<k
        out.append(v)
    return out
cohomology=[]
for d,s,z in [(4,2,1),(4,3,2),(5,2,1)]:
    n=1<<d;w=n-1+z;N=d+s
    masks=[a for a in range(1,n) if a.bit_count()>=2 and a!=n-1][:s]
    fmask=[1<<i for i in range(d)]+masks
    ops=[[1<<((a|f)-1) if not a&f else 0 for a in range(1,n)]+[0]*z for f in fmask]
    incoming=[]
    for op in ops:
        ins=[[] for _ in range(w)]
        for j,v in enumerate(op):
            if v:ins[v.bit_length()-1].append(j)
        incoming.append(ins)
    pairs=list(combinations(range(N),2));pi={p:j for j,p in enumerate(pairs)};nb=len(pairs)*w
    ce=[]
    for i,j,k in combinations(range(N),3):
        for r in range(w):
            v=0
            for a,p in [(i,(j,k)),(j,(i,k)),(k,(i,j))]:
                for c in incoming[a][r]:v^=1<<(pi[p]*w+c)
            ce.append(v)
    rows=ce[:]
    for j in range(N):
        for i in range(N):
            for r in range(w):
                v=0
                for c in incoming[i][r]:v^=1<<(nb+j*w+c)
                if i!=j:
                    for c in incoming[j][r]:v^=1<<(pi[tuple(sorted((i,j)))]*w+c)
                rows.append(v)
    ker=bnull(rows,nb+N*w)
    projected=len(bpiv([v&((1<<nb)-1) for v in ker]))
    boundaries=[]
    pair_boundaries=[]
    for i in range(N):
        for c in range(w):
            v=0
            for k,(a,b) in enumerate(pairs):
                val=ops[b][c] if a==i else ops[a][c] if b==i else 0
                v^=val<<(k*w)
            boundaries.append(v)
            pair_boundaries.append(v^(ops[i][c]<<(nb+i*w)))
    br=len(bpiv(boundaries));compatible=projected-br
    ordinary=nb-len(bpiv(ce))-br
    pred=N+s*(s-1)//2+z*N*(N-1)//2
    assert compatible==pred
    assert ordinary-compatible==d*(d-1)//2+s*d
    pair_piv=bpiv(pair_boundaries)
    restricted=len(ker)-len(pair_piv)
    assert restricted-compatible==s+z*N
    def red(p,v):
        for j in sorted(p,reverse=True):
            if v>>j&1:v^=p[j]
        return v
    for v in ker:
        for i in range(d):
            image=0
            for block in range(len(pairs)+N):
                vec=(v>>(block*w))&((1<<w)-1);outvec=0
                while vec:
                    bit=vec&-vec;outvec^=ops[i][bit.bit_length()-1];vec^=bit
                image^=outvec<<(block*w)
            assert not red(pair_piv,image)
    cohomology.append({'d':d,'s':s,'z':z,'full_ordinary_H2':ordinary,'compatible_H2_literal_constraint_projection':compatible,'predicted':pred,'restricted_pair_H2':restricted,'forget_square_fiber_dimension':restricted-compatible,'predicted_forget_fiber':s+z*N,'all_positive_core_multiplications_null_on_full_pair_kernel':True,'base_change_to_F4':True})
out={'status':'PASS','family_cases':cases,'exact_fiber_exponent_identities':identities,'full_compatible_cohomology':cohomology,'scope':'5 direct F4 compatible families; quotient Jacobi and restricted equations, derived generation, class, free N translations, full Theta core/mixed boundaries, two-seed frame recovery; 3 complete linear compatibility/CE systems over the prime field with F4 base change. No full isomorphism enumeration or general certification.'}
(HERE/'compatible_macro_family_controls.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','families':len(cases),'fiber_identities':identities}))

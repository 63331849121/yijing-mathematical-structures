"""Exact arithmetic controls around the new macro population proof.
The general inequalities are proved in 31--33; this is not Lie enumeration.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb,isqrt
import json
HERE=Path(__file__).resolve().parent
def C(j):return j*(j-1)//2
def exact(d,h,s,t):
    n=1<<d;w0=n-2
    L=(d-1)*C(d)+d*d*t
    E=w0-d+L+t*h
    A=d+C(d)+s*(d+1)+C(s)+h*C(d+s)
    V=s*n-3*s+(h-1)*C(d+s)
    lhs=A+s*(E-s)-t*C(s)-(V+(d-1)-h*(h+1))
    rhs=2*C(d)+1+s*(d+1+L+t*h)+h*(h+1)-t*C(s)
    assert lhs==rhs
    return E,rhs
def upper(d,h,s,t,rho):
    m=h+1-t;E,main=exact(d,h,s,t)
    G=(h+1)*(C(d)+1)+d*t*(h+2)
    eta=(d-1+t)*C(d)
    flag=0
    if rho:
        flag=s*rho*(m-rho)+F(m*(m-1),2)+F(m*s,2)+F(m,4)
    # Covers module/Gaussian/summation finite prefactors and M_h products.
    return F(main-rho*C(s)+G+eta+2*d+12)+flag

identities=0
for d in range(4,13):
    for s in [4,11,29,80]:
        for h in sorted(set([0,1,s//8,s//4])):
            for t in sorted(set([0,min(1,h),h//2,h])):
                exact(d,h,s,t);identities+=1

budgets=[]
for d in [60,64,72,80,100,120]:
    rt=isqrt(1<<d)
    for num,den in [(6,5),(7,5),(8,5)]:
        s=num*rt//den
        for h in sorted(set([0,1,s//20,s//8,s//4])):
            for t in sorted(set([0,min(1,h),min(2,h),h//2,h])):
                m=h+1-t
                for rho in sorted(set([0,min(1,m//2),m//2])):
                    if not t+rho:continue
                    value=upper(d,h,s,t,rho)
                    target=-F((t+rho)*s*s,64)
                    assert value<=target
                    assert exact(d,h,s,t)[0]>=2*s
                    budgets.append({'d':d,'s_over_sqrt_n':[num,den],'h':h,'t':t,'rho':rho,'margin_numerator':(target-value).numerator,'margin_denominator':(target-value).denominator})

def profiles():
    out=[]
    # beta/gamma<1/4 iff 4(2a-sqrt(a^2+6))<a+sqrt(a^2+6),
    # equivalent here to 7a<5sqrt(a^2+6); squared condition 24a^2<150.
    for i in range(150,161):
        a=F(i,100)
        assert 24*a*a<150
        assert a*a>2
        out.append({'alpha':str(a),'allocation_strictly_below_h_eq_s_over_4':True})
    return out

# Recover the exact ratio exponent and its decrement with independent variables.
ratios=0
for d in [4,9,17,32,60]:
    n=1<<d
    for s in [5,14,90,1000]:
        for h in [0,1,3,s//4]:
            r=h+s;N=d+r;u=N-h
            e=-n+C(d+s)-h*(d+s)+1-h
            assert 2*e==3*u*u+(1-2*N)*u-2*n+2-2*N
            enext=-n+C(d+s-1)-(h+1)*(d+s-1)+1-(h+1)
            assert enext-e==-2*(d+s)+h+1
            ratios+=1

result={'status':'PASS','exact_exponent_identities':identities,'macro_uniform_budget_points':len(budgets),'allocation_checks':profiles(),'ratio_identities':ratios,'budget_samples':budgets,'scope':'Exact polynomial and rational inequalities at stated points; no finite sampling certifies the uniform large-d theorem or an effective starting d.'}
(HERE/'macro_head_budget_controls.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','exponent_identities':identities,'macro_budget_points':len(budgets),'ratio_identities':ratios}))

"""Independent exact finite-product and uniform-budget controls for 37."""
from pathlib import Path
from math import prod,isqrt
from fractions import Fraction as F
import json
HERE=Path(__file__).resolve().parent
def C(j):return j*(j-1)//2
def GL(q,j):return prod(q**j-q**i for i in range(j))
def frames(q,D,s):return prod(q**D-q**i for i in range(s))
def M(q,d,h,s):
    D=(1<<d)-d-3;N=d+s
    return F(frames(q,D,s)*q**(C(d)+s+C(s)+h*C(N)-h),(q-1)*GL(q,d-1)*GL(q,h)*GL(q,s))
def P(q,d,h,s):
    D=(1<<d)-d-2;N=d+s;z=h-1
    return F(frames(q,D,s)*q**d*(q**s-1)*q**(C(s)+z*(C(N)-d)),(q-1)*q**(d*s+z)*GL(q,d)*GL(q,z)*GL(q,s))
def K(d,h,s):return C(s)+2*d*s-s+h*(d-2)+d*d-d-1
finite=[]
for q in [4,8]:
    for d in [4,5,6]:
        D=(1<<d)-d-3
        for s in [3,5]:
            for h in [1,2,3]:
                if s>D:continue
                direct=P(q,d,h,s)/M(q,d,h,s)
                predicted=F(q)**(-K(d,h,s))*(1-F(q)**(-D-1))/(1-F(q)**(s-1-D))*(1-F(q)**(-s))*(1-F(q)**(-h))/(1-F(q)**(-d))
                assert direct==predicted
                e=-(1<<d)+C(d+s)-h*(d+s)+1-h
                ratio=F(q)**(e+d+s)*(1-F(q)**(1-s))/((1-F(q)**(-h))*(1-F(q)**(s-2-D)))
                assert P(q,d,h+1,s-1)/P(q,d,h,s)==ratio
                assert K(d,h+1,s-1)-K(d,h,s)==-(d+s)
                marked=P(q,d,h,s)*F(q)**(h*(d+s)-d)
                markednext=P(q,d,h+1,s-1)*F(q)**((h+1)*(d+s-1)-d)
                mr=F(q)**(e+2*(d+s)-h-1)*(1-F(q)**(1-s))/((1-F(q)**(-h))*(1-F(q)**(s-2-D)))
                assert markednext/marked==mr
                shifted=F(q)**(-(1<<d)-d*(h+s)-C(d)+3*s+d+4)
                shifted *= (1-F(q)**(-D-1))*(1-F(q)**(-s))*(1-F(q)**(-s-1))/((1-F(q)**(-d))*(1-F(q)**(s-1-D))*(1-F(q)**(s-D)))
                assert marked/M(q,d,h-1,s+1)==shifted
                finite.append({'q':q,'d':d,'h':h,'s':s,'full_finite_products_match':True,'adjacent_ratio_match':True})

def budget(d,h,s,t,rho):
    m=h+1-t;L=(d-1)*C(d)+d*d*t
    main=2*C(d)+1+s*(d+1+L+t*h)+h*(h+1)-(t+rho)*C(s)
    modules=(h+1)*(C(d)+1)+d*t*(h+2)
    eta=(d-1+t)*C(d)
    flag=0 if not rho else s*rho*(m-rho)+F(m*(m-1),2)+F(m*s,2)+F(m,4)
    return F(main+modules+eta+2*d+20+K(d,h,s))+flag
conditional=[];modes=[]
for d in [60,64,72,80,100]:
    rt=isqrt(1<<d);n=1<<d
    for num,den in [(6,5),(7,5),(8,5)]:
        s=num*rt//den
        for h in sorted(set([1,2,s//20,s//10])):
            for t in sorted(set([1,min(2,h),h//2,h])):
                if not 1<=t<=h:continue
                m=h+1-t
                for rho in sorted(set([0,min(1,m//2),m//2])):
                    if t+rho<2:continue
                    value=budget(d,h,s,t,rho)
                    assert value<=-F((t+rho)*s*s,64)
                    conditional.append({'d':d,'h':h,'s':s,'t':t,'rho':rho,'conditional_gap_verified':True})
    for anum in [150,153,160]:
        r=anum*rt//100
        def e(h):
            s=r-h;return -n+C(d+s)-h*(d+s)+1-h
        def first_negative(comp):
            lo=1;hi=r//11
            while lo<hi:
                mid=(lo+hi)//2
                if e(mid)+(d+r-mid if comp else 0)<0:hi=mid
                else:lo=mid+1
            return lo
        jb=first_negative(False);jc=first_negative(True)
        assert jc in [jb,jb+1]
        assert jc==jb+(e(jb)+d+r-jb>=0)
        jt=jb+int(e(jb-1)>=3)
        assert jb<=jc<=jt<=jb+1
        assert e(jt-1)-3<0 and e(jt-2)-3>=0
        modes.append({'d':d,'alpha_hundredths':anum,'unrestricted_main_mode':jb,'compatible_main_mode':jc,'restricted_main_mode':jt,'three_way_interlacing':True,'shift':jc-jb})

out={'status':'PASS','finite_product_cases':finite,'conditional_budget_cases':conditional,'interlacing_mode_cases':modes,'restricted_pair_finite_transfer':True,'scope':'36 exact rational full-product, compatible/restricted adjacent-ratio and shifted-partition transfer checks; conditional large-d budgets and three-way integer-mode interlacing. These controls do not replace general structure and all-fiber proofs.'}
(HERE/'compatible_partition_controls.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','finite_products':len(finite),'conditional_budgets':len(conditional),'integer_modes':len(modes)}))

Authorship correction 2026-11-03: Baohua Li is the sole author of every Paper E version.
Population constraints and a relaxed square
==========================================
Run from the paper directory:
  python verification/run_replay.py --population-only --output-dir verification/replay_population

The runner executes six controls and two directly used inherited full-fiber
interfaces in an isolated copy. Every JSON states its finite scope.
The macro partition is uniform only in its stated integer window; finite
checks do not prove uniform tails or certify all automorphisms in general.
Original dated research reports are supplied; fresh logs/reports are in
verification/replay_population. No other manuscript is a program input.

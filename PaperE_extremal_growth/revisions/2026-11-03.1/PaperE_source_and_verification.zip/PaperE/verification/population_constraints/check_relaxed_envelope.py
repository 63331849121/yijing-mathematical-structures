"""Exact rational controls of the new all-stratum budget and leading maximum."""
from fractions import Fraction as Q
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
C = lambda a:a*(a-1)//2
def F(b,g,z,x):
    return g*(1+z*(b+g/2)-z*z+x*(z-g/2)-x*x)
grid = 0
for a in [Q(3,2),Q(31,20),Q(8,5)]:
    for ib in range(25):
        b = a*ib/24
        g = a-b
        maximum = a+2*a**3/27
        g0 = a+b*g*g/2
        delta = b-a/3
        assert maximum-g0 == delta*delta*(a-delta)/2
        assert maximum-g0 >= a*delta*delta/6
        assert g*(b-g/2) <= a*a/6 <= Q(32,75)
        for iz in range(13):
            z = b*iz/12
            for ix in range(7):
                x = z*ix/12
                dz = 1+g*(b+g/2-2*z+x)
                dx = -1+g*(z-g/2-2*x)
                assert dz >= Q(43,75)
                assert dx <= -Q(43,75)
                value = F(b,g,z,x)+z-x
                assert g0-value >= Q(43,75)*(b-z+x)
                assert value <= maximum
                grid += 1

budgets = 0
max_remainder_ratio = Q(0)
lower_controls = 0
max_negative_lower_ratio = Q(0)
rounding_controls = 0
for d in range(12,81,4):
    n = 1<<d
    root = 1<<(d//2)
    for target in [Q(3,2),Q(31,20),Q(8,5)]:
        r = int(root*target)
        a = Q(r,root)
        hs = sorted(set([0,1,r//10,r//3,r//2,3*r//4,r-1,r]))
        for h in hs:
            s = r-h
            N = d+s
            for m in sorted(set([1,max(1,(h+1)//2),h+1])):
                for rho in sorted(set([0,m//4,m//2])):
                    if s==0 and rho: continue
                    t = h+1-m
                    e = n-2+h*(d-1)+t*m
                    assert 2*s <= e
                    A = d+C(d)+s*(d+1)+C(s)+h*C(N)
                    budget = h*C(d)+d*h*h+h+s*(e-s)+A-(t+rho)*C(s)
                    budget += s*rho*(m-rho)
                    budget += (d+n-2+r-m+rho)*(m-rho)
                    b,g,z,x = [Q(v,root) for v in (h,s,m,rho)]
                    leading = n*root*(F(b,g,z,x)+z-x)
                    ratio = abs(budget-leading)/(d*n)
                    assert ratio <= 25
                    max_remainder_ratio = max(max_remainder_ratio,ratio)
                    budgets += 1
            if h>=1 and s>=2 and h-1<=C(s) and s<=n-d-2:
                z = h-1
                E = n-1+z*(d+1)+z*z
                exponent = s*(n-d-2)+z*C(N)+h*(n-2)-2*N*N-2*E-(n-1)
                simple = r*n+Q(h*s*s,2)
                neg = (simple-exponent)/n
                assert neg <= 50
                max_negative_lower_ratio = max(max_negative_lower_ratio,neg)
                lower_controls += 1
        h = (r+1)//3
        s = r-h
        rounding_loss = Q(2*r**3,27)-Q(h*s*s,2)
        assert 0 <= rounding_loss <= r
        assert s<=n-d-2 and h-1<=C(s)
        rounding_controls += 1

matrix_controls = 0
for q in [4,8,16]:
    for a in range(1,8):
        for b in range(1,10):
            total = 0
            for k in range(min(a,b)+1):
                count = Q(1)
                for i in range(k): count *= Q((q**a-q**i)*(q**b-q**i),q**k-q**i)
                assert count.denominator == 1
                assert count <= Q(q-1,q-2)*q**(k*(a+b-k))
                total += count
                matrix_controls += 1
            assert total == q**(a*b)

result = {'status':'PASS',
    'scope':'Exact Fraction identities/budgets and classical finite matrix counts; supports, does not replace uniform written proof.',
    'rational_objective_grid_points':grid,'integer_all_stratum_polynomial_budgets':budgets,
    'max_observed_abs_polynomial_remainder_over_dn':str(max_remainder_ratio),
    'lower_family_integer_budget_checks':lower_controls,
    'max_observed_negative_lower_cost_over_n':str(max_negative_lower_ratio),
    'integer_maximizer_rounding_checks':rounding_controls,
    'matrix_rank_product_checks':matrix_controls,
    'uniform_derivative_margin':'43/75; proved symbolically in 45, checked on rational grid here',
    'no_continuous_layer_realizability_assumption':True}
(HERE/'relaxed_envelope_controls.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))

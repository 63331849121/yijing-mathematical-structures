"""Independent finite F4 controls for round 9. Not an orbit classification."""
from pathlib import Path
from itertools import combinations
from random import Random
import json

HERE = Path(__file__).resolve().parent
M = [[0,0,0,0],[0,1,2,3],[0,2,3,1],[0,3,1,2]]
INV = [0,1,3,2]
def plus(a,b): return [x^y for x,y in zip(a,b)]
def times(c,a): return [M[c][x] for x in a]
def rank4(vs):
    piv = {}
    for v in vs:
        v = v[:]
        for j in sorted(piv):
            if v[j]: v = plus(v,times(v[j],piv[j]))
        if any(v):
            j = next(i for i,c in enumerate(v) if c)
            piv[j] = times(INV[v[j]],v)
    return len(piv)
def bpiv(vs):
    piv = {}
    for v in vs:
        while v:
            j = v.bit_length()-1
            if j in piv: v ^= piv[j]
            else:
                piv[j] = v
                break
    return piv
def bnull(rows, width):
    piv = bpiv(rows)
    ans = []
    for j in range(width):
        if j in piv: continue
        v = 1<<j
        for k in sorted(piv):
            if (v & piv[k]).bit_count() & 1: v ^= 1<<k
        ans.append(v)
    return ans
def bits(v):
    while v:
        p = v & -v
        yield p.bit_length()-1
        v ^= p

rng = Random(2026110309)
reports = []
for d,s,h in [(4,2,2),(4,3,3),(5,2,2),(5,3,3)]:
    n = 1<<d
    top = n-1
    z = h-1
    w = n-1+z
    N = d+s
    D = N+w
    masks = [a for a in range(1,n) if 2<=a.bit_count()<d][:s]
    fs = [1<<i for i in range(d)]+masks
    ell = [int(i in (0,d)) for i in range(N)]
    # All action matrices are literal monomial multiplication on J plus zero on Z.
    ops = [[(a|f)-1 if not a&f else -1 for a in range(1,n)]+[-1]*z for f in fs]
    incoming = []
    for op in ops:
        inc = [[] for _ in range(w)]
        for a,b in enumerate(op):
            if b>=0: inc[b].append(a)
        incoming.append(inc)
    def act(i,v):
        out = [0]*w
        for a,b in enumerate(ops[i]):
            if b>=0: out[b] ^= v[a]
        return out
    def f_action(a,v):
        out = [0]*w
        for i,c in enumerate(a):
            if c: out = plus(out,times(c,act(i,v)))
        return out
    def fvec(a):
        out = [0]*w
        for f,c in zip(fs,a): out[f-1] ^= c
        return out
    def linell(a):
        out = 0
        for c,e in zip(a,ell):
            if e: out ^= c
        return out
    pairs = list(combinations(range(N),2))
    gamma = {pair:[rng.randrange(4) for _ in range(z)] for pair in pairs}
    for a,pair in enumerate(combinations(range(d,N),2)):
        if a<z: gamma[pair] = [int(j==a) for j in range(z)]
    def gpolar(a,b):
        out = [0]*z
        for (i,j),g in gamma.items():
            out = plus(out,times(M[a[i]][b[j]]^M[a[j]][b[i]],g))
        return out
    def gquad(a):
        out = [0]*z
        for (i,j),g in gamma.items(): out = plus(out,times(M[a[i]][a[j]],g))
        return out
    def bracket(x,y):
        a,b = x[:N],y[:N]
        out = plus(f_action(a,y[N:]),f_action(b,x[N:]))
        out = plus(out,plus(times(linell(b),fvec(a)),times(linell(a),fvec(b))))
        out[n-1:] = gpolar(a,b)
        return [0]*N+out
    Sidx = [top-1]+list(range(n-1,w))
    # Random central Frobenius-linear map L/S -> S, both W and U parts nonzero.
    fw = [[rng.randrange(4) for _ in Sidx] if j not in Sidx else [0]*h for j in range(w)]
    fu = [[rng.randrange(4) for _ in Sidx] for _ in range(N)]
    def semimap(v,table):
        out = [0]*w
        for c,row in zip(v,table):
            for j,t in zip(Sidx,row): out[j] ^= M[M[c][c]][t]
        return out
    def square(x):
        a,v = x[:N],x[N:]
        out = plus(f_action(a,v),times(linell(a),fvec(a)))
        out[n-1:] = gquad(a)
        return [0]*N+plus(out,plus(semimap(a,fu),semimap(v,fw)))
    basis = [[int(i==j) for j in range(D)] for i in range(D)]
    samples = basis+[[rng.randrange(4) for _ in range(D)] for _ in range(28)]
    for x in samples:
        for c in range(4): assert square(times(c,x)) == times(M[c][c],square(x))
        assert not any(square(square(square(x))))
    polar_checks = 0
    ad_checks = 0
    for x,y in [(x,y) for x in basis for y in basis]+[(rng.choice(samples),rng.choice(samples)) for _ in range(80)]:
        assert square(plus(x,y)) == plus(plus(square(x),square(y)),bracket(x,y))
        assert bracket(square(x),y) == bracket(x,bracket(x,y))
        polar_checks += 1
        ad_checks += 1
    for j in Sidx: assert not any(square(basis[N+j]))
    # Independent complete Z1 and full module End computations.
    rows = []
    for i,j in pairs:
        for a in range(w):
            row = 0
            for b in incoming[i][a]: row ^= 1<<(j*w+b)
            for b in incoming[j][a]: row ^= 1<<(i*w+b)
            rows.append(row)
    ker = bnull(rows,N*w)
    assert len(ker) == n-1+N*h
    endrows = []
    for op,inc in zip(ops,incoming):
        for a in range(w):
            for b in range(w):
                row = (1<<(a*w+op[b])) if op[b]>=0 else 0
                for c in inc[a]: row ^= 1<<(c*w+b)
                endrows.append(row)
    enddim = w*w-len(bpiv(endrows))
    assert enddim == n-1+z*(d+1)+z*z
    # The entire section image as an F2-linear map on F4-valued Z1.
    def sec_image(v,c,relaxed):
        out = 0
        for i in range(N):
            for j in bits((v>>(i*w)) & ((1<<w)-1)):
                k = ops[i][j]
                if k>=0: out ^= c<<(2*(i*w+k))
                if relaxed and j==(1<<1)-1:
                    out ^= M[c][c]<<(2*(i*w+n-1))
        return out
    rank_old = len(bpiv([sec_image(v,c,False) for v in ker for c in (1,2)]))
    rank_new = len(bpiv([sec_image(v,c,True) for v in ker for c in (1,2)]))
    assert rank_old == 2*d
    assert rank_new == 2*(d+1)
    # Mixed top/connecting cocycle: failure of k-linearity is witnessed literally.
    connecting = sum(1<<(i*w+f-1) for i,f in enumerate(fs))
    mixed = connecting ^ (1<<(w+(top^(1<<1))-1))
    assert all((mixed & row).bit_count()%2 == 0 for row in rows)
    one = sec_image(mixed,1,True)
    omega = sec_image(mixed,2,True)
    scaled_one = 0
    for j in range(N*w): scaled_one ^= M[2][(one>>(2*j)) & 3]<<(2*j)
    assert omega != scaled_one
    # Nontrivial unit 1+t0 ceases to commute with F_W(t0*t1)=z.
    def fw2(v):
        ans = [0]*w
        ans[n-1] = M[v[((1<<0)|(1<<1))-1]][v[((1<<0)|(1<<1))-1]]
        return ans
    v = [0]*w
    v[(1<<1)-1] = 1
    assert fw2(plus(v,act(0,v))) != plus(fw2(v),act(0,fw2(v)))
    # Formula for changing a section, tested on all U basis and random W choices.
    section_checks = 0
    for i in range(N):
        for _ in range(16):
            g = [rng.randrange(4) for _ in range(w)]
            x = basis[i]
            assert square(plus(x,[0]*N+g)) == plus(square(x),[0]*N+plus(act(i,g),semimap(g,fw)))
            section_checks += 1
    gens = [bracket(x,y)[N:] for x,y in combinations(basis,2)]
    assert rank4(gens) == w
    reports.append({'d':d,'s':s,'h':h,'field':'F4','full_W_derived_rank':w,
        'all_basis_polar_and_ad_checks':polar_checks,'ad_checks':ad_checks,
        'section_formula_checks':section_checks,'full_End_dimension':enddim,
        'complete_Z1_dimension':len(ker),'section_F2_rank_old':rank_old,
        'section_F2_rank_relaxed':rank_new,'non_k_linear_witness':True,
        'positive_unit_failure_witness':True,'p_S_zero_and_p_cubed_zero':True})

out = {'status':'PASS','scope':'Finite F4 algebra, complete End and Z1, complete F2 section image; not full orbit enumeration or proof for all d.', 'cases':reports}
(HERE/'relaxed_square_sections_controls.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False))

"""Literal finite controls of the new common socle/head gauge.

No earlier Paper E helper is imported. Full module endomorphisms and CE
boundaries/cocycles are solved from their actual matrices. Finite controls
do not establish any asymptotic population theorem.
"""
from pathlib import Path
from itertools import combinations
from random import Random
import json

HERE=Path(__file__).resolve().parent
MUL=[[0,0,0,0],[0,1,2,3],[0,2,3,1],[0,3,1,2]]
INV={1:1,2:3,3:2}
def axpy(x,c,y): return [a^MUL[c][b] for a,b in zip(x,y)]
def fpiv(vectors):
    out={}
    for v in vectors:
        v=v[:]
        for j in sorted(out):
            if v[j]: v=axpy(v,v[j],out[j])
        if any(v):
            j=next(j for j,a in enumerate(v) if a)
            out[j]=[MUL[INV[v[j]]][a] for a in v]
    return out
def fred(piv,v):
    v=v[:]
    for j in sorted(piv):
        if v[j]: v=axpy(v,v[j],piv[j])
    return v
def bpiv(vectors):
    out={}
    for v in vectors:
        while v:
            j=v.bit_length()-1
            if j in out:v^=out[j]
            else:out[j]=v;break
    return out
def bred(piv,v):
    for j in sorted(piv,reverse=True):
        if v>>j&1:v^=piv[j]
    return v
def bnull(rows,n):
    piv=bpiv(rows);out=[]
    for j in range(n):
        if j in piv:continue
        v=1<<j
        for k in sorted(piv):
            if (piv[k]&v).bit_count()%2:v^=1<<k
        out.append(v)
    return out
def apply(op,v):
    out=[0]*len(op)
    for j,a in enumerate(v):
        z=op[j]
        while a and z:
            bit=z&-z;out[bit.bit_length()-1]^=a;z^=bit
    return out
def bitapply(op,v):
    z=0
    while v:
        bit=v&-v;z^=op[bit.bit_length()-1];v^=bit
    return z
def bits(v,n): return [v>>j&1 for j in range(n)]
def model(d,kind,z):
    mons=[a for a in range(1<<d) if a&~1]
    idx={a:j for j,a in enumerate(mons)};w0=len(mons)
    h0=1 if kind=='augmentation' else 2 if kind in ['split','nonsplit'] else min(2,d-1)
    active=w0+h0;N=active+z;ops=[]
    for i in range(d):
        op=[1<<idx[a|(1<<i)] if not a>>i&1 else 0 for a in mons]+[0]*(h0+z)
        if kind in ['split','nonsplit'] and i==0:op[w0]=1<<(w0+1)
        if kind=='nonsplit' and i==1:
            op[idx[2]]=1<<w0;op[idx[3]]=1<<(w0+1)
        if kind=='maxsocle' and 1<=i<=h0:op[idx[1<<i]]=1<<(w0+i-1)
        if kind=='augmentation' and i>0:op[w0]=1<<idx[1|(1<<i)]
        ops.append(op)
    for op in ops:
        assert all(bitapply(op,x)==0 for x in op)
    for a,b in combinations(ops,2):
        assert all(bitapply(a,b[j])==bitapply(b,a[j]) for j in range(N))
    return mons,idx,w0,h0,active,N,ops
def end_basis(ops,soc=None):
    N=len(ops[0]);rows=[]
    for op in ops:
        incoming=[[] for _ in range(N)]
        for j,v in enumerate(op):
            while v:
                bit=v&-v;incoming[bit.bit_length()-1].append(j);v^=bit
        for c in range(N):
            for r in range(N):
                row=0;v=op[c]
                while v:
                    bit=v&-v;row^=1<<((bit.bit_length()-1)*N+r);v^=bit
                for j in incoming[r]:row^=1<<(c*N+j)
                if row:rows.append(row)
    for v in soc or []:
        for r in range(N):
            row=0;x=v
            while x:
                bit=x&-x;row^=1<<((bit.bit_length()-1)*N+r);x^=bit
            rows.append(row)
    return [[(v>>(c*N))&((1<<N)-1) for c in range(N)] for v in bnull(rows,N*N)]
def socle(ops):
    N=len(ops[0]);rows=[]
    for op in ops:
        for r in range(N):rows.append(sum((op[c]>>r&1)<<c for c in range(N)))
    return bnull(rows,N)
def cohomology(ops):
    d=len(ops);N=len(ops[0]);pairs=list(combinations(range(d),2));pi={p:j for j,p in enumerate(pairs)}
    Bs=[]
    for i in range(d):
        for c in range(N):
            v=0
            for j,(a,b) in enumerate(pairs):
                val=ops[b][c] if a==i else ops[a][c] if b==i else 0
                v^=val<<(j*N)
            Bs.append(v)
    rows=[]
    for a,b,c in combinations(range(d),3):
        for r in range(N):
            v=0
            for i,p in [(a,(b,c)),(b,(a,c)),(c,(a,b))]:
                for k,col in enumerate(ops[i]):
                    if col>>r&1:v^=1<<(pi[p]*N+k)
            rows.append(v)
    Z=bnull(rows,len(pairs)*N);bp=bpiv(Bs);hp=[]
    for v in Z:
        r=bred(bp,v)
        if r:
            bp[r.bit_length()-1]=r;hp.append(v)
    B=fpiv([bits(v,len(pairs)*N) for v in Bs])
    return pairs,pi,hp,B
def head_projection(ops,active):
    rad=bpiv([v for op in ops for v in op[:active]])
    hb={};p=0
    for j in range(active):
        r=bred(rad,1<<j)
        for k in sorted(hb,reverse=True):
            if r>>k&1:r^=hb[k][0]
        if r:hb[r.bit_length()-1]=(r,1<<p);p+=1
    def hbvec(v):
        v=bred(rad,v);out=0
        for k in sorted(hb,reverse=True):
            if v>>k&1:v^=hb[k][0];out^=hb[k][1]
        assert not v
        return out
    return p,[hbvec(1<<j) for j in range(active)],rad
def normalize(beta,active,p,headcols):
    pairs=len(beta);z=len(beta[0])-active
    eta=[[0]*pairs for _ in range(p)]
    for k,row in enumerate(beta):
        for j,a in enumerate(row[:active]):
            mask=headcols[j]
            while a and mask:
                bit=mask&-mask;eta[bit.bit_length()-1][k]^=a;mask^=bit
    piv={}
    for j,row in enumerate(eta):
        row=row[:];track=[int(i==j) for i in range(p)]
        for k in sorted(piv):
            if row[k]:
                c=row[k];row=axpy(row,c,piv[k][0]);track=axpy(track,c,piv[k][1])
        if any(row):
            k=next(k for k,a in enumerate(row) if a);c=INV[row[k]]
            piv[k]=([MUL[c][a] for a in row],[MUL[c][a] for a in track])
    psi=[];out=[row[:] for row in beta]
    for zi in range(z):
        row=[v[active+zi] for v in beta];track=[0]*p
        for k in sorted(piv):
            if row[k]:
                c=row[k];row=axpy(row,c,piv[k][0]);track=axpy(track,c,piv[k][1])
        psi.append(track)
        for k,a in enumerate(row):out[k][active+zi]=a
    def phi(v):
        out=v[:];head=[0]*p
        for j,a in enumerate(v[:active]):
            for k in range(p):
                if headcols[j]>>k&1:head[k]^=a
        for zi,coeff in enumerate(psi):
            for k,a in enumerate(head):out[active+zi]^=MUL[a][coeff[k]]
        return out
    assert [phi(row) for row in beta]==out
    return out,len(piv),phi

rng=Random(20261103);reports=[]
for d,kind,z in [(4,'split',2),(4,'nonsplit',2),(4,'augmentation',2),(4,'maxsocle',2),(5,'nonsplit',1),(5,'augmentation',1),(5,'split',1),(5,'maxsocle',1)]:
    mons,idx,w0,h0,active,N,ops=model(d,kind,z)
    S=socle(ops);SA=socle([op[:active] for op in ops])
    p,headcols,rad=head_projection(ops,active)
    assert all(bred(rad,v)==0 for v in SA)
    t=h0+1-len(SA);h=h0+z;m=len(S)
    assert m==h+1-t and p<=d-1+t
    End=end_basis(ops);End0=end_basis(ops,S)
    EA0=end_basis([op[:active] for op in ops],SA)
    pairs,pi,H2,B=cohomology(ops)
    actops=[op[:active] for op in ops]
    ap,api,AH2,AB=cohomology(actops)
    def retains_top(beta):
        for inds in combinations(range(d),d-1):
            for row in beta:
                v=row[:active]
                for i in inds:v=apply(actops[i],v)
                if any(v):return True
        return False
    for sample in range(4):
        while True:
            beta=[[0]*N for _ in pairs]
            for j in range(1,d):beta[pi[0,j]][idx[1<<j]]=1
            for v in AH2:
                c=rng.randrange(4)
                if c:
                    for k in range(len(pairs)):
                        for j in range(active):
                            if v>>(k*active+j)&1:beta[k][j]^=c
            if retains_top(beta):break
        for row in beta:
            for j in range(active,N):row[j]=rng.randrange(4)
        norm,j,phi=normalize(beta,active,p,headcols)
        assert p-j<=t
        for c in range(N):
            v=[int(k==c) for k in range(N)]
            assert phi(phi(v))==v
            for op in ops:assert phi(apply(op,v))==apply(op,phi(v))
        for v in S:assert phi(bits(v,N))==bits(v,N)
        def observables(T):
            residual=[];obs=[]
            for row in norm:
                residual.extend(apply(T,row))
                obs.extend(apply(T,row[:active]+[0]*z)[active:])
            return fred(B,residual),obs
        res=[];aug=[]
        for T in End:
            r,o=observables(T);res.append(r);aug.append(r+o)
        assert len(fpiv(res))==len(fpiv(aug))
        if kind=='maxsocle':
            target=[]
            for i in range(1,d):target.extend(apply(ops[0],norm[pi[0,i]]))
            columns=[]
            for c in range(N):
                columns.append([a for i in range(1,d) for a in bits(ops[i][c],N)])
            assert any(fred(fpiv(columns),target))
        obs0=[observables(T)[1] for T in End0]
        container_kernel=len(End0)-len(fpiv(obs0))
        exact=len(EA0)+z*(p-j)
        bound=w0+h0*(d-1)+t*m
        assert container_kernel==exact<=bound
        visible=[0]*N;visible[active]=1<<idx[(1<<d)-1]
        rv=[]
        for row in norm:rv.extend(apply(visible,row))
        assert not any(fred(B,rv))
        reports.append({'d':d,'kind':kind,'h':h,'t':t,'profile':sample,'H2_active':len(AH2),'top_dimension':p,'core_head_rank':j,'missing_head':p-j,'full_End':len(End),'End_killing_socle':len(End0),'normalized_kernel_exact':container_kernel,'kernel_bound':bound,'full_compatible_End_in_container':True,'visible_rank_one_lift_present':True,'compatibility_b0_obstructed':kind=='maxsocle'})

# Regression: before the actual module shear, a liftable visible action can
# have a nonzero M->Z block. It must not be deleted in the original coordinates.
d=4;mons,idx,w0,h0,active,N,ops=model(d,'nonsplit',2)
p,headcols,rad=head_projection(ops,active)
pairs=list(combinations(range(d),2));pi={v:j for j,v in enumerate(pairs)}
beta=[[0]*N for _ in pairs]
for i in range(1,d):beta[pi[0,i]][idx[1<<i]]=1
beta[pi[1,2]][active]=2
def shear(v):
    out=v[:];out[active+1]^=v[idx[2]];return out
def T0(v):
    out=[0]*N;out[active]=v[active+1];return out
def Traw(v):return shear(T0(shear(v)))
raw=[shear(v) for v in beta]
assert all(not any(T0(v)) for v in beta)
assert all(not any(Traw(v)) for v in raw)
v=[0]*N;v[idx[2]]=1
assert Traw(v)[active]==1
normalized,j,phi=normalize(raw,active,p,headcols)
assert j==d-1
regression={'pre_gauge_nonzero_head_to_Z':True,'actual_conjugated_lift_kills_raw_cocycle':True,'post_gauge_obstruction_checked_in_full_profiles':True}
benchmarks=[]
for d in [4,5,6]:
    mons=list(range(1,1<<d));ix={a:j for j,a in enumerate(mons)};N=len(mons)
    ops=[[1<<ix[a|(1<<i)] if not a>>i&1 else 0 for a in mons] for i in range(d)]+[[0]*N]
    pairs=list(combinations(range(d+1),2));pi={x:j for j,x in enumerate(pairs)}
    beta=[[0]*N for _ in pairs]
    for i in range(1,d):beta[pi[0,i]][ix[1<<i]]=1
    for i in range(d):beta[pi[i,d]][ix[1<<i]]=1
    bs=[[0]*N for _ in range(d+1)];bs[0][ix[1]]=1
    for i in range(d+1):
        assert not any(apply(ops[i],bs[i]))
        for j in range(d+1):
            if i!=j:assert apply(ops[i],bs[j])==apply(ops[j],beta[pi[tuple(sorted((i,j)))]] )
    for i,j,k in combinations(range(d+1),3):
        vals=[apply(ops[i],beta[pi[j,k]]),apply(ops[j],beta[pi[i,k]]),apply(ops[k],beta[pi[i,j]])]
        assert all(a^b^c==0 for a,b,c in zip(*vals))
    benchmarks.append({'d':d,'compatible_surplus':2,'derived_dimension':N,'all_scalar_compatibility_equations':True})
core_square_tests=[]
for d in [4,5]:
    for kind in ['split','nonsplit','augmentation','maxsocle']:
        mons,idx,w0,h0,active,N,ops=model(d,kind,2)
        pairs=list(combinations(range(d),2));pi={v:j for j,v in enumerate(pairs)}
        beta=[[0]*N for _ in pairs]
        for i in range(1,d):beta[pi[0,i]][idx[1<<i]]=1
        columns=[[a for op in ops for a in bits(op[c],N)] for c in range(N)]
        image=fpiv(columns);ok=True
        for j in range(d):
            target=[]
            for i in range(d):
                target.extend([0]*N if i==j else apply(ops[j],beta[pi[tuple(sorted((i,j)))]]))
            ok=ok and not any(fred(image,target))
        assert ok==(kind=='augmentation')
        core_square_tests.append({'d':d,'kind':kind,'all_core_square_equations_solvable':ok,'expected_augmentation_selection':True})
out={'status':'PASS','profiles':reports,'regression':regression,'compatible_benchmarks':benchmarks,'core_square_tests':core_square_tests,'scope':'32 actual F4 core profiles in split, two nonsplit directions, and maximum-socle modules; complete literal R-End and CE computations. Noncentral visible lifts, 3 compatible sharp benchmarks, and 8 complete core-square systems. Does not prove a uniform population bound or all-module classification.'}
(HERE/'socle_head_normalization_controls.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','profiles':len(reports),'pre_gauge_regression':True,'full_End_and_CE':True}))

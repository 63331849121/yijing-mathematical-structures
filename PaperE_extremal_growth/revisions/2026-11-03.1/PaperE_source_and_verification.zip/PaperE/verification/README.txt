Authorship correction 2026-11-03: Baohua Li is the sole author of every Paper E version.
Independent finite verification for Paper E
===========================================
From the actual paper directory:
  python verification/run_replay.py --population-only --output-dir replay_new
  python verification/run_replay.py --full-partition-only --output-dir replay_critical
  python verification/run_replay.py --no-write
Use a new or empty output directory. The runner works in an isolated copy,
collects failures and preserves the source reports. --extended adds the
listed expensive historical tasks; --extended-only runs only that group.

The local 2026-11-03.1 revision freshly ran six population-constraint controls
and two inherited complete-fiber interfaces, all PASS. See replay_population/.
The historical entire suite was not rerun in this merge. Earlier replay and
research reports retain their stated scopes. Finite controls are not general
asymptotic proofs or proof-assistant formalization. All imported code/data
are included; no frozen master or companion manuscript is a runtime input.
The selected population group uses only the Python standard library.
The inherited symbolic staircase task uses SymPy 1.14.0.

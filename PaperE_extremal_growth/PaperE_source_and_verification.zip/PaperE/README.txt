Independent manuscript II / 80 pages / 2026-11-02
============================================================
Read PaperG_extremal_growth.pdf. Edit and compile PaperG_extremal_growth.tex in this directory.
All actually used supporting TeX files and bibliography entries are present.
Use a standard XeLaTeX distribution (two runs), or run build.ps1 from
PowerShell. No source input from the 209-page collection or another split
manuscript is required. The author-specific offline cache script is not
part of this portable distribution.

Verification:
  python -m pip install -r verification/requirements.txt
  python verification/run_replay.py --output-dir replay_new
Use --extended-only for the additional group, or --no-write for temporary
reports. See verification/README.txt and REPLAY_TASKS.json for exact scope.
This split has 22 successful fresh task invocations.
Recorded core/extended logs and interpreter versions are in verification/replay/.
Input fingerprints and fresh replay summaries have distinct files.

DEPENDENCIES.json lists the local principal-proof chain and classical inputs.
The three introductions state their separate contributions and relationships.
This is a local independent draft; the cited DOI identifies an earlier
research collection, not a newly assigned DOI for this manuscript.

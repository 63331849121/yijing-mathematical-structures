from pathlib import Path
import argparse,shutil,subprocess,sys,json,time
HERE=Path(__file__).resolve().parent
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output-dir',required=True);parser.add_argument('--adaptive-only',action='store_true');a=parser.parse_args()
    out=Path(a.output_dir).resolve()
    if out.exists():assert not any(out.iterdir()),'Use a new or empty output directory.'
    out.mkdir(parents=True,exist_ok=True)
    dest=out/'verification';shutil.copytree(HERE,dest,ignore=shutil.ignore_patterns('__pycache__'))
    root='higher_locality/'
    tasks=[] if a.adaptive_only else [
        (root+'PaperS_locality_rate_extension_2026-11-01/check_higher_rank_and_twist.py',[]),
        (root+'PaperS_higher_rank_locality_2026-11-01/check_outer_chain_basis.py',[]),
        (root+'PaperS_weighted_fibers_2026-11-01/check_closure_fibers.py',[]),
        (root+'PaperS_packet_comparison_2026-11-01/check_packet_comparison.py',[]),
        (root+'PaperS_packet_comparison_2026-11-01/check_full_plane_hom.py',[])]
    adaptive='adaptive_planes/research/PaperS_relative_tail_entropy_2026-11-02/'
    tasks += [(adaptive+name,[]) for name in (
        'check_shadow_and_width_extension.py','check_adaptive_polynomial_planes.py',
        'check_chain_interpolation.py','check_filtered_head_and_recovery.py',
        'check_abstract_betti_packets.py')]
    results=[]
    for index,(name,args) in enumerate(tasks,1):
        start=time.monotonic();log=out/f'{index:02d}_{Path(name).stem}.log'
        with log.open('w',encoding='utf-8') as handle:
            p=subprocess.run([sys.executable,str(dest/name),*args],stdout=handle,stderr=subprocess.STDOUT,cwd=dest)
        record={'program':name,'args':args,'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':log.name}
        results.append(record);print(json.dumps(record),flush=True)
        (out/'summary.json').write_text(json.dumps({'status':'PASS' if all(x['exit_code']==0 for x in results) else 'FAIL','completed':len(results),'expected':len(tasks),'results':results},indent=2)+'\n')
    assert all(x['exit_code']==0 for x in results),'One or more replay programs failed.'
if __name__=='__main__':main()

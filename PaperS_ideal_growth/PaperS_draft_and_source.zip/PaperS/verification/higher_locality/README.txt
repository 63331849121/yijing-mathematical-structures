Higher locality and complete extension fibers
These programs are the controls for the newly integrated theorems and appendices.
The stage directory names preserve their relative arithmetic-only imports.
The actual commutator module is used, not a free-module substitute. Fields F2,F3,F4
and actual Frobenius are covered. Counts include1015 module/padding cases,3746
rank/weight cases,11091 closure/Grassmann cases,2016 full-plane Hom checks, and64
weighted complete-fiber comparisons with137943 explicitly enumerated members.
Single fibers exceeding a preset enumeration cap are marked NOT_ENUMERATED;
they are not counted as exhaustive passes. No asymptotic theorem is inferred from
the number of cases. Non-full order-defect conjecture probes are not proof inputs.
From ../ run: python run_new_results.py --output-dir NEW_DIRECTORY
This preserves supplied JSON and writes fresh logs and a summary to the new copy.
The original typical_structure controls and their README remain unchanged.

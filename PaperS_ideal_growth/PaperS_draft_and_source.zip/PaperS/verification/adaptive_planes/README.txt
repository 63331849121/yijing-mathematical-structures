Paper S: adaptive-plane verification, local revision 2026-11-02

Run from any location with Python 3.10 or later; standard library only:
  python verification/run_new_results.py --output-dir NEW_EMPTY_DIRECTORY
To run only the five new entry points, add --adaptive-only.

The runner copies all verification material before executing. Supplied
reports and canonical sources are not rewritten by a replay.

Selected entry points in research/PaperS_relative_tail_entropy_2026-11-02/:
1. check_shadow_and_width_extension.py: rational shadow and tail budgets;
   sampled finite stable extensions, including an auxiliary width control.
2. check_adaptive_polynomial_planes.py: actual truncated Jacobi modules
   M_5 (cutoffs 2 and 3), M_6 (cutoff 2); exact reversible coordinate and
   semilinearity checks; three-normal interpolation and quotient overlaps.
3. check_chain_interpolation.py: polynomial identities over F2, F3, F4;
   chains of length 1 through 5 and capped polynomial lists.
4. check_filtered_head_and_recovery.py: rectangular staircase lengths,
   exact recovery-weight identities, rational exponent inequalities.
5. check_abstract_betti_packets.py: exhaustive ideals and packets over the
   nonregular ring F2[x,y]/(x,y)^3, including obstructed zero-boundary cases.

Sibling research paths are preserved for local helper imports. Historical
probe programs are dependencies only, not additional theorem claims. Their
main functions are not part of the replay; historical failed conjectures
are not assumptions of the manuscript. Detailed coverage and fixed seeds
are recorded in the selected programs and fresh JSON reports.

These finite checks test algebraic interfaces. The arbitrary-size results
are proved in the manuscript. Independent professional review of the new
proof chain remains pending; no proof-assistant formalization is claimed.

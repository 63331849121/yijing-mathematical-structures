"""Exact elementary source reduction for nilpotent semilinear modules.

Tests the inductive d-source argument over F2, F3 and genuine Frobenius F4.
This checks finite module algebra, not the large-n slab/counting theorem.
"""
from functools import cache
from itertools import product
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('arith',ROOT.parent/'PaperS_typical_structure_2026-11-01'/'check_head_fitting.py')
arith=importlib.util.module_from_spec(spec); spec.loader.exec_module(arith)
FIELDS={q:arith.Field(q) for q in [2,3,4]}


def add(q,a,b): return tuple(FIELDS[q].add(x,y) for x,y in zip(a,b))
def scale(q,a,v): return tuple(FIELDS[q].mul(a,x) for x in v)
def subtract(q,a,b): return add(q,a,scale(q,FIELDS[q].neg(1),b))


def combine(q,coeff,cols):
    out=(0,)*len(cols[0]) if cols else ()
    for a,v in zip(coeff,cols): out=add(q,out,scale(q,a,v))
    return out


@cache
def power(q,T,v,k):
    for _ in range(k): v=FIELDS[q].apply(T,v)
    return v


@cache
def height(q,T,v):
    zero=(0,)*len(T)
    for k in range(len(T)+1):
        if v==zero: return k
        v=FIELDS[q].apply(T,v)
    raise AssertionError('operator not nilpotent')


def act(q,T,coeff,v):
    if not coeff: return (0,)*len(T)
    return combine(q,coeff,[power(q,T,v,j) for j in range(len(coeff))])


@cache
def quotient(q,T,x):
    f=FIELDS[q]; n=len(T); a=height(q,T,x)
    chain=[power(q,T,x,j) for j in range(a)]
    full=list(chain)
    for j in range(n):
        v=tuple(int(i==j) for i in range(n))
        if f.rank(full+[v])>len(full): full.append(v)
    assert len(full)==n
    coordinates={combine(q,c,full):c for c in product(range(q),repeat=n)}
    assert len(coordinates)==q**n
    proj={v:c[a:] for v,c in coordinates.items()}
    QT=tuple(proj[f.apply(T,v)] for v in full[a:])
    return tuple(chain),coordinates,proj,QT


def apply_op(q,T,gens,op):
    if op[0]=='swap':
        _,i,j=op; gens[i],gens[j]=gens[j],gens[i]
    else:
        _,i,j,coeff=op
        gens[i]=subtract(q,gens[i],act(q,T,coeff,gens[j]))


def reduce_frame(q,T,gens):
    n=len(T); d=len(gens); gens=list(gens); ops=[]
    if n==0: return ops,[0]*d
    heights=[height(q,T,v) for v in gens]
    pivot=max(range(d),key=lambda i:heights[i])
    if pivot:
        op=('swap',0,pivot); apply_op(q,T,gens,op); ops.append(op)
    x=gens[0]; a=height(q,T,x)
    assert a>0
    chain,coordinates,proj,QT=quotient(q,T,x)
    subops,betas=reduce_frame(q,QT,[proj[v] for v in gens[1:]])
    for op in subops:
        lifted=(op[0],op[1]+1,op[2]+1)+op[3:]
        apply_op(q,T,gens,lifted); ops.append(lifted)
    for j,b in enumerate(betas,1):
        target=power(q,T,gens[j],b)
        c=coordinates[target]
        assert all(v==0 for v in c[a:])
        assert all(v==0 for v in c[:b])
        coeff=list(c[b:a])
        for _ in range(b): coeff=[FIELDS[q].sigma.index(v) for v in coeff]
        if any(coeff):
            op=('shear',j,0,tuple(coeff)); apply_op(q,T,gens,op); ops.append(op)
        assert height(q,T,gens[j])==b
    lengths=[a]+betas
    assert sum(lengths)==n
    assert FIELDS[q].rank([power(q,T,v,j) for v,l in zip(gens,lengths) for j in range(l)])==n
    return ops,lengths


def main():
    start=time.monotonic(); rows=[]; total=shear_count=0
    for q,maxn in [(2,3),(3,2),(4,2)]:
        f=FIELDS[q]
        for n in range(1,maxn+1):
            nil_operators=cases=0
            vecs=list(product(range(q),repeat=n))
            basis=[tuple(int(i==j) for i in range(n)) for j in range(n)]
            for flat in product(range(q),repeat=n*n):
                T=tuple(tuple(flat[j*n+i] for i in range(n)) for j in range(n))
                if any(power(q,T,v,n)!=(0,)*n for v in basis): continue
                nil_operators+=1; used=0
                for frame in product(vecs,repeat=3):
                    if f.rank([power(q,T,v,j) for v in frame for j in range(n)])!=n: continue
                    ops,lengths=reduce_frame(q,T,frame)
                    result=list(frame)
                    for op in ops: apply_op(q,T,result,op)
                    assert [height(q,T,v) for v in result]==lengths
                    # Verify each elementary operation has its exact inverse.
                    for op in reversed(ops):
                        inverse=op if op[0]=='swap' else (op[0],op[1],op[2],tuple(f.neg(a) for a in op[3]))
                        apply_op(q,T,result,inverse)
                    assert tuple(result)==frame
                    cases+=1; total+=1; used+=1
                    shear_count+=sum(op[0]=='shear' for op in ops)
                    if used>=60: break
            row=dict(q=q,dimension=n,nilpotent_operators=nil_operators,
                     generating_three_frames_checked=cases,cap_per_operator=60,
                     sigma='square' if q==4 else 'identity',status='PASS')
            rows.append(row); print(json.dumps(row),flush=True)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
                generating_frames_checked=total,shears_with_inverse_checked=shear_count,cases=rows,
                scope='Exact bounded finite semilinear source-basis controls; not a proof of asymptotic chain heights.')
    (ROOT/'outer_chain_basis_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print('ALL PASS',total,result['seconds'])


if __name__=='__main__': main()

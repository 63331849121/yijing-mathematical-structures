"""Guard the frozen 34-page baseline and validate the new research artifacts."""
from pathlib import Path
import hashlib
import json
import re

root=Path(__file__).parent
snapshot=json.loads((root/'source_snapshot_updated.json').read_text(encoding='utf-8'))
source=Path(snapshot['source']); baseline=Path(snapshot['baseline'])
external_changes=[]
for name,meta in snapshot['files'].items():
    current=hashlib.sha256((source/name).read_bytes()).hexdigest()
    if current!=meta['sha256']: external_changes.append(name)
    if name.endswith('.tex'):
        assert hashlib.sha256((baseline/name).read_bytes()).hexdigest()==meta['sha256'],name

tex=root/'higher_rank_support_and_chain_coupling.tex'
raw=tex.read_text(encoding='utf-8')
text='\n'.join(re.split(r'(?<!\\)%',line)[0] for line in raw.splitlines())
stack=[]
for cmd,env in re.findall(r'\\(begin|end)\{([^}]+)\}',text):
    if cmd=='begin': stack.append(env)
    else: assert stack and stack.pop()==env,(cmd,env)
assert not stack
balance=0
for c in re.sub(r'\\[{}]','',text):
    balance+=(c=='{')-(c=='}')
    assert balance>=0
assert balance==0
labels=re.findall(r'\\label\{([^}]+)\}',text)
refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',text)
assert len(labels)==len(set(labels)) and set(refs)<=set(labels)

controls={}
for name in ['flag_entropy_probe_results.json','support_and_chain_results.json','outer_chain_basis_results.json']:
    data=json.loads((root/name).read_text(encoding='utf-8'))
    assert data['status']=='PASS'
    controls[name]='PASS'
result=dict(status='PASS',date='2026-11-01',stage=5,
            frozen_baseline_verified=True,baseline_matches_current=not external_changes,
            baseline_manuscript_matches_current=not any(name.endswith(('.tex','.pdf')) for name in external_changes),
            metadata_only_changes=bool(external_changes) and all(name in ['manifest.json','PUBLICATION.json'] for name in external_changes),
            external_changes_since_baseline=external_changes,
            proof_source_static_checks='PASS: environments, braces and internal references',
            finite_controls=controls,
            main_manuscript_edits_performed=False,manuscript_compilation_performed=False,
            higher_rank_locality_rate_proved=False,
            remaining_gap='A common-origin-kernel-preserving primary completion with sublinear fiber and nilpotent-weight cost.',
            scope='General proof drafts with exact finite controls; no external proof certification or exhaustive priority determination.')
(root/'research_status.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))

"""Exact tangent/projection dimensions for fixed-origin monomial flags.

This probes the proposed higher-dimensional entropy input, not the final
Lie-quotient probability. All equations are coefficient equalities.
"""
from itertools import combinations
from math import comb
from pathlib import Path
import json
import time


def degree(n,d):
    if d==1:
        yield (n,)
    else:
        for a in range(n,-1,-1):
            for tail in degree(n-a,d-1):
                yield (a,)+tail


def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def divides(a,b): return all(x<=y for x,y in zip(a,b))


class DSU:
    def __init__(self,n): self.p=list(range(n+1)); self.zero=n
    def root(self,i):
        while self.p[i]!=i:
            self.p[i]=self.p[self.p[i]]; i=self.p[i]
        return i
    def equation(self,a,b):
        self.p[self.root(self.zero if a is None else a)]=self.root(self.zero if b is None else b)
    def dimension(self): return len({self.root(i) for i in range(len(self.p))})-1


def tangent(d,s,selected):
    I=tuple(degree(s,d))
    J=tuple(selected)+tuple(m for m in degree(s+1,d)
                            if not any(divides(a,m) for a in selected))
    SI=tuple(m for t in range(s) for m in degree(t,d))
    SJ=SI+tuple(m for m in I if m not in selected)
    axes=[tuple(int(i==j) for i in range(d)) for j in range(d)]
    ids={}
    for tag,gens,std in [('I',I,SI),('J',J,SJ)]:
        for g in gens:
            for m in std: ids[tag,g,m]=len(ids)
    eq=DSU(len(ids))
    def image(tag,g,shift,target):
        source=SI if tag=='I' else SJ
        return {add(m,shift):ids[tag,g,m] for m in source if add(m,shift) in target}
    def match(a,b):
        for m in a.keys()|b.keys(): eq.equation(a.get(m),b.get(m))
    sets={'I':set(SI),'J':set(SJ)}
    for tag,gens in [('I',I),('J',J)]:
        for a,b in combinations(gens,2):
            lcm=tuple(max(x,y) for x,y in zip(a,b))
            match(image(tag,a,sub(lcm,a),sets[tag]),image(tag,b,sub(lcm,b),sets[tag]))
    zero=(0,)*d
    for b in J:
        a=next(a for a in I if divides(a,b))
        match(image('J',b,zero,sets['I']),image('I',a,sub(b,a),sets['I']))
    for a in I:
        for x in axes:
            xa=add(a,x); b=next(b for b in J if divides(b,xa))
            match(image('J',b,sub(xa,b),sets['J']),image('I',a,x,sets['J']))
    total=eq.dimension()
    v=len(I); u=len(selected); gap=v-u
    fiber=u*gap
    assert total>=fiber
    return dict(d=d,s=s,h=len(SI),generator_number=v,gap=gap,retained_heads=u,
                tangent_dimension=total,grassmann_fiber_dimension=fiber,
                projected_tangent_dimension=total-fiber)


def main():
    start=time.monotonic(); rows=[]
    for d in [2,3]:
        for s in range(1,7):
            mons=list(degree(s,d)); v=len(mons)
            choices=sorted(set([0,1,min(s,v-1),min(2*s,v-1)]))
            for u in choices:
                row=tangent(d,s,tuple(mons[:u]))
                if u==0: assert row['tangent_dimension']==0
                if d==2:
                    # Classical refined-Hilbert dimension; no finite-field fit.
                    assert row['tangent_dimension']==2*row['h']-row['gap']*(row['gap']-1)
                rows.append(row); print(json.dumps(row),flush=True)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),cases=rows,
                scope='Exact monomial-flag tangent probe in free rank one; not yet the three-generator commutator module.')
    (Path(__file__).parent/'flag_entropy_probe_results.json').write_text(
        json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print('ALL PASS',len(rows),result['seconds'])


if __name__=='__main__': main()

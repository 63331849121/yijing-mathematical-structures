"""Independent exact controls for actual M_3, head hyperplanes and long chains.

Imports only finite-field arithmetic from an earlier independent research
control, never the manuscript's verification code. No statistical fitting.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations, product
from math import log, log1p, prod
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
arithmetic=ROOT.parent/'PaperS_typical_structure_2026-11-01'/'check_head_fitting.py'
spec=importlib.util.spec_from_file_location('independent_arithmetic',arithmetic)
helpers=importlib.util.module_from_spec(spec); spec.loader.exec_module(helpers)
Field=helpers.Field


def mons(n,d):
    if d==1:
        yield (n,)
    else:
        for a in range(n,-1,-1):
            for tail in mons(n-a,d-1): yield (a,)+tail


def mbasis(s):
    return ([(tag,)+m for tag in [0,1] for m in mons(s,3)]
            +[(2,0,a,s-a) for a in range(s,-1,-1)])


def mult_columns(s,axis,f):
    target=mbasis(s+1); indices={b:i for i,b in enumerate(target)}
    columns=[]
    for tag,x,y,z in mbasis(s):
        out=[0]*len(target)
        if tag==2 and axis==0:
            # X c23 = Y c13 - Z c12, the actual Jacobi relation.
            out[indices[1,0,y+1,z]]=1
            out[indices[0,0,y,z+1]]=f.neg(1)
        else:
            powers=[x,y,z]; powers[axis]+=1
            out[indices[(tag,)+tuple(powers)]]=1
        columns.append(tuple(out))
    return columns


def linear(f,cols,v):
    out=[0]*len(cols[0])
    for a,col in zip(v,cols):
        if a:
            out=[f.add(x,f.mul(a,y)) for x,y in zip(out,col)]
    return tuple(out)


def rref_rows(n,r,q):
    for pivots in combinations(range(n),r):
        free=[(i,j) for i,pivot in enumerate(pivots)
              for j in range(pivot+1,n) if j not in pivots]
        for values in product(range(q),repeat=len(free)):
            rows=[[0]*n for _ in pivots]
            for i,j in enumerate(pivots): rows[i][j]=1
            for (i,j),value in zip(free,values): rows[i][j]=value
            yield pivots,rows


def gaussian(n,r,q):
    value=Fraction(1)
    for i in range(r): value*=Fraction(q**(n-i)-1,q**(r-i)-1)
    assert value.denominator==1
    return int(value)


def module_families():
    rows=[]; cases=0
    for q,s,u in [(2,0,1),(3,0,1),(4,0,1),(2,1,1),(2,1,2)]:
        f=Field(q); v=len(mbasis(s)); w=len(mbasis(s+1))
        assert v==(s+1)*(s+3)
        multiplication=[mult_columns(s,i,f) for i in range(3)]
        hist=Counter(); number=0
        for pivots,ann in rref_rows(v,u,q):
            vbasis=[]
            for j in range(v):
                if j in pivots: continue
                vec=[0]*v; vec[j]=1
                for i,pivot in enumerate(pivots): vec[pivot]=f.neg(ann[i][j])
                vbasis.append(tuple(vec))
            rank=f.rank([linear(f,cols,b) for cols in multiplication for b in vbasis])
            g=v-u+w-rank
            assert v-u<=g<=v+2*u
            hist[g]+=1; number+=1; cases+=1
        assert number==gaussian(v,u,q)
        rows.append(dict(q=q,s=s,head_layer=v,removed_dimension=u,
                         exact_submodule_count=number,generator_histogram=dict(hist),status='PASS'))
    growth=[]
    for s in [5,10,20,50,100,500]:
        v=(s+1)*(s+3); u=s
        h=s*(s+1)*(2*s+7)//6+u; n=2*h
        lower_log=u*(v-u)-log(3*u+1,2)
        growth.append(dict(s=s,n=n,g_min=v-u,g_max=v+2*u,
                           fixed_g_log2_count_lower_bound=lower_log,
                           lower_bound_divided_by_n=lower_log/n))
    return cases,rows,growth


def hyperplanes():
    results=[]; matrices=0
    for q,maxh in [(2,4),(3,3),(4,2)]:
        f=Field(q)
        for h in range(1,maxh+1):
            counts=[0]*(h+1); total=0
            for flat in product(range(q),repeat=h*h):
                cols=tuple(tuple(flat[j*h+i] for i in range(h)) for j in range(h))
                if f.rank(cols)!=h: continue
                total+=1; matrices+=1
                for ell in range(h+1):
                    if all(cols[j][0]==0 for j in range(ell)): counts[ell]+=1
            expected_gl=prod(q**h-q**j for j in range(h))
            assert total==expected_gl
            for ell,count in enumerate(counts):
                actual=Fraction(count,total)
                expected=Fraction(q**(h-ell)-1,q**h-1)
                assert actual==expected,(q,h,ell,actual,expected)
            results.append(dict(q=q,h=h,invertible_head_maps=total,
                                kernel_counts_by_ell=counts,status='PASS'))
    return matrices,results


def counterexamples():
    rows=[]; identities=0
    for L in range(1,13):
        n=L+3; x,y,u=1,2,4
        def bracket(a,b):
            coef=(a&1)*(((b>>1)^(b>>2))&1)
            coef^=(b&1)*(((a>>1)^(a>>2))&1)
            return u*coef
        def power(a):
            out=a&1
            # u -> v1 -> ... -> vL -> 0; y maps to zero.
            out^=(a & (((1<<(L+2))-1)^3))<<1
            out^=u*((a&1)*(((a>>1)^(a>>2))&1))
            return out
        basis=[1<<i for i in range(n)]
        for a in basis:
            for b in basis:
                assert bracket(power(a),b)==bracket(a,bracket(a,b))
                identities+=1
                for c in basis:
                    assert bracket(a,bracket(b,c))^bracket(b,bracket(c,a))^bracket(c,bracket(a,b))==0
        chain=[]; now=u
        while now:
            chain.append(now); now=power(now)
        assert len(chain)==L+1 and all(v&(v-1)==0 for v in chain)
        assert bracket(x,u)==u and power(u)!=u
        if L<=3:
            for a in range(1<<n):
                for b in range(1<<n):
                    assert power(a^b)==power(a)^power(b)^bracket(a,b)
                    assert bracket(power(a),b)==bracket(a,bracket(a,b))
                    identities+=1
        rows.append(dict(L=L,total_dimension=n,ordinary_nilpotent_residual_dimension=1,
                         restricted_closure_dimension=len(chain),inner_is_nilpotent=True,
                         generated_by_x_y=True,status='PASS'))
    return identities,rows


def main():
    start=time.monotonic()
    mcount,mrows,growth=module_families()
    print('actual M3 Grassmann families PASS',mcount,flush=True)
    headcount,headrows=hyperplanes()
    identities,chains=counterexamples()
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
                exact_M3_submodule_cases=mcount,M3_cases=mrows,
                primary_family_growth_bounds=growth,
                invertible_head_maps_checked=headcount,head_hyperplane_cases=headrows,
                counterexample_identities=identities,long_chain_counterexamples=chains,
                scope='Exact finite controls and combinatorial bounds; no assertion that the higher-rank locality rate has been proved.')
    (ROOT/'support_and_chain_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__': main()

"""Nonhomogeneous falsification of the stronger UNPROVED cocyclic bound."""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('p',ROOT/'check_loewy_two_and_uniform.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
dual=p.dual;z=p.z


def main():
    start=time.monotonic();rng=random.Random(2026110237);sources=[];targets=[]
    for a,N,count in [(2,5,12),(3,6,10),(4,7,8)]:
        mon=[m for m in dual.monomials(N) if sum(m)>=a]
        for case in range(count):
            polys=[]
            for k in range(2+case%3):
                poly=[m for m in mon if rng.randrange(5)==0]
                if not any(sum(m)==a for m in poly):poly.append((a,0))
                polys.append(tuple(sorted(set(poly))))
            qs=[dual.quotient(polys,N,j) for j in range(6)];b=a+1-qs[0]['mu'];assert b>=0
            sources.append((b,qs))
            L=z.module(tuple(dual.transpose(op) for op in qs[0]['actions']));assert L['socle']==1
            targets.append(L)
    comparisons=0;bad=[]
    for b,qs in sources:
        for li,L in enumerate(targets):
            base=dual.hom_ideal(qs[0],L)
            for j in range(1,6):
                loss=qs[j]['mu']-qs[0]['mu']-(dual.hom_ideal(qs[j],L)-base);comparisons+=1
                if loss>b:bad.append(dict(b=b,j=j,loss=loss,target=li,source_mu=qs[0]['mu']));break
            if bad:break
        if bad:break
    result=dict(status='COUNTEREXAMPLE_FOUND' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',seconds=round(time.monotonic()-start,3),
        nonhomogeneous_sources=len(sources),cocyclic_targets=len(targets),comparisons=comparisons,counterexamples=bad,
        mathematical_status='UNPROVED stronger bound loss<=b for cocyclic targets; finite controls only.')
    (ROOT/'nonhomogeneous_cocyclic_probe_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

"""Exact controls for planar rank-r Hom comparison and the actual larger quotient.

Source lattices are nonhomogeneous submodules of S^2 and S^3. Generic
section lengths use a certified degree-64 extension. Actual Jacobi maps
are checked over F2, F3, F4, including every coordinate intertwining.
"""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('parameter_tools',ROOT/'check_parameter_and_packets.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
w=c.w;z=c.z;h=c.h


def lattice_quotient(r,polys,N,j):
    bound=N+j;labels=tuple((k,a,b) for k in range(r) for a,b in z.monomials(bound));idx={m:i for i,m in enumerate(labels)};relations=[]
    for poly in polys:
        order=min(a+b for k,a,b in poly)
        for p in range(j+1):
            for x,y in z.monomials(bound-order-j):
                v=0
                for k,a,b in poly:
                    pos=idx.get((k,a+p+x,b+j-p+y))
                    if pos is not None:v^=1<<pos
                relations.append(v)
    rel=h.canonical(relations);piv={(v&-v).bit_length()-1 for v in rel};free=[i for i in range(len(labels)) if i not in piv];fi={v:i for i,v in enumerate(free)}
    acts=[]
    for axis in range(2):
        local=[]
        for i in free:
            k,a,b=labels[i];pos=idx.get((k,a+int(axis==0),b+int(axis==1)));v=h.reduce(0 if pos is None else 1<<pos,rel);out=0
            while v:
                bit=v&-v;out|=1<<fi[bit.bit_length()-1];v^=bit
            local.append(out)
        acts.append(tuple(local))
    Q=w.z.module(tuple(acts));Q['rank']=r;Q['mu_source']=r+Q['socle'];return Q


def rank_hom_controls():
    w.DEG=64;w.MOD=(1<<64)|0x1B;w.MASK=(1<<64)-1;w.verify_field()
    rng=random.Random(2026110215);sources=[]
    for r,N,count in [(2,3,10),(2,4,10),(3,3,10)]:
        candidates=[(k,a,b) for k in range(r) for a,b in z.monomials(N) if a+b>=1]
        for i in range(count):
            polys=[]
            for t in range(1+i%5):
                poly=[m for m in candidates if rng.randrange(5)==0]
                if not poly:poly=[(0,1,0)]
                polys.append(poly)
            sources.append((r,N,polys))
    sources.extend([(2,5,[[(0,2,0)],[(0,0,2)],[(1,3,0)],[(1,0,3)]]),
                    (2,4,[[(0,2,0),(0,0,3)],[(0,1,1),(1,1,0)],[(1,0,2)]]),
                    (3,1,[[(k,0,0)] for k in range(3)])])
    checks=0;tails=0;rows=[]
    for r,N,polys in sources:
        qs=[lattice_quotient(r,polys,N,j) for j in range(4)]
        assert max(Q['length'] for Q in qs)<64
        aa=qs[0]['length']-w.pencil_rank(*qs[0]['actions']);v=qs[0]['mu_source'];bb=aa+r-v;assert bb>=0
        for j,Q in enumerate(qs):
            aj=Q['length']-w.pencil_rank(*Q['actions'])
            assert aj==aa+r*j
            assert Q['mu_source']>=v+r*j
        for which in ['X','Y','X+Y','X+Y^2','X+XY+Y^3']:
            torsion=[c.parameter_kernel(Q,which) for Q in qs];ax=len(torsion[0])
            for j,op in enumerate(torsion):
                assert len(op)==ax+r*j
                assert len(op)-len(h.canonical(op))==qs[j]['mu_source']-r
            for T in range(1,7):
                L=c.curve_module(T,which);hs=[];previous=None
                for j,Q in enumerate(qs):
                    hh=z.hom_ideal(Q,L)+(r-1)*T;hs.append(hh)
                    tail=len(h.canonical(c.power(torsion[j],T)))
                    assert hh==r*T+len(torsion[j])-tail
                    if previous is not None:assert tail<=previous;tails+=1
                    previous=tail
                for j in range(1,4):
                    loss=(qs[j]['mu_source']-v)-(hs[j]-hs[0])
                    assert loss<=bb*int(T>=2),(r,N,polys,which,T,j,loss,bb)
                    checks+=1
        rows.append(dict(rank=r,cutoff=N,lengths=[Q['length'] for Q in qs],generic_section=aa,defect=bb,
                         source_generators=[Q['mu_source'] for Q in qs]))
    return dict(sources=len(sources),strong_Hom_comparisons=checks,torsion_tail_checks=tails,
                exact_generic_extension_degree=64,irreducible_polynomial=hex(w.MOD),source_summaries=rows)


def projection_controls():
    a=h.a;reports=[];identities=0;generator_profiles=[]
    def Wbasis(d,s):return tuple((tag,x,y) for tag in [0]+list(range(2,d)) for x,y in a.mons(s+int(tag!=0),2))
    def image(row,wb):
        i,j=row[:2];powers=row[2:]
        if any(powers[2:]):return None
        if i==0 and j==1:return (0,powers[0],powers[1])
        if i==0:return (j,powers[0]+1,powers[1])
        if i==1:return (j,powers[0],powers[1]+1)
        return None
    for q in [2,3,4]:
        f=a.Field(q)
        for d in range(3,7):
            for s in range(3):
                wb=Wbasis(d,s);wi={m:i for i,m in enumerate(wb)};wb1=Wbasis(d,s+1);wi1={m:i for i,m in enumerate(wb1)}
                ps=[];pt=[]
                for row in a.basis(d,s):
                    m=image(row,wb);ps.append(tuple(int(i==wi.get(m)) for i in range(len(wb))))
                for row in a.basis(d,s+1):
                    m=image(row,wb1);pt.append(tuple(int(i==wi1.get(m)) for i in range(len(wb1))))
                assert f.rank(ps)==len(wb)
                for axis in range(d):
                    columns=a.multiply(d,s,axis,q)
                    for row,col in zip(a.basis(d,s),columns):
                        left=[0]*len(wb1)
                        for k,coef in enumerate(col):
                            if coef:
                                for j,x in enumerate(pt[k]):
                                    if x:left[j]=f.add(left[j],coef)
                        m=image(row,wb);right=[0]*len(wb1)
                        if m is not None and axis<2:
                            tag,x,y=m;right[wi1[tag,x+int(axis==0),y+int(axis==1)]]=1
                        assert tuple(left)==tuple(right),(q,d,s,axis,row)
                        identities+=1
                reports.append(dict(q=q,d=d,degree=s,source_dimension=len(ps),planar_dimension=len(wb),kernel_dimension=len(ps)-len(wb)))
    for d in range(3,7):
        previous=();profile=[]
        for s in range(4):
            wb=Wbasis(d,s);wi={m:i for i,m in enumerate(wb)}
            ims=[0 if image(row,wb) is None else 1<<wi[image(row,wb)] for row in a.basis(d,s)]
            K=h.ker(tuple(1<<i for i in range(len(ims))),ims)
            shadow=h.canonical(h.linear(h.mult(d,s-1,axis),v) for axis in range(d) for v in previous) if s else ()
            profile.append(len(K)-len(shadow));previous=K
        cnormal=d-2;assert profile==[cnormal*(cnormal-1)//2,cnormal*(cnormal+2),0,0],(d,profile)
        generator_profiles.append(dict(d=d,degree_generator_profile=profile))
    return dict(degree_field_cases=len(reports),coordinate_intertwining_identities=identities,cases=reports,kernel_generator_profiles=generator_profiles)


def main():
    start=time.monotonic();rank=rank_hom_controls();projection=projection_controls()
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),planar_rank_controls=rank,larger_projection_controls=projection,
                scope='Exact controls for the proved finite-planar-rank Hom and explicit actual-Md projection. No claim that the new projection closes unrestricted locality.')
    (ROOT/'planar_rank_and_projection_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status='PASS',seconds=result['seconds'],planar_sources=rank['sources'],
                          strong_rank_Hom_checks=rank['strong_Hom_comparisons'],projection_degree_field_cases=projection['degree_field_cases'],
                          coordinate_intertwinings=projection['coordinate_intertwining_identities'],kernel_profiles=projection['kernel_generator_profiles']),indent=2))


if __name__=='__main__':main()

"""Controls for the proved one-module transfer, including empty zero strata."""
from pathlib import Path
import importlib.util
from fractions import Fraction
import json
import time

ROOT=Path(__file__).parent
PREV=ROOT.parent/'PaperS_literature_and_nonfull_boundary_2026-11-02'
spec=importlib.util.spec_from_file_location('boundary_models',PREV/'check_boundary_width_variation.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
h=b.h;hom=b.z.z.hom
spec=importlib.util.spec_from_file_location('old_packets',ROOT.parent/'PaperS_packet_comparison_2026-11-01'/'check_packet_comparison.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def times_n(J):
    gens=set([(x+1,y) for x,y in J]+[(x,y+1) for x,y in J])
    return tuple(sorted((g for g in gens if not any(t!=g and t[0]<=g[0] and t[1]<=g[1] for t in gens)),reverse=True))


def main():
    start=time.monotonic();b.z.verify_field();cases=[];whole=[];skipped=[];subspace_checks=0
    configs=[([(0,0,1),(2,0,0),(1,1,0),(0,2,0)],((2,0),(0,1))),
             ([(0,0,1),(2,0,0),(1,1,0),(0,2,0)],((3,0),(2,2),(0,3))),
             ([(0,0,3),(2,0,0),(0,2,0)],((2,0),(0,2))),
             ([(0,0,1),(3,0,0),(2,1,0),(1,2,0),(0,3,0)],((3,0),(0,2)))]
    for ci,(gens,J) in enumerate(configs):
        J1=times_n(J);v=len(J);v1=len(J1);delta=v1-v;T=2*v-1;T1=2*v1-1
        actions,G=b.scalar_model(tuple(gens));g=len(G);L0=b.normal_module(actions)
        hs=hom(J,L0);ht=hom(J1,L0);A=max(0,delta*L0['socle']-(ht-hs));local=0
        for D in h.subspaces(g):
            dd=tuple(h.linear(G,row) for row in D);LD=b.normal_module(b.quotient_actions(actions,dd));a=len(D)
            sd=hom(J,LD);td=hom(J1,LD)
            assert sd<=hs-a+v*a
            assert td>=ht-v1*a
            assert sd-td+delta*(g-a)<=A+T*a
            local+=1
        subspace_checks+=local
        cases.append(dict(gens=gens,J=J,J_target=J1,g=g,source_Hom_L0=hs,target_Hom_L0=ht,
                          exact_A=A,crude_A=v*L0['u'],all_boundary_subspaces=local))
        assert A<=v*L0['u']
        for q in [2,3,4]:
            src=c.packet_for_ideal(q,gens,J);dst=c.packet_for_ideal(q,gens,J1)
            if src['status']!='PASS' or dst['status']!='PASS':
                skipped.append(dict(case=ci,q=q,source_status=src['status'],target_status=dst['status']));continue
            for m in [g+T+1,g+T+4]:
                z=sum(n*q**(mu*m) for mu,n in src['generator_histogram'].items())
                zz=sum(n*q**(mu*m) for mu,n in dst['generator_histogram'].items())
                exponent=delta*m-A-T*T1
                ratio=Fraction(z,zz)*Fraction(q**max(exponent,0),q**max(-exponent,0))
                assert ratio<=4
                whole.append(dict(case=ci,q=q,m=m,normalized_ratio=str(ratio),source_zero_boundary=src['boundary_rank_histogram'].get(0,0),
                                  target_zero_boundary=dst['boundary_rank_histogram'].get(0,0)))
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),boundary_subspace_comparisons=subspace_checks,
                cases=cases,complete_packet_weight_checks=whole,explicitly_not_enumerated=skipped,
                scope='Exact Hom sandwich and whole-packet controls for the proved one-module theorem, including cases with an empty source zero-boundary stratum. Enumeration caps are not treated as PASS.')
    (ROOT/'one_module_transfer_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['complete_packet_weight_checks','explicitly_not_enumerated']},indent=2))
    print('Complete packet weights:',len(whole),'; enumeration-capped pairs:',len(skipped))


if __name__=='__main__':main()

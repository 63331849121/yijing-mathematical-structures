"""Independent exact controls of the single-reduction and general step bounds.

Tests arbitrary targets as well as unequal coupled DVR strings.  Reduction
is detected by exact generic pencil rank, not assumed from target labels.
"""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
def load(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/file)
    out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out
p=load('loewy_controls','check_loewy_two_and_uniform.py')
mix=load('mixed_controls','probe_mixed_dvr_targets.py')
ranktools=load('rank_controls','check_planar_rank_and_projection.py')
w=p.w;z=p.z;dual=p.dual


def main():
    start=time.monotonic();rng=random.Random(2026110223);w.verify_field()
    loewy,uniform,raw=p.targets();targets=loewy+uniform
    for lengths in [(3,2),(5,2,1),(6,3,2),(4,3,2,1),(8,5,3)]:
        targets.extend(mix.mixed_target(lengths,rng) for _ in range(8))
    for r,N in [(2,3),(2,4),(3,3)]:
        for i in range(12):
            L=z.make_module(r,N,rng,1+i%5,1+i%2)
            for Q in [L,z.module(tuple(dual.transpose(op) for op in L['actions']))]:
                if Q['length']<32:targets.append(Q)
    for L in targets:
        L['e']=L['length']-w.pencil_rank(*L['actions'])
        L['delta']=L['e']-L['top'];assert L['delta']>=0
        L['width']=w.generic_width(L)
        if not L['delta']:assert L['top']>=L['socle']
    source=[w.c.ideal_of(part) for n in range(1,9) for part in w.c.partitions(n)]
    for r in range(2,7):
        source.append(tuple(sorted([(3*(r-i),3*i) for i in range(r+1)]+[(3*(r-i)-1,3*i+2) for i in range(r)],reverse=True)))
    step_checks=0;strong_checks=0;growth_checks=0
    for J in source:
        later=[J]
        for i in range(3):later.append(w.c.times_n(later[-1]))
        for L in targets:
            hs=[z.hom(I,L) for I in later]
            for i in range(3):
                v=len(later[i]);bound=L['e']-v*L['delta']
                assert hs[i+1]-hs[i]>=bound,(J,L,i,hs,bound)
                step_checks+=1
            if not L['delta']:
                for j in range(1,4):
                    dv=len(later[j])-len(J);cost=(dv-j)*L['width'];assert cost>=0
                    assert hs[j]-hs[0]>=dv*L['socle']-cost,(J,L,j,hs,cost)
                    assert hs[j]-hs[0]>=j*L['top']
                    strong_checks+=1;growth_checks+=1
    nonhom_checks=0;rank_checks=0
    smalltargets=targets[::6]
    for a,N,count in [(2,5,6),(3,6,4),(4,7,3)]:
        mon=[m for m in dual.monomials(N) if sum(m)>=a]
        for case in range(count):
            polys=[]
            for k in range(2+case%3):
                poly=[m for m in mon if rng.randrange(5)==0]
                if not any(sum(m)==a for m in poly):poly.append((a,0))
                polys.append(tuple(sorted(set(poly))))
            qs=[dual.quotient(polys,N,j) for j in range(4)]
            for L in smalltargets:
                hs=[dual.hom_ideal(Q,L) for Q in qs]
                for i in range(3):
                    assert hs[i+1]-hs[i]>=L['e']-qs[i]['mu']*L['delta']
                    if not L['delta']:
                        dv=qs[i+1]['mu']-qs[0]['mu'];j=i+1
                        assert hs[i+1]-hs[0]>=dv*L['socle']-(dv-j)*L['width']
                    nonhom_checks+=1
    # Fixed-rank nonhomogeneous source lattices; length identity uses finite duality.
    for r in [2,3]:
        for case in range(5):
            N=4;mon=dual.monomials(N)
            polys=[]
            for k in range(r+case%2):
                poly=tuple((component,a,b) for component in range(r) for a,b in mon
                           if a+b>=1 and rng.randrange(8)==0)
                polys.append(poly or ((k%r,1,0),))
            qs=[ranktools.lattice_quotient(r,polys,N,j) for j in range(4)]
            for L in smalltargets:
                hs=[dual.hom_ideal(Q,L)+(r-1)*L['length'] for Q in qs]
                for i in range(3):
                    assert hs[i+1]-hs[i]>=r*L['e']-qs[i]['mu_source']*L['delta']
                    if not L['delta']:
                        dv=qs[i+1]['mu_source']-qs[0]['mu_source'];j=i+1
                        assert hs[i+1]-hs[0]>=dv*L['socle']-(dv-r*j)*L['width']
                    rank_checks+=1
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),targets=len(targets),
        reduction_targets=sum(not L['delta'] for L in targets),nonreduction_targets=sum(bool(L['delta']) for L in targets),
        monomial_sources=len(source),general_one_step_comparisons=step_checks,
        sharp_reduction_comparisons=strong_checks,linear_top_growth_comparisons=growth_checks,
        nonhomogeneous_comparisons=nonhom_checks,rank_two_three_comparisons=rank_checks,
        scope='Exact independent controls for the general one-step Tor/DVR proof and the complete single-reduction target theorem. No unrestricted higher-Loewy width claim.')
    (ROOT/'single_reduction_comparison_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

"""Exact staircase controls of the cocyclic bw-only counterfamily.

Two independent readings are compared: generator increments and absolute
colength differences. The classical tiny-square family is attributed in
the companion proof; no enormous Hom matrix is substituted by a heuristic.
"""
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('product',ROOT/'probe_cocyclic_product_bound.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)


def colength(J):
    return sum(J[i][0]*(J[i+1][1]-J[i][1]) for i in range(len(J)-1))


def check(m):
    aa=[5*m,4*m]+list(range(4*m-1,3*m+3,-1))+[m,0]
    I=tuple(zip(aa,reversed(aa)));assert len(I)==m
    II=p.product_ideal(I,I);assert len(II)==9
    length=colength(I);assert length==(35*m*m+7*m-12)//2
    initial_h=colength(II)-length;cur=I;prod=II;dh=0;best=(0,0)
    for j in range(1,m-3):
        i=j-1;assert len(cur)==m+3*i and len(prod)==9*(i+1)
        dh+=len(prod)-len(cur)
        cur=p.minimal([(x+1,y) for x,y in cur]+[(x,y+1) for x,y in cur])
        prod=p.minimal([(x+1,y) for x,y in prod]+[(x,y+1) for x,y in prod])
        direct_h=colength(prod)-colength(cur)
        assert direct_h-initial_h==dh
        loss=len(cur)-m-dh;assert loss==(m-3)*j-3*j*j
        if loss>best[1]:best=(j,loss)
    b=4*m+1
    return dict(m=m,source_order=5*m,source_mu=m,source_defect=b,target_length=length,
                target_socle=1,target_width=1,target_u=length-1,
                best_step=best[0],effective_loss=best[1],bw_budget=b,
                violates_bw_only=(best[1]>b),respects_original_u_plus_bw=(best[1]<=length-1+b))


def main():
    start=time.monotonic();rows=[check(m) for m in [10,30,54,55,57,60,100,200]]
    assert any(r['violates_bw_only'] for r in rows)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),counterfamily_controls=len(rows),cases=rows,
                scope='Verifies the general proof draft that the bw-only cocyclic conjecture is FALSE and the u term cannot be o(u). Does not refute the original u+bw bound or Paper S locality.')
    (ROOT/'cocyclic_counter_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

"""Actual Jacobi controls for the radial-normal corner family.

Candidate disproves the old UNPROVED universal O(h^(1-2/d)) width
shortcut, while remaining in the proved Loewy-two Hom class.
All components are selected by genuine multidegrees in M_d.
"""
from pathlib import Path
from math import comb
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('actual_cores',ROOT/'check_actual_core_width.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
h=c.h;a=c.a


def normal_dim(cn,j):return comb(j+cn-1,cn-1)
def support_dim(cn,j):return cn*comb(j+cn-2,cn-1)
def f_bidegree(cn,plane,normal):
    T=support_dim(cn,normal);N=normal_dim(cn,normal)
    if plane==0:return T-N
    return (plane+1)*T+(plane-1)*N


def formulas(d,s,K):
    cn=d-2;S=s+2
    dg=sum((K-j)*(support_dim(cn,j)+normal_dim(cn,j)) for j in range(1,K))
    dh=sum((support_dim(cn,j)+normal_dim(cn,j))*((K-j)*(S-j)+(K-j)*(K-j-1)//2)
           +(support_dim(cn,j)-normal_dim(cn,j))*(K-j) for j in range(1,K))
    u=sum(f_bidegree(cn,S+K-2*j-1,j) for j in range(1,K))
    fs=(s+1)*comb(s+d,d-2)-(s+1)
    hs=sum((i+1)*comb(i+d,d-2)-(i+1) for i in range(s))
    return dict(head=hs+dh,g=fs+dg,u=u,generic_width=u,base_head=hs,base_g=fs,extra_head=dh,extra_g=dg)


def check(d,s,K):
    assert K>=2 and s>=K;N=s+K-1
    labels,ops,masks,idx=c.actual_F(d,N);n=len(labels);rows=[]
    for position,(degree,i) in enumerate(labels):
        row=a.basis(d,degree)[i]
        nj=int(row[0]>=2)+int(row[1]>=2)+sum(row[4:])
        if degree>=s and degree+nj>=s+K:rows.append(1<<position)
    P=tuple(rows)
    assert all(not h.reduce(h.linear(op,row),P) for op in ops for row in P)
    mP=h.canonical(h.linear(op,row) for op in ops for row in P)
    f=formulas(d,s,K);head=n-len(P);g=len(P)-len(mP)
    assert (head,g)==(f['head'],f['g']),(d,s,K,head,g,f)
    W=c.quotient(ops,mP);nw=len(W[0]);domain=tuple(1<<i for i in range(nw))
    soc=h.ker(domain,[sum(op[i]<<(q*nw) for q,op in enumerate(W)) for i in range(nw)])
    assert len(soc)==g
    normal_images=[sum(op[i]<<(q*nw) for q,op in enumerate(W[2:])) for i in range(nw)]
    L=h.ker(domain,normal_images)
    socL=h.ker(L,[h.linear(W[0],v)|(h.linear(W[1],v)<<nw) for v in L])
    assert len(socL)==g and len(L)-g==f['u'],(d,s,K,len(L),g,f)
    Ximage=h.canonical(h.linear(W[0],v) for v in L)
    assert len(Ximage)==f['u']
    assert all(not h.linear(op,v) for op in W[:2] for v in Ximage)
    return dict(d=d,s=s,K=K,ambient_actual_dimension=n,normal_length=len(L),
                basically_full=True,loewy_length_two=True,**f)


def main():
    start=time.monotonic();rows=[check(*case) for case in [(3,4,2),(3,5,3),(4,3,2),(4,4,3),(5,3,2),(6,3,2)]]
    asym=[]
    for d in range(3,7):
        cn=d-2
        for r in [2,4,8,16]:
            s=r**(cn+1);K=r**cn;f=formulas(d,s,K)
            asym.append(dict(d=d,r=r,s=s,K=K,width=f['u'],
                             scaled_width_over_s_to_d_minus_2=f['u']/s**cn,
                             extra_g_over_s_to_d_minus_2=f['extra_g']/s**cn,
                             extra_head_over_s_to_d_minus_1=f['extra_head']/s**(cn+1)))
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),field=2,
                actual_Jacobi_core_controls=len(rows),cases=rows,exact_formula_asymptotic_controls=asym,
                scope='Actual closed near-extremal family: mu=f_s+O(s^(d-2)), head=H_F(s)+O(s^(d-1)), width~s^(d-2+1/(d-1)). Disproves the old universal small-width candidate, not the general Hom bound or global locality rate.')
    (ROOT/'radial_normal_corner_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='exact_formula_asymptotic_controls'},indent=2))


if __name__=='__main__':main()

"""Exact controls of the general target-to-curve-lattices lift.

Checks actual intertwining and both residue ranks; multiplicity is computed
from a symbolic determinant independently of the generic pencil rank.
"""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
def load(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/file)
    out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out
p=load('nonsplit','probe_nonsplit_commuting_targets.py')
fat=load('fat','check_fat_band_comparison.py')
w=p.w;h=p.h;z=p.z


def det_poly(M):
    n=len(M);dp={0:{(0,0)}}
    for mask in range(1<<n):
        if mask not in dp:continue
        row=mask.bit_count()
        if row==n:continue
        for col in range(n):
            if not ((mask>>col)&1):
                dest=mask|(1<<col);term=fat.multiply(dp[mask],M[row][col])
                dp.setdefault(dest,set()).symmetric_difference_update(term)
    return dp.get((1<<n)-1,set())


def check(L):
    lengths=L['lengths'];data=L['Y_data'];e=len(lengths)
    YB=[[set() for a in lengths] for b in lengths];YT=[[set() for a in lengths] for b in lengths]
    for a,Na in enumerate(lengths):
        for b,Nb in enumerate(lengths):
            for r in data[a][b]:
                assert Na-Nb+r>=0;YB[b][a].add(Na-Nb+r);YT[b][a].add(r)
    bzero=tuple(sum((0 in YB[b][a])<<b for b in range(e)) for a in range(e))
    tzero=tuple(sum((0 in YT[b][a])<<b for b in range(e)) for a in range(e))
    assert e-len(h.canonical(bzero))==L['socle']
    assert e-len(h.canonical(tzero))==L['top']
    matrix=[[{(r,0) for r in YB[b][a]} for a in range(e)] for b in range(e)]
    for a in range(e):matrix[a][a].symmetric_difference_update({(0,1)})
    f=det_poly(matrix);assert f
    multiplicity=min(sum(m) for m in f)
    generic_e=L['length']-w.pencil_rank(*L['actions'])
    assert generic_e<=multiplicity<=e
    if generic_e==e:assert multiplicity==e
    offsets=[];total=0
    for N in lengths:offsets.append(total);total+=N
    checks=0
    for N in [max(lengths),max(lengths)+e+2]:
        size=e*N
        emb=[]
        for a,Na in enumerate(lengths):emb.extend(1<<(a*N+N-Na+i) for i in range(Na))
        XE=[];YE=[]
        for a in range(e):
            for i in range(N):
                XE.append(1<<(a*N+i+1) if i+1<N else 0);value=0
                for b in range(e):
                    for r in YB[b][a]:
                        if i+r<N:value^=1<<(b*N+i+r)
                YE.append(value)
        for source_op,target_op in zip(L['actions'],[XE,YE]):
            for i in range(total):
                assert h.linear(emb,source_op[i])==h.linear(target_op,emb[i]);checks+=1
    return dict(length=L['length'],DVR_strings=lengths,e_x=e,generic_Rees_number=generic_e,
                x_generic=(e==generic_e),ambient_multiplicity=multiplicity,
                ambient_mu=L['socle'],lattice_mu=L['top'],socle=L['socle'],top=L['top'],intertwining_checks=checks)


def main():
    start=time.monotonic();rng=random.Random(2026110236)
    w.DEG=64;w.MOD=(1<<64)|0x1B;w.MASK=(1<<64)-1;w.verify_field()
    targets=[]
    for lengths in [(5,3,1),(6,4,2),(8,5,3,2),(5,5,3,3),(7,4,4,2,1)]:
        targets.extend(p.target(lengths,rng) for i in range(5))
    # Complete intersections: X is generic, and both target defects are nonzero.
    for A,B in [(4,2),(5,3),(6,4)]:
        lengths=(A,)*B;data=[[[] for b in range(B)] for a in range(B)]
        for a in range(B-1):data[a][a+1]=[0]
        X=[];Y=[]
        for a in range(B):
            for i in range(A):
                X.append(1<<(a*A+i+1) if i+1<A else 0)
                Y.append(1<<((a+1)*A+i) if a+1<B else 0)
        L=z.module((tuple(X),tuple(Y)));L.update(lengths=lengths,Y_data=data);targets.append(L)
    rows=[check(L) for L in targets]
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),targets=len(rows),
        generic_x_targets=sum(r['x_generic'] for r in rows),intertwining_checks=sum(r['intertwining_checks'] for r in rows),
        cases=rows,scope='General target curve lift: symbolic determinant, two residue ranks and finite embeddings. No unrestricted Hom estimate inferred.')
    (ROOT/'general_target_lift_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))


if __name__=='__main__':main()

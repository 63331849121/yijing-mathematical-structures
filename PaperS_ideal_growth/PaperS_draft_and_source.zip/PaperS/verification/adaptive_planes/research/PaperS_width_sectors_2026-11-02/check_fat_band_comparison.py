"""Exact independent controls of the determinantal thick-band proof.

Checks the intermediate CM tensor inequality with explicit square matrices,
and the absolute/relative Hom bounds with arbitrary nonhomogeneous sources.
"""
from pathlib import Path
from itertools import permutations
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
def load(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/file)
    out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out
p=load('uniform_tools','check_loewy_two_and_uniform.py')
rtools=load('rank_tools','check_planar_rank_and_projection.py')
w=p.w;z=p.z;h=p.h;dual=p.dual


def band(t,A):
    labels=tuple((a,b) for a,b in dual.monomials(A) if a+b>=t);idx={m:i for i,m in enumerate(labels)}
    ops=tuple(tuple(1<<idx[(a+int(axis==0),b+int(axis==1))] if (a+int(axis==0),b+int(axis==1)) in idx else 0 for a,b in labels) for axis in range(2))
    L=z.module(ops);L.update(t=t,A=A,width=A-1 if A-t>=2 else 0)
    assert L['socle']==A;return L


def multiply(f,g):
    out=set()
    for a,b in f:
        for c,d in g:
            m=(a+c,b+d)
            if m in out:out.remove(m)
            else:out.add(m)
    return out


def determinant(M):
    n=len(M);out=set()
    for perm in permutations(range(n)):
        cur={(0,0)}
        for i,j in enumerate(perm):cur=multiply(cur,M[i][j])
        out.symmetric_difference_update(cur)
    return out


def cokernel(M,L):
    n=len(M);size=L['length'];cache={}
    def action(poly,i):
        key=(tuple(sorted(poly)),i)
        if key not in cache:
            value=0
            for a,b in poly:
                v=1<<i
                for _ in range(a):v=h.linear(L['actions'][0],v)
                for _ in range(b):v=h.linear(L['actions'][1],v)
                value^=v
            cache[key]=value
        return cache[key]
    cols=[]
    for j in range(n):
        for k in range(size):cols.append(sum(action(M[i][j],k)<<(i*size) for i in range(n)))
    return n*size-len(h.canonical(cols))


def main():
    start=time.monotonic();rng=random.Random(2026110228)
    targets=[band(t,A) for A in range(1,10) for t in range(A)]
    sources=[w.c.ideal_of(part) for length in range(1,9) for part in w.c.partitions(length)]
    for a in [2,3,4]:
        for r in [2,4,8]:sources.append(tuple((a*(r-i),a*i) for i in range(r+1)))
    for r in [2,4,8]:sources.append(tuple(sorted([(3*(r-i),3*i) for i in range(r+1)]+[(3*(r-i)-1,3*i+2) for i in range(r)],reverse=True)))
    absolute=0;relative=0
    for J in sources:
        b=min(sum(v) for v in J)+1-len(J);J1=w.c.times_n(J);J2=w.c.times_n(J1)
        for L in targets:
            base=z.hom(J,L);budget=L['length']-L['socle']+b*L['width']
            assert base-len(J)*L['socle']<=budget,(J,L,base,budget);absolute+=1
            for later in [J1,J2]:
                assert z.hom(later,L)-base>=(len(later)-len(J))*L['socle']-budget
                relative+=1
    nonhom=0;rank=0;w.DEG=64;w.MOD=(1<<64)|0x1B;w.MASK=(1<<64)-1;w.verify_field()
    for a,N,count in [(2,5,6),(3,6,5),(4,7,4)]:
        mon=[m for m in dual.monomials(N) if sum(m)>=a]
        for i in range(count):
            polys=[]
            for k in range(2+i%3):
                poly=[m for m in mon if rng.randrange(5)==0]
                if not any(sum(m)==a for m in poly):poly.append((a,0))
                polys.append(tuple(sorted(set(poly))))
            Q=dual.quotient(polys,N,0);b=a+1-Q['mu'];assert b>=0
            for L in targets:
                assert dual.hom_ideal(Q,L)-Q['mu']*L['socle']<=L['length']-L['socle']+b*L['width']
                nonhom+=1
    for r in [2,3]:
        N=4;mon=dual.monomials(N)
        for case in range(6):
            polys=[]
            for k in range(r+case%3):
                poly=tuple((component,a,b) for component in range(r) for a,b in mon if a+b>=1 and rng.randrange(7)==0)
                polys.append(poly or ((k%r,1,0),))
            Q=rtools.lattice_quotient(r,polys,N,0)
            aa=Q['length']-w.pencil_rank(*Q['actions']);v=Q['mu_source'];b=aa+r-v;assert b>=0
            for L in targets:
                hv=dual.hom_ideal(Q,L)+(r-1)*L['length']
                assert hv-v*L['socle']<=r*(L['length']-L['socle'])+b*L['width']
                rank+=1
    matrices=[];mon=[m for m in dual.monomials(5) if sum(m)>=1]
    for n in [1,2,3]:
        for i in range(12):
            M=[[set(m for m in mon if rng.randrange(8)==0) for j in range(n)] for k in range(n)]
            det=determinant(M)
            if det:matrices.append((M,min(sum(m) for m in det)))
    tensor_checks=0;hilbert_checks=0
    for M,a in matrices:
        for A in range(1,9):
            full=cokernel(M,band(0,A));assert full<=len(M)+(A-1)*a;hilbert_checks+=1
            for t in range(A):
                assert cokernel(M,band(t,A))<=full,(M,a,t,A,full)
                tensor_checks+=1
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),target_bands=len(targets),
        monomial_sources=len(sources),absolute_comparisons=absolute,relative_comparisons=relative,
        nonhomogeneous_ideal_comparisons=nonhom,rank_two_three_comparisons=rank,
        independent_square_presentations=len(matrices),CM_tensor_band_controls=tensor_checks,CM_Hilbert_controls=hilbert_checks,
        scope='Independent controls for the general determinantal proof of arbitrary thick bands and fixed planar-rank sources. Not a proof for arbitrary target extensions.')
    (ROOT/'fat_band_comparison_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

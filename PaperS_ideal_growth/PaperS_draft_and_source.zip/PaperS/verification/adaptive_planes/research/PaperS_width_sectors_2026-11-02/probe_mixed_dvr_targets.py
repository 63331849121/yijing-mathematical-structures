"""Falsification search beyond uniform DVR lifts; not a general proof.

X=t, Y=tC on direct sums of unequal A/(t^N) blocks.  C is generated
as a genuine A-linear endomorphism, including maps between different lengths.
"""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('uniform_controls',ROOT/'check_loewy_two_and_uniform.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
w=p.w;z=p.z;h=p.h;dual=p.dual


def mixed_target(lengths,rng):
    offsets=[];n=0
    for N in lengths:offsets.append(n);n+=N
    X=[];Y=[];C=[]
    for a,Na in enumerate(lengths):
        ca=[]
        for b,Nb in enumerate(lengths):
            minimum=max(Nb-Na,0)
            ca.append([r for r in range(minimum,Nb) if rng.randrange(3)==0])
        C.append(ca)
        for i in range(Na):
            X.append(1<<(offsets[a]+i+1) if i+1<Na else 0);value=0
            for b,Nb in enumerate(lengths):
                for r in ca[b]:
                    if i+r+1<Nb:value^=1<<(offsets[b]+i+r+1)
            Y.append(value)
    L=z.module((tuple(X),tuple(Y)))
    assert all(h.linear(Y,X[i])==h.linear(X,Y[i]) for i in range(n))
    L.update(width=w.generic_width(L),lengths=lengths,C=C)
    assert L['socle']==len(lengths)
    assert L['width']==sum(N>=2 for N in lengths)
    return L


def main():
    start=time.monotonic();rng=random.Random(2026110220);w.verify_field()
    lengths_list=[(3,2),(5,2),(5,2,1),(6,3,2),(4,3,2,1),(8,5,3),(7,3,1,1),(9,6,4,2)]
    targets=[mixed_target(lengths,rng) for lengths in lengths_list for _ in range(24)]
    sources=[w.c.ideal_of(part) for n in range(1,11) for part in w.c.partitions(n)]
    for r in range(2,13):
        sources.append(tuple(sorted([(3*(r-i),3*i) for i in range(r+1)]+[(3*(r-i)-1,3*i+2) for i in range(r)],reverse=True)))
        sources.append(tuple((2*(r-i),2*i) for i in range(r+1)))
    for A in [4,6,8,12,18]:
        sources.append(tuple([(A,0)]+[(i,A+1-i) for i in range(A-1,1,-1)]+[(0,A)]))
    checks=0;strong_counter=None;general_counter=None;max_excess=0
    for J in sources:
        b=min(sum(g) for g in J)+1-len(J);cur=J;later=[]
        for j in range(1,7):
            cur=w.c.times_n(cur)
            if j in (1,2,4,6):later.append((j,cur))
        for L in targets:
            initial=z.hom(J,L);strong=b*L['width'];general=strong+L['length']-L['socle']
            for j,J1 in later:
                loss=(len(J1)-len(J))*L['socle']-(z.hom(J1,L)-initial);checks+=1
                excess=loss-strong;max_excess=max(excess,max_excess)
                if excess>0 and strong_counter is None:
                    strong_counter=dict(J=J,b=b,j=j,lengths=L['lengths'],C=L['C'],loss=loss,strong_budget=strong)
                if loss>general and general_counter is None:
                    general_counter=dict(J=J,b=b,j=j,lengths=L['lengths'],C=L['C'],loss=loss,general_budget=general)
    nonhom_checks=0
    for a,N,count in [(2,5,8),(3,6,6),(4,7,4)]:
        mon=[m for m in dual.monomials(N) if sum(m)>=a]
        for i in range(count):
            polys=[]
            for k in range(2+i%3):
                poly=[m for m in mon if rng.randrange(5)==0]
                if not any(sum(m)==a for m in poly):poly.append((a,0))
                polys.append(tuple(sorted(set(poly))))
            qs=[dual.quotient(polys,N,j) for j in range(4)];b=a+1-qs[0]['mu']
            for L in targets[::3]:
                initial=dual.hom_ideal(qs[0],L);budget=b*L['width']
                for j in range(1,4):
                    loss=(qs[j]['mu']-qs[0]['mu'])*L['socle']-(dual.hom_ideal(qs[j],L)-initial)
                    nonhom_checks+=1;max_excess=max(loss-budget,max_excess)
                    if loss>budget and strong_counter is None:
                        strong_counter=dict(polys=polys,N=N,b=b,j=j,lengths=L['lengths'],C=L['C'],loss=loss,strong_budget=budget)
                    if loss>budget+L['length']-L['socle'] and general_counter is None:
                        general_counter=dict(polys=polys,N=N,b=b,j=j,lengths=L['lengths'],C=L['C'],loss=loss)
    result=dict(status='COUNTEREXAMPLE_FOUND' if strong_counter else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',
                seconds=round(time.monotonic()-start,3),targets=len(targets),monomial_sources=len(sources),
                monomial_comparisons=checks,nonhomogeneous_comparisons=nonhom_checks,max_strong_excess=max_excess,
                strong_counterexample=strong_counter,general_width_counterexample=general_counter,
                mathematical_status='UNPROVED for mixed lengths; finite falsification probe only.')
    (ROOT/'mixed_dvr_probe_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

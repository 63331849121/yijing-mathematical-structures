"""Plane-choice controls for the actual corner origin family.

The previous large-width counterexample is a fixed-plane statement.
This control deliberately changes its plane and records the difference.
"""
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('actual',ROOT/'check_actual_core_width.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
h=c.h;a=c.a


def check(d,s,K,badplane):
    N=s+K;labels,ops,masks,idx=c.actual_F(d,N);rows=[]
    outside=[i for i in range(d) if i not in badplane]
    for k,(degree,i) in enumerate(labels):
        row=a.basis(d,degree)[i]
        nj=sum(int(row[0]==axis)+int(row[1]==axis)+row[axis+2] for axis in outside)
        if degree>=s and degree+nj>=s+K:rows.append(1<<k)
    P=tuple(rows);mP=h.canonical(h.linear(op,v) for op in ops for v in P)
    g=len(P)-len(mP);head=len(labels)-len(P)
    W=c.quotient(ops,mP);nw=len(W[0]);domain=tuple(1<<i for i in range(nw))
    L=h.ker(domain,[sum(op[i]<<(q*nw) for q,op in enumerate(W[2:])) for i in range(nw)])
    Soc=h.ker(L,[h.linear(W[0],v)|(h.linear(W[1],v)<<nw) for v in L]);assert len(Soc)==g
    widths=[]
    for alpha,beta in [(1,0),(0,1),(1,1)]:
        image=h.canonical((h.linear(W[0],v) if alpha else 0)^(h.linear(W[1],v) if beta else 0) for v in L)
        widths.append(len(image)+len(Soc)-len(h.canonical(list(image)+list(Soc))))
    def member(x,y):
        degree=x+y
        nj=(x+1)*int(0 not in badplane)+(y+1)*int(1 not in badplane)
        return degree>=s and degree+nj>=s+K
    gens=[]
    for degree in range(s+K+1):
        for x in range(degree+1):
            y=degree-x
            if member(x,y) and (not x or not member(x-1,y)) and (not y or not member(x,y-1)):gens.append((x,y))
    order=min(x+y for x,y in gens);v=len(gens);assert v==order+1
    return dict(d=d,s=s,K=K,bad_plane=badplane,projection_plane=(0,1),
                intersection_dimension=len(set(badplane)&{0,1}),head=head,g=g,u=len(L)-g,
                tested_direction_widths=widths,plane_ideal_generators=gens,plane_order=order,plane_mu=v,plane_full=True)


def main():
    start=time.monotonic();rows=[]
    for d,s,K in [(3,4,2),(4,3,2),(5,3,2),(6,2,2)]:
        for plane in [(0,1),(0,2)]+([(2,3)] if d>=4 else []):rows.append(check(d,s,K,plane))
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),actual_plane_comparisons=len(rows),cases=rows,
                scope='Changing the plane can change the corner width; all tested scalar plane images are full. The large-width theorem only disproves a uniform fixed-plane shortcut, not existence of a suitable plane.')
    (ROOT/'corner_plane_change_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

"""Exact actual-Jacobi controls for stable, nonreduced one-dimensional tails.

For actual F_3=R a+R b, take H=(Z^nu,Y^p)a+R b. Its quotient is a
fat projective point, not a direct sum of reduced point evaluations.
"""
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('actual',ROOT/'check_actual_core_width.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
h=c.h


def check(nu,p,s,A):
    labels,ops,masks,idx=c.actual_F(3,A);n=len(labels)
    aa=1<<idx[(0,1)];bb=1<<idx[(0,2)]
    za=aa;ya=aa
    for _ in range(nu):za=h.linear(ops[2],za)
    for _ in range(p):ya=h.linear(ops[1],ya)
    H=c.close(ops,[za,ya,bb]);assert s>=max(nu,p,nu+p-2)
    P=[]
    for row in H:
        first=(row&-row).bit_length()-1;degree=labels[first][0]
        assert row&masks[degree]==row
        if degree>=s:P.append(row)
    P=h.canonical(P+[1<<i for i,(j,k) in enumerate(labels) if j==A])
    assert all(not h.reduce(h.linear(op,row),P) for op in ops for row in P)
    mP=h.canonical(h.linear(op,row) for op in ops for row in P)
    fs=masks[s].bit_count();head=sum(j<s for j,k in labels)+nu*p*(A-s)
    assert len(labels)-len(P)==head
    g=len(P)-len(mP);assert g==fs
    W=c.quotient(ops,mP);nw=len(W[0]);domain=tuple(1<<i for i in range(nw))
    soc=h.ker(domain,[sum(op[i]<<(q*nw) for q,op in enumerate(W)) for i in range(nw)])
    assert len(soc)==g
    L=h.ker(domain,W[2]);socL=h.ker(L,[h.linear(W[0],v)|(h.linear(W[1],v)<<nw) for v in L])
    assert len(socL)==fs and len(L)-fs==p*(A-s)
    NX=A-s+1;RX=L;RY=L
    for k in range(1,NX+2):
        RX=h.canonical(h.linear(W[0],v) for v in RX)
        RY=h.canonical(h.linear(W[1],v) for v in RY)
        assert len(RX)==p*max(NX-k,0)
        assert len(RY)==max(p-k,0)*max(NX-k,0)
    Ximage=h.canonical(h.linear(W[0],v) for v in L)
    mimage=h.canonical([h.linear(op,v) for op in W[:2] for v in L])
    assert Ximage==mimage
    width=len(socL)+len(Ximage)-len(h.canonical(list(socL)+list(Ximage)));assert width==p
    return dict(nu=nu,p=p,s=s,end=A,head=head,g=g,u=p*(A-s),generic_width=width,
                stable_tail_dimension=nu*p,nonreduced=True,basically_full=True,reduction_equality=True)


def main():
    start=time.monotonic();rows=[check(*case) for case in [(1,2,2,6),(1,3,3,7),(2,2,3,7),(2,3,4,8),(3,2,4,8)]]
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),field=2,
                actual_nonreduced_core_families=len(rows),cases=rows,
                scope='Independent exact controls for the general stable-tail proof. Does not enumerate arbitrary higher-dimensional tails.')
    (ROOT/'stable_fat_tail_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

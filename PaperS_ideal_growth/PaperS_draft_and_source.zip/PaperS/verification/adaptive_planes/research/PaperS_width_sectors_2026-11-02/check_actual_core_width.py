"""Exact controls for the last-degree core-width bound in actual M_d.

Uses the genuine Jacobi module and the kernel of its fixed plane projection.
Nonhomogeneous submodules are closed under all coordinate actions. Associated
graded generator increases and the semisimple error D are checked explicitly.
"""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('jacobi_controls',ROOT.parent/'PaperS_joint_normals_2026-11-01'/'check_joint_normal.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
a=h.a


def actual_F(d,N):
    indices={j:tuple(i for i,r in enumerate(a.basis(d,j)) if not(r[:2]==(0,1) and not any(r[4:]))) for j in range(N+1)}
    labels=tuple((j,i) for j in range(N+1) for i in indices[j]);idx={m:i for i,m in enumerate(labels)}
    actions=[]
    for axis in range(d):
        local=[]
        for j,i in labels:
            if j==N:local.append(0);continue
            col=a.multiply(d,j,axis,2)[i];out=0
            for k,coef in enumerate(col):
                if coef:assert (j+1,k) in idx;out^=1<<idx[j+1,k]
            local.append(out)
        actions.append(tuple(local))
    masks={j:sum(1<<idx[j,i] for i in indices[j]) for j in range(N+1)}
    return labels,tuple(actions),masks,idx


def quotient(actions,relations):
    n=len(actions[0]);basis=h.canonical(relations);piv={(v&-v).bit_length()-1 for v in basis}
    free=[i for i in range(n) if i not in piv];idx={a:i for i,a in enumerate(free)};out=[]
    for op in actions:
        local=[]
        for i in free:
            v=h.reduce(op[i],basis);w=0
            while v:
                bit=v&-v;w|=1<<idx[bit.bit_length()-1];v^=bit
            local.append(w)
        out.append(tuple(local))
    return tuple(out)


def normal_u(actions):
    n=len(actions[0]);images=[sum(op[i]<<(k*n) for k,op in enumerate(actions[2:])) for i in range(n)]
    L=h.ker(tuple(1<<i for i in range(n)),images)
    soc=h.ker(L,[h.linear(actions[0],v)|(h.linear(actions[1],v)<<n) for v in L])
    return len(L),len(soc),len(L)-len(soc)


def close(actions,rows):
    P=h.canonical(rows)
    while True:
        new=h.canonical(list(P)+[h.linear(op,v) for op in actions for v in P])
        if len(new)==len(P):return P
        P=new


def analyse(d,N,labels,actions,masks,gens):
    top=tuple(1<<i for i,(j,k) in enumerate(labels) if j==N)
    P=close(actions,list(top)+list(gens));mP=h.canonical(h.linear(op,v) for op in actions for v in P)
    g=len(P)-len(mP);fn=masks[N].bit_count()
    barred=[]
    for row in P:
        i=(row&-row).bit_length()-1;j=labels[i][0];barred.append(row&masks[j])
    barP=h.canonical(barred);assert len(barP)==len(P)
    mbar=h.canonical(h.linear(op,v) for op in actions for v in barP)
    gb=len(barP)-len(mbar);delta=gb-g;assert delta>=0
    grm=[]
    for row in mP:
        i=(row&-row).bit_length()-1;j=labels[i][0];grm.append(row&masks[j])
    grm=h.canonical(grm)
    assert all(not h.reduce(v,grm) for v in mbar)
    assert all(not h.reduce(v,barP) for v in grm)
    assert len(grm)-len(mbar)==delta
    length,soc,u=normal_u(quotient(actions,mP));bl,bs,bu=normal_u(quotient(actions,mbar))
    cn=d-2;bound=cn*(fn-g);refined=fn-gb+cn*delta
    assert gb<=fn and u<=refined<=bound,(d,N,g,gb,u,refined,bound)
    assert bl-gb<=fn-gb
    return dict(d=d,degree_cutoff=N,head=len(labels)-len(P),g=g,graded_g=gb,graded_generator_increase=delta,
                last_degree=fn,joint_normal_length=length,joint_normal_socle=soc,u=u,refined_bound=refined,bound=bound)


def main():
    start=time.monotonic();rng=random.Random(2026110214);rows=[]
    for d,N,number in [(3,3,20),(4,2,20),(4,3,16),(5,2,20),(5,3,8),(6,2,12)]:
        labels,actions,masks,idx=actual_F(d,N)
        candidates=[i for i,(j,k) in enumerate(labels) if 1<=j<N]
        for trial in range(number):
            if trial==0:gens=[]
            else:
                gens=[]
                for k in range(1+trial%5):
                    v=sum((rng.randrange(7)==0)<<i for i in candidates)
                    if v:gens.append(v)
            rows.append(analyse(d,N,labels,actions,masks,gens))
    # Deliberate nonhomogeneous generator cancellation in actual free F of M3:
    # P=(z,x^2+y^3,xy)a + Rb, which has one more graded minimal generator.
    d,N=3,4;labels,actions,masks,idx=actual_F(d,N)
    ai=next(i for i,r in enumerate(a.basis(3,0)) if r[:2]==(0,2))
    bi=next(i for i,r in enumerate(a.basis(3,0)) if r[:2]==(1,2))
    aa=1<<idx[0,ai];bb=1<<idx[0,bi]
    def mon(v,powers):
        for axis,power in enumerate(powers):
            for k in range(power):v=h.linear(actions[axis],v)
        return v
    gens=[bb,mon(aa,(0,0,1)),mon(aa,(2,0,0))^mon(aa,(0,3,0)),mon(aa,(1,1,0))]
    row=analyse(d,N,labels,actions,masks,gens)
    assert (row['g'],row['graded_g'],row['graded_generator_increase'])==(4,5,1),row
    row['deliberate_nongraded_example']=True;rows.append(row)
    result=dict(status='PASS',field=2,seconds=round(time.monotonic()-start,3),actual_Jacobi_core_cases=len(rows),
                nonzero_graded_generator_increase_cases=sum(r['graded_generator_increase']>0 for r in rows),cases=rows,
                scope='Exact controls for the proved last-degree width bound in actual plane kernels of M3 through M6; no inference that arbitrary near-extremal cores have bounded degree width.')
    (ROOT/'actual_core_width_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2));print('Deliberate nonhomogeneous case:',row)


if __name__=='__main__':main()

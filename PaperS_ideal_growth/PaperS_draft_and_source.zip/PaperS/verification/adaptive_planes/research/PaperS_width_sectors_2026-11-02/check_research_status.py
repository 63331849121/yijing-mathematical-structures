"""Artifact consistency only; not mathematical or priority certification."""
from pathlib import Path
import hashlib
import json
import re
import ast

ROOT=Path(__file__).parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
proofs={}
for tex in sorted(ROOT.glob('*.tex')):
    raw=tex.read_text(encoding='utf-8')
    code='\n'.join(re.split(r'(?<!\\)%',s)[0] for s in raw.splitlines());stack=[]
    for op,env in re.findall(r'\\(begin|end)\{([^}]+)\}',code):
        if op=='begin':stack.append(env)
        else:assert stack and stack.pop()==env,tex.name
    assert not stack,tex.name
    balance=0
    for char in re.sub(r'\\[{}]','',code):
        balance+=(char=='{')-(char=='}');assert balance>=0,tex.name
    assert balance==0,tex.name
    labels=re.findall(r'\\label\{([^}]+)\}',code);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',code)
    assert len(set(labels))==len(labels) and set(refs)<=set(labels),(tex.name,set(refs)-set(labels))
    proofs[tex.name]=dict(static_status='PASS',sha256=digest(tex),mathematical_status='General proof draft or explicitly scoped consequence; independent expert review pending.')
controls={}
pairs=[('check_parameter_and_packets.py','parameter_and_packet_controls.json'),
       ('check_one_module_transfer.py','one_module_transfer_results.json'),
       ('check_actual_core_width.py','actual_core_width_results.json'),
       ('check_projective_line_tails.py','projective_line_tail_results.json'),
       ('check_planar_rank_and_projection.py','planar_rank_and_projection_results.json'),
       ('check_loewy_two_and_uniform.py','loewy_two_and_uniform_results.json'),
       ('check_single_reduction_comparison.py','single_reduction_comparison_results.json'),
       ('check_stable_fat_tails.py','stable_fat_tail_results.json'),
       ('check_radial_normal_corner.py','radial_normal_corner_results.json'),
       ('check_corner_plane_changes.py','corner_plane_change_results.json'),
       ('check_fat_band_comparison.py','fat_band_comparison_results.json'),
       ('check_thick_normal_corners.py','thick_normal_corner_results.json'),
       ('check_source_curve_lattice.py','source_curve_lattice_results.json'),
       ('check_general_target_lift.py','general_target_lift_results.json'),
       ('check_cocyclic_tiny_square_counter.py','cocyclic_counter_controls.json')]
for script,result in pairs:
    ast.parse((ROOT/script).read_text(encoding='utf-8'))
    data=json.loads((ROOT/result).read_text(encoding='utf-8'));assert data['status']=='PASS',result
    controls[result]=dict(status='PASS',script_sha256=digest(ROOT/script),result_sha256=digest(ROOT/result))
probes={}
probe_pairs=[('probe_nonhomogeneous_width.py','nonhomogeneous_width_results.json')]
if (ROOT/'nonsplit_target_probe_results.json').exists():probe_pairs.append(('probe_nonsplit_commuting_targets.py','nonsplit_target_probe_results.json'))
for script,result in probe_pairs:
    ast.parse((ROOT/script).read_text(encoding='utf-8'))
    data=json.loads((ROOT/result).read_text(encoding='utf-8'))
    probes[result]=dict(status=data['status'],mathematical_status='UNPROVED; finite falsification only.',script_sha256=digest(ROOT/script),result_sha256=digest(ROOT/result))
historical=json.loads((ROOT/'mixed_dvr_probe_results.json').read_text(encoding='utf-8'))
historical=dict(status=historical['status'],result_sha256=digest(ROOT/'mixed_dvr_probe_results.json'),
                superseded_mathematical_status='The mixed-length class is now PROVED IN DRAFT by single_reduction_target_comparison.tex; the earlier result remains a historical finite probe.')
false_probes={}
for filename in ['cocyclic_product_probe_results.json','nonhomogeneous_cocyclic_probe_results.json']:
    data=json.loads((ROOT/filename).read_text(encoding='utf-8'))
    false_probes[filename]=dict(historical_status=data['status'],result_sha256=digest(ROOT/filename),
        current_mathematical_status='Stronger bw-only cocyclic conjecture is FALSE; see cocyclic_product_reduction_and_counter.tex. Finite passes are superseded by the explicit tiny-square counterfamily.')
lit=ROOT.parent/'PaperS_packet_comparison_2026-11-01'/'literature'
sources=json.loads((lit/'intake_manifest.json').read_text(encoding='utf-8'))
for src in sources:assert digest(lit/src['file'])==src['sha256']
snap=json.loads((ROOT.parent/'PaperS_higher_rank_locality_2026-11-01'/'source_snapshot_updated.json').read_text(encoding='utf-8'))
changes=[]
for name,meta in snap['files'].items():
    p=Path(snap['source'])/name
    if not p.exists() or digest(p)!=meta['sha256']:changes.append(name)
status=dict(status='PASS',date='2026-11-02',stage=12,
    work_state='Proof drafts archived; mixed-length DVR class closed; continuing higher-Loewy, frame-adapted and weighted common-core research. Old universal small-width target DISPROVED.',
    proof_sources=proofs,completed_finite_controls=controls,unproved_probes=probes,historical_mixed_length_probe=historical,
    historical_passes_superseded_by_counterexample=false_probes,
    literature_received_and_audited=[s['file'] for s in sources],original_pdfs_unchanged=True,
    canonical_manuscript_external_changes_since_old_baseline=changes,
    canonical_manuscript_edits_performed=False,canonical_manuscript_compilation_performed=False,
    latest_report='第十二阶段研究报告.txt',
    proved_draft_increments=[
      'Full weighted packet comparison from a single target L0, without zero-boundary feasibility or plane-fullness.',
      'Strong bw Hom comparison for arbitrary one-parameter targets and uniform matrix-coupled DVR lifts.',
      'All single-reduction targets nL=ellL, including unequal coupled strings: strong comparison proved by Tor/DVR connecting-image control.',
      'Complete Loewy-two comparison with bw+tau, tau<=u, using classical Kronecker decomposition.',
      'All arbitrarily thick target bands n^t/n^A and direct sums: nonhomogeneous rank-r sources satisfy the determinantal absolute/relative bound r*u+b*w.',
      'Nonhomogeneous final-degree core bound u0<=c*(dim F_N-mu P).',
      'Controlled-cutoff and stable-one-dimensional-tail sectors for ranks five and six.',
      'Actual near-extremal closed long-tail families disprove globally small u0; width and packet cost stay controlled.',
      'Arbitrary fixed-rank planar transfer and explicit actual larger planar projection.',
      'Actual closed near-extremal normal-corner family DISPROVES the old uniform fixed-plane width target: w~h^(1-2/d+1/(d*(d-1))). Its Loewy-two packet sector remains controlled.',
      'Actual near-extremal thick normal-corner cores with growing Loewy length are controlled in ranks five/six under a stated uniform budget; u may have order n^(1-1/d).'
      ,'Exact source-curve lattice reduction identifies b_i with rank of y modulo a generic DVR parameter; connecting-map estimate for arbitrary targets remains open.'
      ,'Every finite target has a generic-parameter curve-lattice lift with multiplicity e and two generator counts equal to target socle and top.'
      ,'The stronger bw-only cocyclic comparison is FALSE: explicit classical tiny-square ideals give loss~u/210 and bw=o(u). Thus an order-u budget is necessary in general.'
    ],remaining_gaps=[
      'General higher-Loewy width-sensitive Hom inequality.',
      'A weaker or frame-adapted width theorem; the old O(h^(1-2/d)) fixed-plane target is FALSE.',
      'Structure or weighted mass bound for all remaining near-extremal common cores.',
      'Unconditional global rank-five/six locality and whole-quotient nilpotence rates.'
    ],false_shortcuts=[
      'Near-extremality plus basic closure implies uniformly small u0=O(h^(1-2/d)): FALSE.',
      'Near-extremality plus basic closure implies fixed-plane w0=O(h^(1-2/d)): FALSE.',
      'Cocyclic targets need only b*w (or o(u)+O(b*w)) in general: FALSE.'
    ],no_claims=['Finite controls do not prove unrestricted conjectures.','No independent expert certification.','No canonical manuscript edits or compilation.','No originality claim for classical closure, DVR, Hilbert-Burch, Kronecker or tiny-square families.'])
(ROOT/'research_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS',proof_drafts=len(proofs),control_reports=len(controls),unproved_probe_reports=len(probes),canonical_edits=False),indent=2))

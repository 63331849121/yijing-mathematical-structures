"""Exact controls for proved uniform-lift and complete Loewy-two bounds.

All matrix-pair presentations of length at most four are enumerated, with
the required zero joint kernel on the nonsocle quotient. Kronecker budgets
are computed by chain ranks, not by assuming a decomposition of each sample.
Nonhomogeneous source Hom uses canonical-module tensor duality.
"""
from pathlib import Path
from itertools import product
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
PREV=ROOT.parent/'PaperS_literature_and_nonfull_boundary_2026-11-02'
spec=importlib.util.spec_from_file_location('width_tools',PREV/'probe_refined_width_cost.py')
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
z=w.z;h=w.h;dual=z.z


def power_ideal(r):return tuple((r-i,i) for i in range(r+1))


def pencil_module(P,Q,s):
    u=len(P);n=u+s;zero=(0,)*s
    L=z.module((tuple(p<<u for p in P)+zero,tuple(q<<u for q in Q)+zero))
    assert L['socle']==s
    L['width']=w.generic_width(L);R=u+1
    er=z.hom(power_ideal(R),L)-(R+1)*s;ep=z.hom(power_ideal(R-1),L)-R*s
    L['tau']=u-er+R*(er-ep)
    assert 0<=L['tau']<=u
    return L


def targets():
    out=[];raw=0
    for u in range(1,4):
        for s in range(1,5-u):
            if u>2*s:continue
            for values in product(range(1<<s),repeat=2*u):
                P,Q=values[:u],values[u:]
                if len(h.canonical(p|(q<<s) for p,q in zip(P,Q)))<u:continue
                L=pencil_module(P,Q,s);L['kind']='exhaustive_square_zero';out.append(L);raw+=1
    for s in range(1,5):
        L=z.module(((0,)*s,(0,)*s));L.update(width=0,tau=0,kind='semisimple');out.append(L);raw+=1
    rng=random.Random(2026110216)
    for n in range(1,7):
        left=pencil_module(tuple(1<<i for i in range(n)),tuple(1<<(i+1) for i in range(n)),n+1)
        assert (left['tau'],left['width'])==(n,n);left['kind']='left_block';out.append(left)
        right=pencil_module(tuple(1<<i if i<n else 0 for i in range(n+1)),
                            tuple(1<<(i-1) if i else 0 for i in range(n+1)),n)
        assert (right['tau'],right['width'])==(0,n);right['kind']='right_block';out.append(right)
        C=tuple(rng.randrange(1<<n) for i in range(n))
        regular=pencil_module(tuple(1<<i for i in range(n)),C,n)
        assert (regular['tau'],regular['width'])==(0,n);regular['kind']='regular_block';out.append(regular)
    uniform=[]
    for e,N in [(2,3),(2,4),(3,3),(3,5),(4,4),(4,6)]:
        n=e*N;idx=lambda a,j:a*N+j
        C0=[rng.randrange(1<<e) for i in range(e)];C1=[rng.randrange(1<<e) for i in range(e)]
        X=[];Y=[]
        for a in range(e):
            for j in range(N):
                X.append(1<<idx(a,j+1) if j+1<N else 0);value=0
                for shift,C in [(1,C0),(2,C1)]:
                    if j+shift<N:
                        for b in range(e):
                            if (C[a]>>b)&1:value^=1<<idx(b,j+shift)
                Y.append(value)
        L=z.module((tuple(X),tuple(Y)));L.update(width=w.generic_width(L),kind='uniform_DVR_lift')
        assert L['socle']==L['width']==e;uniform.append(L)
    return out,uniform,raw


def main():
    start=time.monotonic();w.verify_field();loewy,uniform,raw=targets()
    sources=[w.c.ideal_of(p) for n in range(1,9) for p in w.c.partitions(n)]
    for r in range(2,9):
        sources.append(tuple(sorted([(3*(r-i),3*i) for i in range(r+1)]+[(3*(r-i)-1,3*i+2) for i in range(r)],reverse=True)))
        sources.append(tuple((2*(r-i),2*i) for i in range(r+1)))
    for A in [4,6,8,12]:sources.append(tuple([(A,0)]+[(i,A+1-i) for i in range(A-1,1,-1)]+[(0,A)]))
    checks=0;uniform_checks=0
    for J in sources:
        b=min(sum(g) for g in J)+1-len(J);later=[];cur=J
        for j in range(1,5):
            cur=w.c.times_n(cur)
            if j in [1,2,4]:later.append((j,cur))
        for L in loewy+uniform:
            initial=z.hom(J,L);budget=b*L['width']+L.get('tau',0)
            for j,J1 in later:
                loss=(len(J1)-len(J))*L['socle']-(z.hom(J1,L)-initial)
                assert loss<=budget,(J,L,j,loss,budget)
                if L['kind']=='uniform_DVR_lift':uniform_checks+=1
                else:checks+=1
    rng=random.Random(2026110217);nonhom=[]
    for a,N,count in [(2,5,8),(3,6,6),(4,7,4)]:
        mon=[m for m in dual.monomials(N) if sum(m)>=a]
        for i in range(count):
            polys=[]
            for k in range(2+i%3):
                p=[m for m in mon if rng.randrange(5)==0]
                if not any(sum(m)==a for m in p):p.append((a,0))
                polys.append(tuple(sorted(set(p))))
            qs=[dual.quotient(polys,N,j) for j in range(4)];b=a+1-qs[0]['mu'];assert b>=0
            nonhom.append((b,qs))
    nonhom_checks=0
    for b,qs in nonhom:
        for L in loewy+uniform:
            initial=dual.hom_ideal(qs[0],L);budget=b*L['width']+L.get('tau',0)
            for j in range(1,4):
                loss=(qs[j]['mu']-qs[0]['mu'])*L['socle']-(dual.hom_ideal(qs[j],L)-initial)
                assert loss<=budget,(b,qs,L,j,loss,budget);nonhom_checks+=1
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),field=2,
                exhaustive_length_at_most_four_presentations=raw,loewy_two_targets=len(loewy),uniform_higher_Loewy_targets=len(uniform),
                monomial_sources=len(sources),nonhomogeneous_sources=len(nonhom),
                loewy_two_strong_comparisons=checks,uniform_strong_comparisons=uniform_checks,nonhomogeneous_strong_comparisons=nonhom_checks,
                scope='Finite independent controls for the general proof drafts: all Loewy-two targets and uniform DVR lifts. The unrestricted higher-Loewy width conjecture remains unproved.')
    (ROOT/'loewy_two_and_uniform_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

"""Exact source-curve lattice controls over a finite DVR truncation.

The truncation is chosen inside x*C_i, so it preserves all generator
and rank identities being tested. Source generator numbers are computed
independently from finite quotient socles.
"""
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('controls',ROOT/'check_loewy_two_and_uniform.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
h=p.h;dual=p.dual


def curve_module(a,f,T):
    assert (0,a) in f and all(j<a for i,j in f if (i,j)!=(0,a))
    labels=tuple((i,j) for i in range(T) for j in range(a));idx={v:i for i,v in enumerate(labels)}
    X=[];Y=[]
    for i,j in labels:
        X.append(1<<idx[(i+1,j)] if i+1<T else 0)
        if j+1<a:Y.append(1<<idx[(i,j+1)])
        else:
            out=0
            for r,k in f:
                if (r,k)!=(0,a) and i+r<T:out^=1<<idx[(i+r,k)]
            Y.append(out)
    ops=(tuple(X),tuple(Y));p.z.module(ops)
    def evaluate(poly):
        out=0
        for i,j in poly:
            v=1<<idx[(0,0)]
            for _ in range(i):v=h.linear(X,v)
            for _ in range(j):v=h.linear(Y,v)
            out^=v
        return out
    assert not evaluate(f)
    return ops,evaluate


def close(ops,rows):
    out=h.canonical(rows)
    while True:
        new=h.canonical(list(out)+[h.linear(op,v) for op in ops for v in out])
        if new==out:return out
        out=new


def check(a,f,others,N):
    max_i=a+1;T=N+max_i+3;ops,evaluate=curve_module(a,f,T)
    C=close(ops,[evaluate(poly) for poly in others]+[evaluate(((i,N-i),)) for i in range(N+1)])
    rows=[]
    for i in range(max_i+1):
        Q=dual.quotient([f]+others,N,i);v=Q['mu'];b=a+i+1-v
        XC=h.canonical(h.linear(ops[0],w) for w in C)
        YC=h.canonical(h.linear(ops[1],w) for w in C)
        mC=h.canonical(list(XC)+list(YC))
        assert len(C)-len(XC)==a
        assert len(C)-len(mC)==v-i-1==a-b,(a,f,others,N,i,v,b,len(C)-len(mC))
        assert len(mC)-len(XC)==b
        if i>=a-1:assert mC==XC and b==0
        rows.append(dict(i=i,source_mu=v,source_defect=b,curve_A_rank=a,curve_S_mu=a-b,lattice_increment=b))
        C=mC
    return dict(a=a,f=f,other_generators=others,N=N,finite_DVR_power=T,steps=rows)


def main():
    start=time.monotonic();cases=[]
    for a in [2,3,4,5]:
        for A in [a+1,a+3]:
            f=((0,a),(a+1,0),(a,1));others=[((A,0),)]
            cases.append(check(a,f,others,a+A))
    for a in [3,4,6]:cases.append(check(a,((0,a),),[((a,0),)],a+1))
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),field=2,
        source_families=len(cases),independent_lattice_steps=sum(len(c['steps']) for c in cases),cases=cases,
        scope='Exact checks of the source curve-lattice rank identities and contracted stabilization. No unrestricted target comparison inferred.')
    (ROOT/'source_curve_lattice_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))


if __name__=='__main__':main()

"""Falsification only: width Hom candidate for nonhomogeneous source ideals.

Hom is computed from canonical-module duality, independently of monomial
Hilbert--Burch neighbor matrices. Generic widths use certified pencil ranks.
"""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
PREV=ROOT.parent/'PaperS_literature_and_nonfull_boundary_2026-11-02'
spec=importlib.util.spec_from_file_location('width_tools',PREV/'probe_refined_width_cost.py')
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
z=w.z.z


def main():
    start=time.monotonic();w.verify_field();rng=random.Random(2026110212);sources=[]
    for a,N,count in [(2,5,12),(3,6,12),(4,7,8)]:
        mon=[m for m in z.monomials(N) if sum(m)>=a]
        for i in range(count):
            polys=[]
            for k in range(2+i%3):
                poly=[m for m in mon if rng.randrange(5)==0]
                if not any(sum(m)==a for m in poly):poly.append((a,0))
                polys.append(tuple(sorted(set(poly))))
            qs=[z.quotient(polys,N,j) for j in range(4)];b=a+1-qs[0]['mu'];assert b>=0
            sources.append(dict(order=a,cutoff=N,polynomials=polys,b=b,quotients=qs))
    targets=[]
    # Nonhomogeneous quotient targets and their duals.
    for src in sources[:8]+sources[12:16]:
        Q=src['quotients'][0]
        for actions in [Q['actions'],tuple(z.transpose(op) for op in Q['actions'])]:
            L=w.z.module(actions);L['width']=w.generic_width(L);targets.append(L)
    for i in range(30):
        Q=w.z.make_module(2,3,rng,1+i%4,1+i%2)
        if Q['length']<=18:
            Q['width']=w.generic_width(Q);targets.append(Q)
    checks=0;bad=[];saturated=[]
    for si,src in enumerate(sources):
        A=src['quotients'][0];b=src['b'];v=A['mu']
        for li,L in enumerate(targets):
            initial=z.hom_ideal(A,L);u=L['length']-L['socle'];bound=u+b*L['width']
            for j in range(1,4):
                B=src['quotients'][j];later=z.hom_ideal(B,L);loss=(B['mu']-v)*L['socle']-(later-initial);checks+=1
                if loss>bound:
                    bad.append(dict(source=src,target=L,j=j,initial_Hom=initial,later_Hom=later,loss=loss,bound=bound))
                    if len(bad)>=3:break
                if b and loss==bound and bound and len(saturated)<4:
                    saturated.append(dict(source=si,target=li,b=b,j=j,loss=loss,bound=bound))
            if len(bad)>=3:break
        if len(bad)>=3:break
    result=dict(status='COUNTEREXAMPLE' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',seed=2026110212,
                seconds=round(time.monotonic()-start,3),field=2,nonhomogeneous_sources=len(sources),target_modules=len(targets),
                checked_inequalities=checks,counterexamples=bad,saturated_examples=saturated,
                mathematical_status='UNPROVED width conjecture; finite nonhomogeneous falsification only.')
    (ROOT/'nonhomogeneous_width_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

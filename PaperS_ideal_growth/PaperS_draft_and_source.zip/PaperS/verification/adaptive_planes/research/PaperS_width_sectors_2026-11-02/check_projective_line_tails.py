"""Exact controls of the long-tail decomposition in actual M_d plane kernels.

Checks head, minimal generators, basic closure, non-socle length and all
three binary plane directions, including unequal tail endpoints.
"""
from pathlib import Path
from itertools import product
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('actual_cores',ROOT/'check_actual_core_width.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
h=c.h;a=c.a


def value(row,p):
    i,j=row[:2]
    if not all(not n or p[k] for k,n in enumerate(row[2:])):return 0
    return (p[i]<<j)^(p[j]<<i)


def check(d,s,points,ends):
    N=max(ends);labels,actions,masks,idx=c.actual_F(d,N);n=len(labels)
    rps=[]
    for p in points:
        rps.append(len(h.canonical(value(a.basis(d,0)[k],p) for j,k in labels if j==0)))
    P=[]
    for degree in range(s,N+1):
        active=[i for i,A in enumerate(ends) if A>degree]
        rows=tuple(1<<k for k,(j,i) in enumerate(labels) if j==degree)
        images=[]
        for bit in rows:
            k=bit.bit_length()-1;j,i=labels[k];row=a.basis(d,j)[i]
            images.append(sum(value(row,points[z])<<(q*d) for q,z in enumerate(active)))
        P.extend(h.ker(rows,images))
    P=h.canonical(P)
    assert all(not h.reduce(h.linear(op,v),P) for op in actions for v in P)
    mP=h.canonical(h.linear(op,v) for op in actions for v in P);g=len(P)-len(mP)
    f_s=masks[s].bit_count();H_s=sum(j<s for j,i in labels)
    expected_head=H_s+sum(r*(A-s) for r,A in zip(rps,ends))
    assert len(labels)-len(P)==expected_head
    assert g==f_s,(d,s,points,ends,g,f_s)
    W=c.quotient(actions,mP);nw=len(W[0]);images=[sum(op[i]<<(q*nw) for q,op in enumerate(W)) for i in range(nw)]
    soc_R=len(h.ker(tuple(1<<i for i in range(nw)),images));assert soc_R==g
    normal_images=[sum(op[i]<<(q*nw) for q,op in enumerate(W[2:])) for i in range(nw)]
    L=h.ker(tuple(1<<i for i in range(nw)),normal_images)
    Soc=h.ker(L,[h.linear(W[0],v)|(h.linear(W[1],v)<<nw) for v in L])
    inside=[i for i,p in enumerate(points) if not any(p[2:])]
    expected_u=sum(rps[i]*(ends[i]-s) for i in inside)
    assert len(Soc)==g and len(L)-len(Soc)==expected_u
    for axis,(alpha,beta) in enumerate([(1,0),(0,1),(1,1)]):
        op=tuple((x if alpha else 0)^(y if beta else 0) for x,y in zip(W[0],W[1]));rows=L
        for k in range(1,N-s+3):
            rows=h.canonical(h.linear(op,v) for v in rows)
            expected=sum(rps[i]*max(ends[i]-s+1-k,0) for i in inside if alpha*points[i][0]^beta*points[i][1])
            assert len(rows)==expected,(d,s,points,ends,axis,k,len(rows),expected)
    return dict(d=d,s=s,projective_points=points,end_degrees=ends,fiber_dimensions=rps,head=expected_head,g=g,
                normal_length=len(L),normal_socle=len(Soc),u=expected_u,generic_width=sum(rps[i] for i in inside),
                basically_full=True,final_degree=N)


def main():
    start=time.monotonic();rows=[]
    rows.append(check(3,2,[(1,0,0)],[6]))
    rows.append(check(3,3,[(1,0,0),(0,1,0),(1,1,0)],[6,7,8]))
    pts=[p for p in product([0,1],repeat=3) if any(p)]
    rows.append(check(3,4,pts,[7]*len(pts)))
    rows.append(check(4,2,[(1,0,0,0)],[5]))
    rows.append(check(5,1,[(1,0,0,0,0)],[3]))
    rows.append(check(6,1,[(1,0,0,0,0,0)],[2]))
    result=dict(status='PASS',field=2,seconds=round(time.monotonic()-start,3),actual_core_families=len(rows),cases=rows,
                scope='Exact controls for the proved projective-line-tail decomposition and closure; no claim that all long near-extremal tails split into these modules.')
    (ROOT/'projective_line_tail_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

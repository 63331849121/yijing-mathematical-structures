"""Exact independent controls for the proved one-parameter sector.

Sources are nonhomogeneous truncated ideals. Torsion tails are computed as
the actual parameter kernel in S/J_i, independently of the Hom calculation
from canonical-module tensor duality. Includes nonlinear regular parameters.
Complete actual-M3 packets check zero-stratum dominance and sharp defect cost.
"""
from pathlib import Path
import importlib.util
import random
import json
import time
from fractions import Fraction

ROOT=Path(__file__).parent
PREV=ROOT.parent/'PaperS_literature_and_nonfull_boundary_2026-11-02'
spec=importlib.util.spec_from_file_location('width_tools',PREV/'probe_refined_width_cost.py')
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
z=w.z.z;h=w.h
spec=importlib.util.spec_from_file_location('packet_tools',ROOT.parent/'PaperS_packet_comparison_2026-11-01'/'check_packet_comparison.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def add(*ops):return tuple(__import__('functools').reduce(int.__xor__,s,0) for s in zip(*ops))


def compose(A,B):return tuple(h.linear(A,v) for v in B)


def power(op,n):
    out=tuple(1<<i for i in range(len(op)))
    for _ in range(n):out=compose(op,out)
    return out


def parameter_kernel(A,which):
    X,Y=A['actions'];n=A['length']
    p={'X':X,'Y':Y,'X+Y':add(X,Y),'X+Y^2':add(X,power(Y,2)),
       'X+XY+Y^3':add(X,compose(X,Y),power(Y,3))}[which]
    residual=X if which=='Y' else Y
    basis=h.ker(tuple(1<<i for i in range(n)),p);piv=[(v&-v).bit_length()-1 for v in basis]
    def coordinates(v):
        out=0
        for i,(row,p) in enumerate(zip(basis,piv)):
            if (v>>p)&1:v^=row;out|=1<<i
        assert not v
        return out
    op=tuple(coordinates(h.linear(residual,v)) for v in basis)
    return op


def curve_module(N,which):
    y=tuple(1<<(i+1) if i+1<N else 0 for i in range(N));zero=(0,)*N
    if which=='X':ops=(zero,y)
    elif which=='Y':ops=(y,zero)
    elif which=='X+Y':ops=(y,y)
    elif which=='X+Y^2':ops=(power(y,2),y)
    else:ops=(add(*(power(y,k) for k in range(3,N))) if N>3 else zero,y)
    return w.z.module(ops)


def source_controls():
    rng=random.Random(2026110213);sources=[]
    for a,N,count in [(2,5,10),(3,6,10),(4,7,8)]:
        choices=[m for m in z.monomials(N) if sum(m)>=a]
        for i in range(count):
            polys=[]
            for k in range(2+i%3):
                poly=[m for m in choices if rng.randrange(5)==0]
                if not any(sum(m)==a for m in poly):poly.append((a,0))
                polys.append(tuple(sorted(set(poly))))
            qs=[z.quotient(polys,N,j) for j in range(4)]
            sources.append((a,N,polys,qs))
    # Exceptional tangent directions and the earlier closed zigzag family.
    for a,N,polys in [(2,6,[[(2,0)],[(1,1)],[(0,5)]]),
                       (3,7,[[(3,0)],[(0,3)],[(2,2)]]),
                       (6,8,[[(6,0)],[(5,2)],[(3,3)],[(2,5)],[(0,6)]])]:
        sources.append((a,N,polys,[z.quotient(polys,N,j) for j in range(4)]))
    checks=0;tail_checks=0;special=0
    for a,N,polys,qs in sources:
        b=a+1-qs[0]['mu'];assert b>=0
        for which in ['X','Y','X+Y','X+Y^2','X+XY+Y^3']:
            torsion=[parameter_kernel(Q,which) for Q in qs];a_x=len(torsion[0]);special+=int(a_x>a)
            for j,op in enumerate(torsion):
                assert len(op)==a_x+j
                assert len(op)-len(h.canonical(op))==qs[j]['mu']-1
            for T in range(1,9):
                L=curve_module(T,which);assert (L['socle'],L['top'])==(1,1)
                hs=[z.hom_ideal(Q,L) for Q in qs];tails=[len(h.canonical(power(op,T))) for op in torsion]
                for j in range(4):
                    bi=a+j+1-qs[j]['mu'];ei=hs[j]-qs[j]['mu']
                    assert ei==T-1+(a_x-a)+bi-tails[j]
                    if j:
                        assert tails[j]<=tails[j-1];tail_checks+=1
                        loss=(qs[j]['mu']-qs[0]['mu'])-(hs[j]-hs[0])
                        assert loss<=b*int(T>=2),(a,N,polys,which,T,j,loss,b)
                        checks+=1
    return dict(source_ideals=len(sources),regular_parameter_types=5,exceptional_nontransverse_cases=special,
                strong_Hom_comparisons=checks,independent_torsion_tail_comparisons=tail_checks)


def packet_controls():
    out=[];weights=[];total=0
    for q,A,B in [(2,2,3),(2,3,3),(2,4,4),(3,2,3),(3,3,3)]:
        gens=[(0,0,1),(0,1,0),(A,0,0)];J=((B,0),(B-1,B-1),(0,B))
        j=B-1;R=B+j;J1=tuple((R-i,i) for i in range(R+1))
        src=c.packet_for_ideal(q,gens,J);dst=c.packet_for_ideal(q,gens,J1)
        assert src['status']==dst['status']=='PASS'
        assert src['generator_histogram'][7]==q**(A+B-3)
        assert dst['generator_histogram'][4+len(J1)]==q**(A-1)
        for m in [10,13]:
            zs=sum(n*q**(mu*m) for mu,n in src['generator_histogram'].items())
            zt=sum(n*q**(mu*m) for mu,n in dst['generator_histogram'].items())
            delta=len(J1)-3;normalized=Fraction(zs,zt)*q**(delta*m-(B-2))
            assert normalized<=4
            # Each feasible zero stratum controls its full packet.
            assert Fraction(zs,q**(7*m+A+B-3))<=4
            weights.append(dict(q=q,A=A,B=B,m=m,normalized_sharp_cost_ratio=str(normalized)))
        for side,row in [('source',src),('target',dst)]:
            total+=row['packet_members'];out.append(dict(q=q,A=A,B=B,side=side,members=row['packet_members'],histogram=row['generator_histogram']))
    empty=[]
    for q in [2,3,4]:
        row=c.packet_for_ideal(q,[(0,0,1),(2,0,0),(1,1,0),(0,2,0)],((2,0),(0,1)))
        assert row['status']=='PASS'
        assert row['generator_histogram']=={5:q**5-q**3,6:q**3}
        assert 0 not in row['boundary_rank_histogram']
        empty.append(dict(q=q,members=row['packet_members'],histogram=row['generator_histogram']));total+=row['packet_members']
    return dict(complete_packets=out,sharp_weight_comparisons=weights,empty_zero_boundary_controls=empty,
                total_enumerated_packet_members=total)


def main():
    start=time.monotonic();linear=source_controls();packet=packet_controls()
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),field_for_Hom=2,
                one_parameter_controls=linear,**packet,
                mathematical_scope='Exact controls for the general proof drafts in the one-parameter and feasible-zero-boundary sector. No general width conjecture or unconditional high-rank locality theorem is inferred.')
    (ROOT/'parameter_and_packet_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['complete_packets','sharp_weight_comparisons']},indent=2))


if __name__=='__main__':main()

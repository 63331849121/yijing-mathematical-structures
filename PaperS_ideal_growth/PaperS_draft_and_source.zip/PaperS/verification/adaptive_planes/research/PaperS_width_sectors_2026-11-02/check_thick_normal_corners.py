"""Exact actual-M_d controls for variable-thickness normal corners."""
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('corners',ROOT/'check_radial_normal_corner.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
c=p.c;h=p.h;a=p.a


def check(d,s,K,D):
    assert s>=K>=2 and D>=2
    N=s+(D-1)*(K-1);labels,ops,masks,idx=c.actual_F(d,N);rows=[]
    for k,(degree,i) in enumerate(labels):
        row=a.basis(d,degree)[i]
        nj=int(row[0]>=2)+int(row[1]>=2)+sum(row[4:])
        if degree>=s and degree+(D-1)*nj>=s+(D-1)*K:rows.append(1<<k)
    P=tuple(rows);mP=h.canonical(h.linear(op,v) for op in ops for v in P)
    cn=d-2;S=s+2;fs=masks[s].bit_count();hs=sum(j<s for j,i in labels)
    dg=0;dh=0;ww=0;ee=0
    for j in range(1,K):
        Q=p.support_dim(cn,j)+p.normal_dim(cn,j);DD=p.support_dim(cn,j)-p.normal_dim(cn,j)
        aj=S+(D-1)*K-D*j;L=(D-1)*(K-j)
        dg+=L*Q;dh+=Q*(L*(S-j)+L*(L-1)//2)+DD*L
        ww+=Q*(aj-1)+DD;ee+=Q
    uu=(D-1)*ww-(D-1)*(D-2)//2*ee
    head=len(labels)-len(P);g=len(P)-len(mP)
    assert (head,g)==(hs+dh,fs+dg),(d,s,K,D,head,g,hs+dh,fs+dg)
    W=c.quotient(ops,mP);nw=len(W[0]);domain=tuple(1<<i for i in range(nw))
    SocR=h.ker(domain,[sum(op[i]<<(q*nw) for q,op in enumerate(W)) for i in range(nw)])
    assert len(SocR)==g
    L=h.ker(domain,[sum(op[i]<<(q*nw) for q,op in enumerate(W[2:])) for i in range(nw)])
    Soc=h.ker(L,[h.linear(W[0],v)|(h.linear(W[1],v)<<nw) for v in L])
    assert len(Soc)==g and len(L)-g==uu
    Xi=h.canonical(h.linear(W[0],v) for v in L)
    width=len(Xi)+g-len(h.canonical(list(Xi)+list(Soc)));assert width==ww
    # The full Loewy length is checked with the entire maximal ideal, not X alone.
    layer=L;loewy=0
    while layer:
        layer=h.canonical(h.linear(op,v) for op in W[:2] for v in layer);loewy+=1
    assert loewy==D
    return dict(d=d,s=s,K=K,thickness=D,head=head,g=g,u=uu,generic_width=ww,
                loewy_length=loewy,basically_full=True,ambient_actual_dimension=len(labels))


def main():
    start=time.monotonic();rows=[check(*case) for case in [(3,3,2,3),(3,4,3,5),(4,3,2,3),(5,2,2,3),(6,2,2,3)]]
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),field=2,
                actual_variable_thickness_families=len(rows),cases=rows,
                scope='Exact controls of the actual Jacobi band decomposition, closure, head, generator count, width and full Loewy length. General uniform recovery statements use the proof, not these finite samples.')
    (ROOT/'thick_normal_corner_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

"""Falsification beyond all proved target decompositions.

Y is an arbitrary radical A-linear map on unequal Jordan strings for X=t,
not required to be divisible by t. General width comparison stays UNPROVED.
"""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('previous',ROOT/'check_loewy_two_and_uniform.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
w=p.w;z=p.z;h=p.h;dual=p.dual


def target(lengths,rng):
    offsets=[];n=0
    for N in lengths:offsets.append(n);n+=N
    X=[];Y=[];data=[]
    for a,Na in enumerate(lengths):
        ca=[]
        for b,Nb in enumerate(lengths):
            lower=max(Nb-Na,0)
            if Na==Nb and b<=a:lower=max(lower,1)
            ca.append([r for r in range(lower,Nb) if rng.randrange(4)==0])
        data.append(ca)
        for i in range(Na):
            X.append(1<<(offsets[a]+i+1) if i+1<Na else 0);value=0
            for b,Nb in enumerate(lengths):
                for r in ca[b]:
                    if i+r<Nb:value^=1<<(offsets[b]+i+r)
            Y.append(value)
    L=z.module((tuple(X),tuple(Y)))
    row=tuple(1<<i for i in range(n))
    for _ in range(n):row=h.canonical(h.linear(Y,v) for v in row)
    assert not row
    e=n-w.pencil_rank(*L['actions']);L.update(e=e,delta=e-L['top'],width=w.generic_width(L),lengths=lengths,Y_data=data)
    assert L['delta']>=0
    return L


def main():
    start=time.monotonic();rng=random.Random(2026110232)
    w.DEG=64;w.MOD=(1<<64)|0x1B;w.MASK=(1<<64)-1;w.verify_field()
    shapes=[(8,5,3,2),(12,7,4,1),(9,8,5,3,1),(14,10,7,4,2,1),(7,7,4,4,2,2),(11,6,6,3,3,1)]
    targets=[target(shape,rng) for shape in shapes for _ in range(20)]
    source=[w.c.ideal_of(part) for length in range(1,9) for part in w.c.partitions(length)]
    for a in [2,3,4]:
        for r in [2,4,8,12]:source.append(tuple((a*(r-i),a*i) for i in range(r+1)))
    for r in [2,4,8,12]:source.append(tuple(sorted([(3*(r-i),3*i) for i in range(r+1)]+[(3*(r-i)-1,3*i+2) for i in range(r)],reverse=True)))
    for a in [2,3,4,6]:
        for b in [a+4,a+12]:source.append(((a,0),(0,b)))
    checks=0;bad=[];saturated=[]
    for J in source:
        b=min(sum(m) for m in J)+1-len(J);cur=J;later=[]
        for j in range(1,17):
            cur=w.c.times_n(cur)
            if j in [1,2,4,8,16]:later.append((j,cur))
        for li,L in enumerate(targets):
            initial=z.hom(J,L);bound=L['length']-L['socle']+b*L['width']
            for j,J1 in later:
                loss=(len(J1)-len(J))*L['socle']-(z.hom(J1,L)-initial);checks+=1
                if loss>bound:
                    bad.append(dict(J=J,b=b,j=j,target=L,loss=loss,bound=bound));break
                if b and loss==bound and len(saturated)<4:saturated.append(dict(J=J,b=b,j=j,target=li,loss=loss))
            if bad:break
        if bad:break
    nonhom=0
    if not bad:
        for a,N,count in [(2,5,6),(3,6,4),(4,7,3)]:
            mon=[m for m in dual.monomials(N) if sum(m)>=a]
            for case in range(count):
                polys=[]
                for k in range(2+case%3):
                    poly=[m for m in mon if rng.randrange(5)==0]
                    if not any(sum(m)==a for m in poly):poly.append((a,0))
                    polys.append(tuple(sorted(set(poly))))
                qs=[dual.quotient(polys,N,j) for j in range(4)];b=a+1-qs[0]['mu']
                for L in targets[::3]:
                    initial=dual.hom_ideal(qs[0],L);bound=L['length']-L['socle']+b*L['width']
                    for j in range(1,4):
                        loss=(qs[j]['mu']-qs[0]['mu'])*L['socle']-(dual.hom_ideal(qs[j],L)-initial);nonhom+=1
                        if loss>bound:bad.append(dict(polys=polys,b=b,j=j,target=L,loss=loss,bound=bound));break
                    if bad:break
                if bad:break
            if bad:break
    result=dict(status='COUNTEREXAMPLE_FOUND' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',
        seconds=round(time.monotonic()-start,3),targets=len(targets),nonreduction_targets=sum(bool(L['delta']) for L in targets),
        max_length=max(L['length'] for L in targets),monomial_sources=len(source),monomial_comparisons=checks,
        nonhomogeneous_comparisons=nonhom,counterexamples=bad,saturated_examples=saturated,
        mathematical_status='UNPROVED general width comparison; these finite nonsplit commuting targets do not establish it.')
    (ROOT/'nonsplit_target_probe_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

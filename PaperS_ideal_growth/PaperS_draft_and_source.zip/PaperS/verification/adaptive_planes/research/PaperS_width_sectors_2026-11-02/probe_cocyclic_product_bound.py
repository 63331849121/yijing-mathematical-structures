"""Falsification of a stronger UNPROVED cocyclic-target comparison.

For L=D(S/Q), h(mJ,L)-h(J,L)=mu(QJ)-mu(J) exactly.
Search tests loss<=b(J), stronger than the general u+b*w candidate.
"""
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('c',ROOT.parent/'PaperS_packet_comparison_2026-11-01'/'check_full_plane_hom.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def minimal(rows):
    out=[];last=10**12
    for x,y in sorted(set(rows)):
        if y<last:out.append((x,y));last=y
    return tuple(reversed(out))


def product_ideal(I,J):return minimal((a+c,b+d) for a,b in I for c,d in J)


def main():
    start=time.monotonic()
    targets=[c.ideal_of(p) for n in range(1,14) for p in c.partitions(n)]
    sources=[c.ideal_of(p) for n in range(1,14) for p in c.partitions(n)]
    for a in [4,8,16,32]:
        sources.append(minimal([(a,0),(0,a)]+[(i,a+1-i) for i in range(a+2)]))
    for r in [2,4,8]:
        sources.append(tuple(sorted([(3*(r-i),3*i) for i in range(r+1)]+[(3*(r-i)-1,3*i+2) for i in range(r)],reverse=True)))
        targets.append(sources[-1])
    for a in [2,4,8,16]:targets.append(((a,0),(0,a)))
    comparisons=0;bad=[];minimum_slack=10**9
    for J in sources:
        a=min(sum(m) for m in J);b=a+1-len(J)
        for Q in targets:
            later=J;prod=product_ideal(Q,J);dh=0;maxj=a+min(sum(m) for m in Q)+3
            for j in range(1,maxj+1):
                dh+=len(prod)-len(later)
                later=c.times_n(later);prod=c.times_n(prod)
                loss=len(later)-len(J)-dh;comparisons+=1;minimum_slack=min(minimum_slack,b-loss)
                if loss>b:
                    bad.append(dict(J=J,Q=Q,b=b,j=j,loss=loss,strong_budget=b));break
            if bad:break
        if bad:break
    result=dict(status='COUNTEREXAMPLE_FOUND' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',
        seconds=round(time.monotonic()-start,3),source_ideals=len(sources),cocyclic_target_ideals=len(targets),
        comparisons=comparisons,counterexamples=bad,minimum_slack=minimum_slack,
        mathematical_status='UNPROVED stronger cocyclic bound; even a pass would not prove it.')
    (ROOT/'cocyclic_product_probe_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

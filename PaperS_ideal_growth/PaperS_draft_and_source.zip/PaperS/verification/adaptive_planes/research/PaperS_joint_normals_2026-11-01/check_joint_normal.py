"""Exact simultaneous-normal controls in actual M_d over F_2.

The Jacobi module is imported from the independent higher-rank control;
subspaces, intersections and simultaneous kernel equations use bit-vector
elimination here. Sampled families are explicitly labelled as samples.
"""
from pathlib import Path
from functools import lru_cache
from collections import Counter
import importlib.util
import json
import random
import time
from itertools import combinations,product

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('jacobi_module',ROOT.parent/'PaperS_locality_rate_extension_2026-11-01'/'check_higher_rank_and_twist.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)


def bitrow(v):
    return sum(int(x)<<i for i,x in enumerate(v))


def canonical(rows):
    piv={}
    for v in rows:
        while v:
            p=(v&-v).bit_length()-1
            if p in piv:v^=piv[p]
            else:
                for q,b in list(piv.items()):
                    if (b>>p)&1:piv[q]=b^v
                piv[p]=v;break
    return tuple(piv[p] for p in sorted(piv))


def reduce(v,rows):
    for b in rows:
        p=(b&-b).bit_length()-1
        if (v>>p)&1:v^=b
    return v


def linear(cols,v):
    out=0
    while v:
        low=v&-v;out^=cols[low.bit_length()-1];v^=low
    return out


def ker(rows,images):
    """Kernel on the given independent domain rows, in ambient coordinates."""
    piv={};out=[]
    for i,v in enumerate(images):
        tag=1<<i
        while v:
            p=(v&-v).bit_length()-1
            if p in piv:v^=piv[p][0];tag^=piv[p][1]
            else:piv[p]=(v,tag);break
        if not v:out.append(linear(rows,tag))
    return canonical(out)


@lru_cache(None)
def full(d,s):return tuple(1<<i for i in range(len(a.basis(d,s))))


@lru_cache(None)
def mult(d,s,axis):return tuple(bitrow(v) for v in a.multiply(d,s,axis,2))


@lru_cache(None)
def plane(d,s):
    return tuple((1<<row[3]) if row[:2]==(0,1) and not any(row[4:]) else 0 for row in a.basis(d,s))


def plane_preimage(d,s,rows,target):
    return ker(rows,[reduce(linear(plane(d,s),v),target) for v in rows])


def planar_next(rows):return canonical(list(rows)+[v<<1 for v in rows])


def eigenspaces(d,spaces):
    bound=max(spaces)
    J={s:canonical(linear(plane(d,s),v) for v in rows) for s,rows in spaces.items()}
    Jp={0:()}
    for s in range(1,bound+1):Jp[s]=planar_next(J[s-1])
    Ip={s:plane_preimage(d,s,spaces[s],Jp[s]) for s in spaces}
    Kp={s:plane_preimage(d,s,full(d,s),Jp[s]) for s in spaces}
    mIp={0:()}
    for s in range(1,bound+1):
        mIp[s]=canonical(linear(mult(d,s-1,i),v) for i in range(d) for v in Ip[s-1])
    single={i:{} for i in range(2,d)};joint={}
    for s in range(bound):
        width=len(a.basis(d,s+1))
        for chosen in list(range(2,d))+[None]:
            images=[]
            for v in Kp[s]:
                bits=0
                for i in range(2,d):
                    target=mIp[s+1] if chosen is None or i==chosen else Ip[s+1]
                    bits|=reduce(linear(mult(d,s,i),v),target)<<((i-2)*width)
                images.append(bits)
            sub=ker(Kp[s],images)
            assert all(reduce(v,sub)==0 for v in Ip[s])
            quotient=canonical(reduce(v,Ip[s]) for v in sub)
            if chosen is None:joint[s]=quotient
            else:single[chosen][s]=quotient
    z=sum(map(len,joint.values()));gen=z
    for s in range(1,bound):
        prev=joint[s-1]
        images=canonical(reduce(linear(mult(d,s-1,i),v),Ip[s]) for i in [0,1] for v in prev)
        assert all(reduce(v,joint[s])==0 for v in images)
        gen-=len(images)
    singles={i:sum(map(len,part.values())) for i,part in single.items()}
    assert all(z<=v for v in singles.values())
    return dict(single_normal_effective_lengths=singles,joint_length=z,joint_planar_generators=gen),Ip,J,Jp,joint


def full_relation_kernel(d,spaces,Ip,J,Jp,joint):
    """Exact linear kernel for J=n^r, Jplus=n^(r+1), T semisimple."""
    bound=max(spaces)
    r=next(s for s in spaces if J[s])
    if any(J[s] != tuple(1<<i for i in range(s+1)) for s in range(r,bound+1)):
        return None
    v=r+1;w=(d-1)*v-1
    mIp={0:()}
    for s in range(1,bound+1):
        mIp[s]=canonical(linear(mult(d,s-1,i),u) for i in range(d) for u in Ip[s-1])
    offsets={};width=0
    for s in range(1,bound+1):offsets[s]=width;width+=len(a.basis(d,s))
    soc=[]
    for s in range(bound):
        K=plane_preimage(d,s,full(d,s),Jp[s]);targetwidth=len(a.basis(d,s+1))
        images=[]
        for u in K:
            out=0
            for axis in range(d):out|=reduce(linear(mult(d,s,axis),u),Ip[s+1])<<(axis*targetwidth)
            images.append(out)
        basis=canonical(reduce(u,Ip[s]) for u in ker(K,images))
        soc.extend((s,u) for u in basis)
    cols=[]
    for l in range(v):
        for s,u in soc:
            images=[reduce(linear(mult(d,s,i),u),mIp[s+1])<<offsets[s+1] for i in range(d)]
            out=0
            for axis in range(2,d):out^=images[axis]<<(((axis-2)*v+l)*width)
            if l<r:out^=images[1]<<(((d-2)*v+l)*width)
            if l>0:out^=images[0]<<(((d-2)*v+l-1)*width)
            cols.append(out)
    kappa=len(cols)-len(canonical(cols))
    jointsoc=0
    for s in range(bound):
        images=[];targetwidth=len(a.basis(d,s+1))
        for u in joint[s]:
            images.append(reduce(linear(mult(d,s,0),u),Ip[s+1]) |
                          (reduce(linear(mult(d,s,1),u),Ip[s+1])<<targetwidth))
        jointsoc+=len(ker(joint[s],images))
    assert kappa<=v*jointsoc,(d,r,kappa,jointsoc)
    # Exact basically-full closure defect of the output.
    defect=0
    for s in range(bound):
        targetwidth=len(a.basis(d,s+1));images=[]
        for u in full(d,s):
            out=0
            for axis in range(d):out|=reduce(linear(mult(d,s,axis),u),mIp[s+1])<<(axis*targetwidth)
            images.append(out)
        defect+=len(ker(full(d,s),images))-len(Ip[s])
    return dict(planar_power=r,minimal_plane_generators=v,relation_domain_dimension=w,
                parameter_dimension=len(cols),joint_normal_Hom_dimension=v*jointsoc,
                full_relation_kernel_dimension=kappa,output_closure_defect=defect)


def point_kernel(d,s,points):
    # c_ij evaluates to p_i e_j-p_j e_i. Characteristic two.
    images=[]
    for row in a.basis(d,s):
        i,j=row[:2];out=0
        for k,p in enumerate(points):
            if all(not power or p[axis] for axis,power in enumerate(row[2:])):
                out|=((p[i]<<j)^(p[j]<<i))<<(k*d)
        images.append(out)
    return ker(full(d,s),images)


def subspaces(n):
    """All subspaces, each once, by reduced row-echelon pivot positions."""
    for rank in range(n+1):
        for pivots in combinations(range(n),rank):
            free=[(i,j) for i,p in enumerate(pivots) for j in range(p+1,n) if j not in pivots]
            for values in product([0,1],repeat=len(free)):
                rows=[1<<p for p in pivots]
                for (i,j),v in zip(free,values):rows[i]|=v<<j
                yield tuple(rows)


def nonplane_spaces(d,V,degree,r,bound):
    spaces={}
    for s in range(bound+1):
        F=tuple(u for u,col in zip(full(d,s),plane(d,s)) if not col)
        rows=() if s<degree else V if s==degree else F
        if s>=r:rows=tuple(rows)+tuple(u for u,col in zip(full(d,s),plane(d,s)) if col)
        spaces[s]=canonical(rows)
    return spaces


def main():
    start=time.monotonic();rng=random.Random(2026110109);hist=Counter();cases=[];strict=0
    # All 63 degree-zero hyperplanes for d=4; d=5 cases below are samples.
    for d,s,number in [(3,1,255),(4,0,63),(4,1,64),(5,0,64),(5,1,64)]:
        dim=len(a.basis(d,s))
        masks=list(range(1,1<<dim)) if (d,s) in [(3,1),(4,0)] else [rng.randrange(1,1<<dim) for _ in range(number)]
        if (d,s)==(4,1):masks += [sum(1<<i for i in choice) for c in [1,2] for choice in combinations(range(dim),c)]
        for mask in masks:
            V=ker(full(d,s),[(v&mask).bit_count()%2 for v in full(d,s)])
            spaces={t:() if t<s else V if t==s else full(d,t) for t in range(s+3)}
            row,Ip,J,Jp,joint=eigenspaces(d,spaces)
            detail=full_relation_kernel(d,spaces,Ip,J,Jp,joint)
            if detail:row['full_relation']=detail
            old=min(row['single_normal_effective_lengths'].values());joint=row['joint_length']
            hist[(d,s,old,joint)]+=1
            if joint<old:strict+=1
            cases.append(dict(d=d,degree=s,annihilator_mask=mask,**row))
    # Structured exact point-evaluation kernels, away from the chosen plane.
    structured=[]
    for d in [4,5]:
        points=[tuple(int(i==j) for i in range(d)) for j in range(2,d)]
        for s in [1,2]:
            V=point_kernel(d,s,points)
            spaces={t:() if t<s else V if t==s else full(d,t) for t in range(s+3)}
            row,Ip,J,Jp,joint=eigenspaces(d,spaces)
            row['full_relation']=full_relation_kernel(d,spaces,Ip,J,Jp,joint)
            assert row['joint_length']==0,(d,s,row)
            assert min(row['single_normal_effective_lengths'].values())>0,(d,s,row)
            structured.append(dict(d=d,degree=s,points=points,**row))
    # Exhaust all 2825 nonplane degree-one subspaces in actual M3, with
    # variable planar padding. This probes the remaining planar pencil.
    F=[u for u,col in zip(full(3,1),plane(3,1)) if not col]
    pencils=[];pencilhist=Counter();badclosed=[]
    for coords in subspaces(len(F)):
        V=tuple(linear(F,u) for u in coords)
        spaces=nonplane_spaces(3,V,1,1,4)
        row,Ip,J,Jp,joint=eigenspaces(3,spaces)
        detail=full_relation_kernel(3,spaces,Ip,J,Jp,joint)
        pencilhist[(row['joint_length'],detail['full_relation_kernel_dimension'],detail['output_closure_defect'])]+=1
        if detail['output_closure_defect']==0 and detail['full_relation_kernel_dimension']>row['joint_length']:
            badclosed.append(dict(V=list(V),joint=row['joint_length'],**detail))
        if detail['output_closure_defect']==0 and row['joint_length']:
            growth=[]
            for r in [1,2,3]:
                spaces=nonplane_spaces(3,V,1,r,r+3)
                rr,II,JJ,JP,ee=eigenspaces(3,spaces)
                dd=full_relation_kernel(3,spaces,II,JJ,JP,ee)
                growth.append(dict(r=r,joint=rr['joint_length'],**dd))
            pencils.append(dict(V=list(V),growth=growth))
    fullcases=[row['full_relation'] for row in cases if row.get('full_relation')]
    khist=Counter((row['joint_normal_Hom_dimension'],row['full_relation_kernel_dimension'],row['output_closure_defect']) for row in fullcases)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
                actual_module_cases=len(cases),all_degree_zero_hyperplanes_d4=63,
                all_degree_one_hyperplanes_d3=255,low_weight_degree_one_hyperplanes_d4=210,
                sampled_hyperplanes=192,strictly_better_than_best_single_normal=strict,
                histogram={f'd={d},degree={s},best_single={u},joint={v}':n for (d,s,u,v),n in sorted(hist.items())},
                structured_exact_certificates=structured,cases=cases,
                full_relation_cases=len(fullcases),
                full_relation_strict_improvements=sum(row['full_relation_kernel_dimension']<row['joint_normal_Hom_dimension'] for row in fullcases),
                full_relation_histogram={f'joint_Hom={u},full_kernel={v},output_closure_defect={c}':n for (u,v,c),n in sorted(khist.items())},
                exhaustive_nonplane_M3_subspaces=sum(pencilhist.values()),
                nonplane_pencil_histogram={f'joint_length={u},full_kernel={v},output_closure_defect={c}':n for (u,v,c),n in sorted(pencilhist.items())},
                closed_output_growing_pencils=pencils,
                closed_output_kernel_exceeds_joint_length=badclosed,
                scope='Exact finite arithmetic in the actual Jacobi module M_d over F2. Random families are samples, not exhaustive. No asymptotic conclusion is inferred.')
    (ROOT/'joint_normal_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    compact={k:v for k,v in result.items() if k not in ['cases','closed_output_growing_pencils']}
    compact['closed_output_pencil_growth_histogram']={str(k):v for k,v in Counter(tuple(x['full_relation_kernel_dimension'] for x in row['growth']) for row in pencils).items()}
    print(json.dumps(compact,ensure_ascii=False,indent=2))


if __name__=='__main__':main()

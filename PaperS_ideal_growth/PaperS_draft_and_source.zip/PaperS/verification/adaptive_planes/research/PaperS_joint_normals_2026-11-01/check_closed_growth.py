"""Actual M3 certificates for growing full-relation kernels of closed outputs."""
from pathlib import Path
from collections import Counter
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('joint_helpers',ROOT/'check_joint_normal.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)


def spaces_for(exponent,r,bound):
    out={}
    for s in range(bound+1):
        basis=h.a.basis(3,s);index={row:i for i,row in enumerate(basis)};rows=[]
        for x,y,z in h.a.mons(s,3):
            # a=c13 is a free R-generator of F.
            if z or x>=exponent or y>=exponent or (x>=exponent-1 and y>=exponent-1):
                rows.append(1<<index[(0,2,x,y,z)])
            # b=c23 is the other free R-generator of F.
            # X b=Y a+Z c12 in characteristic two (Jacobi).
            if x:
                rows.append((1<<index[(0,2,x-1,y+1,z)]) ^ (1<<index[(0,1,x-1,y,z+1)]))
            else:rows.append(1<<index[(1,2,0,y,z)])
        if s>=r:
            rows.extend(1<<index[(0,1,x,s-x,0)] for x in range(s+1))
        out[s]=h.canonical(rows)
    # Check actual R-submodule closure using independent Jacobi multiplication.
    for s in range(bound):
        assert all(h.reduce(h.linear(h.mult(3,s,i),u),out[s+1])==0 for i in range(3) for u in out[s])
    return out


def closure_defect_of_mI(Ip,bound):
    mIp={0:()};mmIp={0:()}
    for s in range(1,bound+1):
        mIp[s]=h.canonical(h.linear(h.mult(3,s-1,i),u) for i in range(3) for u in Ip[s-1])
        mmIp[s]=h.canonical(h.linear(h.mult(3,s-1,i),u) for i in range(3) for u in mIp[s-1])
    defect=0
    for s in range(bound):
        width=len(h.a.basis(3,s+1));images=[]
        for u in h.full(3,s):
            out=0
            for i in range(3):out|=h.reduce(h.linear(h.mult(3,s,i),u),mmIp[s+1])<<(i*width)
            images.append(out)
        defect+=len(h.ker(h.full(3,s),images))-len(mIp[s])
    return defect


def generator_histogram(exponent,r,Ip,bound):
    """Exhaust all parameters; ranks use actual M3 multiplication, not the pencil formula."""
    offsets={};width=0
    for s in range(bound+1):offsets[s]=width;width+=len(h.a.basis(3,s))
    ipglobal=h.canonical(u<<offsets[s] for s,rows in Ip.items() for u in rows)
    mglobal=h.canonical(h.linear(h.mult(3,s,i),u)<<offsets[s+1]
                        for s in range(bound) for i in range(3) for u in Ip[s])
    gplus=len(ipglobal)-len(mglobal)
    assert gplus==r+7
    socdegree=2*exponent-3;index={row:i for i,row in enumerate(h.a.basis(3,socdegree))}
    u=1<<index[(0,2,exponent-2,exponent-1,0)]
    v=1<<index[(0,2,exponent-1,exponent-2,0)]
    units=[u,v];hist=Counter()
    base=[]
    for l in range(r+1):
        idx=h.a.basis(3,r).index((0,1,r-l,l,0));plane=1<<idx
        base.append([h.linear(h.mult(3,r,i),plane)<<offsets[r+1] for i in range(3)])
    delta=[[[h.linear(h.mult(3,socdegree,i),e)<<offsets[socdegree+1] for i in range(3)] for e in units] for _ in range(r+1)]
    for mask in range(1<<(2*(r+1))):
        images=[]
        for l in range(r+1):
            for i in range(3):
                out=base[l][i]
                if (mask>>(2*l))&1:out^=delta[l][0][i]
                if (mask>>(2*l+1))&1:out^=delta[l][1][i]
                images.append(h.reduce(out,mglobal))
        g=gplus+(r+1)-len(h.canonical(images));hist[g]+=1
    assert hist==Counter({gplus-1:1<<(r+2),gplus-2:(1<<(2*(r+1)))-(1<<(r+2))})
    return dict(parameters=sum(hist.values()),output_generators=gplus,generator_histogram=dict(sorted(hist.items())))


def main():
    start=time.monotonic();rows=[]
    for exponent,r in [(3,4),(3,6),(3,10),(4,6),(4,8)]:
        spaces=spaces_for(exponent,r,r+3)
        row,Ip,J,Jp,joint=h.eigenspaces(3,spaces)
        detail=h.full_relation_kernel(3,spaces,Ip,J,Jp,joint)
        assert detail['output_closure_defect']==0,(exponent,r,row,detail)
        assert detail['full_relation_kernel_dimension']==r+2,(exponent,r,row,detail)
        assert detail['joint_normal_Hom_dimension']==2*(r+1)
        second=closure_defect_of_mI(Ip,r+3)
        assert second>=1
        report=dict(exponent=exponent,r=r,joint_normal_length=row['joint_length'],
                    second_closure_defect=second,**detail)
        if (exponent,r)==(3,4):report['exhaustive_actual_generator_control']=generator_histogram(exponent,r,Ip,r+3)
        rows.append(report)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),actual_M3_growth_cases=rows,
                scope='Actual Jacobi-module submodule, normal and full-relation kernel computations over F2. General proof is in the companion note; this family does not contradict the global locality rate.')
    (ROOT/'closed_growth_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()

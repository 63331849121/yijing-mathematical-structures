"""Research-only source and exact-control guard; never compiles manuscripts."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).parent
snap=json.loads((ROOT.parent/'PaperS_higher_rank_locality_2026-11-01'/'source_snapshot_updated.json').read_text(encoding='utf-8'))
changes=[]
for name,meta in snap['files'].items():
    current=Path(snap['source'])/name
    if not current.exists() or hashlib.sha256(current.read_bytes()).hexdigest()!=meta['sha256']:changes.append(name)

proofs={}
for tex in ROOT.glob('*.tex'):
    raw=tex.read_text(encoding='utf-8')
    code='\n'.join(re.split(r'(?<!\\)%',line)[0] for line in raw.splitlines())
    stack=[]
    for cmd,env in re.findall(r'\\(begin|end)\{([^}]+)\}',code):
        if cmd=='begin':stack.append(env)
        else:assert stack and stack.pop()==env,(tex.name,cmd,env)
    assert not stack,tex.name
    balance=0
    for c in re.sub(r'\\[{}]','',code):
        balance+=(c=='{')-(c=='}');assert balance>=0,tex.name
    assert balance==0,tex.name
    labels=re.findall(r'\\label\{([^}]+)\}',code)
    refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',code)
    assert len(labels)==len(set(labels)) and set(refs)<=set(labels),(tex.name,set(refs)-set(labels))
    proofs[tex.name]=dict(status='PASS',sha256=hashlib.sha256(raw.encode()).hexdigest(),bytes=len(raw.encode()))

controls={}
for stem,resultname in [('joint_normal','joint_normal_results.json'),('closed_growth','closed_growth_results.json')]:
    script=ROOT/f'check_{stem}.py';result=ROOT/resultname
    data=json.loads(result.read_text(encoding='utf-8'));assert data['status']=='PASS'
    controls[resultname]=dict(status='PASS',script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),result_sha256=hashlib.sha256(result.read_bytes()).hexdigest())

status=dict(status='PASS',stage=9,date='2026-11-01',work_state='Active: full-relation kernel and higher-defect estimates remain under investigation.',
            latest_index='研究进展与下一步.txt',proofs=proofs,controls=controls,
            baseline_manuscript_matches_current=not any(x.endswith(('.tex','.pdf')) for x in changes),external_changes_since_baseline=changes,
            main_manuscript_edits_performed=False,main_manuscript_compilation_performed=False,
            mathematical_status='General proof drafts and finite certificates; no independent external mathematical certification.',
            remaining_gap='A uniform near-extremal estimate or weighted rarity bound for the full-relation liftable-map kernel in ranks five and higher.',
            no_claims=['No unconditional rank-five theorem.','No inference that basically-full closure controls all higher defects.','No inference that a growing kernel defeats the locality rate.'])
(ROOT/'research_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in status.items() if k not in ['proofs','controls']},ensure_ascii=False,indent=2))
print('Static proof checks:',len(proofs),'PASS; finite-control records:',len(controls),'PASS')

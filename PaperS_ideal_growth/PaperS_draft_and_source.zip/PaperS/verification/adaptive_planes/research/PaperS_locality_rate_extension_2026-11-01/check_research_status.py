"""Archive guard and static checks for the rank extension research note."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).parent
PREV=ROOT.parent/'PaperS_higher_rank_locality_2026-11-01'
snap=json.loads((PREV/'source_snapshot_updated.json').read_text(encoding='utf-8'))
changes=[]
for name,meta in snap['files'].items():
    current=Path(snap['source'])/name
    if not current.exists() or hashlib.sha256(current.read_bytes()).hexdigest()!=meta['sha256']:changes.append(name)
    if name.endswith('.tex'):
        assert hashlib.sha256((Path(snap['baseline'])/name).read_bytes()).hexdigest()==meta['sha256']

sources={}
for tex in ROOT.glob('*.tex'):
    raw=tex.read_text(encoding='utf-8')
    code='\n'.join(re.split(r'(?<!\\)%',x)[0] for x in raw.splitlines())
    stack=[]
    for cmd,env in re.findall(r'\\(begin|end)\{([^}]+)\}',code):
        if cmd=='begin':stack.append(env)
        else:assert stack and stack.pop()==env,(tex.name,env)
    assert not stack
    bal=0
    for c in re.sub(r'\\[{}]','',code):
        bal+=(c=='{')-(c=='}');assert bal>=0
    assert bal==0
    labels=re.findall(r'\\label\{([^}]+)\}',code)
    refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',code)
    assert len(labels)==len(set(labels)) and set(refs)<=set(labels),(tex.name,set(refs)-set(labels))
    sources[tex.name]=dict(static_status='PASS',sha256=hashlib.sha256(raw.encode()).hexdigest())

data=json.loads((ROOT/'higher_rank_twist_results.json').read_text(encoding='utf-8'))
assert data['status']=='PASS'
status=dict(status='PASS',date='2026-11-01',stage=7,work_state='Continuing research without requesting confirmation.',
            main_manuscript_edits_performed=False,main_manuscript_compilation_performed=False,
            baseline_manuscript_matches_current=not any(n.endswith(('.tex','.pdf')) for n in changes),
            external_changes_since_baseline=changes,proof_sources=sources,
            finite_controls=dict(status='PASS',actual_module_and_padding_checks=data['actual_module_and_padding_checks'],
                                 exact_twist_checks=data['exact_twist_checks'],
                                 script_sha256=hashlib.sha256((ROOT/'check_higher_rank_and_twist.py').read_bytes()).hexdigest()),
            proof_status='General proof drafts conditional on explicitly listed previous research inputs; external specialist review pending.',
            new_results=['For d=3,4: E_n/P_n=1-pi_n=q^(-n/2+O(n^(1-1/d))) in logarithmic order.',
                         'For d=3,4: P_n/C_n=q^(-n/2+O(n^(1-1/d))).',
                         'For all fixed d>=2: E_n/P_n>=q^(-n/2-O(n^(1-1/d))).'],
            continuing_focus='Rank-five recovery/overshoot competition, length-dependent index bounds, alternative plane projections.',
            no_claims=['No uniform-type fine probability law.','No global upper result in d>=5.','No external mathematical certification.'])
(ROOT/'research_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(status,ensure_ascii=False,indent=2))

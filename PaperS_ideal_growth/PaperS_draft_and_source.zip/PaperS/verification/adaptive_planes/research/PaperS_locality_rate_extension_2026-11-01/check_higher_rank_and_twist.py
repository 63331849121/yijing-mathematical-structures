"""Exact controls on actual M_d, plane padding and the nonlocal twist.

The module basis is the standard metabelian basis c_ij times monomials
in variables with indices at least i (i<j). Multiplication below implements
Jacobi directly; it is not a free-rank surrogate. Finite cases do not prove
the general counting theorem.
"""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, product
from pathlib import Path
import importlib.util
import json
import random
import time

ROOT=Path(__file__).parent
OLD=ROOT.parent/'PaperS_core_weight_comparison_2026-11-01'
spec=importlib.util.spec_from_file_location('independent_field_and_head_counts',OLD/'check_core_weights.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
Field=h.Field


def mons(total,variables):
    if variables==1:
        yield (total,)
    else:
        for x in range(total,-1,-1):
            for tail in mons(total-x,variables-1):yield (x,)+tail


@lru_cache(None)
def basis(d,s):
    return tuple((i,j)+(0,)*i+tail for i in range(d-1) for j in range(i+1,d)
                 for tail in mons(s,d-i))


@lru_cache(None)
def multiply(d,s,axis,q):
    f=Field(q);target=basis(d,s+1);idx={v:i for i,v in enumerate(target)};columns=[]
    for row in basis(d,s):
        i,j=row[:2];powers=list(row[2:]);out=[0]*len(target)
        if axis>=i:
            powers[axis]+=1;out[idx[(i,j)+tuple(powers)]]=1
        else:
            a=powers.copy();a[i]+=1
            b=powers.copy();b[j]+=1
            out[idx[(axis,j)+tuple(a)]]=1
            out[idx[(axis,i)+tuple(b)]]=f.neg(1)
        columns.append(tuple(out))
    return tuple(columns)


def apply(f,cols,v):
    if not cols:return ()
    out=[0]*len(cols[0])
    for a,col in zip(v,cols):
        if a:out=[f.add(x,f.mul(a,y)) for x,y in zip(out,col)]
    return tuple(out)


def units(n,indices=None):
    if indices is None:indices=range(n)
    return tuple(tuple(int(i==j) for j in range(n)) for i in indices)


def actual_padding():
    reports=[];identities=0
    for d,q,s,maxj in [(3,2,1,3),(3,3,2,2),(4,2,1,3),(4,3,1,2),(4,4,1,2),(5,2,1,2)]:
        f=Field(q);g=len(basis(d,s));k=sum(len(basis(d,t)) for t in range(s))
        for j in range(1,maxj+1):
            length=gen=0;previous=()
            for t in range(s+j+2):
                dim=len(basis(d,t))
                if t<s:current=()
                elif t<s+j:
                    kept=[a for a,row in enumerate(basis(d,t)) if not (row[:2]==(0,1) and all(x==0 for x in row[4:]))]
                    current=units(dim,kept)
                else:current=units(dim)
                length+=dim-len(current)
                if t:
                    if len(previous)==len(basis(d,t-1)) and len(current)==dim:rank=dim
                    else:
                        images=[apply(f,multiply(d,t-1,i,q),v) for i in range(d) for v in previous]
                        rank=f.rank(images)
                        assert f.rank(list(current)+images)==len(current)
                else:rank=0
                gen+=len(current)-rank;previous=current
            added=j*(s+1)+j*(j-1)//2
            assert length==k+added and gen==g+j,(d,q,s,j,k,length,g,gen)
            reports.append(dict(d=d,q=q,initial_degree=s,padding_steps=j,
                                initial_head=k,added_head=added,initial_generators=g,
                                output_generators=gen,status='PASS'))
            identities+=1
    # Check the same generic module's commuting variables, including Jacobi.
    for d,q in [(3,2),(4,2),(4,3),(4,4),(5,2)]:
        f=Field(q)
        for s in [0,1]:
            for i,j in combinations(range(d),2):
                for v in units(len(basis(d,s))):
                    lhs=apply(f,multiply(d,s+1,j,q),apply(f,multiply(d,s,i,q),v))
                    rhs=apply(f,multiply(d,s+1,i,q),apply(f,multiply(d,s,j,q),v))
                    assert lhs==rhs;identities+=1
    return identities,reports


def truncated(d,s,q):
    f=Field(q);labels=tuple(v for t in range(s+1) for v in basis(d,t))
    index={v:i for i,v in enumerate(labels)};size=len(labels);actions=[]
    for axis in range(d):
        cols=[]
        for row in labels:
            t=sum(row[2:]);out=[0]*size
            if t<s:
                local=multiply(d,t,axis,q)[basis(d,t).index(row)]
                for a,v in zip(local,basis(d,t+1)):
                    if a:out[index[v]]=a
            cols.append(tuple(out))
        actions.append(tuple(cols))
    return labels,index,actions


def twists():
    reports=[];checked=0;rng=random.Random(20261101)
    for d,q,s in [(2,2,1),(3,2,1),(3,2,3),(3,3,2),(3,4,1),(4,2,1),(4,3,2),(4,4,1),(5,2,1)]:
        f=Field(q);labels,index,actions=truncated(d,s,q);size=len(labels)
        k=sum(len(basis(d,t)) for t in range(s));g=len(basis(d,s))
        v=h.ceil_log(f.p,s+1);P=f.p**v
        def power(axis,vec,e):
            for _ in range(e):vec=apply(f,actions[axis],vec)
            return vec
        def comm(i,j):
            out=[0]*size
            if i==j:return tuple(out)
            a,b=sorted((i,j));out[index[(a,b)+(0,)*d]]=1 if i<j else f.neg(1)
            return tuple(out)
        old_c=[[power(j,comm(i,j),P-1) for j in range(d)] for i in range(d)]
        new_c=[[power(0,comm(i,0),f.p*P-1) if j==0 else old_c[i][j]
                for j in range(d)] for i in range(d)]
        for i in range(d):
            new_c[i][0]=tuple(f.add(a,f.neg(b)) for a,b in zip(new_c[i][0],old_c[i][0]))
        socle_indices=[index[row] for row in basis(d,s-1)]
        histogram=Counter()
        samples=[[[0]*size for _ in range(d)]]
        for z in range(min(48,2*len(socle_indices)+8)):
            alpha=[]
            for col in range(d):
                vec=[0]*size
                for a in socle_indices:vec[a]=rng.randrange(q)
                alpha.append(vec)
            samples.append(alpha)
        for alpha in samples:
            after=[list(x) for x in alpha]
            Talpha=power(0,alpha[0],(f.p-1)*P)
            after[0]=[f.add(a,f.neg(b)) for a,b in zip(Talpha,alpha[0])]
            old_errors=[];new_errors=[]
            for i in range(d):
                for j in range(d):
                    olderr=tuple(f.add(a,b) for a,b in zip(old_c[i][j],apply(f,actions[i],alpha[j])))
                    newerr=tuple(f.add(a,b) for a,b in zip(new_c[i][j],apply(f,actions[i],after[j])))
                    assert all(not x or sum(labels[a][2:])==s for a,x in enumerate(olderr))
                    expected=tuple(f.neg(a) for a in olderr) if j==0 else olderr
                    assert newerr==expected
                    old_errors.append(olderr);new_errors.append(newerr)
                    checked+=1
            r=f.rank(old_errors);assert f.rank(new_errors)==r;histogram[r]+=1
            # On the added away line, X1=1 and other variables are zero.
            for i in range(d):
                for j in range(d):
                    cvalue=(1 if (i,j)==(0,1) else f.neg(1) if (i,j)==(1,0) else 0)
                    coefficient=(1-1) if j==0 else 0**(P-1)
                    assert f.mul(cvalue,coefficient)==0
            A=k+g-r+d-1
            for m in [1,2,3]:
                oldW=q**(d*m)*h.old.helpers.u_nil(k+g-r,k+m,k,q)
                newW=q**(d*(m-1))*h.old.helpers.u_nil(k+1+g-r,k+m,k+1,q)
                assert oldW>0 and newW>0
                def Ah(head,excess):
                    out=Fraction(1)
                    for a in range(1,excess+1):out*=Fraction(q**(head-1+a)-1,q**(head-1+a))/Fraction(q**a-1,q**a)
                    return out
                scale=Fraction(q**max(m-A-1,0),q**max(A+1-m,0))
                assert Fraction(newW,oldW)==scale*Ah(k+1,m-1)/Ah(k,m)
                checked+=1
        reports.append(dict(d=d,q=q,origin_degree=s,P=P,head_length=k,generator_number=g,
                            head_tuples_checked=len(samples),preserved_error_rank_histogram=dict(histogram),status='PASS'))
    return checked,reports


def exponent_audit():
    rows=[]
    for d in [3,4,5,6]:
        alpha=Fraction(d-1,d);eta=Fraction(d-2,d)
        fiber=3*alpha/2;index=2*alpha*alpha
        j=Fraction(0) if d==3 else max(fiber,index)-1
        overshoot=j+alpha/2
        costs=max(overshoot+eta,2*overshoot)
        if d==4:
            assert fiber==index==Fraction(9,8)
            assert j==Fraction(1,8) and overshoot==Fraction(1,2)
            assert costs==1<1+j
        rows.append(dict(d=d,alpha=str(alpha),fiber=str(fiber),aggregate_index=str(index),
                         minimum_padding=str(j),overshoot=str(overshoot),
                         overshoot_cost=str(costs),useful_weight=str(1+j),
                         coarse_scaling_closes=d in [3,4]))
    return rows


def main():
    start=time.monotonic();identities,padding=actual_padding()
    print('Actual higher-rank M_d padding and module identities PASS',identities,flush=True)
    checks,twist=twists()
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
                actual_module_and_padding_checks=identities,padding_cases=padding,
                exact_twist_checks=checks,twist_cases=twist,exponent_audit=exponent_audit(),
                scope='Exact finite controls on the actual metabelian modules and head-count identities; no external proof certification and no finite-data inference of asymptotics.')
    (ROOT/'higher_rank_twist_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()

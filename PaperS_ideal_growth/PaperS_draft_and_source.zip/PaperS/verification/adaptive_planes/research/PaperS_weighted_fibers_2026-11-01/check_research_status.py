"""Final archive guard for proof drafts and exact finite controls."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).parent
BASE=ROOT.parent/'PaperS_higher_rank_locality_2026-11-01'
snap=json.loads((BASE/'source_snapshot_updated.json').read_text(encoding='utf-8'))
changes=[]
for name,meta in snap['files'].items():
    current=Path(snap['source'])/name
    if not current.exists() or hashlib.sha256(current.read_bytes()).hexdigest()!=meta['sha256']:changes.append(name)
    if name.endswith('.tex'):
        assert hashlib.sha256((Path(snap['baseline'])/name).read_bytes()).hexdigest()==meta['sha256']

proofs={}
for tex in ROOT.glob('*.tex'):
    raw=tex.read_text(encoding='utf-8')
    code='\n'.join(re.split(r'(?<!\\)%',line)[0] for line in raw.splitlines())
    stack=[]
    for cmd,env in re.findall(r'\\(begin|end)\{([^}]+)\}',code):
        if cmd=='begin':stack.append(env)
        else:assert stack and stack.pop()==env,(tex.name,cmd,env)
    assert not stack,tex.name
    balance=0
    for c in re.sub(r'\\[{}]','',code):
        balance+=(c=='{')-(c=='}');assert balance>=0,tex.name
    assert balance==0,tex.name
    labels=re.findall(r'\\label\{([^}]+)\}',code)
    refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',code)
    assert len(labels)==len(set(labels)) and set(refs)<=set(labels),(tex.name,set(refs)-set(labels))
    proofs[tex.name]=dict(static_status='PASS',sha256=hashlib.sha256(raw.encode()).hexdigest(),
                         bytes=len(raw.encode()),scope='Environment, brace and internal reference checks only; no mathematical certification or PDF compilation.')

controls={}
for stem in ['weighted_fibers','closure_fibers','relative_map','invariant_frame_obstruction','line_hom']:
    script=ROOT/f'check_{stem}.py'
    resultname={'weighted_fibers':'weighted_fiber_results.json','closure_fibers':'closure_fiber_results.json',
                'relative_map':'relative_map_results.json','invariant_frame_obstruction':'invariant_frame_results.json',
                'line_hom':'line_hom_results.json'}[stem]
    result=ROOT/resultname;data=json.loads(result.read_text(encoding='utf-8'))
    assert data['status']=='PASS',resultname
    controls[resultname]=dict(status='PASS',script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),
                              result_sha256=hashlib.sha256(result.read_bytes()).hexdigest())

status=dict(status='PASS',date='2026-11-01',stage=8,
            work_state='Archived after the tested unconditional rank-five routes reached explicit structural gaps; no permission or clarification requested.',
            latest_index='本次自主推进总览.txt',
            baseline_manuscript_matches_current=not any(x.endswith(('.tex','.pdf')) for x in changes),
            external_changes_since_baseline=changes,
            main_manuscript_edits_performed=False,main_manuscript_compilation_performed=False,
            source_baseline_verified=True,proof_sources=proofs,finite_controls=controls,
            mathematical_status='General research proof drafts with explicit dependencies; external professional review pending.',
            strongest_completed_drafts=['For d=3,4: 1-pi_n=q^(-n/2+O(n^(1-1/d))) and P_n/C_n=q^(-n/2+O(n^(1-1/d))).',
                                        'Universal logarithmic outer tail for every fixed free rank d>=3.',
                                        'Basically-full closure defect has upper probability q^(-u*n/2+O(n^(1-1/d))).',
                                        'General head-counting principle also applies to the stated homogeneous/graph hull sources.',
                                        'Unconditional weighted recovery inequality with effective Hom obstruction; conditional fifth/sixth-rank sectors.'],
            known_false_shortcuts=['Unchanged full origin kernel with uniform sublinear comparison.',
                                   'Weak fullness implies the exact relative normal-colon condition.',
                                   'Every near-extremal kernel has an exact good source frame.',
                                   'The existing macro-window automatically gives a power-saving joint plane-length/normal-defect bound.'],
            remaining_gap='A uniform effective Hom estimate or structural decomposition for arbitrary multilayer, nonhomogeneous rank-five cores.',
            no_claims=['No unconditional rank-five upper theorem.','No fine uniform-type probability theorem.',
                       'No external mathematical certification or exhaustive priority determination.'],
            internal_correction='The abstract affine rank bound now includes the offset-column span; the special zero-offset and full-ambient proofs are unaffected.')
(ROOT/'research_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in status.items() if k not in ['proof_sources','finite_controls']},ensure_ascii=False,indent=2))
print('Proof sources:',len(proofs),'PASS; finite controls:',len(controls),'PASS')

"""Exact actual-M3 colon closures, admissible flags and weighted fibers."""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('core_field_helpers',ROOT.parent/'PaperS_core_weight_comparison_2026-11-01'/'check_core_weights.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
Field,mbasis,mult_columns=h.Field,h.mbasis,h.mult_columns


def remainder(f,row,L):
    v=list(row)
    for b in L:
        pivot=next(j for j,x in enumerate(b) if x)
        c=v[pivot]
        if c:v=[f.add(x,f.neg(f.mul(c,y))) for x,y in zip(v,b)]
    return tuple(v)


def Ah(q,h,m):
    ans=Fraction(1)
    for i in range(1,m+1):ans*=Fraction(q**(h-1+i)-1,q**(h-1+i))/Fraction(q**i-1,q**i)
    return ans


def main():
    start=time.monotonic();reports=[];cases=0;witness=None;weight_checks=0
    for q,s,t in [(2,0,1),(3,0,1),(4,0,1),(2,1,1),(2,1,2)]:
        f=Field(q);v=len(mbasis(s));w=len(mbasis(s+1));cols=[mult_columns(s,i,f) for i in range(3)]
        Fidx=[i for i,row in enumerate(mbasis(s)) if not (row[0]==0 and row[3]==0)]
        F=h.full(v);F=tuple(F[i] for i in Fidx)
        ZF=[h.lin(f,cols[2],u) for u in F]
        hist=Counter();allowed=Counter();total=0
        for pivots,ann in h.old.rref_rows(v,t,q):
            V=h.basis_from_ann(f,v,pivots,ann)
            images=[h.lin(f,c,u) for c in cols for u in V]
            L=h.canonical(f,images,w);rank=len(L)
            if rank==w:dimclosure=v
            else:
                stacked=[]
                for j in range(v):
                    stacked.append(tuple(x for c in cols for x in remainder(f,c[j],L)))
                dimclosure=v-f.rank(stacked)
            defect=dimclosure-len(V)
            Fintersection=len(V)+len(F)-f.rank(list(V)+list(F))
            dim_relative=len(F)-(f.rank(list(L)+ZF)-rank)
            relative_defect=dim_relative-Fintersection
            assert defect>=0 and relative_defect>=0
            hist[(defect,relative_defect)]+=1
            if defect==0 and relative_defect>0 and witness is None:
                for ui,u in zip(Fidx,F):
                    if not any(remainder(f,h.lin(f,cols[2],u),L)) and f.rank(list(V)+[u])>len(V):
                        witness=dict(q=q,s=s,annihilator_rows=ann,basis_labels=mbasis(s),
                                     witness_basis_index=ui,witness_label=mbasis(s)[ui],
                                     closure_defect=defect,relative_normal_colon_defect=relative_defect)
                        break
            if rank==w:
                assert defect==t
                for r in [0,1,2]:
                    if r<=v-t and all(not ann[i][j] for i in range(t) for j in range(r)):allowed[r]+=1
            total+=1;cases+=1
        for r,count in allowed.items():
            assert count<=h.old.gaussian(v-r,t,q)
            if s:
                H=s*(s+1)*(2*s+7)//6;S=H+v;M=t+2;A=S-r+2
                old=f.q**(3*(M-t))*h.old.helpers.u_nil(S-r,H+M,H+t,q)
                target=f.q**(3*M)*h.old.helpers.u_nil(S-r,H+M,H,q)
                actual=Fraction(count*q**(3*t)*old,target)
                exp=3*t-A*t
                scale=Fraction(q**max(exp,0),q**max(-exp,0))
                predicted=count*scale*Ah(q,H+t,M-t)/Ah(q,H,M)
                assert actual==predicted
                # The rank-independent exponent after the Gaussian upper bound.
                assert t*(v-r-t)+3*t-A*t==-t*H+t-t*t
                weight_checks+=1
        reports.append(dict(q=q,s=s,codimension_in_target_head=t,total_subspaces=total,
                            closed_target_predecessor_counts=dict(allowed),
                            defect_histogram={f'closure={x},relative={y}':z for (x,y),z in sorted(hist.items())},status='PASS'))
        print('closure fibers PASS',q,s,t,total,dict(allowed),flush=True)
    assert witness is not None
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),actual_submodule_cases=cases,
                exact_weighted_fiber_checks=weight_checks,cases=reports,
                weak_full_does_not_imply_relative_condition=witness,
                scope='Exact finite colon and Grassmann controls in actual M3. No extrapolation to asymptotic probabilities; those are separate general proofs.')
    (ROOT/'closure_fiber_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()

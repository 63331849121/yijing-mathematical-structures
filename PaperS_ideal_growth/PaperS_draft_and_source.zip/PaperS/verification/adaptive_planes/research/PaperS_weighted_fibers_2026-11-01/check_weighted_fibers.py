"""Enumerate actual recovery fibers and compute generators via Koszul homology.

Finite cases include nonhomogeneous predecessors. Exhaustive and sampled
families are labeled separately. No asymptotic conclusion is inferred from
the data; the companion proof establishes the general family inequality.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations,product
from pathlib import Path
import importlib.util
import json
import random
import time

ROOT=Path(__file__).parent
PREV=ROOT.parent/'PaperS_locality_rate_extension_2026-11-01'
spec=importlib.util.spec_from_file_location('actual_general_module',PREV/'check_higher_rank_and_twist.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
Field,basis,multiply,apply,units=a.Field,a.basis,a.multiply,a.apply,a.units


def plane(row):return row[:2]==(0,1) and all(x==0 for x in row[4:])


def quotient_model(d,q,s,r):
    f=Field(q)
    labels=tuple(row for t in range(r+1) for row in basis(d,t) if t<s or plane(row))
    idx={v:i for i,v in enumerate(labels)};size=len(labels);actions=[]
    for axis in range(d):
        cols=[]
        for row in labels:
            t=sum(row[2:]);out=[0]*size
            if t<r:
                local=multiply(d,t,axis,q)[basis(d,t).index(row)]
                for coef,target in zip(local,basis(d,t+1)):
                    if coef and target in idx:out[idx[target]]=coef
            cols.append(tuple(out))
        actions.append(tuple(cols))
    heads={pair:units(size,[idx[pair+(0,)*d]])[0] for pair in combinations(range(d),2)}
    soc=[idx[row] for row in basis(d,s-1) if not plane(row)]
    top=[idx[row] for row in basis(d,r) if plane(row)]
    return labels,actions,heads,soc,top


def generator_number(f,d,actions,heads):
    L=len(actions[0]);cols=[]
    for i,j in combinations(range(d),2):
        for w in units(L):
            out=[0]*(d*L);iw,jw=apply(f,actions[i],w),apply(f,actions[j],w)
            for z in range(L):out[j*L+z]=iw[z];out[i*L+z]=f.neg(jw[z])
            cols.append(tuple(out))
    for i,j,k in combinations(range(d),3):
        out=[0]*(d*L)
        for block,sign,pair in [(i,1,(j,k)),(j,-1,(i,k)),(k,1,(i,j))]:
            for z,v in enumerate(heads[pair]):out[block*L+z]=v if sign==1 else f.neg(v)
        cols.append(tuple(out))
    return (d-1)*L+d*(d-1)//2-f.rank(cols)


def predecessor(f,actions,heads,soc,top,A):
    L=len(actions[0]);kept=[i for i in range(L) if i not in top];idx={z:i for i,z in enumerate(kept)}
    def reduce(v):
        out=[v[i] for i in kept]
        for col,t in enumerate(top):
            coef=v[t]
            if coef:
                for row,z in enumerate(soc):out[idx[z]]=f.add(out[idx[z]],f.neg(f.mul(coef,A[col][row])))
        return tuple(out)
    smaller=[tuple(reduce(cols[i]) for i in kept) for cols in actions]
    smallheads={p:reduce(v) for p,v in heads.items()}
    return smaller,smallheads


def rank_count(q,v,S,b):
    return a.h.old.gaussian(v,b,q)*a.h.old.gaussian(S,b,q)*a.h.old.helpers.gl(b,q)


def main():
    start=time.monotonic();rng=random.Random(20261102);reports=[];total=0
    cases=[(3,2,1,1,True),(3,3,1,1,True),(3,4,1,1,True),
           (3,2,1,2,True),(4,2,1,1,True),
           (3,2,2,2,False),(5,2,1,1,False),(5,3,1,2,False)]
    for d,q,s,r,exhaustive in cases:
        f=Field(q);labels,actions,heads,soc,top=quotient_model(d,q,s,r)
        S,v=len(soc),len(top);gout=generator_number(f,d,actions,heads)
        assert gout==len(basis(d,s))+(r+1-s)
        for z in soc:
            assert all(not any(c[z]) for c in actions)
        if exhaustive:flats=product(range(q),repeat=S*v)
        else:
            sample=[(0,)*(S*v)]
            for b in range(min(S,v)):
                m=[0]*(S*v);m[b*S+b]=1;sample.append(tuple(m))
            sample.extend(tuple(rng.randrange(q) for _ in range(S*v)) for _ in range(48))
            flats=sample
        histogram=Counter();rankhist=Counter();normalized=Fraction(0);checked=0
        m=v+S+2
        for flat in flats:
            A=tuple(tuple(flat[j*S+i] for i in range(S)) for j in range(v))
            rank=f.rank(A)
            small,smallheads=predecessor(f,actions,heads,soc,top,A)
            g=generator_number(f,d,small,smallheads)
            assert g<=gout-1-rank,(d,q,s,r,gout,g,rank)
            histogram[g]+=1;rankhist[rank]+=1;checked+=1;total+=1
            normalized+=Fraction(1,q**((gout-1-g)*m))
        assert histogram[gout-1]>=1
        bound=sum((Fraction(rank_count(q,v,S,b),q**(b*m)) for b in range(min(v,S)+1)),Fraction(0))
        if exhaustive:
            assert checked==q**(S*v)
            assert all(rankhist[b]==rank_count(q,v,S,b) for b in range(min(v,S)+1))
            assert 1<=normalized<=bound
        reports.append(dict(d=d,q=q,s=s,r=r,mode='exhaustive' if exhaustive else 'deterministic_sample',
                            raw_fiber_exponent=S*v,full_fiber_size=str(q**(S*v)),predecessors_checked=checked,
                            output_generators=gout,predecessor_generator_histogram=dict(histogram),
                            parameter_rank_histogram=dict(rankhist),weight_parameter=m,
                            normalized_weighted_sum=str(normalized) if exhaustive else None,
                            exact_rank_bound=str(bound),status='PASS'))
        print('weighted fiber PASS',d,q,s,r,checked,flush=True)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),actual_predecessors_checked=total,cases=reports,
                scope='Full recovery fibers in designated small cases and labeled samples in larger actual modules. Generator counts computed from Koszul homology and the Jacobi presentation, independently of the proved rank inequality.')
    (ROOT/'weighted_fiber_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()

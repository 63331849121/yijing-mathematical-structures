"""Exact binary evaluation certificates for the invariant counterfamily."""
from itertools import product
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('actual_md',ROOT.parent/'PaperS_locality_rate_extension_2026-11-01'/'check_higher_rank_and_twist.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)


def rank(columns):
    piv={}
    for v in columns:
        while v:
            p=v.bit_length()-1
            if p in piv:v^=piv[p]
            else:piv[p]=v;break
    return len(piv)


def kernel(columns):
    piv={};null=[]
    for i,v in enumerate(columns):
        comb=1<<i
        while v:
            p=v.bit_length()-1
            if p in piv:v^=piv[p][0];comb^=piv[p][1]
            else:piv[p]=(v,comb);break
        if not v:null.append(comb)
    return null


def apply(columns,v):
    out=0
    while v:
        bit=v&-v;i=bit.bit_length()-1;out^=columns[i];v^=bit
    return out


def evaluation(d,s):
    points=[p for p in product([0,1],repeat=d) if any(p)];cols=[]
    for row in a.basis(d,s):
        i,j=row[:2];out=0
        for z,p in enumerate(points):
            if any(power and not x for power,x in zip(row[2:],p)):continue
            if p[i]:out^=1<<(z*d+j)
            if p[j]:out^=1<<(z*d+i)
        cols.append(out)
    return cols


def main():
    reports=[]
    for d,s in [(3,3),(3,4),(4,4),(5,5)]:
        B=a.basis(d,s);C=a.basis(d,s+1);ev=evaluation(d,s);evnext=evaluation(d,s+1)
        V=kernel(ev);mul=[]
        for axis in range(d):
            cols=[]
            for c in a.multiply(d,s,axis,2):cols.append(sum(x<<i for i,x in enumerate(c)))
            mul.append(cols)
        images=[apply(op,v) for op in mul for v in V]
        image_rank=rank(images);t=(d-1)*(2**d-1)
        assert rank(ev)==rank(evnext)==t
        assert image_rank==len(C)-t
        assert all(apply(evnext,v)==0 for v in images)
        F=[i for i,row in enumerate(B) if not (row[:2]==(0,1) and all(x==0 for x in row[4:]))]
        defect=rank([ev[i] for i in F])-rank([apply(evnext,mul[2][i]) for i in F])
        assert defect>0
        # Explicit f_p X1^(s-d)c13 witness.
        indices={v:i for i,v in enumerate(B)};u=0
        for choices in product([0,1],repeat=d-1):
            powers=[s-d+1]+[0]*(d-1)
            for axis,choice in enumerate(choices,1):
                if choice:powers[axis]+=1
                else:powers[0]+=1
            u^=1<<indices[(0,2)+tuple(powers)]
        assert apply(ev,u)!=0 and apply(evnext,apply(mul[2],u))==0
        reports.append(dict(d=d,s=s,head_layer=len(B),projective_fiber_length=t,
                            evaluation_kernel_dimension=len(V),next_kernel_dimension=len(C)-t,
                            multiplication_image_rank=image_rank,relative_colon_defect=defect,
                            explicit_witness_verified=True,status='PASS'))
    result=dict(status='PASS',cases=reports,
                scope='Exact actual Md evaluation, multiplication and witness certificates. Source-frame invariance and the infinite family are proved in the companion note, not inferred from finitely many degrees.')
    (ROOT/'invariant_frame_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()

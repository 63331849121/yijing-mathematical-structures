"""Check the new normal connecting-map injection in actual M3 subspaces."""
from collections import Counter
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('actual_plane_helpers',ROOT.parent/'PaperS_core_weight_comparison_2026-11-01'/'check_planar_transport.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
h=p.h;Field=p.Field;mbasis=p.mbasis


def main():
    start=time.monotonic();f=Field(2);s=1;v=len(mbasis(s));hist=Counter();total=0
    Fidx=[i for i,row in enumerate(mbasis(s)) if not (row[0]==0 and row[3]==0)]
    F=tuple(h.full(v)[i] for i in Fidx)
    for pivots,ann in h.old.rref_rows(v,1,2):
        V=h.basis_from_ann(f,v,pivots,ann)
        spaces={0:(),1:V,2:h.full(len(mbasis(2))),3:h.full(len(mbasis(3))),4:h.full(len(mbasis(4)))}
        L=h.canonical(f,[h.lin(f,p.mult_columns(1,i,f),u) for i in range(3) for u in V],len(mbasis(2)))
        ZF=[h.lin(f,p.mult_columns(1,2,f),u) for u in F]
        rel=len(F)-(f.rank(list(L)+ZF)-len(L))-(len(V)+len(F)-f.rank(list(V)+list(F)))
        J={d:(h.full(d+1) if len(spaces[d])==len(mbasis(d)) else h.canonical(f,[p.image_plane(f,d,u) for u in spaces[d]],d+1)) for d in spaces}
        Jplus={0:()}
        for d in range(1,5):Jplus[d]=h.canonical(f,[h.lin(f,p.pmult(d-1,i),u) for i in range(2) for u in J[d-1]],d+1)
        Iplus={d:p.preimage(f,d,spaces[d],Jplus[d]) for d in spaces}
        Kspace={d:p.preimage(f,d,h.full(len(mbasis(d))),Jplus[d]) for d in spaces}
        kerneldim=Hdim=0
        for d in range(3):
            normal=[h.lin(f,p.mult_columns(d,2,f),u) for u in Kspace[d]]
            mnext=h.canonical(f,[h.lin(f,p.mult_columns(d,i,f),u) for i in range(3) for u in Iplus[d]],len(mbasis(d+1)))
            kernel=len(Kspace[d])-(f.rank(list(mnext)+normal)-len(mnext))-len(Iplus[d])
            domain=len(Kspace[d])-(f.rank(list(Iplus[d+1])+normal)-len(Iplus[d+1]))-len(Iplus[d])
            assert 0<=kernel<=domain
            kerneldim+=kernel;Hdim+=domain
        if rel==0:assert kerneldim==0
        hist[(rel,Hdim,kerneldim)]+=1;total+=1
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),actual_input_subspaces=total,
                normal_map_histogram={f'input_relative_defect={r},domain={d},kernel={k}':v for (r,d,k),v in sorted(hist.items())},
                scope='All 255 codimension-one degree-one subspaces in actual M3 over F2, followed by one plane-padding step; checks the sufficient-condition normal map, not an asymptotic inference.')
    (ROOT/'relative_map_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()

"""Compute exact planar Hom spaces from intertwining equations."""
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('field_helpers',ROOT/'check_weighted_fibers.py')
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)


def main():
    rows=[];total=0
    for q in [2,3,4]:
        f=w.Field(q)
        for r in range(4):
            for j in range(1,5):
                T=[(a,d-a) for d in range(r,r+j) for a in range(d,-1,-1)]
                indices={v:i for i,v in enumerate(T)}
                for L in range(1,7):
                    unknown=len(T)*L;equations=[]
                    for b,(x,y) in enumerate(T):
                        for axis in range(2):
                            target=indices.get((x+int(axis==0),y+int(axis==1)))
                            for z in range(L):
                                row=[0]*unknown
                                if axis==0 and z>0:row[b*L+z-1]=1
                                if target is not None:row[target*L+z]=f.add(row[target*L+z],f.neg(1))
                                equations.append(tuple(row))
                    dimension=unknown-f.rank(equations)
                    assert dimension==r+min(j,L),(q,r,j,L,dimension)
                    rows.append(dict(q=q,r=r,j=j,line_length=L,Hom_dimension=dimension,status='PASS'));total+=1
    result=dict(status='PASS',exact_intertwiner_spaces=total,
                largest_line_length=6,cases=rows,
                scope='Exact finite linear systems for module intertwiners; companion proof establishes the all-parameter formula.')
    (ROOT/'line_hom_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},ensure_ascii=False,indent=2))


if __name__=='__main__':main()

"""Larger explicit monomial stress cases for the OPEN u+b cocyclic bound.

Colength and generator-increment calculations are compared independently.
No finite pass proves the arbitrary-ideal or arbitrary-module statement.
"""
from pathlib import Path
import importlib.util
import random
import time
import json

ROOT=Path(__file__).parent
OLD=ROOT.parent/'PaperS_width_sectors_2026-11-02'
spec=importlib.util.spec_from_file_location('prod',OLD/'probe_cocyclic_product_bound.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)

def col(J):return sum(J[i][0]*(J[i+1][1]-J[i][1]) for i in range(len(J)-1))
def order(J):return min(x+y for x,y in J)
def tiny(m):
    aa=[5*m,4*m]+list(range(4*m-1,3*m+3,-1))+[m,0]
    return tuple(zip(aa,reversed(aa)))

def main():
    start=time.monotonic();rng=random.Random(2026110248)
    sources=[tiny(m) for m in [10,20,40,80,120]]
    for A in [2,3,5,8]:
        for r in [3,10,25]:sources.append(tuple((A*(r-i),A*i) for i in range(r+1)))
    for _ in range(18):
        A=rng.randrange(10,90);B=rng.randrange(10,90)
        sources.append(p.minimal([(A,0),(0,B)]+[(rng.randrange(1,A),rng.randrange(1,B)) for i in range(rng.randrange(3,20))]))
    targets=[((A,0),(0,B)) for A in [2,4,8,16,32] for B in [A,3*A]]
    targets+=[tiny(m) for m in [10,20,40]]
    for _ in range(12):
        A=rng.randrange(5,65);B=rng.randrange(5,65)
        targets.append(p.minimal([(A,0),(0,B)]+[(rng.randrange(1,A),rng.randrange(1,B)) for i in range(rng.randrange(2,12))]))
    checks=0;bad=[];worst=None
    for si,I in enumerate(sources):
        a=order(I);b=a+1-len(I)
        for qi,Q in enumerate(targets):
            u=col(Q)-1;J=I;QI=p.product_ideal(Q,I);initial=col(QI)-col(I);dh=0
            for j in range(1,min(a+order(Q)+4,100)+1):
                dh+=len(QI)-len(J);J=p.c.times_n(J);QI=p.c.times_n(QI)
                direct=col(QI)-col(J)-initial;assert dh==direct
                loss=len(J)-len(I)-dh;checks+=1
                row=dict(source=si,target=qi,j=j,source_order=a,source_mu=len(I),source_defect=b,
                         target_length=u+1,effective_loss=loss,budget=u+b)
                if worst is None or loss*worst['budget']>worst['effective_loss']*(u+b):worst=row
                if loss>u+b:bad.append(dict(**row,I=I,Q=Q));break
            if bad:break
        if bad:break
        if (si+1)%10==0:print(json.dumps(dict(sources_completed=si+1,comparisons=checks)),flush=True)
    result=dict(status='COUNTEREXAMPLE_FOUND' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',
        seconds=round(time.monotonic()-start,3),sources=len(sources),cocyclic_targets=len(targets),
        exact_comparisons=checks,worst_normalized_case=worst,counterexamples=bad,
        mathematical_status='The u+b cocyclic inequality remains OPEN. This probe stresses large tiny-square/product-collapse and nonradial targets; it is not a proof.')
    (ROOT/'hard_cocyclic_probe.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

"""Exact dual-identity and finite Rees-kernel controls.

A finite kernel is only a lower bound for the eventual H0 degree-zero
part. Finite no-counterexample results never certify the open torsion bound.
"""
from pathlib import Path
import importlib.util
import random
import time
import json

ROOT=Path(__file__).parent
OLD=ROOT.parent/'PaperS_width_sectors_2026-11-02'
spec=importlib.util.spec_from_file_location('ns',OLD/'probe_nonsplit_commuting_targets.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
w=p.w;z=p.z;h=p.h

def power(op,a,col):
    for _ in range(a):col=h.linear(op,col)
    return col

def coords(v,Q):
    v=h.reduce(v,Q['relations']);out=0
    for i,j in enumerate(Q['free']):out|=((v>>j)&1)<<i
    return out

def tensor(J,D):
    n=D['length'];v=len(J);X,Y=D['actions'];rel=[]
    for i in range(v-1):
        dx=J[i][0]-J[i+1][0];dy=J[i+1][1]-J[i][1]
        for j in range(n):
            rel.append((power(Y,dy,1<<j)<<(i*n))^(power(X,dx,1<<j)<<((i+1)*n)))
    rel=h.canonical(rel);piv={(v&-v).bit_length()-1 for v in rel}
    free=tuple(j for j in range(n*v) if j not in piv)
    return dict(J=J,D=D,relations=rel,free=free,dim=len(free))

def source_map(Q,T,a,b):
    D=Q['D'];n=D['length'];X,Y=D['actions'];out=[]
    for f in Q['free']:
        gi,di=divmod(f,n);xx=Q['J'][gi][0]+a;yy=Q['J'][gi][1]+b
        choices=[i for i,(x,y) in enumerate(T['J']) if x<=xx and y<=yy]
        assert choices
        vals=[]
        for i in choices[:2]:
            gx,gy=T['J'][i];value=power(X,xx-gx,power(Y,yy-gy,1<<di))<<(i*n)
            vals.append(coords(value,T))
        assert len(set(vals))==1
        out.append(vals[0])
    # The original tensor relations must descend under the same source map.
    return tuple(out)

def finite_torsion(Q,N):
    Jj=Q['J']
    for _ in range(N):Jj=w.c.times_n(Jj)
    T=tensor(Jj,Q['D'])
    maps=[source_map(Q,T,a,N-a) for a in range(N+1)]
    cols=[sum(op[j]<<(i*T['dim']) for i,op in enumerate(maps)) for j in range(Q['dim'])]
    return Q['dim']-len(h.canonical(cols))

def quotient_target(J):
    A=max(x for x,y in J);B=max(y for x,y in J)
    labels=[(x,y) for y in range(B) for x in range(A) if not any(gx<=x and gy<=y for gx,gy in J)]
    idx={m:i for i,m in enumerate(labels)}
    ops=tuple(tuple(1<<idx[b] if (b:=(x+int(axis==0),y+int(axis==1))) in idx else 0 for x,y in labels) for axis in range(2))
    return z.module(ops)

def hom_modules(L,A):
    n=L['length'];m=A['length'];cols=[]
    for i in range(n):
        for j in range(m):
            image=0
            for axis in range(2):
                local=A['actions'][axis][j]<<(i*m)
                for k in range(n):
                    if (L['actions'][axis][k]>>i)&1:local^=1<<(k*m+j)
                image|=local<<(axis*n*m)
            cols.append(image)
    return n*m-len(h.canonical(cols))

def main():
    start=time.monotonic();rng=random.Random(2026110245)
    w.DEG=64;w.MOD=(1<<64)|0x1B;w.MASK=(1<<64)-1;w.verify_field()
    targets=[p.target(shape,rng) for shape in [(5,3,1),(7,4,2),(4,4,3,1)] for _ in range(6)]
    loewy,uniform,_=p.p.targets();targets+=loewy[::12]+uniform[:3]
    ideals=[w.c.ideal_of(part) for length in range(1,8) for part in w.c.partitions(length)]
    identities=0;widths=0;tensors=0;torsions=0;bad=[];rows=[]
    for L in targets:
        n=L['length'];D=z.module(tuple(p.dual.transpose(op) for op in L['actions']))
        radical=h.canonical(D['actions'][0]+D['actions'][1])
        for ell in [L['actions'][0],L['actions'][1],tuple(x^y for x,y in zip(*L['actions']))]:
            soc=h.ker(tuple(1<<i for i in range(n)),[x|(y<<n) for x,y in zip(*L['actions'])])
            image=h.canonical(ell);left=len(soc)+len(image)-len(h.canonical(soc+image))
            ellD=p.dual.transpose(ell);im=h.canonical(ellD)
            right=len(im)-len(h.canonical([h.linear(op,v) for op in D['actions'] for v in im]))
            assert left==right;widths+=1
        for J in ideals[::3]:
            Q=tensor(J,D);hj=z.hom(J,L);assert Q['dim']==hj;tensors+=1
            if L['length']<=16:
                assert hj==L['length']+hom_modules(L,quotient_target(J));identities+=1
            if (L['socle']+L['top']<L['length']) and len(J)<=5:
                vals=[finite_torsion(Q,N) for N in [1,2,4]]
                assert vals==sorted(vals)
                a=min(sum(g) for g in J);budget=L['length']-L['socle']+a*L['width']
                torsions+=len(vals)
                # Only probe targets with no split semisimple summand.
                rad=h.canonical(L['actions'][0]+L['actions'][1])
                soc=h.ker(tuple(1<<i for i in range(n)),[x|(y<<n) for x,y in zip(*L['actions'])])
                ss=len(soc)-(len(rad)+len(soc)-len(h.canonical(rad+soc)))
                if not ss and vals[-1]>budget:bad.append(dict(J=J,target=L,finite_kernels=vals,budget=budget))
    L=z.module(((2,0,0),(4,0,0)));D=z.module(tuple(p.dual.transpose(op) for op in L['actions']))
    for r in [1,2,3,5,8,12]:
        J=tuple(sorted([(3*(r-i),3*i) for i in range(r+1)]+[(3*(r-i)-1,3*i+2) for i in range(r)],reverse=True))
        Q=tensor(J,D);J1=w.c.times_n(J)
        assert z.hom(J,L)==5*r+3 and z.hom(J1,L)==4*r+4
        vals=[finite_torsion(Q,N) for N in [1,2,4]]
        assert vals[-1]>=r+1
        rows.append(dict(r=r,initial_hom=5*r+3,next_hom=4*r+4,finite_H0_kernels=vals))
    result=dict(status='PASS' if not bad else 'COUNTEREXAMPLE_FOUND',seconds=round(time.monotonic()-start,3),
        targets=len(targets),dual_quotient_hom_identities=identities,dual_width_identities=widths,
        tensor_presentation_identities=tensors,finite_Rees_kernel_checks=torsions,
        explicit_baseline_counterfamily=rows,open_torsion_bound_counterexamples=bad,
        mathematical_status='Dual identities and explicit baseline counterfamily have general proofs. The exploratory isolated u+a*w Rees-torsion bound is FALSE by the later complete-intersection counterfamily; these finite passes are superseded as evidence for that bound. The compensated Hom comparison remains OPEN.')
    (ROOT/'dual_and_rees_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

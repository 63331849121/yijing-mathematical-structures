"""Exact controls of full Rees cancellation and the dual-radial zero-cost class."""
from pathlib import Path
import importlib.util
from math import comb
import random
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('hard',ROOT/'probe_hard_cocyclic_losses.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
spec=importlib.util.spec_from_file_location('dual_controls',ROOT/'check_dual_and_rees_controls.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def main():
    start=time.monotonic();ci=0;radial=0
    for A in [2,3,4,6,10]:
        for r in [1,3,10,30]:
            I=tuple((A*(r-i),A*i) for i in range(r+1));Q=((A,0),(0,A))
            J=I;initial=A*A*(r+1);H0=(r+1)*comb(A,2)
            for j in range(A+5):
                actual=p.col(p.p.product_ideal(Q,J))-p.col(J)
                C=comb(max(A-j,0),2);Hj=(r+1)*C
                assert actual==A*(A*r+j)+A*(A+1)//2+C
                positive=r*sum(min(j,k) for k in range(1,A))
                assert actual-initial==j*A+positive+Hj-H0
                loss=len(J)-len(I)-(actual-initial);assert loss<=r*(A-1)
                if j<=A-1:assert actual-initial==comb(j+1,2)
                J=p.p.c.times_n(J);ci+=1
    d=c.p.dual;rng=random.Random(2026110249)
    for a,N in [(2,5),(3,6)]:
        mon=[m for m in d.monomials(N) if sum(m)>=a]
        for case in range(8):
            polys=[]
            for k in range(2+case%3):
                row=[m for m in mon if rng.randrange(5)==0]
                if not any(sum(m)==a for m in row):row.append((a,0))
                polys.append(tuple(sorted(set(row))))
            qs=[d.quotient(polys,N,j) for j in range(7)]
            for A in [1,2,3,4]:
                labels=d.monomials(A);idx={m:i for i,m in enumerate(labels)}
                ops=tuple(tuple(1<<idx[b] if (b:=(x+int(axis==0),y+int(axis==1))) in idx else 0 for x,y in labels) for axis in range(2))
                L=c.z.module(tuple(d.transpose(op) for op in ops));assert L['socle']==1
                initial=d.hom_ideal(qs[0],L)
                for j in [0,1,2,3]:
                    actual=d.hom_ideal(qs[j],L)
                    assert actual==sum(qs[i]['mu'] for i in range(j,j+A))
                    assert actual-initial>=qs[j]['mu']-qs[0]['mu'];radial+=1
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
                complete_intersection_full_cancellation_cases=ci,nonhomogeneous_dual_radial_identities=radial,
                scope='Independent exact controls for proved family identities. The compensated general Hom comparison remains OPEN.')
    (ROOT/'compensated_rees_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

"""Static artifact audit plus exact rational exponent bookkeeping.

This is not mathematical certification of a theorem or an open hypothesis.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import ast
import json
import re

ROOT=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
proofs={}
for path in sorted(ROOT.glob('*.tex')):
    text=path.read_text(encoding='utf-8')
    code='\n'.join(re.split(r'(?<!\\)%',s)[0] for s in text.splitlines())
    stack=[]
    for op,env in re.findall(r'\\(begin|end)\{([^}]+)\}',code):
        if op=='begin':stack.append(env)
        else:assert stack and stack.pop()==env,path.name
    assert not stack,path.name
    balance=0
    for char in re.sub(r'\\[{}]','',code):
        balance+=(char=='{')-(char=='}');assert balance>=0,path.name
    assert balance==0,path.name
    labels=re.findall(r'\\label\{([^}]+)\}',code)
    refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',code)
    assert len(labels)==len(set(labels)) and set(refs)<=set(labels),path.name
    proofs[path.name]=dict(static_status='PASS',sha256=sha(path),
                          review='Proof draft or explicitly conditional deduction; expert review pending.')
for path in ROOT.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
data=json.loads((ROOT/'shadow_and_width_extension_results.json').read_text(encoding='utf-8'))
assert data['status']=='PASS'
dual=json.loads((ROOT/'dual_and_rees_controls.json').read_text(encoding='utf-8'))
assert dual['status']=='PASS'
overcount=json.loads((ROOT/'rees_overcount_counter_controls.json').read_text(encoding='utf-8'))
assert overcount['status']=='PASS'
socle_probe=json.loads((ROOT/'reduced_socle_width_probe.json').read_text(encoding='utf-8'))
baseline=json.loads((ROOT/'baseline_hom_probe_results.json').read_text(encoding='utf-8'))
assert baseline['status']=='COUNTEREXAMPLE_FOUND'
new_controls={}
for filename in ['compensated_rees_controls.json','adaptive_plane_controls.json',
                 'chain_interpolation_controls.json','filtered_head_and_recovery_controls.json',
                 'abstract_betti_packet_controls.json']:
    result=json.loads((ROOT/filename).read_text(encoding='utf-8'));assert result['status']=='PASS'
    new_controls[filename]=dict(sha256=sha(ROOT/filename),data=result)
hard_probe=json.loads((ROOT/'hard_cocyclic_probe.json').read_text(encoding='utf-8'))
exponents=[]
for d in [3,4,5,6,7,8]:
    a=1-F(1,d);eta=1-F(2,d);gamma=eta+F(2,d*(d-1));beta=a/2+gamma
    overshoot=max(beta-1,F(0))-F(1,d);away=2*a*a-a/2-1
    if d in [5,6]:assert overshoot<0 and away<0
    exponents.append(dict(d=d,alpha=str(a),eta=str(eta),gamma=str(gamma),
                          beta=str(beta),overshoot=str(overshoot),away_entropy=str(away)))
status=dict(status='PASS',stage=13,date='2026-11-02',proofs=proofs,
    exact_control_report=dict(file='shadow_and_width_extension_results.json',sha256=sha(ROOT/'shadow_and_width_extension_results.json'),data=data),
    dual_and_rees_controls=dict(file='dual_and_rees_controls.json',sha256=sha(ROOT/'dual_and_rees_controls.json'),data=dual),
    baseline_growth_proposal='FALSE; explicit unbounded Loewy-two counterfamily archived',
    isolated_rees_torsion_upper_bound='FALSE; Q=(x^A,y^A), I=Q^r counterfamily',
    compensated_rees_hilbert_comparison='OPEN; must retain positive depth-one Hilbert increments',
    rees_overcount_counter_controls=overcount,
    reduced_socle_width_proposal=dict(status='OPEN',finite_probe=socle_probe),
    exponents=exponents,canonical_manuscript_edited=False,canonical_manuscript_compiled=False,
    general_weak_hom_status='OPEN; no longer required by the adaptive rank-five/six proof draft',
    global_rank_five_six_rate='NEW GENERAL PROOF DRAFT COMPLETE via near-radial adaptive planes; independent review pending; no canonical merge',
    adaptive_plane_status='General universal and near-extremal projection proof drafts, including arbitrary-length chains',
    new_exact_controls=new_controls,
    hard_cocyclic_probe=dict(status=hard_probe['status'],mathematical_status='OPEN; finite falsification only',data=hard_probe),
    higher_rank_bottleneck='d>=7: natural-depth away entropy; rank-seven margin +2/49. All-rank small-away sector cutoff theta_d=2d/(3d-4); no all-fixed-rank closure claimed.',
    new_proof_drafts=[
      'Universal weaker near-extremal fixed-plane width for actual fixed torsion-free sources, including nonhomogeneous and nonclosed cores.',
      'Nonsplit extension width inequality w(W)<=w(A)+2*soc(V).',
      'Weighted shadow deficit, high-degree head and generator budgets.',
      'Uniform hypersurface whole-quotient entropy with explicit growing-rank/degree dependence; not a relative-tail count.'
      ,'Exact dual and Rees reformulations; baseline growth and isolated torsion shortcuts explicitly refuted.'
      ,'Reversible polynomial-plane interpolation in every rank d>=4, with universal head O(h^(2/(d-1))*polylog h).'
      ,'Filtered near-extremal adaptive head O(h^(2/d)*log(h)^2); crude packet cost O(n log n).'
      ,'Complete weighted rank-five/six recovery proof draft bypassing the general Hom conjecture.'
      ,'Abstract Betti-controlled packet theorem over arbitrary Noetherian local rings with finite residue field; nonregular exhaustive finite control.'
    ],no_claims=['Finite controls are not proof of unrestricted statements.',
                 'New rank-five/six result is a proof draft, not independent professional certification.',
                 'The general higher-Loewy Hom comparison remains open.',
                 'No all-fixed-rank rate theorem.',
                 'No edits or compilation of canonical G or S.',
                 'No priority claim for classical ingredients.'])
(ROOT/'research_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS',proof_drafts=len(proofs),controls=data['status'],
                     new_exact_reports=len(new_controls),weak_hom='OPEN',
                     global_rank_five_six='NEW GENERAL PROOF DRAFT; independent review pending'),indent=2))

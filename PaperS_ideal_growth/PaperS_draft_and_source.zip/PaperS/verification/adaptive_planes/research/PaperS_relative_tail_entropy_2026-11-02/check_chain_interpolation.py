"""Symbolic finite-field checks of the arbitrary-length interpolation chain."""
from pathlib import Path
import importlib.util
from itertools import product
import random
import time
import json

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('actual',ROOT/'check_adaptive_polynomial_planes.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def main():
    start=time.monotonic();rng=random.Random(2026110253);checks=0;models=[]
    for q in [2,3,4]:
        field=c.a.Field(q)
        def add(*polys):
            out={}
            for P in polys:
                for m,a in P.items():
                    value=field.add(out.get(m,0),a)
                    if value:out[m]=value
                    else:out.pop(m,None)
            return out
        def neg(P):return {m:field.neg(a) for m,a in P.items()}
        def mul(P,Q):
            out={}
            for x,a in P.items():
                for y,b in Q.items():
                    m=(x[0]+y[0],x[1]+y[1]);value=field.add(out.get(m,0),field.mul(a,b))
                    if value:out[m]=value
                    else:out.pop(m,None)
            return out
        D=4
        for b in [2,3,4]:
            # Distinct coefficient vectors, with quadratic and higher terms.
            codes=rng.sample(range(q**(D-1)),b);fx=[];fy=[]
            for code in codes:
                digits=[]
                for k in range(D-1):digits.append(code%q);code//=q
                fx.append({(k+2,0):a for k,a in enumerate(digits) if a})
                fy.append({(0,k+2):a for k,a in enumerate(digits) if a})
            for s in range(1,6):
                indices=list(product(range(b),repeat=s))
                chosen=indices if len(indices)<=16 else rng.sample(indices,16)
                others=indices if len(indices)<=40 else rng.sample(indices,40)
                local=0
                for sel in chosen:
                    expectedX={(0,0):1};expectedY={(0,0):1}
                    for k in range(s):
                        for a in range(b):
                            if a!=sel[k]:
                                expectedX=mul(expectedX,add(fx[sel[k]],neg(fx[a])))
                                expectedY=mul(expectedY,add(fy[sel[k]],neg(fy[a])))
                    assert expectedX and expectedY
                    rx=min(x for x,y in expectedX);ry=min(y for x,y in expectedY)
                    assert rx==ry and rx<=s*(b-1)*D
                    for other in set(others+[sel]):
                        graph=[fx[other[0]]]+[add(fy[other[k-1]],fx[other[k]]) for k in range(1,s)]+[fy[other[-1]]]
                        TX={(0,0):1};TY={(0,0):1}
                        for k in range(s):
                            for a in range(b):
                                if a!=sel[k]:
                                    factor=add(graph[k],neg(fx[a]),neg(fy[sel[k-1]]) if k else {})
                                    TX=mul(TX,factor)
                        for k in range(s-1,-1,-1):
                            for a in range(b):
                                if a!=sel[k]:
                                    factor=add(graph[k+1],neg(fy[a]),neg(fx[sel[k+1]]) if k+1<s else {})
                                    TY=mul(TY,factor)
                        assert TX==(expectedX if other==sel else {})
                        assert TY==(expectedY if other==sel else {})
                        checks+=2;local+=2
                models.append(dict(q=q,indices=s,b=b,D=D,total_frames=b**s,
                                   symbolic_operator_checks=local,sampled=(len(chosen)<len(indices) or len(others)<len(indices))))
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
                finite_fields=[2,3,4],symbolic_operator_checks=checks,models=models,
                scope='Exact symbolic controls of the proved interpolation identities, including signs and extension-field coefficients. General theorem still requires proof review.')
    (ROOT/'chain_interpolation_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='models'},indent=2))

if __name__=='__main__':main()

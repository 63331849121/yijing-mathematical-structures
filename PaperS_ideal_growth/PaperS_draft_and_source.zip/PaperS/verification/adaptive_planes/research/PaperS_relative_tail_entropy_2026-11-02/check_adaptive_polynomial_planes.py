"""Exact checks of three-normal interpolation and actual Jacobi shears.

Binary finite controls; the general proof is separate and needs review.
"""
from pathlib import Path
import importlib.util
from itertools import product
import random
import json
import time

ROOT=Path(__file__).parent
OLD=ROOT.parent/'PaperS_width_sectors_2026-11-02'
spec=importlib.util.spec_from_file_location('core',OLD/'check_actual_core_width.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
h=c.h;a=h.a

def restrict(ops,space):
    space=h.canonical(space);piv=[(v&-v).bit_length()-1 for v in space]
    def coord(v):
        out=0
        for i,(row,p) in enumerate(zip(space,piv)):
            if (v>>p)&1:v^=row;out|=1<<i
        assert not v;return out
    return tuple(tuple(coord(h.linear(op,v)) for v in space) for op in ops)

def power(op,j,v):
    for _ in range(j):v=h.linear(op,v)
    return v

def poly(op,exponents,v):
    out=0
    for j in exponents:out^=power(op,j,v)
    return out

def inverse_rows(columns):
    piv={}
    for i,raw in enumerate(columns):
        v=raw;tag=1<<i
        while v:
            p=(v&-v).bit_length()-1
            if p in piv:v^=piv[p][0];tag^=piv[p][1]
            else:piv[p]=(v,tag);break
        assert v
    def solve(v):
        tag=0
        while v:
            p=(v&-v).bit_length()-1;assert p in piv
            row,t=piv[p];v^=row;tag^=t
        return tag
    return solve

def xor(A,B):return A.symmetric_difference(B)

def pmul(A,B,N):
    out=set()
    for x in A:
        for y in B:
            z=tuple(a+b for a,b in zip(x,y))
            if sum(z)<=N:
                if z in out:out.remove(z)
                else:out.add(z)
    return out

def actual_shears():
    rng=random.Random(2026110251);identities=0;rows=[]
    for d,N in [(5,2),(5,3),(6,2)]:
        labels,index,rawops=a.truncated(d,N,2);n=len(labels)
        ops=tuple(tuple(sum(v<<k for k,v in enumerate(col)) for col in op) for op in rawops)
        ambient=[(i,mon) for deg in range(1,N+2) for mon in a.mons(deg,d) for i in range(d)]
        idx={m:i for i,m in enumerate(ambient)}
        def addcoord(out,i,mon):
            if sum(mon)<=N+1:out^=1<<idx[i,mon]
            return out
        embeddings=[]
        for row in labels:
            i,j=row[:2];mon=row[2:];mi=tuple(v+int(k==i) for k,v in enumerate(mon));mj=tuple(v+int(k==j) for k,v in enumerate(mon))
            embeddings.append((1<<idx[j,mi])^(1<<idx[i,mj]))
        solve=inverse_rows(embeddings)
        maps=[]
        for fi,gj in [((2,),(2,)),((2,),(3,)),((2,3),(2,)),((),(2,3))]:
            pp=[set() for _ in range(d)];aa=[set() for _ in range(d)];bb=[set() for _ in range(d)]
            for e in fi:pp[2].add((e,)+(0,)*(d-1));aa[2].add((e-1,)+(0,)*(d-1))
            for e in gj:pp[3].add((0,e)+(0,)*(d-2));bb[3].add((0,e-1)+(0,)*(d-2))
            for e in gj:pp[4].add((e,)+(0,)*(d-1));aa[4].add((e-1,)+(0,)*(d-1))
            for e in fi:pp[4].add((0,e)+(0,)*(d-2));bb[4].add((0,e-1)+(0,)*(d-2))
            theta=[xor({tuple(int(k==i) for k in range(d))},pp[i]) for i in range(d)]
            def sub(mon):
                out={(0,)*d}
                for i,e in enumerate(mon):
                    for _ in range(e):out=pmul(out,theta[i],N+1)
                return out
            cols=[]
            for emb in embeddings:
                out=0;v=emb
                while v:
                    bit=v&-v;i,mon=ambient[bit.bit_length()-1];base=sub(mon)
                    for m in base:out=addcoord(out,i,m)
                    for coord,pol in [(0,aa[i]),(1,bb[i])]:
                        for m in pmul(base,pol,N+1):out=addcoord(out,coord,m)
                    v^=bit
                cols.append(solve(out))
            for i,col in enumerate(cols):assert h.linear(cols,col)==1<<i;identities+=1
            for axis,op in enumerate(ops):
                for i,col in enumerate(cols):
                    left=h.linear(cols,op[i]);right=h.linear(op,col)
                    if pp[axis]:
                        for mon in pp[axis]:
                            v=col
                            for k,e in enumerate(mon):v=power(ops[k],e,v)
                            right^=v
                    assert left==right;identities+=1
            # Use actual stable kernels, with the last degree included.
            top=[1<<i for i,row in enumerate(labels) if sum(row[2:])==N]
            for trial in range(6):
                candidates=[i for i,row in enumerate(labels) if 0<sum(row[2:])<N]
                rel=top+[sum((rng.randrange(5)==0)<<i for i in candidates) for _ in range(trial%3)]
                I=c.close(ops,rel);J=h.canonical(h.linear(cols,v) for v in I)
                assert len(I)==len(J)
                mi=h.canonical(h.linear(op,v) for op in ops for v in I)
                mj=h.canonical(h.linear(op,v) for op in ops for v in J)
                assert len(mi)==len(mj)
                assert len(c.close(ops,J))==len(J);identities+=3
            maps.append(dict(f=fi,g=gj,actual_dimension=n))
        rows.append(dict(d=d,cutoff=N,maps=maps))
    return rows,identities

def interpolation_controls():
    cases=[];checks=0
    pols=[(),(2,),(3,),(2,3)]
    for b,A,B in [(2,7,6),(3,9,8),(4,10,9)]:
        D=3;labels=[(i,j,x,y) for i in range(b) for j in range(b) for y in range(B) for x in range(A)]
        idx={m:i for i,m in enumerate(labels)};n=len(labels);ops=[]
        for axis in range(5):
            col=[]
            for i,j,x,y in labels:
                terms=[]
                if axis==0:terms=[(x+1,y)]
                elif axis==1:terms=[(x,y+1)]
                elif axis==2:terms=[(x+k,y) for k in pols[i]]
                elif axis==3:terms=[(x,y+k) for k in pols[j]]
                else:terms=[(x,y+k) for k in pols[i]]+[(x+k,y) for k in pols[j]]
                v=0
                for xx,yy in terms:
                    if (i,j,xx,yy) in idx:v^=1<<idx[i,j,xx,yy]
                col.append(v)
            ops.append(tuple(col))
        one=sum(1<<idx[i,j,0,0] for i in range(b) for j in range(b))
        E=c.close(ops,[one]);ee=restrict(ops,E);hhead=len(E)
        L=[]
        for i in range(b):
            for j in range(b):
                # Dual coordinate projection to each rectangle quotient.
                rows=[]
                for y in range(B):
                    for x in range(A):rows.append(sum(((row>>idx[i,j,x,y])&1)<<k for k,row in enumerate(E)))
                local=h.canonical(rows);assert len(local)==A*B;L.append(local)
        relation_dim=sum(map(len,L))-len(h.canonical([v for space in L for v in space]))
        assert relation_dim<=b*b*4*(b-1)**2*D*D
        assert A*B<=hhead/(b*b)+4*(b-1)**2*D*D
        dualops=tuple(tuple(sum(((op[k]>>i)&1)<<k for k in range(hhead)) for i in range(hhead)) for op in ee)
        for i,j in product(range(b),repeat=2):
            for other,space in enumerate(L):
                ii,jj=divmod(other,b)
                for raw in space[::max(1,len(space)//7)]:
                    v=raw
                    for a0 in range(b):
                        if a0!=i:v=h.linear(dualops[2],v)^poly(dualops[0],pols[a0],v)
                    for c0 in range(b):
                        if c0!=j:v=h.linear(dualops[4],v)^poly(dualops[1],pols[i],v)^poly(dualops[0],pols[c0],v)
                    if (ii,jj)!=(i,j):assert v==0
                    else:
                        expected=raw
                        for a0 in range(b):
                            if a0!=i:expected=poly(dualops[0],set(pols[i])^set(pols[a0]),expected)
                        for c0 in range(b):
                            if c0!=j:expected=poly(dualops[0],set(pols[j])^set(pols[c0]),expected)
                        assert v==expected
                    checks+=1
        cases.append(dict(b=b,D=D,rectangle=[A,B],quotients=b*b,each_head=A*B,
                          ambient_head=hhead,relation_dimension=relation_dim))
    return cases,checks

def main():
    start=time.monotonic();actual,checks=actual_shears();planes,interpolation=interpolation_controls()
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),actual_Jacobi_models=actual,
        reversible_semilinear_and_kernel_checks=checks,interpolation_models=planes,
        exact_interpolation_operator_checks=interpolation,
        scope='Finite controls for the adaptive polynomial-plane proof draft. No certification of the full weighted recovery or priority.')
    (ROOT/'adaptive_plane_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

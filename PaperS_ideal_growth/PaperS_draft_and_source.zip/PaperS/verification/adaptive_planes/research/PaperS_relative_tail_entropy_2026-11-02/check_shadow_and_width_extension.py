"""Exact controls for the new shadow budget and nonsplit width extension.

Shadow inequalities use rational arithmetic. Width extension uses genuine
stable submodules and exact generic pencil ranks over a certified field.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction
from math import comb
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
OLD=ROOT.parent/'PaperS_width_sectors_2026-11-02'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out
core=load('core',OLD/'check_actual_core_width.py')
ww=load('width',ROOT.parent/'PaperS_literature_and_nonfull_boundary_2026-11-02'/'check_boundary_width_variation.py')
h=core.h;w=ww.z


def monomials(d,j):
    if d==1:return [(j,)]
    return [(a,)+v for a in range(j+1) for v in monomials(d-1,j-a)]


def contains(m,gens):return any(all(a>=b for a,b in zip(m,g)) for g in gens)
def gens_of(D,d):
    out=set()
    for m in D:
        for i in range(d):
            b=tuple(a+int(k==i) for k,a in enumerate(m))
            if b in D:continue
            if all(tuple(a-int(k==j) for k,a in enumerate(b)) in D for j in range(d) if b[j]):out.add(b)
    return tuple(sorted(out))


def actions_on(labels,d):
    idx={m:i for i,m in enumerate(labels)}
    return tuple(tuple(1<<idx[b] if (b:=tuple(a+int(k==axis) for k,a in enumerate(m))) in idx else 0 for m in labels) for axis in range(d))


def normal_width(ops):return ww.normal_module(ops)['width']


def socle(ops):
    n=len(ops[0]);return n-len(h.canonical(sum(op[i]<<(k*n) for k,op in enumerate(ops)) for i in range(n)))


def restrict(ops,space):
    space=h.canonical(space);piv=[(v&-v).bit_length()-1 for v in space]
    def coords(v):
        out=0
        for i,(row,p) in enumerate(zip(space,piv)):
            if (v>>p)&1:v^=row;out|=1<<i
        assert not v;return out
    return tuple(tuple(coords(h.linear(op,v)) for v in space) for op in ops)


def monomial_controls(rng):
    cases=[];moments=0;cutoffs=0
    for d in [3,4]:
        for trial in range(100):
            D={(0,)*d}
            for _ in range(6+trial%17):
                corners=gens_of(D,d);D.add(rng.choice(corners))
            # Take the actual basically-full closure, recomputing after every step.
            while trial%2:
                G=gens_of(D,d)
                extra={m for m in D if all(contains(tuple(a+int(k==i) for k,a in enumerate(m)),
                         [tuple(a+int(k==axis) for k,a in enumerate(g)) for g in G for axis in range(d)]) for i in range(d))}
                if not extra:break
                D-=extra
            G=gens_of(D,d);maxdegree=max(map(sum,G));labels=tuple(sorted(D|set(G),key=lambda m:(sum(m),m)))
            ops=actions_on(labels,d);extra_socle=socle(ops)-len(G)
            if trial%2:assert extra_socle==0
            width=normal_width(ops);hist={j:sum(sum(m)==j for m in D) for j in range(maxdegree+1)}
            total_gap=Fraction(0);weighted=Fraction(1);C={}
            for j in range(maxdegree+1):
                universe=set(monomials(d,j));A=universe-D
                B={tuple(a+int(k==i) for k,a in enumerate(m)) for m in A for i in range(d)}
                delta=Fraction(len(B))-Fraction(j+d,j+1)*len(A);assert delta>=0
                candidates=[m for m in D if sum(m)==j and all(tuple(a+int(k==axis) for k,a in enumerate(m)) in B for axis in range(2,d))]
                moment=sum(sum(m[2:])+d-2 for m in candidates)
                assert moment<=(j+1)*delta,(d,D,j,candidates,moment,delta)
                total_gap+=delta;weighted+=Fraction(d-1,j+1)*hist[j];C[j]=len(candidates);moments+=1
            assert weighted-total_gap==len(G)
            assert extra_socle<=total_gap
            for L in range(1,maxdegree+2):
                assert width<=sum(v for j,v in C.items() if j<L)+sum(sum(g)>=L+1 for g in G)+extra_socle
                t=max(1,L//(2*d))
                if d*t<=L:
                    high=sum(sum(g)>=L for g in G);tail=sum(sum(m)>=L-t for m in D)
                    assert high*t<=d*tail;cutoffs+=1
            cases.append(dict(d=d,head=len(D),g=len(G),width=width,extra_socle=extra_socle,
                              closed=bool(trial%2),shadow_budget=str(total_gap)))
    return cases,moments,cutoffs


def extension_controls(rng):
    rows=[];checks=0
    for d,N,r in [(3,3,1),(3,3,2),(4,3,1),(5,2,2)]:
        mons=[m for j in range(N) for m in monomials(d,j)]
        labels=[(k,)+m for k in range(r) for m in mons];idx={m:i for i,m in enumerate(labels)};n=len(labels)
        ops=tuple(tuple(1<<idx[b] if (b:=(m[0],)+tuple(a+int(k==axis) for k,a in enumerate(m[1:]))) in idx else 0 for m in labels) for axis in range(d))
        width=normal_width(ops)
        for trial in range(40):
            gens=[sum((rng.randrange(7)==0)<<i for i in range(n)) for k in range(1+trial%4)]
            A=core.close(ops,gens);Aops=restrict(ops,A);Vops=core.quotient(ops,A)
            av=normal_width(Aops) if A else 0;sv=socle(Vops) if Vops[0] else 0
            assert width<=av+2*sv,(d,N,r,trial,width,av,sv)
            checks+=1
        rows.append(dict(d=d,N=N,rank=r,ambient_length=n,submodule_cases=40))
    return rows,checks


def main():
    start=time.monotonic();rng=random.Random(2026110241);w.verify_field()
    cases,moments,cutoffs=monomial_controls(rng);ext,checks=extension_controls(rng)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
        monomial_cores=len(cases),closed_cores=sum(x['closed'] for x in cases),
        unrestricted_cores=sum(not x['closed'] for x in cases),exact_shadow_moment_checks=moments,
        high_generator_and_cutoff_checks=cutoffs,nonsplit_width_extension_checks=checks,
        extension_models=ext,scope='Exact controls of elementary identities used in the weaker near-extremal width proof draft. Not an independent certification of the full theorem.')
    (ROOT/'shadow_and_width_extension_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

"""Exact staircase, exponent-identity and rational-margin controls."""
from pathlib import Path
from fractions import Fraction as F
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('hard',ROOT/'probe_hard_cocyclic_losses.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)

def main():
    start=time.monotonic();tensors=0
    for N in range(13):
        I=tuple((N-i,i) for i in range(N+1))
        for r in range(1,10):
            for t in range(1,10):
                Q=((r,0),(0,t));actual=p.col(p.p.product_ideal(I,Q))-p.col(I)
                exact=r*t+sum(j+1 for j in range(max(N-min(r,t),0),N))
                assert actual==exact<=r*t+N*min(r,t);tensors+=1
    rng=random.Random(2026110254);identities=0
    for d in [5,6]:
        for trial in range(3000):
            k=rng.randrange(1000,10000);ell=rng.randrange(1,100);a=rng.randrange(0,100)
            gp=rng.randrange(10,200);v=rng.randrange(1,20);j=rng.randrange(1,20)
            T=(d-1)*v-1;vj=v+j+rng.randrange(0,20);Tj=(d-1)*vj-1;delta=vj-v
            beta=rng.randrange(0,min(T,gp+v-1)+1);gi=gp+v-beta;U=rng.randrange(1,100)
            n=2*k+gi+U;h=k+ell;m=n-a-h;e=rng.randrange(0,100);astar=rng.randrange(1,40)
            gout=gp+vj-rng.randrange(0,min(Tj,gp+vj-1)+1)
            Aprime=h+e+gout+d-1;mp=n-astar-h-e;cost=rng.randrange(0,1000)
            assert m>0 and mp>0 and 2*k+gp+v<n+T
            direct=(h+gout+d-1-delta)*m+cost-Aprime*mp
            exact=cost-delta*m+e*(Aprime-m)+Aprime*(astar-a)
            bound=(cost-delta*(n-h)-(h+gout+d-1-delta)*a+Aprime*astar
                   +e*(2*ell+T+delta+e+d-1))
            assert direct==exact<=bound
            identities+=1
    exponents=[]
    for d in range(3,11):
        alpha=1-F(1,d);packet=alpha+F(1,d);minimum=F(2,d)-1
        natural=2*alpha*alpha-alpha/2-1
        theta=F(2*d,3*d-4)
        assert packet==1 and minimum<0
        assert (alpha<theta)==(d<=6)
        sector_margin=(theta-F(1,100))*(2*alpha-F(1,2))-1
        assert sector_margin<0
        if d<=6:assert natural<0
        else:assert natural>0
        exponents.append(dict(d=d,radial_plane_head=str(F(2,d)),packet_cost_power=str(packet),
                              minimum_overshoot=str(minimum),natural_away_entropy=str(natural),
                              all_rank_away_cutoff=str(theta),strict_cutoff_margin=str(sector_margin)))
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
        rectangular_tensor_staircase_identities=tensors,exact_weight_difference_and_upper_bound_checks=identities,
        exponent_margins=exponents,
        scope='Checks the new filtered projection and weighted-recovery algebra. Finite controls do not independently certify the complete asymptotic proof draft.')
    (ROOT/'filtered_head_and_recovery_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

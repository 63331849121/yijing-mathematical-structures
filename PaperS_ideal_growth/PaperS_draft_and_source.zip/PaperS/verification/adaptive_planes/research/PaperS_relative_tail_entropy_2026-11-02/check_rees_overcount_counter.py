"""Exact tensor-map controls of the isolated-Rees-torsion counterfamily."""
from pathlib import Path
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('controls',ROOT/'check_dual_and_rees_controls.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
spec=importlib.util.spec_from_file_location('prod',ROOT.parent/'PaperS_width_sectors_2026-11-02'/'probe_cocyclic_product_bound.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)

def main():
    start=time.monotonic();rows=[]
    for A,r in [(2,1),(2,3),(2,7),(3,1),(3,5),(3,10),(4,5),(6,5)]:
        Q=((A,0),(0,A));I=tuple((A*(r-i),A*i) for i in range(r+1));D=c.quotient_target(Q)
        T=c.tensor(I,D);observed=c.finite_torsion(T,A-1);expected=(r+1)*A*(A-1)//2
        assert observed==expected
        L=D;Jj=I
        for _ in range(A-1):Jj=c.w.c.times_n(Jj)
        dh=c.z.hom(Jj,L)-c.z.hom(I,L)
        assert dh==A*(A-1)-A*(A-1)//2
        rows.append(dict(A=A,r=r,finite_Rees_torsion=observed,u_plus_order_width=A*A-1+A*r,
                         u_plus_v_minus_one_soc=A*A-1+r,actual_Hom_increment=dh))
    products=[]
    for m in [10,20,50,100,200]:
        aa=[5*m,4*m]+list(range(4*m-1,3*m+3,-1))+[m,0]
        I=tuple(zip(aa,reversed(aa)));assert len(I)==m
        expected=tuple((a*m,b*m) for a,b in [(6,0),(5,1),(4,2),(2,4),(1,5),(0,6)])
        actual=p.product_ideal(((m,0),(0,m)),I);assert actual==expected
        products.append(dict(source_mu=m,parameter_ideal_mu=2,product_mu=len(actual)))
    assert any(r['finite_Rees_torsion']>r['u_plus_order_width'] for r in rows)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),Rees_counterfamily=rows,
                parameter_product_counterfamily=products,
                scope='Certifies finite exact controls of two explicitly proved false shortcuts. Does not refute the original or weaker general Hom comparison.')
    (ROOT/'rees_overcount_counter_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

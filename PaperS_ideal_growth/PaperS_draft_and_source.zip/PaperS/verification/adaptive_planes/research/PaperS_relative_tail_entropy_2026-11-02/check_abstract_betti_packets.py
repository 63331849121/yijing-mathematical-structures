"""Exhaustive packets over the nonregular ring F2[x,y]/(x,y)^3."""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('core',ROOT.parent/'PaperS_width_sectors_2026-11-02'/'check_actual_core_width.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
h=c.h
old_canonical=h.canonical
def reduced_basis(rows):
    out=list(old_canonical(rows))
    for i in range(len(out)-1,-1,-1):
        pivot=(out[i]&-out[i]).bit_length()-1
        for j in range(i):
            if (out[j]>>pivot)&1:out[j]^=out[i]
    return tuple(out)
h.canonical=reduced_basis
mons=((0,0),(1,0),(0,1),(2,0),(1,1),(0,2));idx={m:i for i,m in enumerate(mons)}
ops=tuple(tuple(1<<idx[b] if (b:=(x+int(axis==0),y+int(axis==1))) in idx else 0 for x,y in mons) for axis in range(2))
Fspace=(1<<idx[2,0],);free=[i for i in range(6) if i!=idx[2,0]]
qops=c.quotient(ops,Fspace)

def quotient(v):
    v=h.reduce(v,Fspace);return sum(((v>>j)&1)<<i for i,j in enumerate(free))
def mu(space,actions):return len(space)-len(h.canonical(h.linear(op,v) for op in actions for v in space))
def beta1(U):
    rad=h.canonical(h.linear(op,v) for op in qops for v in U);span=rad;gens=[]
    for row in U:
        if h.reduce(row,span):gens.append(row);span=h.canonical(span+(row,))
    v=len(gens);columns=[]
    for gen in gens:
        for x,y in mons:
            out=gen
            for _ in range(x):out=h.linear(qops[0],out)
            for _ in range(y):out=h.linear(qops[1],out)
            columns.append(out)
    K=h.ker(tuple(1<<i for i in range(6*v)),columns)
    rops=tuple(tuple(op[i]<<(6*j) for j in range(v) for i in range(6)) for op in ops)
    return mu(K,rops) if v else 0

def main():
    start=time.monotonic();packets=defaultdict(list);ideals=0;boundary_checks=0;lift_checks=0
    for I in h.subspaces(6):
        if any(h.reduce(h.linear(op,v),I) for op in ops for v in I):continue
        ideals+=1;P=bool(not h.reduce(Fspace[0],I));g=int(P)
        U=h.canonical(quotient(v) for v in I);v=mu(U,qops)
        mI=h.canonical(h.linear(op,z) for op in ops for z in I)
        beta=int(P and not h.reduce(Fspace[0],mI));gi=mu(I,ops)
        assert gi==g+v-beta;boundary_checks+=1
        packets[(P,U)].append((gi,beta))
    bettis={U:beta1(U) for P,U in packets};comparisons=0;positive=0;empty_zero=0
    for (P,U),members in packets.items():
        g=int(P);v=mu(U,qops)
        for da in range(g+1):
            count=sum(beta<=da for gi,beta in members)
            if count:assert count==2**(v*(1-g)),(P,U,v,g,da,count,members);lift_checks+=1
            if da==0 and not count:empty_zero+=1
        T=bettis[U]
        for (P1,V),target in packets.items():
            if P1!=P or any(h.reduce(z,U) for z in V):continue
            vp=mu(V,qops);delta=vp-v
            if delta<0:continue
            Tp=bettis[V]
            for m in [g+T+1,g+T+3]:
                left=sum(2**(gi*m) for gi,beta in members)
                right=sum(2**(gi*m) for gi,beta in target)
                factor=Fraction(2)**(T*Tp-delta*m)
                assert left<=8*factor*right
                comparisons+=1;positive+=bool(delta)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
        ring='F2[x,y]/(x,y)^3 (nonregular)',all_ideals=ideals,packets=len(packets),
        generator_boundary_identities=boundary_checks,nonempty_exact_lift_counts=lift_checks,
        obstructed_zero_boundary_packets=empty_zero,weighted_packet_comparisons=comparisons,
        positive_generator_gain_comparisons=positive,observed_first_Betti_numbers=sorted(set(bettis.values())),
        scope='Exhaustive finite controls of the abstract Betti packet proof over this nonregular ring; not a replacement for the general proof.')
    (ROOT/'abstract_betti_packet_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

"""Falsify a new baseline-growth route; never treat finite passes as proof."""
from pathlib import Path
import importlib.util
import random
import time
import json

ROOT=Path(__file__).parent
OLD=ROOT.parent/'PaperS_width_sectors_2026-11-02'
spec=importlib.util.spec_from_file_location('ns',OLD/'probe_nonsplit_commuting_targets.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
w=p.w;z=p.z;h=p.h

def main():
    start=time.monotonic();rng=random.Random(2026110243)
    w.DEG=64;w.MOD=(1<<64)|0x1B;w.MASK=(1<<64)-1;w.verify_field()
    shapes=[(8,5,3,2),(12,7,4,1),(9,8,5,3,1),(14,10,7,4,2,1),(7,7,4,4,2,2),(11,6,6,3,3,1)]
    targets=[p.target(shape,rng) for shape in shapes for _ in range(8)]
    loewy,uniform,_=p.p.targets();targets+=loewy[::8]+uniform
    for L in targets:
        n=L['length'];X,Y=L['actions']
        radical=h.canonical(X+Y)
        soc=h.ker(tuple(1<<i for i in range(n)),[x|(y<<n) for x,y in zip(X,Y)])
        intersection=len(radical)+len(soc)-len(h.canonical(radical+soc))
        semisimple=L['socle']-intersection
        L.update(semisimple_direct_part=semisimple,reduced_socle=L['socle']-semisimple)
    small_width=[dict(length=L['length'],socle=L['socle'],width=L['width'],
                      reduced_socle=L['reduced_socle']) for L in targets if L['reduced_socle']>2*L['width']]
    source=[w.c.ideal_of(part) for length in range(1,10) for part in w.c.partitions(length)]
    for A in [2,3,4,6]:
        for r in [2,4,8,12]:source.append(tuple((A*(r-i),A*i) for i in range(r+1)))
    checks=0;bad=[];maxloss=0
    for J in source:
        cur=J;later=[]
        for j in range(1,17):
            cur=w.c.times_n(cur)
            if j in [1,2,4,8,16]:later.append((j,cur))
        for li,L in enumerate(targets):
            initial=z.hom(J,L);u=L['length']-L['socle']
            for j,Jj in later:
                growth=z.hom(Jj,L)-initial;loss=j*L['socle']-growth
                checks+=1;maxloss=max(maxloss,loss)
                if loss>u:
                    bad.append(dict(J=J,j=j,target=li,length=L['length'],socle=L['socle'],
                                    width=L['width'],growth=growth,baseline_loss=loss,u=u));break
            if bad:break
        if bad:break
    result=dict(status='COUNTEREXAMPLE_FOUND' if bad or small_width else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',
        seconds=round(time.monotonic()-start,3),targets=len(targets),sources=len(source),comparisons=checks,
        baseline_growth_counterexamples=bad,small_width_counterexamples=small_width,max_baseline_loss=maxloss,
        mathematical_status='Baseline growth is FALSE by the explicit unbounded counterfamily. The separate reduced-socle width proposal remains OPEN; finite passes do not prove it.')
    (ROOT/'baseline_hom_probe_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

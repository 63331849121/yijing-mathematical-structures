"""Falsification of a possible reduced-socle bound; not a theorem."""
from pathlib import Path
import importlib.util
import random
import time
import json

ROOT=Path(__file__).parent
OLD=ROOT.parent/'PaperS_width_sectors_2026-11-02'
spec=importlib.util.spec_from_file_location('ns',OLD/'probe_nonsplit_commuting_targets.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
w=p.w;z=p.z;h=p.h

def main():
    start=time.monotonic();rng=random.Random(2026110246)
    w.DEG=64;w.MOD=(1<<64)|0x1B;w.MASK=(1<<64)-1;w.verify_field()
    shapes=[(8,)+(1,)*20,(5,3)+(1,)*18,(3,)*3+(1,)*18,
            (6,)*2+(2,)*3+(1,)*14,(4,)*4+(1,)*16,(2,)*8+(1,)*12]
    checks=0;best=None;bad=[]
    for shape in shapes:
        for trial in range(50):
            raw=p.target(shape,rng)
            for L in [raw,z.module(tuple(p.dual.transpose(op) for op in raw['actions']))]:
                n=L['length'];soc=h.ker(tuple(1<<i for i in range(n)),[x|(y<<n) for x,y in zip(*L['actions'])])
                rad=h.canonical(L['actions'][0]+L['actions'][1])
                reduced=len(soc)+len(rad)-len(h.canonical(soc+rad))
                width=L.get('width',None)
                if width is None:width=w.generic_width(L)
                row=dict(shape=shape,trial=trial,length=n,socle=L['socle'],reduced_socle=reduced,width=width)
                checks+=1
                if best is None or reduced*best['width']>best['reduced_socle']*max(width,1):best=row
                if reduced>2*width:bad.append(dict(**row,actions=L['actions']));break
            if bad:break
        if bad:break
    result=dict(status='COUNTEREXAMPLE_FOUND' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',
        seconds=round(time.monotonic()-start,3),targets=checks,best_ratio_case=best,counterexamples=bad,
        mathematical_status='UNPROVED auxiliary proposal: dim(Soc(L) intersect mL)<=2*w(L) for generic plane w. Neither implication to the needed Hom estimate nor the proposal is established by this finite probe.')
    (ROOT/'reduced_socle_width_probe.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

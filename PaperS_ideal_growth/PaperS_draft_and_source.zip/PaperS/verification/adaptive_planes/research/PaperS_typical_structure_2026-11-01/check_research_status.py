"""Read-only source guards, TeX structure checks and the Fitting caveat example."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).parent
snapshot = json.loads((root / 'source_snapshot.json').read_text(encoding='utf-8'))
changed = []
for name, digest in snapshot['sha256'].items():
    path = Path(snapshot['source']) / name
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        changed.append(name)
assert not changed, changed

tex_checks = []
for name in ['typical_structure_and_head_laws.tex', 'outer_compatibility_and_global_laws.tex',
             'central_torus_convolution_and_growth_smoothness.tex', 'rank_two_locality_cost.tex']:
    raw = (root / name).read_text(encoding='utf-8')
    text = '\n'.join(re.split(r'(?<!\\)%', line)[0] for line in raw.splitlines())
    stack = []
    for cmd, env in re.findall(r'\\(begin|end)\{([^}]+)\}', text):
        if cmd == 'begin':
            stack.append(env)
        else:
            assert stack and stack.pop() == env, (name, env)
    assert not stack
    braces = 0
    for c in re.sub(r'\\[{}]', '', text):
        if c == '{':
            braces += 1
        elif c == '}':
            braces -= 1
        assert braces >= 0
    assert braces == 0
    labels = re.findall(r'\\label\{([^}]+)\}', text)
    refs = re.findall(r'\\(?:ref|eqref)\{([^}]+)\}', text)
    assert len(labels) == len(set(labels)) and set(refs) <= set(labels)
    tex_checks.append(dict(file=name, status='PASS', scope='Static structure, not compilation or layout.'))


def bracket(a, b):
    coefficient = (a & 1) * (((b >> 1) ^ (b >> 2)) & 1)
    coefficient ^= (b & 1) * (((a >> 1) ^ (a >> 2)) & 1)
    return 12 * coefficient


def power(a):
    # x^[2]=x, v^[2]=v; Jacobson cross term x*(y+u)*(u+v).
    return (a & 1) ^ (a & 8) ^ (12 * ((a & 1) * (((a >> 1) ^ (a >> 2)) & 1)))


for a in range(16):
    assert bracket(a, a) == 0
    for b in range(16):
        assert power(a ^ b) == power(a) ^ power(b) ^ bracket(a, b)
        assert bracket(power(a), b) == bracket(a, bracket(a, b))
        for c in range(16):
            assert (bracket(a, bracket(b, c)) ^ bracket(b, bracket(c, a))
                    ^ bracket(c, bracket(a, b))) == 0
assert bracket(1, 4) == 12 and power(4) == 0 and power(8) == 8
assert bracket(1, 2) == 12 and power(12) == 8

checks = {}
for name in ['head_fitting_results.json', 'outer_compatibility_results.json',
             'nil_condensation_results.json', 'toral_convolution_results.json']:
    data = json.loads((root / name).read_text(encoding='utf-8'))
    assert data['status'] == 'PASS'
    checks[name] = data['status']

data=json.loads((root/'rank_two_locality_results.json').read_text(encoding='utf-8'))
assert data['status']=='PASS'
checks['rank_two_locality_results.json']=data['status']

result = dict(status='PASS', stage=4, original_snapshot_unchanged=True, tex_static_checks=tex_checks,
              finite_controls=checks,
              nonideal_nilpotent_fitting_part_example='PASS: all 4096 Jacobi triples and 256 restricted adjoint identities.',
              tex_compile_status='Not completed: MiKTeX configuration access denied before TeX source processing.',
              scope='Research proof drafts and finite controls; no external proof certification or exhaustive priority search.',
              probability_measure='Uniform ideals; detailed laws not established for uniform unmarked isomorphism types.')
(root / 'research_status.json').write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))

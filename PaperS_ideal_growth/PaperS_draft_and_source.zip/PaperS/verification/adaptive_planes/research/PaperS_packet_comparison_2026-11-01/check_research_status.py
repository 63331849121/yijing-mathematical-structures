"""Static research-source and manuscript guard; not mathematical certification."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).parent
proofs={}
for tex in ROOT.glob('*.tex'):
    raw=tex.read_text(encoding='utf-8');code='\n'.join(re.split(r'(?<!\\)%',line)[0] for line in raw.splitlines());stack=[]
    for cmd,env in re.findall(r'\\(begin|end)\{([^}]+)\}',code):
        if cmd=='begin':stack.append(env)
        else:assert stack and stack.pop()==env,(tex.name,cmd,env)
    assert not stack,tex.name
    balance=0
    for ch in re.sub(r'\\[{}]','',code):
        balance+=(ch=='{')-(ch=='}');assert balance>=0,tex.name
    assert balance==0,tex.name
    labels=re.findall(r'\\label\{([^}]+)\}',code);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',code)
    assert len(labels)==len(set(labels)) and set(refs)<=set(labels),(tex.name,set(refs)-set(labels))
    proofs[tex.name]=dict(static_status='PASS',sha256=hashlib.sha256(raw.encode()).hexdigest(),bytes=len(raw.encode()))

controls={}
for stem,resultname in [('packet_comparison','packet_comparison_results.json'),('full_plane_hom','full_plane_hom_results.json')]:
    result=ROOT/resultname;script=ROOT/f'check_{stem}.py';data=json.loads(result.read_text(encoding='utf-8'));assert data['status']=='PASS'
    controls[resultname]=dict(status='PASS',script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),result_sha256=hashlib.sha256(result.read_bytes()).hexdigest())
probes={}
for scriptname,resultname in [('probe_order_defect_bound.py','order_defect_probe_results.json'),('probe_nonhomogeneous_order_defect.py','nonhomogeneous_order_defect_probe_results.json')]:
    result=ROOT/resultname;data=json.loads(result.read_text(encoding='utf-8'))
    probes[resultname]=dict(status=data['status'],mathematical_status='UNPROVED conjecture; finite falsification search only.',script_sha256=hashlib.sha256((ROOT/scriptname).read_bytes()).hexdigest(),result_sha256=hashlib.sha256(result.read_bytes()).hexdigest())

snap=json.loads((ROOT.parent/'PaperS_higher_rank_locality_2026-11-01'/'source_snapshot_updated.json').read_text(encoding='utf-8'));changes=[]
for name,meta in snap['files'].items():
    current=Path(snap['source'])/name
    if not current.exists() or hashlib.sha256(current.read_bytes()).hexdigest()!=meta['sha256']:changes.append(name)
status=dict(status='PASS',stage=10,date='2026-11-01',work_state='Active: general non-full plane packets and the order-defect comparison remain under investigation.',
            latest_report='第十阶段研究报告.txt',proof_sources=proofs,finite_controls=controls,unproved_conjecture_probes=probes,
            baseline_manuscript_matches_current=not any(x.endswith(('.tex','.pdf')) for x in changes),external_changes_since_baseline=changes,
            main_manuscript_edits_performed=False,main_manuscript_compilation_performed=False,
            strongest_new_proof_draft='Uniform weighted packet comparison for n-full plane images, independent of higher colon defects; a d=5,6 bulk locality sector application.',
            remaining_gap='Non-full plane packets. The proposed order-defect Hom bound is not proved, and the global rank-five/six locality upper bound remains open.',
            no_claims=['No unconditional rank-five or rank-six locality theorem.','No claim that all near-extremal cores have n-full plane images.','No inference of a theorem from finite probes.','No independent external mathematical certification.'])
(ROOT/'research_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in status.items() if k not in ['proof_sources','finite_controls','unproved_conjecture_probes']},ensure_ascii=False,indent=2))
print('Static proof sources:',len(proofs),'PASS; completed finite controls:',len(controls),'PASS; unproved conjecture probes:',len(probes))

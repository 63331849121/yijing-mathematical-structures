"""Stress the UNPROVED bound on defect-one ideals with delayed fullness.

J=(f,g)+n^(a+1), f,g general binary forms of degree a.  These can
have many higher-degree minimal generators despite plane order defect one.
This is a falsification probe, never a proof input.
"""
from pathlib import Path
import importlib.util
import json
import random
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('nonhomogeneous_probe',ROOT/'probe_nonhomogeneous_order_defect.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)


def radial_target(N,dual=False):
    q=p.quotient([],N,0)
    if dual:
        ops=tuple(p.transpose(op) for op in q['actions']);size=q['length']
        soc=size-len(p.h.canonical(x|(y<<size) for x,y in zip(*ops)))
        q=dict(length=size,socle=soc,mu=None,actions=ops)
    return q


def main():
    start=time.monotonic();rng=random.Random(2026110111);checks=0;bad=[];families=[]
    modules=[radial_target(N,d) for N in [2,3,4] for d in [False,True]]
    for a in [3,4,5,6,8]:
        for sample in range(3):
            forms=[]
            for i in range(2):
                form=[(x,a-x) for x in range(a+1) if rng.randrange(2)]
                if not form:form=[(a,0)]
                forms.append(tuple(form))
            orders=[0,1,2,min(a-1,4),a-1]
            powers=sorted(set(orders));local={j:p.quotient(forms,a+1,j) for j in powers}
            A0=local[0];b=a+1-A0['mu']
            families.append(dict(a=a,forms=forms,order_defect=b,powers=powers,mu=[local[j]['mu'] for j in powers],lengths=[local[j]['length'] for j in powers]))
            for li,L in enumerate(modules):
                first=p.hom_ideal(A0,L);u=L['length']-L['socle']
                for j in powers[1:]:
                    later=p.hom_ideal(local[j],L);loss=(local[j]['mu']-A0['mu'])*L['socle']-(later-first)
                    checks+=1
                    if loss>(b+1)*u:
                        bad.append(dict(a=a,forms=forms,defect=b,j=j,L=li,loss=loss,bound=(b+1)*u))
    result=dict(status='COUNTEREXAMPLE' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',seconds=round(time.monotonic()-start,3),field=2,
                checked_inequalities=checks,structured_families=families,counterexamples=bad,
                mathematical_status='UNPROVED conjecture; structured stress test only. Some forms can have common factors; the n^(a+1) truncation always ensures finite colength.')
    (ROOT/'delayed_fullness_probe_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='structured_families'},ensure_ascii=False,indent=2))


if __name__=='__main__':main()

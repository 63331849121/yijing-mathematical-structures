"""Exact independent monomial Hilbert--Burch controls for the full-plane lemma."""
from pathlib import Path
from functools import lru_cache
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('packet_helpers',ROOT/'check_packet_comparison.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)


def partitions(n,cap=None):
    if not n:yield ();return
    if cap is None:cap=n
    for first in range(min(n,cap),0,-1):
        for rest in partitions(n-first,first):yield (first,)+rest


def minimal(gens):
    distinct=sorted(set(gens),reverse=True)
    return tuple(g for g in distinct if not any(h!=g and h[0]<=g[0] and h[1]<=g[1] for h in distinct))


def ideal_of(part):return minimal([(width,y) for y,width in enumerate(part)]+[(0,len(part))])


def times_n(gens):return minimal([(x+1,y) for x,y in gens]+[(x,y+1) for x,y in gens])


def apply_power(f,actions,axis,power,v):
    for _ in range(power):v=p.h.lin(f,actions[axis],v)
    return v


def hom(f,gens,actions):
    size=len(actions[0]);v=len(gens);images=[]
    for i in range(v):
        for k in range(size):
            out=[0]*((v-1)*size);e=tuple(int(z==k) for z in range(size))
            if i<v-1:
                dy=gens[i+1][1]-gens[i][1]
                vec=apply_power(f,actions,1,dy,e)
                for z,a in enumerate(vec):out[i*size+z]=f.add(out[i*size+z],a)
            if i:
                dx=gens[i-1][0]-gens[i][0]
                vec=apply_power(f,actions,0,dx,e)
                for z,a in enumerate(vec):out[(i-1)*size+z]=f.add(out[(i-1)*size+z],f.neg(a))
            images.append(tuple(out))
    return v*size-f.rank(images)


def main():
    start=time.monotonic();rows=[];checks=0;full=0;nonfull=0;failure=[]
    shapes=[part for n in range(1,9) for part in partitions(n)]
    for q in [2,3,4]:
        f=p.Field(q)
        for part in shapes:
            J=ideal_of(part);v=len(J);order=min(sum(g) for g in J)
            isfull=(v==order+1)
            full+=isfull;nonfull+=not isfull
            for A,B in [(2,2),(2,3)]:
                labels,actions=p.plane_actions(A,B);size=len(labels)
                for dual in [False,True]:
                    ops=[tuple(zip(*op)) for op in actions] if dual else actions
                    soc=size-f.rank([tuple(ops[0][i])+tuple(ops[1][i]) for i in range(size)])
                    initial=hom(f,J,ops);current=J
                    for j in [1,2,3]:
                        current=times_n(current);later=hom(f,current,ops)
                        if isfull:
                            assert len(current)==v+j,(q,part,j)
                            assert later-initial>=j*soc-(size-soc),(q,part,A,B,dual,j,initial,later)
                            checks+=1
                        # This stronger arbitrary-ideal analogue is deliberately
                        # audited rather than assumed: replace j by the actual
                        # number of additional generators in the Hom estimate.
                        if not isfull and later-initial<(len(current)-v)*soc-(size-soc):
                            if len(failure)<8:
                                failure.append(dict(q=q,partition=part,J=J,padded_J=current,j=j,
                                                    module_rectangle=[A,B],dual=dual,
                                                    initial_Hom=initial,target_Hom=later,socle=soc,
                                                    excess_loss=(len(current)-v)*soc-(later-initial),single_state_budget=size-soc))
    structured=[]
    labels=[(x,y) for x in range(3) for y in range(3-x)];index={m:i for i,m in enumerate(labels)}
    actions=[]
    for axis in range(2):
        actions.append(tuple(tuple(int(z==index.get((x+int(axis==0),y+int(axis==1)))) for z in range(len(labels))) for x,y in labels))
    for q in [2,3,4]:
        f=p.Field(q);J=((4,0),(3,3),(0,4));J1=times_n(J)
        initial=hom(f,J,actions);later=hom(f,J1,actions)
        assert initial==15 and later==14 and len(J1)==4
        structured.append(dict(q=q,J=J,target=J1,module='S/n^3',length=6,socle=3,initial_Hom=initial,target_Hom=later,
                               effective_loss=4,single_state_budget=3,status='EXPECTED_COUNTEREXAMPLE'))
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),partitions_per_field=len(shapes),
                full_ideal_field_cases=full,nonfull_ideal_field_cases=nonfull,full_plane_Hom_checks=checks,
                counterexamples_to_unrestricted_single_state_bound=failure,
                larger_structured_counterexamples=structured,
                scope='All monomial plane ideals of colength 1 through 8, over F2,F3,F4, tested by their actual neighboring monomial syzygies. Fullness is classified by mu(J)=ord(J)+1 after infinite scalar extension; general proof is in the note. No probability inference.')
    (ROOT/'full_plane_hom_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()

"""Exact planar Hom and actual M3 packet controls; no asymptotic inference."""
from pathlib import Path
from itertools import product
from collections import Counter
from fractions import Fraction
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('field_and_linear_algebra',ROOT.parent/'PaperS_core_weight_comparison_2026-11-01'/'check_core_weights.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
Field=h.Field


def nullspace(f,images,n):
    equations=h.canonical(f,list(zip(*images)) if images else [],n)
    pivots=tuple(next(i for i,x in enumerate(row) if x) for row in equations)
    return h.basis_from_ann(f,n,pivots,equations)


def plane_actions(A,B):
    labels=tuple((x,y) for x in range(A) for y in range(B));idx={p:i for i,p in enumerate(labels)}
    actions=[]
    for axis in range(2):
        columns=[]
        for x,y in labels:
            target=idx.get((x+int(axis==0),y+int(axis==1)))
            columns.append(tuple(int(i==target) for i in range(len(labels))))
        actions.append(tuple(columns))
    return labels,actions


def hom_power(f,actions,r):
    size=len(actions[0]);v=r+1;n=v*size;images=[]
    for l in range(v):
        for k in range(size):
            out=[0]*(r*size)
            if l<r:
                for z,a in enumerate(actions[1][k]):out[l*size+z]=f.add(out[l*size+z],a)
            if l>0:
                for z,a in enumerate(actions[0][k]):out[(l-1)*size+z]=f.add(out[(l-1)*size+z],f.neg(a))
            images.append(tuple(out))
    return n-f.rank(images)


def hom_controls():
    rows=[];checks=0
    for q in [2,3,4]:
        f=Field(q)
        for A,B in [(1,1),(1,3),(2,2),(2,3),(3,3)]:
            labels,actions=plane_actions(A,B);size=len(labels)
            for dual in [False,True]:
                operators=[tuple(zip(*op)) for op in actions] if dual else actions
                # Dimension of joint kernel, via the vertically concatenated maps.
                soc=size-f.rank([tuple(operators[0][i])+tuple(operators[1][i]) for i in range(size)])
                dims={r:hom_power(f,operators,r) for r in range(7)}
                for r in range(4):
                    for j in [1,2,3]:
                        difference=dims[r+j]-dims[r]
                        assert difference>=j*soc-(size-soc),(q,A,B,dual,r,j,difference)
                        checks+=1
                rows.append(dict(q=q,rectangle=[A,B],Matlis_dual=dual,length=size,socle=soc,Hom_dimensions=dims))
    return checks,rows


def ideal_contains(m,gens):return any(all(x>=y for x,y in zip(m,g)) for g in gens)


def scalar_quotient(gens):
    bounds=[next(g[i] for g in gens if g[i] and all(g[j]==0 for j in range(3) if j!=i)) for i in range(3)]
    labels=tuple(m for m in product(*(range(b) for b in bounds)) if not ideal_contains(m,gens));idx={m:i for i,m in enumerate(labels)}
    return labels,idx


def packet_for_ideal(q,gens,J):
    """F=Ra+Rb, P=Aa+Rb in actual M3; Zc12=Ya-Xb."""
    f=Field(q);labels,index=scalar_quotient(gens);size=len(labels);v=len(J);ng=len(gens);g=ng+1
    for x,y in J:assert ideal_contains((x,y+1,0),gens),(gens,J)
    def action(m,axis):return tuple(x+int(i==axis) for i,x in enumerate(m))
    images=[]
    for l in range(v):
        for m in labels:
            out=[0]*((2*v-1)*size)
            target=index.get(action(m,2))
            if target is not None:out[l*size+target]=1
            dy=J[l+1][1]-J[l][1] if l<v-1 else 0
            target=index.get((m[0],m[1]+dy,m[2]))
            if l<v-1 and target is not None:out[(v+l)*size+target]=1
            dx=J[l-1][0]-J[l][0] if l else 0
            target=index.get((m[0]+dx,m[1],m[2]))
            if l>0 and target is not None:out[(v+l-1)*size+target]=f.neg(1)
            images.append(tuple(out))
    kernel=nullspace(f,images,v*size);dim=len(kernel)
    if q**dim>20000:
        return dict(q=q,ideal_generators=gens,plane_generators=J,nonplane_length=size,
                    section_parameter_dimension=dim,status='NOT_ENUMERATED',reason='Explicit 20000-member enumeration cap; excluded from comparisons.')
    gi={m:i for i,m in enumerate(gens)};hist=Counter();boundary_hists=Counter()
    for coeffs in product(range(q),repeat=dim):
        param=h.lin(f,kernel,coeffs) if kernel else (0,)*(v*size)
        delta=[]
        for l in range(v):
            row=[0]*g;base=gi.get((J[l][0],J[l][1]+1,0))
            if base is not None:row[base]=1
            for coefficient,m in zip(param[l*size:(l+1)*size],labels):
                target=gi.get(action(m,2))
                if target is not None:row[target]=f.add(row[target],coefficient)
            delta.append(tuple(row))
        for l in range(v-1):
            row=[0]*g
            dy=J[l+1][1]-J[l][1];dx=J[l][0]-J[l+1][0]
            for coefficient,m in zip(param[l*size:(l+1)*size],labels):
                target=gi.get((m[0],m[1]+dy,m[2]))
                if target is not None:row[target]=f.add(row[target],coefficient)
            for coefficient,m in zip(param[(l+1)*size:(l+2)*size],labels):
                target=gi.get((m[0]+dx,m[1],m[2]))
                if target is not None:row[target]=f.add(row[target],f.neg(coefficient))
            delta.append(tuple(row))
        rank=f.rank(delta);hist[g+v-rank]+=1;boundary_hists[rank]+=1
    assert sum(hist.values())==q**dim
    return dict(q=q,ideal_generators=gens,plane_generators=J,nonplane_length=size,nonplane_generators=g,
                section_parameter_dimension=dim,packet_members=sum(hist.values()),generator_histogram=dict(sorted(hist.items())),
                boundary_rank_histogram=dict(sorted(boundary_hists.items())),status='PASS')


def packet_histogram(q,gens,r):
    row=packet_for_ideal(q,gens,tuple((r-i,i) for i in range(r+1)));row['plane_power']=r
    return row


def packet_controls():
    configs=[
        ([(1,0,0),(0,1,0),(0,0,1)],[0,1,2,3],[2,3,4]),
        ([(2,0,0),(0,2,0),(0,0,1)],[2,3,4],[2,3,4]),
        ([(2,0,0),(0,2,0),(0,0,2)],[2,3,4],[2,3]),
        ([(3,0,0),(0,3,0),(2,2,0),(0,0,1)],[4,5],[2]),
        ([(2,0,0),(1,1,0),(1,0,1),(0,2,0),(0,1,1),(0,0,2)],[1,2],[2]),
    ]
    rows=[];skipped=[];comparisons=[];checks=0
    for gens,powers,fields in configs:
        for q in fields:
            proposed={r:packet_histogram(q,gens,r) for r in powers}
            skipped.extend(row for row in proposed.values() if row['status']=='NOT_ENUMERATED')
            local={r:row for r,row in proposed.items() if row['status']=='PASS'};rows.extend(local.values())
            for r in local:
                for target in local:
                    if target<=r:continue
                    g=local[r]['nonplane_generators'];k=local[r]['nonplane_length'];j=target-r
                    for m in [g+1,g+3]:
                        z=sum(n*q**(int(mu)*m) for mu,n in local[r]['generator_histogram'].items())
                        zz=sum(n*q**(int(mu)*m) for mu,n in local[target]['generator_histogram'].items())
                        ratio=Fraction(z,zz)*Fraction(q**max(j*m-k,0),q**max(k-j*m,0))
                        assert ratio<=4,(q,gens,r,target,m,ratio)
                        comparisons.append(dict(q=q,source_power=r,target_power=target,weight=m,normalized_ratio=str(ratio)))
                        checks+=1
    # Non-power full plane ideals, including a shape whose fullness needs
    # a generic mixed direction rather than a preferred monomial axis.
    def minimize(gens):
        gens=sorted(set(gens),reverse=True)
        return tuple(g for g in gens if not any(h!=g and h[0]<=g[0] and h[1]<=g[1] for h in gens))
    for J in [((4,0),(1,1),(0,2)),((4,0),(2,1),(1,2),(0,4))]:
        assert len(J)==min(sum(g) for g in J)+1
        for q in [2,3,4]:
            gens=[(2,0,0),(0,2,0),(0,0,1)];current=J;local={}
            for step in [0,1,2]:
                row=packet_for_ideal(q,gens,current);row['padding_step']=step
                assert len(current)==len(J)+step
                if row['status']=='PASS':local[step]=row;rows.append(row)
                else:skipped.append(row)
                current=minimize([(x+1,y) for x,y in current]+[(x,y+1) for x,y in current])
            for step,targetrow in local.items():
                if not step or 0 not in local:continue
                source=local[0];g=source['nonplane_generators'];k=source['nonplane_length']
                for m in [g+1,g+3]:
                    z=sum(n*q**(int(mu)*m) for mu,n in source['generator_histogram'].items())
                    zz=sum(n*q**(int(mu)*m) for mu,n in targetrow['generator_histogram'].items())
                    ratio=Fraction(z,zz)*Fraction(q**max(step*m-k,0),q**max(k-step*m,0))
                    assert ratio<=4
                    comparisons.append(dict(q=q,nonpower_source=J,padding_step=step,weight=m,normalized_ratio=str(ratio)))
                    checks+=1
    return checks,rows,comparisons,skipped


def main():
    start=time.monotonic();hom_count,hom=hom_controls()
    print('Planar Hom comparison controls PASS:',hom_count,flush=True)
    packet_count,packets,comparisons,skipped=packet_controls()
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),planar_Hom_inequalities=hom_count,planar_modules=hom,
                actual_M3_packets=packets,packet_weight_comparisons=packet_count,weight_cases=comparisons,
                explicitly_not_enumerated_packets=skipped,
                total_enumerated_packet_members=sum(row['packet_members'] for row in packets),
                scope='Exact finite-field computations, including F4 multiplication, of arbitrary rectangle modules and their Matlis duals, and complete actual-M3 packets via its free nonplane Jacobi kernel. These checks do not imply asymptotics.')
    (ROOT/'packet_comparison_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['planar_modules','actual_M3_packets','weight_cases']},ensure_ascii=False,indent=2))


if __name__=='__main__':main()

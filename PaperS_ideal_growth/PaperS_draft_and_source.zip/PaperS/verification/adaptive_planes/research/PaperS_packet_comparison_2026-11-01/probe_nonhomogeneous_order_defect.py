"""Falsification of the UNPROVED defect bound using nonhomogeneous plane ideals.

Quotients are exact truncated polynomial algebras (m^N is a generator).
Hom(J,L) is computed from finite-length duality, not from a chosen
Hilbert--Burch matrix: dim Hom(J,L)=len L+len(D(S/J) tensor L).
"""
from pathlib import Path
from functools import lru_cache
import importlib.util
import json
import random
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('binary_linear_algebra',ROOT.parent/'PaperS_joint_normals_2026-11-01'/'check_joint_normal.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)


@lru_cache(None)
def monomials(N):return tuple((a,d-a) for d in range(N) for a in range(d,-1,-1))


def quotient(polys,N,j):
    bound=N+j;labels=monomials(bound);index={p:i for i,p in enumerate(labels)};relations=[]
    for poly in polys:
        order=min(sum(m) for m in poly)
        for k in range(j+1):
            # Multipliers of exact degree j, followed by arbitrary monomials.
            for x,y in monomials(bound-order-j):
                vector=0
                for a,b in poly:
                    pos=index.get((a+k+x,b+j-k+y))
                    if pos is not None:vector^=1<<pos
                relations.append(vector)
    basis=h.canonical(relations);pivots={(b&-b).bit_length()-1 for b in basis};free=[i for i in range(len(labels)) if i not in pivots]
    newindex={old:i for i,old in enumerate(free)};actions=[]
    for axis in range(2):
        cols=[]
        for old in free:
            a,b=labels[old];pos=index.get((a+int(axis==0),b+int(axis==1)))
            reduced=h.reduce(0 if pos is None else 1<<pos,basis);out=0
            while reduced:
                low=reduced&-reduced;out^=1<<newindex[low.bit_length()-1];reduced^=low
            cols.append(out)
        actions.append(tuple(cols))
    size=len(free)
    soc=size-len(h.canonical(x|(y<<size) for x,y in zip(*actions)))
    for e in range(size):assert h.linear(actions[0],actions[1][e])==h.linear(actions[1],actions[0][e])
    return dict(length=size,socle=soc,mu=soc+1,actions=tuple(actions))


def transpose(cols):
    n=len(cols)
    return tuple(sum(((cols[i]>>j)&1)<<i for i in range(n)) for j in range(n))


def hom_ideal(A,L):
    a=A['length'];l=L['length'];dual=tuple(transpose(op) for op in A['actions']);relations=[]
    for axis in range(2):
        for i in range(a):
            for k in range(l):
                vector=L['actions'][axis][k]<<(i*l);x=dual[axis][i]
                while x:
                    low=x&-x;vector^=1<<((low.bit_length()-1)*l+k);x^=low
                relations.append(vector)
    return l+a*l-len(h.canonical(relations))


def main():
    start=time.monotonic();rng=random.Random(2026110110);sources=[];targets=[]
    for a,N,count in [(2,5,32),(3,6,32),(4,7,24)]:
        candidates=[m for m in monomials(N) if sum(m)>=a]
        for z in range(count):
            polys=[]
            for k in range(2+z%4):
                poly=[m for m in candidates if rng.randrange(4)==0]
                if not any(sum(m)==a for m in poly):poly.append((a,0))
                poly=tuple(sorted(set(poly)))
                polys.append(poly)
            # m^N is imposed by truncation, so the generators above define
            # an origin-primary ideal without any radical assumption.
            local=[quotient(polys,N,j) for j in range(4)]
            b=a+1-local[0]['mu'];assert b>=0
            sources.append(dict(order=a,cutoff=N,polys=polys,b=b,quotients=local))
    # Targets include random nonhomogeneous quotients and their exact duals.
    for src in sources[:16]+sources[32:40]:
        L=src['quotients'][0];targets.append(L)
        ops=tuple(transpose(op) for op in L['actions']);size=L['length']
        soc=size-len(h.canonical(x|(y<<size) for x,y in zip(*ops)))
        targets.append(dict(length=size,socle=soc,mu=None,actions=ops))
    checks=0;bad=[];saturated=[]
    for si,src in enumerate(sources):
        a=src['order'];b=src['b'];A0=src['quotients'][0];v=A0['mu']
        for li,L in enumerate(targets):
            initial=hom_ideal(A0,L);u=L['length']-L['socle']
            for j in range(1,4):
                Aj=src['quotients'][j];later=hom_ideal(Aj,L)
                loss=(Aj['mu']-v)*L['socle']-(later-initial);bound=(b+1)*u;checks+=1
                if loss>bound:
                    bad.append(dict(source_index=si,source_order=a,order_defect=b,generators=v,polys=src['polys'],cutoff=src['cutoff'],
                                    source_length=A0['length'],target_index=li,module_length=L['length'],module_socle=L['socle'],j=j,
                                    target_plane_mu=Aj['mu'],source_Hom=initial,target_Hom=later,loss=loss,candidate_bound=bound))
                    if len(bad)>=4:break
                if b and loss==bound and bound and len(saturated)<4:
                    saturated.append(dict(source=si,target=li,order_defect=b,j=j,loss=loss,bound=bound))
            if len(bad)>=4:break
        if len(bad)>=4:break
    result=dict(status='COUNTEREXAMPLE' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',seconds=round(time.monotonic()-start,3),field=2,
                random_nonhomogeneous_sources=len(sources),target_modules=len(targets),checked_inequalities=checks,
                counterexamples=bad,saturated_examples=saturated,
                source_summaries=[dict(order=s['order'],cutoff=s['cutoff'],order_defect=s['b'],lengths=[q['length'] for q in s['quotients']],generator_numbers=[q['mu'] for q in s['quotients']]) for s in sources],
                mathematical_status='UNPROVED conjecture. Exact randomized finite ideals, not exhaustive; no use as a theorem input.')
    (ROOT/'nonhomogeneous_order_defect_probe_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='source_summaries'},ensure_ascii=False,indent=2))


if __name__=='__main__':main()

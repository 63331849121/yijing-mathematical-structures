"""Falsification probe for an UNPROVED order-defect Hom bound.

PASS means only that the enumerated monomial cases contain no violation.
The general statement is not an input to any theorem in this directory.
"""
from pathlib import Path
from functools import lru_cache
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('plane_shapes',ROOT/'check_full_plane_hom.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def rank(columns):
    piv={}
    for v in columns:
        while v:
            p=v.bit_length()-1
            if p in piv:v^=piv[p]
            else:piv[p]=v;break
    return len(piv)


@lru_cache(None)
def target(part,dual):
    labels=tuple((x,y) for y,width in enumerate(part) for x in range(width));idx={m:i for i,m in enumerate(labels)}
    delta=-1 if dual else 1
    acts=tuple(tuple(idx.get((x+delta*int(axis==0),y+delta*int(axis==1))) for x,y in labels) for axis in range(2))
    soc=sum(acts[0][i] is None and acts[1][i] is None for i in range(len(labels)))
    return len(labels),acts,soc


def hdim(J,part,dual):
    size,acts,soc=target(part,dual);v=len(J);columns=[]
    def shifted(axis,n,k):
        for _ in range(n):
            if k is None:break
            k=acts[axis][k]
        return k
    for l in range(v):
        for k in range(size):
            out=0
            if l<v-1:
                dest=shifted(1,J[l+1][1]-J[l][1],k)
                if dest is not None:out^=1<<(l*size+dest)
            if l:
                dest=shifted(0,J[l-1][0]-J[l][0],k)
                if dest is not None:out^=1<<((l-1)*size+dest)
            columns.append(out)
    return v*size-rank(columns)


def main():
    start=time.monotonic()
    source=[p for n in range(1,15) for p in c.partitions(n)]
    modules=[p for n in range(1,8) for p in c.partitions(n)]
    total=0;bad=[];saturated=[];maxratio=0
    for shape in source:
        J=c.ideal_of(shape);v=len(J);a=min(sum(g) for g in J);b=a+1-v
        assert b>=0
        padded=[];current=J
        for j in [1,2,3,4]:current=c.times_n(current);padded.append((j,current))
        for part in modules:
            for dual in [False,True]:
                size,acts,soc=target(part,dual);u=size-soc;initial=hdim(J,part,dual)
                for j,J1 in padded:
                    later=hdim(J1,part,dual);loss=(len(J1)-v)*soc-(later-initial)
                    bound=(b+1)*u;total+=1
                    if u:maxratio=max(maxratio,loss/u)
                    if loss>bound:
                        bad.append(dict(source_partition=shape,J=J,order=a,generators=v,order_defect=b,
                                        target_partition=part,dual=dual,j=j,padded_J=J1,
                                        loss=loss,candidate_bound=bound))
                        if len(bad)>=6:break
                    if b and loss==bound and bound and len(saturated)<6:
                        saturated.append(dict(source_partition=shape,J=J,order_defect=b,target_partition=part,dual=dual,j=j,loss=loss,bound=bound))
                if len(bad)>=6:break
            if len(bad)>=6:break
        if len(bad)>=6:break
    result=dict(status='COUNTEREXAMPLE' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',seconds=round(time.monotonic()-start,3),
                field=2,source_partitions=len(source),target_partitions=len(modules),checked_inequalities=total,
                conjecture='Hom(n^j J,L)-Hom(J,L) >= (mu(n^j J)-mu(J))*soc(L) - (ord(J)+2-mu(J))*(len(L)-soc(L))',
                counterexamples=bad,saturated_nonfull_examples=saturated,max_loss_per_nonsocle_dimension=maxratio,
                mathematical_status='UNPROVED conjecture; this probe is not a proof and is not used in the completed packet theorem.')
    (ROOT/'order_defect_probe_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()

"""Falsify a stronger, UNPROVED width-sensitive Hom comparison.

Candidate loss <= u + b*w, with u=len(L)-soc(L) and
w=dim(Soc(L) intersect ell*L) for a generic linear ell.
Generic pencil ranks are exact over F2(t): evaluate in a verified extension
whose degree exceeds all matrix-minor degrees. No genericity heuristic.
"""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('general_targets',ROOT/'probe_general_target_modules.py')
z=importlib.util.module_from_spec(spec);spec.loader.exec_module(z)
h=z.h;c=z.c
DEG=32;MOD=(1<<DEG)|0x8D;MASK=(1<<DEG)-1


def mul(a,b):
    out=0
    while b:
        if b&1:out^=a
        b>>=1;a<<=1
        if a>>DEG:a^=MOD
    return out


def rem(a,b):
    while a and a.bit_length()>=b.bit_length():a^=b<<(a.bit_length()-b.bit_length())
    return a


def gcd(a,b):
    while b:a,b=b,rem(a,b)
    return a


def verify_field():
    t=2
    for k in range(1,DEG+1):
        t=mul(t,t)
        if k==DEG//2:assert gcd(t^2,MOD)==1
    assert t==2


def inv(a):
    assert a;u,v=a,MOD;g1,g2=1,0
    while u!=1:
        j=u.bit_length()-v.bit_length()
        if j<0:u,v=v,u;g1,g2=g2,g1;j=-j
        u^=v<<j;g1^=g2<<j
    return rem(g1,MOD)


def pencil_rank(X,Y):
    n=len(X);assert n<DEG
    piv={}
    for x,y in zip(X,Y):
        row=[((x>>i)&1)^(((y>>i)&1)<<1) for i in range(n)]
        for i in range(n):
            if not row[i]:continue
            if i in piv:
                scale=row[i];old=piv[i]
                for j in range(i,n):row[j]^=mul(scale,old[j])
            else:
                scale=inv(row[i]);row=[mul(a,scale) for a in row];piv[i]=row;break
    return len(piv)


def generic_width(L):
    n=L['length'];X,Y=L['actions'];soc=h.ker(tuple(1<<i for i in range(n)),[x|(y<<n) for x,y in zip(X,Y)])
    assert len(soc)==L['socle']
    piv={(v&-v).bit_length()-1 for v in soc};free=[i for i in range(n) if i not in piv];idx={a:i for i,a in enumerate(free)}
    quotient=[]
    for op in [X,Y]:
        local=[]
        for i in free:
            v=h.reduce(op[i],soc);out=0
            while v:
                low=v&-v;out|=1<<idx[low.bit_length()-1];v^=low
            local.append(out)
        quotient.append(tuple(local))
    w=pencil_rank(X,Y)-pencil_rank(*quotient)
    assert 0<=w<=min(L['socle'],n-L['socle'])
    return w


def main():
    start=time.monotonic();verify_field();rng=random.Random(2026110201);targets=[];seen=set()
    for r,N in [(2,3),(2,4),(3,3)]:
        for i in range(40):
            L=z.make_module(r,N,rng,1+i%5,1+i%2)
            for Q in [L,z.module(tuple(z.z.transpose(op) for op in L['actions']))]:
                if 2<=Q['length']<=25 and Q['top']>=2 and Q['socle']>=2 and Q['actions'] not in seen:
                    seen.add(Q['actions']);Q['generic_width']=generic_width(Q);targets.append(Q)
    # Add cyclic and dual-cyclic targets, including long one-variable strings.
    for n in range(1,9):
        for p in c.partitions(n):
            labels=tuple((x,y) for y,width in enumerate(p) for x in range(width));idx={m:i for i,m in enumerate(labels)}
            actions=tuple(tuple(0 if (x+int(a==0),y+int(a==1)) not in idx else
                                1<<idx[(x+int(a==0),y+int(a==1))] for x,y in labels) for a in range(2))
            for op in [actions,tuple(z.z.transpose(a) for a in actions)]:
                Q=z.module(op);Q['generic_width']=generic_width(Q);targets.append(Q)
    source=[c.ideal_of(p) for n in range(1,14) for p in c.partitions(n)]
    checks=0;bad=[];saturated=[]
    for J in source:
        b=min(sum(g) for g in J)+1-len(J);later=[];cur=J
        for j in range(1,4):cur=c.times_n(cur);later.append((j,cur))
        for li,L in enumerate(targets):
            initial=z.hom(J,L);u=L['length']-L['socle'];bound=u+b*L['generic_width']
            for j,J1 in later:
                final=z.hom(J1,L);loss=(len(J1)-len(J))*L['socle']-(final-initial);checks+=1
                if loss>bound:
                    bad.append(dict(J=J,j=j,J_later=J1,b=b,target_index=li,target=L,initial_Hom=initial,final_Hom=final,loss=loss,bound=bound))
                    if len(bad)>=3:break
                if b and loss==bound and bound and len(saturated)<5:
                    saturated.append(dict(J=J,j=j,b=b,length=L['length'],socle=L['socle'],width=L['generic_width'],loss=loss))
            if len(bad)>=3:break
        if len(bad)>=3:break
    result=dict(status='COUNTEREXAMPLE' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',seconds=round(time.monotonic()-start,3),field=2,
                generic_rank_extension_degree=DEG,verified_irreducible_polynomial=hex(MOD),
                exact_generic_ranks=True,source_ideals=len(source),target_modules=len(targets),checked_inequalities=checks,
                candidate='effective Hom loss <= len(L)-soc(L) + (ord(J)+1-mu(J))*dim(Soc(L) intersect ell*L), generic ell',
                counterexamples=bad,saturated_examples=saturated,
                mathematical_status='UNPROVED stronger conjecture; finite falsification only, not an input to any theorem.')
    (ROOT/'refined_width_probe_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

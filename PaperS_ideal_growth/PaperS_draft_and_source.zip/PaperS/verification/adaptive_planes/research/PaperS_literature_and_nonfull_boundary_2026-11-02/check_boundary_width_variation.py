"""Exact controls for the PROVED boundary-width variation lemma.

All boundary subspaces over F2 are enumerated in four free-kernel models,
with one or two normal variables. This is distinct from testing the
unproved width-sensitive Hom conjecture.
"""
from pathlib import Path
from itertools import product
import importlib.util
import json
import time

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('generic_width',ROOT/'probe_refined_width_cost.py')
z=importlib.util.module_from_spec(spec);spec.loader.exec_module(z)
h=z.h
spec=importlib.util.spec_from_file_location('monomial_controls',ROOT/'check_literature_and_packet_boundary.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def quotient_actions(actions,relations):
    n=len(actions[0]);basis=h.canonical(relations);piv={(v&-v).bit_length()-1 for v in basis}
    free=[i for i in range(n) if i not in piv];idx={a:i for i,a in enumerate(free)};out=[]
    for op in actions:
        cols=[]
        for i in free:
            v=h.reduce(op[i],basis);w=0
            while v:
                low=v&-v;w|=1<<idx[low.bit_length()-1];v^=low
            cols.append(w)
        out.append(tuple(cols))
    return tuple(out)


def normal_module(actions):
    n=len(actions[0]);images=[sum(op[i]<<(k*n) for k,op in enumerate(actions[2:])) for i in range(n)]
    basis=h.ker(tuple(1<<i for i in range(n)),images);piv=[(v&-v).bit_length()-1 for v in basis]
    def coordinates(v):
        out=0
        for i,(row,p) in enumerate(zip(basis,piv)):
            if (v>>p)&1:v^=row;out|=1<<i
        assert not v
        return out
    ops=tuple(tuple(coordinates(h.linear(op,row)) for row in basis) for op in actions[:2])
    L=z.z.module(ops);L['width']=z.generic_width(L);L['u']=L['length']-L['socle']
    return L


def scalar_model(gens):
    r=len(gens[0]);m_gens=c.times_m(gens)
    bounds=[next(g[i] for g in m_gens if g[i] and all(g[j]==0 for j in range(r) if j!=i)) for i in range(r)]
    labels=tuple(p for p in product(*(range(a) for a in bounds)) if not c.contains(p,m_gens));idx={p:i for i,p in enumerate(labels)}
    n=len(labels)+1;G=tuple(1<<idx[g] for g in gens)+(1<<(n-1),);actions=[]
    for axis in range(r):
        local=[]
        for mon in labels:
            p=tuple(a+int(i==axis) for i,a in enumerate(mon));local.append(0 if p not in idx else 1<<idx[p])
        actions.append(tuple(local)+(0,))
    return tuple(actions),G


def main():
    start=time.monotonic();z.verify_field();cases=[];checks=0
    configs=[[(0,0,1),(2,0,0),(1,1,0),(0,2,0)],
             [(0,0,2),(2,0,0),(0,2,0)],
             [(0,0,1),(3,0,0),(0,3,0),(2,2,0)],
             [(0,0,1,0),(0,0,0,1),(2,0,0,0),(1,1,0,0),(0,2,0,0)]]
    for gens in configs:
        actions,G=scalar_model(tuple(gens));c_normal=len(gens[0])-2;L0=normal_module(actions);local=0;maxdu=0;maxdw=0
        for D in h.subspaces(len(G)):
            rows=tuple(h.linear(G,v) for v in D);LD=normal_module(quotient_actions(actions,rows));a=len(D)
            assert LD['u']<=L0['u']+c_normal*a,(gens,D,L0,LD)
            assert LD['width']<=L0['width']+(c_normal+2)*a,(gens,D,L0,LD)
            local+=1;maxdu=max(maxdu,LD['u']-L0['u']);maxdw=max(maxdw,LD['width']-L0['width'])
        checks+=local
        cases.append(dict(scalar_ideal_generators=gens,normal_variables=c_normal,boundary_dimension=len(G),
                          initial_length=L0['length'],initial_socle=L0['socle'],initial_u=L0['u'],initial_width=L0['width'],
                          all_boundary_subspaces=local,max_increase_u=maxdu,max_increase_width=maxdw))
    result=dict(status='PASS',field=2,seconds=round(time.monotonic()-start,3),checked_boundary_subspaces=checks,cases=cases,
                scope='Exact finite controls for the independently proved variation lemma. No use of the unproved Hom conjecture.')
    (ROOT/'boundary_width_variation_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

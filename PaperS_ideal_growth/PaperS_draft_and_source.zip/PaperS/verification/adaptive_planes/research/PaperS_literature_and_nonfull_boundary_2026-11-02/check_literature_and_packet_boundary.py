"""Exact finite controls for the eleventh note; not a proof certification.

The scalar Fan counts use monomial enumeration. Actual M3 packet dimensions
use linear equations over F2, F3, F4; selected small packets are also fully
enumerated by the independent older packet routine.
"""
from pathlib import Path
from itertools import product
import importlib.util
import hashlib
import json
import re
import time
from fractions import Fraction

ROOT=Path(__file__).parent
OLD=ROOT.parent/'PaperS_packet_comparison_2026-11-01'
spec=importlib.util.spec_from_file_location('packet_controls',OLD/'check_packet_comparison.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def contains(u,gens):
    return any(all(a>=b for a,b in zip(u,g)) for g in gens)


def minimal(gens):
    gens=set(gens)
    return tuple(sorted((g for g in gens if not any(h!=g and all(a>=b for a,b in zip(g,h)) for h in gens)),reverse=True))


def times_m(gens):
    n=len(gens[0])
    return minimal(tuple(a+int(i==j) for i,a in enumerate(g)) for g in gens for j in range(n))


def fan_case(e,D,l):
    N=e*(D-1)+1;T=N-l
    pure=tuple(tuple(D*int(i==j) for i in range(e)) for j in range(e))
    box=list(product(range(D),repeat=e))
    gens=pure+tuple(u for u in box if sum(u)==T)
    next_gens=times_m(gens)
    outside=[u for u in box if sum(u)<T]
    for u in outside:
        assert any(not contains(tuple(a+int(i==j) for i,a in enumerate(u)),next_gens) for j in range(e))
    H=lambda t:sum(sum(u)==t for u in box)
    assert len(gens)==e+H(T)
    assert len(next_gens)==e*e+H(T+1)
    assert len(outside)==D**e-sum(H(i) for i in range(l))
    return dict(variables=e,power=D,colon_power=l,head=len(outside),mu=len(gens),mu_m=len(next_gens),basically_full=True)


def zigzag(r):
    gens=[(3*(r-i),3*i) for i in range(r+1)]
    gens +=[(3*(r-i)-1,3*i+2) for i in range(r)]
    return tuple(sorted(gens,reverse=True))


def packet_dimensions(q,J):
    """Independent constraints on section values and zero-boundary values."""
    f=c.Field(q);basis=((0,0,0),(1,0,0),(0,1,0));ki={m:i for i,m in enumerate(basis)}
    Q=((0,0,1),(2,0,0),(1,1,0),(0,2,0));qi={m:i for i,m in enumerate(Q)}
    v=len(J);relations=2*v-1;hom_cols=[];all_cols=[]
    for ell in range(v):
        for mon in basis:
            hom=[0]*(relations*3);boundary=[0]*(relations*5)
            # z times the chosen generator value.
            dest=(mon[0],mon[1],mon[2]+1)
            if dest in ki:hom[ell*3+ki[dest]]=1
            if dest in qi:boundary[ell*5+qi[dest]]=1
            if ell<v-1:
                dy=J[ell+1][1]-J[ell][1];dest=(mon[0],mon[1]+dy,0);row=v+ell
                if dest in ki:hom[row*3+ki[dest]]=1
                if dest in qi:boundary[row*5+qi[dest]]=1
            if ell:
                dx=J[ell-1][0]-J[ell][0];dest=(mon[0]+dx,mon[1],0);row=v+ell-1
                if dest in ki:hom[row*3+ki[dest]]=f.neg(1)
                if dest in qi:boundary[row*5+qi[dest]]=f.neg(1)
            hom_cols.append(tuple(hom));all_cols.append(tuple(hom+boundary))
    return v*3-f.rank(hom_cols),v*3-f.rank(all_cols)


def static_checks():
    p=ROOT/'literature_boundary_and_closed_packets.tex';raw=p.read_text(encoding='utf-8')
    code='\n'.join(re.split(r'(?<!\\)%',s)[0] for s in raw.splitlines());stack=[]
    for op,env in re.findall(r'\\(begin|end)\{([^}]+)\}',code):
        if op=='begin':stack.append(env)
        else:assert stack and stack.pop()==env
    assert not stack
    balance=0
    for a in re.sub(r'\\[{}]','',code):
        balance+=(a=='{')-(a=='}');assert balance>=0
    assert balance==0
    labels=re.findall(r'\\label\{([^}]+)\}',code);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',code)
    assert len(set(labels))==len(labels) and set(refs)<=set(labels)
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check_joint_normal_budget():
    data=json.loads((OLD/'packet_comparison_results.json').read_text(encoding='utf-8'))
    rows=data['actual_M3_packets'];checks=0;strict=0
    for src in rows:
        J=tuple(map(tuple,src['plane_generators']))
        if len(J)!=min(sum(g) for g in J)+1:continue
        gens=src['ideal_generators'];labels,_=c.scalar_quotient(gens)
        kz=sum(c.ideal_contains((x,y,z+1),gens) for x,y,z in labels)
        q=src['q'];g=src['nonplane_generators'];current=J
        for j in range(1,5):
            current=times_m(current)
            for dst in rows:
                if dst['q']!=q or dst['ideal_generators']!=gens or tuple(map(tuple,dst['plane_generators']))!=current:continue
                for m in [g+1,g+3]:
                    z1=sum(n*q**(int(mu)*m) for mu,n in src['generator_histogram'].items())
                    z2=sum(n*q**(int(mu)*m) for mu,n in dst['generator_histogram'].items())
                    ratio=Fraction(z1,z2)*Fraction(q**max(j*m-kz,0),q**max(kz-j*m,0))
                    assert ratio<=4,(src,dst,m,kz,ratio)
                    checks+=1;strict+=int(kz<len(labels))
    return dict(status='PASS',weighted_comparisons=checks,strictly_smaller_cost_cases=strict,
                note='Reuses already fully enumerated packet histograms; tests the new joint-normal-head budget.')


def main():
    start=time.monotonic();fans=[fan_case(*p) for p in [(3,7,7),(3,8,7),(3,9,7),(4,5,5),(5,4,5),(5,5,5)]]
    assert (fans[0]['head'],fans[0]['mu'],fans[0]['mu_m'])==(259,31,30)
    assert (fans[4]['head'],fans[4]['mu'],fans[4]['mu_m'])==(903,70,60)
    rows=[]
    for r in range(1,13):
        J=zigzag(r);J1=times_m(J);J2=times_m(J1)
        assert len(J)==2*r+1 and len(J1)==2*r+2 and len(J2)==3*r+3
        assert set(J2)=={(3*r+2-i,i) for i in range(3*r+3)}
        for x,y in product(range(3*r),repeat=2):
            if not contains((x,y),J):assert not(contains((x+1,y),J1) and contains((x,y+1),J1))
        for q in [2,3,4]:
            hs,ds=packet_dimensions(q,J);ht,dt=packet_dimensions(q,J1)
            assert (hs,ds,ht,dt)==(5*r+3,2*r+2,4*r+4,r+1),(q,r,hs,ds,ht,dt)
            rows.append(dict(field=q,r=r,source_Hom=hs,source_max_generator_parameter_dimension=ds,
                             target_Hom=ht,target_max_generator_parameter_dimension=dt,scaled_weighted_limit_exponent=ds-dt))
    enumeration=[]
    for q,r in [(2,1),(2,2),(3,1)]:
        J=zigzag(r);gens=[(0,0,1),(2,0,0),(1,1,0),(0,2,0)]
        for name,jj,expected_mu,expected_dim in [('source',J,2*r+6,2*r+2),('target',times_m(J),2*r+7,r+1)]:
            row=c.packet_for_ideal(q,gens,jj);assert row['status']=='PASS'
            hist=row['generator_histogram'];assert max(hist)==expected_mu and hist[expected_mu]==q**expected_dim
            enumeration.append(dict(q=q,r=r,side=name,packet_members=row['packet_members'],histogram=hist))
    snap=json.loads((ROOT.parent/'PaperS_higher_rank_locality_2026-11-01'/'source_snapshot_updated.json').read_text(encoding='utf-8'))
    canonical=[]
    for name,meta in snap['files'].items():
        if name.endswith(('.tex','.pdf')):
            p=Path(snap['source'])/name
            if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=meta['sha256']:canonical.append(name)
    result=dict(status='PASS',date='2026-11-02',seconds=round(time.monotonic()-start,3),fan_controls=fans,
                actual_M3_linear_controls=rows,complete_packet_enumerations=enumeration,
                joint_normal_budget_controls=check_joint_normal_budget(),
                enumerated_packet_members=sum(a['packet_members'] for a in enumeration),proof_sha256=static_checks(),
                canonical_manuscript_changes_since_baseline=canonical,main_manuscript_edits_performed=False,
                scope='Exact controls for stated finite cases; algebraic proof drafts remain subject to mathematical review. No general non-full Hom bound or global rank-five rate is asserted.')
    (ROOT/'boundary_controls.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['actual_M3_linear_controls','complete_packet_enumerations']},ensure_ascii=False,indent=2))
    print('Actual M3 linear cases:',len(rows),'; fully enumerated packets:',len(enumeration))


if __name__=='__main__':main()

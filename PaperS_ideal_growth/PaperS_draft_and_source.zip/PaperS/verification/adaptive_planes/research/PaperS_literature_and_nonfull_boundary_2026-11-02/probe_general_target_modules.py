"""Falsification search only: UNPROVED order-defect Hom comparison.

Extends earlier quotient/dual targets to quotients of rank-two and rank-three
free modules over truncated F2[x,y], including nonhomogeneous relations.
No claim follows from absence of a finite counterexample.
"""
from pathlib import Path
import importlib.util
import random
import json
import time

ROOT=Path(__file__).parent
OLD=ROOT.parent/'PaperS_packet_comparison_2026-11-01'
spec=importlib.util.spec_from_file_location('binary_probe',OLD/'probe_nonhomogeneous_order_defect.py')
z=importlib.util.module_from_spec(spec);spec.loader.exec_module(z)
h=z.h
spec=importlib.util.spec_from_file_location('source_shapes',OLD/'check_full_plane_hom.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def make_module(r,N,rng,relation_count,lowest):
    mon=z.monomials(N);labels=tuple((j,a,b) for j in range(r) for a,b in mon);idx={m:i for i,m in enumerate(labels)};n=len(labels)
    ops=[]
    for axis in range(2):
        ops.append(tuple(0 if (j,a+int(axis==0),b+int(axis==1)) not in idx else
                         1<<idx[(j,a+int(axis==0),b+int(axis==1))] for j,a,b in labels))
    candidates=[i for i,(j,a,b) in enumerate(labels) if a+b>=lowest]
    rel=[sum((rng.randrange(5)==0)<<i for i in candidates) for _ in range(relation_count)]
    basis=h.canonical(rel)
    while True:
        larger=h.canonical(list(basis)+[h.linear(op,v) for op in ops for v in basis])
        if len(larger)==len(basis):break
        basis=larger
    piv={(v&-v).bit_length()-1 for v in basis};free=[i for i in range(n) if i not in piv];fi={a:i for i,a in enumerate(free)}
    actions=[]
    for op in ops:
        local=[]
        for i in free:
            v=h.reduce(op[i],basis);w=0
            while v:
                low=v&-v;w|=1<<fi[low.bit_length()-1];v^=low
            local.append(w)
        actions.append(tuple(local))
    return module(tuple(actions))


def module(actions):
    n=len(actions[0]);soc=n-len(h.canonical(x|(y<<n) for x,y in zip(*actions)))
    top=n-len(h.canonical(actions[0]+actions[1]))
    for i in range(n):assert h.linear(actions[0],actions[1][i])==h.linear(actions[1],actions[0][i])
    return dict(length=n,socle=soc,top=top,actions=actions)


def hom(J,L):
    n=L['length'];v=len(J)
    cache={}
    def action(axis,p,i):
        key=(axis,p,i)
        if key not in cache:
            out=1<<i
            for _ in range(p):out=h.linear(L['actions'][axis],out)
            cache[key]=out
        return cache[key]
    cols=[]
    for ell in range(v):
        for i in range(n):
            out=0
            if ell<v-1:out^=action(1,J[ell+1][1]-J[ell][1],i)<<(ell*n)
            if ell:out^=action(0,J[ell-1][0]-J[ell][0],i)<<((ell-1)*n)
            cols.append(out)
    return v*n-len(h.canonical(cols))


def main():
    start=time.monotonic();rng=random.Random(2026110201);targets=[];seen=set()
    for r,N in [(2,3),(2,4),(3,3)]:
        for i in range(40):
            L=make_module(r,N,rng,1+i%5,1+i%2)
            for Q in [L,module(tuple(z.transpose(op) for op in L['actions']))]:
                key=Q['actions']
                if 2<=Q['length']<=25 and Q['top']>=2 and Q['socle']>=2 and key not in seen:
                    seen.add(key);targets.append(Q)
    source=[c.ideal_of(p) for n in range(1,12) for p in c.partitions(n)]
    checks=0;bad=[];maxratio=0.0
    for J in source:
        b=min(sum(g) for g in J)+1-len(J);later=[];current=J
        for j in range(1,4):current=c.times_n(current);later.append((j,current))
        for li,L in enumerate(targets):
            base=hom(J,L);u=L['length']-L['socle']
            for j,J1 in later:
                nxt=hom(J1,L);loss=(len(J1)-len(J))*L['socle']-(nxt-base);checks+=1
                if u:maxratio=max(maxratio,loss/((b+1)*u))
                if loss>(b+1)*u:
                    bad.append(dict(J=J,j=j,J_later=J1,order_defect=b,target_index=li,target=L,loss=loss,bound=(b+1)*u))
                    if len(bad)>=3:break
            if len(bad)>=3:break
        if len(bad)>=3:break
    result=dict(status='COUNTEREXAMPLE' if bad else 'NO_COUNTEREXAMPLE_IN_FINITE_PROBE',date='2026-11-02',
                seconds=round(time.monotonic()-start,3),field=2,seed=2026110201,source_ideals=len(source),target_modules=len(targets),
                checked_inequalities=checks,max_normalized_loss=maxratio,counterexamples=bad,
                target_summary=[dict(length=L['length'],top=L['top'],socle=L['socle']) for L in targets],
                mathematical_status='UNPROVED conjecture; finite randomized noncyclic/noncocyclic targets do not establish a theorem.')
    (ROOT/'general_target_probe_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='target_summary'},indent=2))


if __name__=='__main__':main()

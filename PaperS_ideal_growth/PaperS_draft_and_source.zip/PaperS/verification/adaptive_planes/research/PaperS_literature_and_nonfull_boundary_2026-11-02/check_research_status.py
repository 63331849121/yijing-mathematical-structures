"""Artifact consistency guard, not mathematical or priority certification."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).parent
proofs={}
for tex in ROOT.glob('*.tex'):
    raw=tex.read_text(encoding='utf-8');code='\n'.join(re.split(r'(?<!\\)%',s)[0] for s in raw.splitlines());stack=[]
    for op,env in re.findall(r'\\(begin|end)\{([^}]+)\}',code):
        if op=='begin':stack.append(env)
        else:assert stack and stack.pop()==env,tex.name
    assert not stack,tex.name
    balance=0
    for a in re.sub(r'\\[{}]','',code):
        balance+=(a=='{')-(a=='}');assert balance>=0,tex.name
    assert balance==0,tex.name
    labels=re.findall(r'\\label\{([^}]+)\}',code);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',code)
    assert len(set(labels))==len(labels) and set(refs)<=set(labels),(tex.name,set(refs)-set(labels))
    proofs[tex.name]=dict(static_status='PASS',sha256=hashlib.sha256(tex.read_bytes()).hexdigest(),
                         mathematical_status='Conditional packet reduction; Hom and near-extremal width inputs UNPROVED.' if tex.name.startswith('width_') else 'General proof drafts with classical attributions; independent mathematical review pending.')
controls={}
for script,result in [('check_literature_and_packet_boundary.py','boundary_controls.json'),('check_boundary_width_variation.py','boundary_width_variation_results.json')]:
    data=json.loads((ROOT/result).read_text(encoding='utf-8'));assert data['status']=='PASS'
    controls[result]=dict(status='PASS',script_sha256=hashlib.sha256((ROOT/script).read_bytes()).hexdigest(),result_sha256=hashlib.sha256((ROOT/result).read_bytes()).hexdigest())
probes={}
for script,result in [('probe_general_target_modules.py','general_target_probe_results.json'),('probe_refined_width_cost.py','refined_width_probe_results.json')]:
    data=json.loads((ROOT/result).read_text(encoding='utf-8'))
    probes[result]=dict(status=data['status'],mathematical_status='UNPROVED; finite falsification search only.',script_sha256=hashlib.sha256((ROOT/script).read_bytes()).hexdigest(),result_sha256=hashlib.sha256((ROOT/result).read_bytes()).hexdigest())
lit=ROOT.parent/'PaperS_packet_comparison_2026-11-01'/'literature'
sources=json.loads((lit/'intake_manifest.json').read_text(encoding='utf-8'))
for src in sources:assert hashlib.sha256((lit/src['file']).read_bytes()).hexdigest()==src['sha256']
snap=json.loads((ROOT.parent/'PaperS_higher_rank_locality_2026-11-01'/'source_snapshot_updated.json').read_text(encoding='utf-8'));changes=[]
for name,meta in snap['files'].items():
    p=Path(snap['source'])/name
    if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=meta['sha256']:changes.append(name)
status=dict(status='PASS',date='2026-11-02',stage=11,
            work_state='Proof drafts archived; width-sensitive plane Hom and near-extremal common-core width estimates remain open.',
            proof_sources=proofs,completed_finite_controls=controls,unproved_conjecture_probes=probes,
            literature_received_and_audited=[s['file'] for s in sources],original_pdfs_unchanged=True,
            canonical_manuscript_external_changes_since_old_baseline=changes,
            canonical_manuscript_edits_performed=False,canonical_manuscript_compilation_performed=False,
            latest_report='第十一阶段研究报告.txt',
            proved_draft_increments=['Joint-normal-head cost replaces the full nonplane quotient length under the existing plane-fullness hypothesis.',
                                    'A closed non-full family in actual M3 has unbounded normalized weighted-packet cost at fixed nonplane core length three.',
                                    'Boundary-subspace variation u_D<=u_0+c*dim D and w_D<=w_0+(c+2)*dim D.'],
            conditional_increment='Assuming the width Hom conjecture, a complete packet comparison with cost u_0+b*w_0+lambda*((c+1)*v_j-1) follows.',
            remaining_gaps=['General width-sensitive plane Hom inequality.',
                            'Near-extremal structural or weighted-probability control of the common-core width.',
                            'Global rank-five/six locality upper bounds, with complete asymptotic bookkeeping.'],
            no_claims=['Finite checks do not prove the Hom conjectures.','No unconditional rank-five/six rate.','No independent expert certification.','No priority claim for the classical scalar families or closure theory.'])
(ROOT/'research_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in status.items() if k not in ['proof_sources','completed_finite_controls','unproved_conjecture_probes']},ensure_ascii=False,indent=2))
print('Static sources:',len(proofs),'PASS; exact-control reports:',len(controls),'PASS; conjecture probes:',len(probes))

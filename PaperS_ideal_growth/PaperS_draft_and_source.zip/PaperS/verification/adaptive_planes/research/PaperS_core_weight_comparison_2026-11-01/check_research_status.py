"""Check research artifacts and ensure canonical TeX/PDF remain unchanged."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).parent
PREVIOUS=ROOT.parent/'PaperS_higher_rank_locality_2026-11-01'
snapshot=json.loads((PREVIOUS/'source_snapshot_updated.json').read_text(encoding='utf-8'))
source=Path(snapshot['source']); baseline=Path(snapshot['baseline'])
external=[]
for name,meta in snapshot['files'].items():
    current=source/name
    if not current.exists() or hashlib.sha256(current.read_bytes()).hexdigest()!=meta['sha256']:
        external.append(name)
    if name.endswith('.tex'):
        assert hashlib.sha256((baseline/name).read_bytes()).hexdigest()==meta['sha256']

checks={}
for name in ['core_weights_and_primary_extensions.tex','three_generator_locality_rate.tex']:
    raw=(ROOT/name).read_text(encoding='utf-8')
    text='\n'.join(re.split(r'(?<!\\)%',line)[0] for line in raw.splitlines())
    stack=[]
    for cmd,env in re.findall(r'\\(begin|end)\{([^}]+)\}',text):
        if cmd=='begin': stack.append(env)
        else: assert stack and stack.pop()==env,(name,cmd,env)
    assert not stack,name
    balance=0
    for c in re.sub(r'\\[{}]','',text):
        balance+=(c=='{')-(c=='}')
        assert balance>=0,name
    assert balance==0,name
    labels=re.findall(r'\\label\{([^}]+)\}',text)
    refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',text)
    assert len(labels)==len(set(labels)) and set(refs)<=set(labels),(name,set(refs)-set(labels))
    checks[name]={'status':'PASS','sha256':hashlib.sha256(raw.encode()).hexdigest(),
                  'scope':'Static TeX environments, braces, duplicate labels and internal references; no mathematical certification or PDF compilation.'}

controls={}
for script,result in [('check_core_weights.py','core_weight_results.json'),('check_planar_transport.py','planar_transport_results.json')]:
    data=json.loads((ROOT/result).read_text(encoding='utf-8'))
    assert data['status']=='PASS',result
    controls[result]={'status':'PASS','script_sha256':hashlib.sha256((ROOT/script).read_bytes()).hexdigest(),
                      'result_sha256':hashlib.sha256((ROOT/result).read_bytes()).hexdigest()}

status=dict(status='PASS',date='2026-11-01',stage=6,
            main_manuscript_edits_performed=False,manuscript_compilation_performed=False,
            frozen_34_page_baseline_verified=True,
            baseline_manuscript_matches_current=not any(x.endswith(('.tex','.pdf')) for x in external),
            external_changes_since_baseline=external,
            proof_sources=checks,finite_controls=controls,
            three_generator_locality_closure='General proof draft completed, conditional on the explicitly listed preceding research inputs; external specialist review pending.',
            main_results=['0 <= 1-pi_n <= q^(-n/2+O(n^(8/9))) for uniform ideals of F_3.',
                          'P_n/C_n=q^(-n/2+O(n^(2/3))); logarithmic rate 1/2.',
                          'Pointwise identical-origin-kernel comparison is impossible in the resolved bulk window.',
                          'Planar primary extensions preserve recoverable input cores and pay linear recovery fibers by generator gain.'],
            scope_exclusions=['No uniform-unmarked-type fine probability theorem.',
                              'No conclusion for free rank d>=4.',
                              'No matching lower exponent for 1-pi_n.',
                              'No external proof certification or exhaustive priority determination.'])
(ROOT/'research_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(status,ensure_ascii=False,indent=2))

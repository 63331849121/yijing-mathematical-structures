"""Independent exact finite controls of the planar-to-actual-M3 construction.

Checks planar maximal-ideal multiplication, exact padding length, actual
M3 preimages, and the generator gain used to pay the recovery fiber.
The infinite-parameter theorem is proved separately, not by these cases.
"""
from collections import Counter
from itertools import combinations, product
from pathlib import Path
import importlib.util
import json
import time

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('core_control_helpers', ROOT / 'check_core_weights.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
Field, mbasis, mult_columns = h.Field, h.mbasis, h.mult_columns
canonical, lin, full = h.canonical, h.lin, h.full


def pbase(d):
    return [(x, d-x) for x in range(d, -1, -1)]


def pmult(d, axis):
    target = {m:i for i,m in enumerate(pbase(d+1))}
    return tuple(tuple(int(j == target[x+int(axis==0),y+int(axis==1)]) for j in range(d+2)) for x,y in pbase(d))


def image_plane(f, degree, row):
    target = {m:i for i,m in enumerate(pbase(degree))}
    out = [0]*(degree+1)
    for coefficient, (tag,x,y,z) in zip(row,mbasis(degree)):
        if tag==0 and z==0:
            out[target[x,y]] = f.add(out[target[x,y]],coefficient)
    return tuple(out)


def remainder(f, row, basis):
    out = list(row)
    for b in basis:
        pivot = next(i for i,x in enumerate(b) if x)
        a = out[pivot]
        if a:
            out = [f.add(x,f.neg(f.mul(a,y))) for x,y in zip(out,b)]
    return tuple(out)


def preimage(f, degree, rows, target):
    if len(target)==degree+1:
        return rows
    if len(rows)==len(mbasis(degree)):
        labels=mbasis(degree)
        plane_indices=[i for i,(tag,x,y,z) in enumerate(labels) if tag==0 and z==0]
        plane_indices=sorted(plane_indices,key=lambda i: -labels[i][1])
        nonplane=[i for i in range(len(labels)) if i not in plane_indices]
        out=[tuple(int(i==j) for j in range(len(labels))) for i in nonplane]
        for row in target:
            lifted=[0]*len(labels)
            for i,a in zip(plane_indices,row): lifted[i]=a
            out.append(tuple(lifted))
        return tuple(out)
    rows = canonical(f,rows,len(mbasis(degree)))
    target = canonical(f,target,degree+1)
    for coordinate in range(degree+1):
        def value(v):
            return remainder(f,image_plane(f,degree,v),target)[coordinate]
        chosen = next((v for v in rows if value(v)),None)
        if chosen is None:
            continue
        inv = f.inv[value(chosen)]
        chosen = tuple(f.mul(inv,x) for x in chosen)
        rows = canonical(f,[tuple(f.add(x,f.neg(f.mul(value(v),y))) for x,y in zip(v,chosen)) for v in rows],len(mbasis(degree)))
    for v in rows:
        assert not any(remainder(f,image_plane(f,degree,v),target))
    return rows


def statistics(f, spaces, kind):
    length = generators = 0
    previous = ()
    for degree in sorted(spaces):
        current = spaces[degree]
        dim = degree+1 if kind=='plane' else len(mbasis(degree))
        length += dim-len(current)
        if degree:
            prevdim=degree if kind=='plane' else len(mbasis(degree-1))
            if len(current)==dim and len(previous)==prevdim:
                previous=current
                continue
            if kind=='plane':
                images = [lin(f,pmult(degree-1,i),v) for i in range(2) for v in previous]
            else:
                images = [lin(f,mult_columns(degree-1,i,f),v) for i in range(3) for v in previous]
            rank = f.rank(images)
            assert f.rank(list(current)+images)==len(current)
        else:
            rank=0
        generators += len(current)-rank
        previous=current
    return length,generators


def test_actual_module():
    reports=[]; checked=0
    for q,s in [(2,0),(3,0),(4,0),(2,1)]:
        f=Field(q); v=len(mbasis(s)); number=0; gains=Counter()
        for pivots,ann in h.old.rref_rows(v,1,q):
            V=h.basis_from_ann(f,v,pivots,ann)
            maxdegree=s+9
            I={d: (() if d<s else V if d==s else full(len(mbasis(d)))) for d in range(maxdegree+1)}
            J={d: (full(d+1) if len(I[d])==len(mbasis(d)) else canonical(f,[image_plane(f,d,row) for row in I[d]],d+1)) for d in range(maxdegree+1)}
            k,g=statistics(f,I,'module'); t0,v0=statistics(f,J,'plane')
            current=J; length_previous=t0; v_previous=v0
            for j in [1,2,3]:
                nxt={0:()}
                for d in range(1,maxdegree+1):
                    nxt[d]=canonical(f,[lin(f,pmult(d-1,i),row) for i in range(2) for row in current[d-1]],d+1)
                t1,v1=statistics(f,nxt,'plane')
                assert t1-length_previous==v_previous
                assert v1>=v_previous+1
                for residual in [0,1,2]:
                    padded=nxt.copy()
                    if residual:
                        axis_order=next(d for d in range(maxdegree+1) if any(row[0] for row in padded[d]))
                        end=axis_order+residual
                        assert end+1<maxdegree
                        for d in range(end):
                            padded[d]=h.hyperplane_section(f,padded[d],0,d+1)
                    tplus,vplus=statistics(f,padded,'plane')
                    assert tplus==t1+residual and vplus>=v1
                    Iplus={d:preimage(f,d,I[d],padded[d]) for d in range(maxdegree+1)}
                    kplus,gplus=statistics(f,Iplus,'module')
                    assert kplus-k==tplus-t0
                    assert gplus-g>=vplus-v0>=j
                    gains[(j,residual,gplus-g)]+=1
                    checked+=1
                current=nxt; length_previous=t1; v_previous=v1
            number+=1
        reports.append(dict(q=q,original_boundary_degree=s,input_primary_kernels=number,
                            lifted_padding_cases=number*9,
                            effective_generator_gain_histogram={f'j={j},remainder={r},gain={g}':v for (j,r,g),v in sorted(gains.items())},
                            status='PASS'))
    return checked,reports


def downsets(n):
    # Partitions represented as nonincreasing positive row lengths.
    def rec(left,cap):
        if not left:
            yield ()
        for x in range(min(left,cap),0,-1):
            for tail in rec(left-x,x):
                yield (x,)+tail
    yield from rec(n,n)


def monomial_generators(rows):
    D={(x,y) for y,width in enumerate(rows) for x in range(width)}
    if not D:
        return {(0,0)}
    border={(x+1,y) for x,y in D}|{(x,y+1) for x,y in D}
    return {m for m in border-D if all(tuple(m[i]-int(i==j) for i in range(2)) in D for j in range(2) if m[j])}


def minimize(gens):
    return {m for m in gens if not any(a!=m and a[0]<=m[0] and a[1]<=m[1] for a in gens)}


def combinatorial_planar_controls():
    cases=0
    for n in range(0,18):
        for rows in downsets(n):
            G=monomial_generators(rows)
            H=minimize({(x+1,y) for x,y in G}|{(x,y+1) for x,y in G})
            assert len(H)>=len(G)+1,(rows,G,H)
            maxx=max(x for x,y in H); maxy=max(y for x,y in H)
            length=sum(not any(a<=x and b<=y for a,b in H) for x in range(maxx+1) for y in range(maxy+1))
            assert length-n==len(G)
            cases+=1
    return cases


def weight_and_overshoot_controls():
    cases=0
    # Independent exact algebra for the new-head exponent, including overshoot.
    for head in [30,50]:
        for g in [8,15]:
            for m in [40,80]:
                for e in [0,1,5]:
                    for delta in [1,4,9]:
                        for da in [-2,0,3]:
                            A=head+g+2
                            actual=(A+e+delta)*(m-e-da)-A*m
                            formula=e*(m-A-e)+delta*(m-e)-(A+e+delta)*da
                            assert actual==formula
                            cases+=1
    return cases


def kernel_generator_number(f, actions, heads):
    # Compute Tor_1(W,k), the map Tor_1(M,k), and N/mN independently
    # from the Koszul complex of the actual M presentation.
    length=len(actions[0])
    d1=[col for cols in actions for col in cols]
    d2=[]
    for i,j in combinations(range(3),2):
        for w in full(length):
            out=[0]*(3*length)
            iw,jw=lin(f,actions[i],w),lin(f,actions[j],w)
            for a in range(length):
                out[j*length+a]=iw[a]
                out[i*length+a]=f.neg(jw[a])
            d2.append(tuple(out))
    r1,r2=f.rank(d1),f.rank(d2)
    c12,c13,c23=heads
    cycle=tuple(c23)+tuple(f.neg(a) for a in c13)+tuple(c12)
    assert not any(lin(f,d1,cycle))
    image=f.rank(d2+[cycle])-r2
    H1=3*length-r1-r2
    return H1-image+3-(length-r1)


def exact_recovery_sections():
    rows=[]; total=0
    for q in [2,3,4]:
        f=Field(q)
        # Output for I=mM, J=(X,Y), Jplus=(X,Y)^2:
        # Wplus has c12,c13,c23,Xc12,Yc12; the fiber is Hom(k^2,k^2).
        L=5; actions=[]
        for axis in range(3):
            cols=[[0]*L for _ in range(L)]
            if axis<2: cols[0][3+axis]=1
            actions.append(tuple(tuple(v) for v in cols))
        gplus=kernel_generator_number(f,actions,full(L)[:3])
        assert gplus==9
        histogram=Counter(); sections=set()
        for u,v,w,z in product(range(q),repeat=4):
            # A section sends a->a+u*c13+v*c23, b->b+w*c13+z*c23.
            sec=((0,u,v,1,0),(0,w,z,0,1))
            assert all(not any(lin(f,c,row)) for c in actions for row in sec)
            sections.add(sec)
            smaller=[]
            for axis in range(3):
                cols=[[0]*3 for _ in range(3)]
                if axis==0: cols[0]=[0,f.neg(u),f.neg(v)]
                if axis==1: cols[0]=[0,f.neg(w),f.neg(z)]
                smaller.append(tuple(tuple(row) for row in cols))
            g=kernel_generator_number(f,smaller,full(3))
            assert gplus>=g+1
            histogram[g]+=1; total+=1
        assert len(sections)==q**4
        rows.append(dict(q=q,exact_sections=q**4,Hom_dimension=4,
                         output_generator_number=gplus,
                         predecessor_generator_histogram=dict(histogram),status='PASS'))
    return total,rows


def main():
    start=time.monotonic()
    actual,reports=test_actual_module()
    print('Actual M3 planar padding and generator gains PASS',actual,flush=True)
    monomial=combinatorial_planar_controls()
    weights=weight_and_overshoot_controls()
    fibers,fiber_rows=exact_recovery_sections()
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
                actual_M3_lifted_padding_cases=actual,actual_M3_cases=reports,
                planar_monomial_ideal_checks=monomial,paid_weight_identity_checks=weights,
                exact_recovery_sections_checked=fibers,actual_M3_recovery_fibers=fiber_rows,
                scope='Finite algebraic controls. The asymptotic theorem is a separate general proof conditional on the explicitly listed Paper S inputs; no external certification.')
    (ROOT/'planar_transport_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()

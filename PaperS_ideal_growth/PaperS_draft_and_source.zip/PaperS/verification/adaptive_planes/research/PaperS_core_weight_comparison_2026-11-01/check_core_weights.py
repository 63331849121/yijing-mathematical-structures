"""Exact controls for the actual M_3 module and common-core comparisons.

The general arguments are in the companion proof, not inferred from these
finite checks. Arithmetic over F_4 uses its field multiplication. We use no
canonical manuscript verification code and never write to the manuscript.
"""
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path
import importlib.util
import json
import math
import time

ROOT = Path(__file__).parent
OLD = ROOT.parent / 'PaperS_higher_rank_locality_2026-11-01'
spec = importlib.util.spec_from_file_location('actual_m3_helpers', OLD / 'check_support_and_chain_coupling.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
Field, mbasis, mult_columns = old.Field, old.mbasis, old.mult_columns


def ceil_log(p, n):
    j, power = 0, 1
    while power < n:
        j += 1
        power *= p
    return j


def zero(n):
    return tuple(0 for _ in range(n))


def lin(f, cols, v):
    if not cols:
        return ()
    out = [0] * len(cols[0])
    for c, col in zip(v, cols):
        if c:
            out = [f.add(a, f.mul(c, b)) for a, b in zip(out, col)]
    return tuple(out)


def canonical(f, rows, n):
    basis = {}
    for row in rows:
        v = list(row)
        for j in sorted(basis):
            if v[j]:
                a = v[j]
                v = [f.add(x, f.neg(f.mul(a, y))) for x, y in zip(v, basis[j])]
        pivot = next((j for j, x in enumerate(v) if x), None)
        if pivot is None:
            continue
        a = f.inv[v[pivot]]
        v = tuple(f.mul(a, x) for x in v)
        for j, b in list(basis.items()):
            if b[pivot]:
                c = b[pivot]
                basis[j] = tuple(f.add(x, f.neg(f.mul(c, y))) for x, y in zip(b, v))
        basis[pivot] = v
    return tuple(basis[j] for j in sorted(basis))


def hyperplane_section(f, rows, index, n):
    rows = canonical(f, rows, n)
    chosen = next((v for v in rows if v[index]), None)
    if chosen is None:
        return rows
    chosen = tuple(f.mul(f.inv[chosen[index]], x) for x in chosen)
    return canonical(f, [tuple(f.add(x, f.neg(f.mul(v[index], y))) for x, y in zip(v, chosen))
                         for v in rows], n)


def full(n):
    return tuple(tuple(int(i == j) for j in range(n)) for i in range(n))


def basis_from_ann(f, n, pivots, ann):
    rows = []
    for j in range(n):
        if j in pivots:
            continue
        row = [0] * n
        row[j] = 1
        for i, pivot in enumerate(pivots):
            row[pivot] = f.neg(ann[i][j])
        rows.append(tuple(row))
    return canonical(f, rows, n)


def ray_family_controls():
    reports = []
    total = 0
    for q, s in [(2, 0), (3, 0), (4, 0), (2, 1)]:
        f = Field(q)
        v = len(mbasis(s))
        hist = Counter()
        fibers = Counter()
        predecessors = 0
        # All codimension-one subspaces in the actual M_s, not a rank-one toy.
        for pivots, ann in old.rref_rows(v, 1, q):
            V = basis_from_ann(f, v, pivots, ann)
            xindex = mbasis(s).index((0, s, 0, 0))
            u = s if any(row[xindex] for row in V) else s + 1
            h = s * (s + 1) * (2 * s + 7) // 6 + 1
            multiplication = [mult_columns(s, axis, f) for axis in range(3)]
            g = len(V) + len(mbasis(s + 1)) - f.rank([lin(f, cols, row) for cols in multiplication for row in V])
            predecessors += 1
            for ell in [1, 2, 3]:
                b = u + ell
                graded = {}
                for j in range(s, b + 2):
                    dim = len(mbasis(j))
                    original = V if j == s else full(dim)
                    xi = mbasis(j).index((0, j, 0, 0))
                    graded[j] = hyperplane_section(f, original, xi, dim) if j < b else original
                hplus, gplus = 0, 0
                previous = ()
                for j in range(b + 2):
                    dim = len(mbasis(j))
                    current = graded.get(j, ())
                    hplus += dim - len(current)
                    if j:
                        images = [lin(f, cols, row) for axis in range(3)
                                  for cols in [mult_columns(j - 1, axis, f)] for row in previous]
                        rank = f.rank(images)
                        # Verify multiplication stability, rather than just dimensions.
                        assert f.rank(list(current) + images) == len(current)
                    else:
                        rank = 0
                    gplus += len(current) - rank
                    previous = current
                assert hplus == h + ell
                assert gplus >= g + int(u == 0), (q, s, ell, g, gplus)
                hist[(ell, gplus - g)] += 1
                key = (u, b, tuple((j, graded[j]) for j in sorted(graded)))
                fibers[key] += 1
                total += 1
        max_fiber = max(fibers.values())
        for key, count in fibers.items():
            u = key[0]
            h = s * (s + 1) * (2 * s + 7) // 6 + 1
            assert count <= q ** (h - u)
        reports.append(dict(q=q, s=s, predecessors=predecessors,
                            extensions=3 * predecessors,
                            gain_histogram={f'ell={ell},gain={gain}': value for (ell, gain), value in sorted(hist.items())},
                            largest_observed_recovery_fiber=max_fiber, status='PASS'))
    return total, reports


def crt_controls():
    rows = []
    checks = 0
    for q, maxs in [(2, 4), (3, 3), (4, 3)]:
        f = Field(q)
        for s in range(1, maxs + 1):
            local_basis = [b for j in range(s + 1) for b in mbasis(j)]
            idx = {b: i for i, b in enumerate(local_basis)}
            away = [(i, j) for i in range(s) for j in range(s)]
            aidx = {b: i for i, b in enumerate(away)}
            nlocal = len(local_basis)
            size = nlocal + len(away)
            cols = []
            for axis in range(3):
                columns = []
                for tag, x, y, z in local_basis:
                    out = [0] * size
                    if x + y + z < s:
                        if tag == 2 and axis == 0:
                            out[idx[1, 0, y + 1, z]] = 1
                            out[idx[0, 0, y, z + 1]] = f.neg(1)
                        else:
                            powers = [x, y, z]
                            powers[axis] += 1
                            out[idx[(tag,) + tuple(powers)]] = 1
                    columns.append(tuple(out))
                for y, z in away:
                    out = [0] * size
                    yy, zz = y + int(axis == 1), z + int(axis == 2)
                    if yy < s and zz < s:
                        out[nlocal + aidx[yy, zz]] = 1
                    columns.append(tuple(out))
                cols.append(tuple(columns))
            generators = []
            for tag in range(3):
                out = [0] * size
                out[idx[tag, 0, 0, 0]] = 1
                if tag == 0:
                    out[nlocal + aidx[0, 0]] = 1
                elif tag == 2 and s > 1:
                    out[nlocal + aidx[0, 1]] = f.neg(1)
                generators.append(tuple(out))
            # Check the presentation relation and commutation on all basis vectors.
            terms = [lin(f, cols[2], generators[0]), lin(f, cols[1], generators[1]), lin(f, cols[0], generators[2])]
            assert all(f.add(f.add(x, f.neg(y)), z) == 0 for x, y, z in zip(*terms))
            for v in full(size):
                for i in range(3):
                    for j in range(i):
                        assert lin(f, cols[i], lin(f, cols[j], v)) == lin(f, cols[j], lin(f, cols[i], v))
                        checks += 1
            # CRT surjectivity: the displayed three generator images generate
            # the entire origin-plus-away module, not just each projection.
            span = canonical(f, generators, size)
            while True:
                images = [lin(f, c, v) for c in cols for v in span]
                larger = canonical(f, list(span) + images, size)
                if len(larger) == len(span):
                    break
                span = larger
            assert len(span) == size
            height = ceil_log(f.p, s + 2)
            P = f.p ** height
            def power(c, v, degree):
                for _ in range(degree):
                    v = lin(f, c, v)
                return v
            for gen in generators:
                first = power(cols[0], gen, f.p * P - 1)
                second = power(cols[0], gen, P - 1)
                assert first == second
                assert power(cols[1], gen, P - 1) == zero(size)
                assert power(cols[2], gen, P - 1) == zero(size)
                checks += 3
            k = s * (s + 1) * (2 * s + 7) // 6
            g = (s + 1) * (s + 3)
            assert size == k + g + s * s
            rows.append(dict(q=q, s=s, auxiliary_module_dimension=size,
                             original_head_dimension=k+s*s, origin_kernel_length=k,
                             away_length=s*s, origin_generator_number=g,
                             outer_dimension=3*height+1, CRT_span_rank=len(span),
                             centrality_error_rank=0, status='PASS'))
    return checks, rows


def weight_checks():
    count = 0
    for k, g, r, ell, t, m in product([2, 7, 13], [2, 5], [0, 1, 2], [1, 3, 9], [1, 2], [0, 4, 17]):
        A = k + g - r + 2
        a = t + 2
        n = a + k + ell + m
        delta = n - a - 2*k - g + r - 2
        direct = (A + ell)*m - A*(m + ell + t)
        predicted = ell*(delta - ell) - t*A
        assert direct == predicted
        assert Fraction(predicted) <= Fraction(max(delta, 0)**2, 4) - t*A
        count += 1
    # This is exact evaluation of the proved lower bound, not fitting data.
    growth = []
    for p in [2, 3, 5]:
        for s in [10, 100, 1000, 10000]:
            k = s*(s+1)*(2*s+7)//6
            g = (s+1)*(s+3)
            ell = s*s
            a = 3*ceil_log(p, s+2)+1
            A = k+g+2
            n = 2*k+g+2*ell+a+2
            advantage = ell*ell-a*A-3*s*(s+2)
            assert (A+ell)**2-A*(n-k)-3*s*(s+2) == advantage
            growth.append(dict(p=p,s=s,n=n,outer_dimension=a,
                               logarithmic_advantage_lower_bound_up_to_field_constant=advantage,
                               normalized_by_n_to_four_thirds=advantage/(n**(4/3)),
                               limiting_lower_bound_coefficient=(1.5)**(4/3),
                               direct_ray_extra_first_height=ceil_log(p,s+s*s)-ceil_log(p,s+2)))
    return count, growth


def main():
    start = time.monotonic()
    crt_count, crt = crt_controls()
    print('Actual M3 origin/away module and zero-error outer controls PASS', flush=True)
    ray_count, rays = ray_family_controls()
    print('Actual M3 primary ray extensions and observed recovery fibers PASS', flush=True)
    weights, growth = weight_checks()
    result = dict(status='PASS', seconds=round(time.monotonic()-start,3),
                  exact_weight_identity_cases=weights, actual_M3_CRT_identity_checks=crt_count,
                  actual_M3_CRT_cases=crt, primary_ray_extensions_checked=ray_count,
                  actual_M3_ray_cases=rays, explicit_obstruction_asymptotic_bounds=growth,
                  higher_rank_locality_rate_proved=False,
                  scope='Exact finite checks of actual M3 examples and elementary identities. General proofs and infinite families are in the companion TeX, not inferred from finite computations.')
    (ROOT/'core_weight_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()

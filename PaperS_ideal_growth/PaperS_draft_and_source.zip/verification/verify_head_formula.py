"""Check the exact head formula against direct skew-Hermite data counts.

Enumerate constant terms of canonical triangular generators, weighting
their higher coefficients. This does not use the Mobius formula to
construct the measured counts. It includes nonnilpotent quotients.
"""
from collections import defaultdict
from itertools import product
from pathlib import Path
import json
from verify_semilinear_blocks import Field

ROOT=Path(__file__).resolve().parent

def compositions(n,s):
    if s==1:
        yield (n,)
    else:
        for a in range(n+1):
            for tail in compositions(n-a,s-1):
                yield (a,)+tail

def gaussian(n,r,q):
    if not 0<=r<=n:
        return 0
    a=b=1
    for i in range(r):
        a*=q**(n-i)-1
        b*=q**(r-i)-1
    return a//b

def head_space(cols,f):
    # Canonical reduced row-echelon basis for the column span.
    rows=[list(c) for c in cols]
    pivot=0
    for j in range(len(cols)):
        nxt=next((i for i in range(pivot,len(rows)) if rows[i][j]),None)
        if nxt is None:
            continue
        rows[pivot],rows[nxt]=rows[nxt],rows[pivot]
        c=f.inv[rows[pivot][j]]
        rows[pivot]=[f.mul[c][x] for x in rows[pivot]]
        for i in range(len(rows)):
            if i==pivot or not rows[i][j]:
                continue
            c=rows[i][j]
            rows[i]=[f.add[x][f.mul[c][y]] for x,y in zip(rows[i],rows[pivot])]
        pivot+=1
    return tuple(tuple(row) for row in rows[:pivot])

def direct_count(q,s,b):
    f=Field(q)
    counts=defaultdict(int)
    for deg in compositions(b,s):
        free=[(i,j) for i,e in enumerate(deg) if e>0 for j in range(i+1)]
        weight=q**sum((i+1)*(e-1) for i,e in enumerate(deg) if e>0)
        for cs in product(range(q),repeat=len(free)):
            a=[[0]*s for _ in range(s)]
            for i,e in enumerate(deg):
                if e==0:
                    a[i][i]=1
            for (i,j),c in zip(free,cs):
                a[i][j]=c
            cols=tuple(tuple(a[i][j] for i in range(s)) for j in range(s))
            counts[head_space(cols,f)]+=weight
    return counts

def total_series(q,s,max_b):
    dp=[1]+[0]*max_b
    for i in range(1,s+1):
        for b in range(1,max_b+1):
            dp[b]+=q**i*dp[b-1]
    return dp

def main():
    rows=[]
    for q,max_s,max_b in ((2,4,5),(4,3,4)):
        for s in range(1,max_s+1):
            all_counts=total_series(q,s,max_b)
            measured={}
            max_ratio=0.0
            for b in range(max_b+1):
                h=direct_count(q,s,b)
                assert sum(h.values())==all_counts[b]
                grouped=defaultdict(list)
                for space,count in h.items():
                    grouped[s-len(space)].append(count)
                for k in range(s+1):
                    actual=0
                    if k<=b:
                        vals=grouped[k]
                        assert len(vals)==gaussian(s,k,q)
                        assert len(set(vals))==1
                        actual=vals[0]
                    expected=sum((-1)**j*q**(j*(j-1)//2)*gaussian(s-k,j,q)*
                                 (all_counts[b-k-j] if b>=k+j else 0)
                                 for j in range(s-k+1))
                    assert actual==expected,(q,s,b,k,actual,expected)
                    measured[b,k]=actual
                    if k<=b:
                        max_ratio=max(max_ratio,actual/q**(s*(b-k)))
                    if k>0:
                        rec=sum(gaussian(k,j,q)*q**((s-k)*j)*measured[b-k,j]
                                for j in range(min(k,b-k)+1)) if b>=k else 0
                        assert actual==rec,(q,s,b,k,'colon recursion')
            row={'q':q,'s':s,'max_colength':max_b,'all_heads_checked':True,
                 'mobius_formula':'PASS','colon_recursion':'PASS',
                 'max_observed_normalized_count':max_ratio}
            print(json.dumps(row),flush=True)
            rows.append(row)
    out={'status':'PASS','method':'direct enumeration of canonical skew-Hermite constant terms, with exact weights for higher coefficients',
         'cases':rows,'limitation':'Finite checks; general proof is in exact_prescribed_head_formula.tex. Not Lean.'}
    (ROOT/'head_formula_check.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':
    main()

"""Independent finite controls for the nilpotent automorphism factor.

Directly enumerate generator images and construct full matrices. The
formula under audit is used only to compare the resulting counts.
This is a bounded check, not a proof for arbitrary dimensions.
"""
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent

class Field:
    def __init__(self, q):
        self.q = q
        self.add = [[(a ^ b) if q == 4 else (a+b) % q
                     for b in range(q)] for a in range(q)]
        def mult(a,b):
            if q != 4:
                return a*b % q
            z = 0
            while b:
                if b & 1:
                    z ^= a
                b >>= 1
                a <<= 1
                if a & 4:
                    a ^= 7
            return z
        self.mul = [[mult(a,b) for b in range(q)] for a in range(q)]
        self.inv = [0] + [next(b for b in range(1,q)
                              if self.mul[a][b] == 1) for a in range(1,q)]
        self.sigma = [self.mul[a][a] if q == 4 else a for a in range(q)]

    def rank(self, cols):
        if not cols:
            return 0
        basis = {}
        for col in cols:
            v = list(col)
            for i in range(len(v)):
                if not v[i]:
                    continue
                if i in basis:
                    c = v[i]
                    row = basis[i]
                    for j in range(i, len(v)):
                        # Only characteristics two and three are tested.
                        term = self.mul[c][row[j]]
                        v[j] = self.add[v[j]][term] if self.q in (2,4) else (v[j]-term) % self.q
                else:
                    c = self.inv[v[i]]
                    basis[i] = tuple(self.mul[c][x] for x in v)
                    break
        return len(basis)

def partitions(n, top=None):
    if not n:
        yield ()
        return
    if top is None:
        top=n
    for a in range(min(n,top), 0, -1):
        for rest in partitions(n-a,a):
            yield (a,)+rest

def count_partition(field, lengths):
    n=sum(lengths)
    blocks=[]
    off=0
    for length in lengths:
        blocks.append(tuple(range(off, off+length)))
        off += length

    def t(v):
        out=[0]*n
        for block in blocks:
            for i,j in zip(block,block[1:]):
                out[j]=field.sigma[v[i]]
        return tuple(out)

    choices=[]
    for length in lengths:
        vectors=[]
        for v in product(range(field.q),repeat=n):
            powers=[v]
            for _ in range(length):
                powers.append(t(powers[-1]))
            if not any(powers[-1]):
                vectors.append(tuple(powers[:-1]))
        choices.append(vectors)

    end=units=0
    for images in product(*choices):
        columns=tuple(col for chain in images for col in chain)
        end+=1
        if field.rank(columns)==n:
            units+=1
    exponent=sum(min(a,b) for a in lengths for b in lengths)
    expected_end=field.q**exponent
    expected_units=Fraction(expected_end)
    for mult in Counter(lengths).values():
        for h in range(1,mult+1):
            expected_units *= 1-Fraction(1,field.q**h)
    assert end==expected_end
    assert units==expected_units
    k=len(lengths)
    lower=Fraction(field.q**(k*k))*(1-Fraction(1,field.q))**n
    assert units >= lower
    return dict(q=field.q, sigma=('square' if field.q==4 else 'identity'),
                lengths=lengths, endomorphisms=end, automorphisms=units,
                formula_verified=True)

def main():
    rows=[]
    for q, max_n in ((2,4),(3,3),(4,3)):
        f=Field(q)
        for n in range(1,max_n+1):
            for lengths in partitions(n):
                row=count_partition(f,lengths)
                rows.append(row)
                print(json.dumps(row),flush=True)
    result={'status':'PASS','check':'direct enumeration of semilinear nilpotent block endomorphisms',
            'case_count':len(rows),'cases':rows,
            'limitation':'Finite controls only; general proof is in the audit note. No Lean formalization.'}
    (ROOT/'semilinear_block_check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':
    main()

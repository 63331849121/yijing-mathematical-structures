"""Exact finite controls for the nilpotent ensemble and its giant-chain law.

Independent of Paper S's verification code. Uses only arithmetic helpers from
the new first research control. General assertions require the written proof.
"""
from collections import defaultdict
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import json
import time

from check_head_fitting import aut, partitions, phi, u_nil


@cache
def gaussian(n, r, q):
    if not 0 <= r <= n:
        return F(0)
    value = F(1)
    for j in range(r):
        value *= F(q ** (n - j) - 1, q ** (r - j) - 1)
    assert value.denominator == 1
    return value


@cache
def ph(n, q):
    return phi(n, q)


def check_q(q):
    sums_by_length = {}
    automorphism_identities = length_identities = 0
    normalized_sizes = head_cases = hook_cases = 0
    calibrations = []
    for m in range(29):
        by_length = defaultdict(F)
        remainder_law = defaultdict(F)
        for nu in partitions(m):
            a = aut(nu, q)
            by_length[len(nu)] += 1 / a
            if m:
                tau = nu[1:]
                k = sum(tau)
                remainder_law[tau] += ph(m, q) * q ** m / a
                if 2 * k < m:
                    assert a == q ** (m + k) * ph(1, q) * aut(tau, q)
                    automorphism_identities += 1
        assert sum(by_length.values(), F(0)) == F(1, q ** m) / ph(m, q)
        normalized_sizes += 1
        sums_by_length[m] = by_length
        if m:
            assert sum(remainder_law.values(), F(0)) == 1
            for r in range(1, m + 1):
                expected = F(1, q ** (r * m)) / ph(r, q) * gaussian(m - 1, r - 1, q)
                assert by_length.get(r, F(0)) == expected
                length_identities += 1
            # Compute total variation against the infinite limiting measure.
            # phi(100) substitutes for phi_infinity with error below 2^-99.
            if m in [8, 12, 20, 28]:
                limit_seen = F(0)
                distance_seen = F(0)
                for tau, prob in remainder_law.items():
                    limit = ph(100, q) / ph(1, q) / (q ** sum(tau) * aut(tau, q))
                    limit_seen += limit
                    distance_seen += abs(prob - limit)
                tv = (distance_seen + 1 - limit_seen) / 2
                assert tv >= 0
                # A generous uniform bound; no fit or estimated constant.
                assert tv <= 16 * F(1, q ** m)
                calibrations.append(dict(m=m, total_variation=float(tv),
                                         scaled_total_variation=float(tv * q ** m),
                                         hook_probability=float(remainder_law[()]),
                                         hook_limit=float(ph(100, q) / ph(1, q))))
    for h in range(1, 13):
        for m in range(21):
            s = h + 2
            weighted = sum((ph(h, q) / ph(h - r, q) * value
                            for r, value in sums_by_length[m].items() if r <= h), F(0))
            # Left: partition/automorphism enumeration. Right: the independent
            # prescribed-head generating function from the first control.
            assert q ** (s * m) * weighted == u_nil(s, h + m, h, q)
            head_cases += 1
            if m:
                hook = (m + 1,) + (1,) * (h - 1)
                # Here compute directly with the full partition lambda,
                # not its tail nu, to independently check the deleted-column
                # formula and the giant-chain limiting constant.
                lambda_count = F(q ** (s * m))
                lambda_count *= F(q ** (h * h)) * ph(h, q) / aut(hook, q)
                actual_hook = lambda_count / u_nil(s, h + m, h, q)
                A = F(u_nil(s, h + m, h, q), q ** ((s - 1) * m))
                expected_hook = (1 - F(1, q ** h)) / (ph(1, q) * A)
                assert actual_hook == expected_hook
                hook_cases += 1
    h, m, s = 30, 60, 35
    A = F(u_nil(s, h + m, h, q), q ** ((s - 1) * m))
    finite = []
    limiting = []
    for k in range(7):
        prob = F(0)
        for tau in partitions(k):
            nu = (m - k,) + tau
            assert nu[0] > max(tau, default=0)
            prob += F(q ** m, 1) / A * ph(h, q) / ph(h - len(nu), q) / aut(nu, q)
        finite.append(float(prob))
        limiting.append(float(ph(100, q) / ph(1, q) / (q ** (2 * k) * ph(k, q))))
    return dict(q=q, status='PASS', normalized_partition_sizes=normalized_sizes,
                length_identities=length_identities,
                unique_largest_row_aut_identities=automorphism_identities,
                prescribed_head_partition_sums=head_cases,
                hook_identities=hook_cases, total_variation_calibrations=calibrations,
                large_head_calibration=dict(h=h, m=m, remainder_size_probabilities=finite,
                                            limiting_probabilities=limiting))


def main():
    start = time.monotonic()
    cases = []
    for q in [2, 3, 4]:
        row = check_q(q)
        cases.append(row)
        print(json.dumps(row), flush=True)
    result = dict(status='PASS', seconds=round(time.monotonic() - start, 3), cases=cases,
                  scope='Exact finite partition controls; no simulation or proof of global ideal asymptotics.')
    (Path(__file__).parent / 'nil_condensation_results.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('ALL PASS', result['seconds'])


if __name__ == '__main__':
    main()

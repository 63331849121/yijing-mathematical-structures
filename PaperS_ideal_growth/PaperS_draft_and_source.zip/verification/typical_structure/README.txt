Exact controls for the typical-structure and locality results.
Use Python 3.12 or later; all five scripts use the standard library.
Run each check_*.py from this directory. It writes only its adjacent JSON report.
The mathematical statements and their general proofs are in Sections 7--10.
Detailed probability laws use uniform ideals, not uniform unmarked types.

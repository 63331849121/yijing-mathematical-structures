"""Read-only independent small semilinear quotient counts and exact identities.

Writes results only next to this new research file. Does not import Paper S code.
Finite controls do not prove the general statements in the companion note.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from math import prod
from pathlib import Path
import json
import time


class Field:
    def __init__(self, q):
        self.q = q
        self.p = 2 if q == 4 else q
        self.add = lambda a, b: a ^ b if q == 4 else (a + b) % q
        self.neg = lambda a: a if q == 4 else -a % q
        def mul(a, b):
            if q != 4:
                return a * b % q
            z = 0
            while b:
                if b & 1:
                    z ^= a
                a <<= 1
                b >>= 1
                if a & 4:
                    a ^= 7
            return z
        self.mul = mul
        self.inv = [0] + [next(b for b in range(1, q) if mul(a, b) == 1)
                         for a in range(1, q)]
        self.sigma = [mul(a, a) if q == 4 else a for a in range(q)]

    def rank(self, cols):
        basis = {}
        for col in cols:
            v = list(col)
            for j in range(len(v)):
                if not v[j]:
                    continue
                if j in basis:
                    c = v[j]
                    v = [self.add(x, self.neg(self.mul(c, y)))
                         for x, y in zip(v, basis[j])]
                else:
                    c = self.inv[v[j]]
                    basis[j] = tuple(self.mul(c, x) for x in v)
                    break
        return len(basis)

    def apply(self, cols, v):
        z = [0] * len(cols)
        for col, a in zip(cols, v):
            a = self.sigma[a]
            z = [self.add(x, self.mul(a, y)) for x, y in zip(z, col)]
        return tuple(z)


def gl(n, q):
    return prod(q ** n - q ** j for j in range(n))


def phi(n, q):
    return prod((1 - F(1, q ** j) for j in range(1, n + 1)), start=F(1))


def partitions(n, cap=None):
    if n == 0:
        yield ()
        return
    for a in range(min(n, n if cap is None else cap), 0, -1):
        for rest in partitions(n - a, a):
            yield (a,) + rest


def aut(part, q):
    columns = [sum(x >= j for x in part) for j in range(1, max(part, default=0) + 1)]
    return F(q ** sum(x * x for x in columns)) * prod(
        (phi(m, q) for m in Counter(part).values()), start=F(1))


def coeff_product(indices, n, q):
    dp = [1] + [0] * n
    for i in indices:
        for j in range(1, n + 1):
            dp[j] += q ** i * dp[j - 1]
    return dp


def u_all(s, b, h, q):
    if b < h or h > s:
        return 0
    dp = coeff_product(range(1, s + 1), b, q)
    for i in range(s - h):
        for j in range(b, 0, -1):
            dp[j] -= q ** i * dp[j - 1]
    return dp[b - h]


def u_nil(s, b, h, q):
    if b < h or h > s:
        return 0
    return coeff_product(range(s - h, s), b - h, q)[b - h]


def w(s, k, q):
    return 1 if k == 0 else (q ** s - 1) * q ** (s * (k - 1))


def predicted_partition_count(s, b, h, nu, q):
    ell, r = sum(nu), len(nu)
    if r > h or ell > b - h:
        return F(0)
    k = b - h - ell
    return q ** (s * ell) * phi(h, q) / phi(h - r, q) / aut(nu, q) * w(s, k, q)


def direct_matrix_case(q, b, s):
    """Count (semilinear T, marked generating tuple)/GL_b by enumeration.

    A fixed head kernel is the coordinate subspace on the first S-h inputs.
    The Fitting decomposition and nilpotent tail partition are read from ranks.
    """
    field = Field(q)
    vectors = list(product(range(q), repeat=b))
    measured = Counter()
    for flat in product(range(q), repeat=b * b):
        cols = tuple(tuple(flat[j * b + i] for i in range(b)) for j in range(b))
        image_rank = field.rank(cols)
        h = b - image_rank
        if h > s:
            continue
        iterated = [tuple(int(i == j) for i in range(b)) for j in range(b)]
        ranks = [b]
        for _ in range(b):
            iterated = [field.apply(cols, v) for v in iterated]
            ranks.append(field.rank(iterated))
        invdim = ranks[-1]
        lambdaprime = [ranks[j] - ranks[j + 1] for j in range(b)]
        lam = tuple(sum(x >= j for x in lambdaprime) for j in range(1, h + 1))
        nu = tuple(x - 1 for x in lam if x > 1)
        assert sum(nu) == b - invdim - h
        inside = [v for v in vectors if field.rank(cols + (v,)) == image_rank]
        for first in product(inside, repeat=s - h):
            for last in product(vectors, repeat=h):
                if field.rank(cols + last) != b:
                    continue
                inputs = first + last
                span = list(inputs)
                now = inputs
                for _ in range(b):
                    now = tuple(field.apply(cols, v) for v in now)
                    span.extend(now)
                if field.rank(span) == b:
                    measured[h, nu] += 1
    actual = {key: F(value, gl(b, q)) for key, value in measured.items()}
    for h in range(min(b, s) + 1):
        total = sum((v for (hh, _), v in actual.items() if hh == h), F(0))
        assert total == u_all(s, b, h, q), (q, s, b, h, total)
        niltotal = sum((v for (hh, nu), v in actual.items()
                        if hh == h and sum(nu) == b - h), F(0))
        assert niltotal == u_nil(s, b, h, q), (q, s, b, h, niltotal)
        for ell in range(b - h + 1):
            for nu in partitions(ell):
                expected = predicted_partition_count(s, b, h, nu, q)
                assert actual.get((h, nu), F(0)) == expected, (q, s, b, h, nu)
    return dict(q=q, dimension=b, generators=s, sigma='square' if q == 4 else 'identity',
                quotient_counts='PASS', nilpotent_counts='PASS', fitting_partition_counts='PASS')


def exact_identities():
    cases = 0
    for q in [2, 3, 4]:
        for s in range(1, 7):
            for h in range(s + 1):
                for m in range(11):
                    b = h + m
                    total = u_all(s, b, h, q)
                    conv = sum(u_nil(s, b - k, h, q) * w(s, k, q) for k in range(m + 1))
                    assert total == conv
                    marked = sum((predicted_partition_count(s, b, h, nu, q)
                                  for ell in range(m + 1) for nu in partitions(ell)), F(0))
                    assert marked == total
                    cases += 1
    return cases


def check_triangular_cores():
    cases = 0
    for h in range(1, 26):
        for rows in partitions(h):
            generators = [(rows[0], 0)]
            generators += [(rows[j], j) for j in range(1, len(rows))
                           if rows[j] < rows[j - 1]]
            generators.append((0, len(rows)))
            v = len(generators)
            assert all(a + b >= v - 1 for a, b in generators)
            assert h >= v * (v - 1) // 2
            for a in range(v - 1):
                for b in range(v - 1 - a):
                    assert b < len(rows) and a < rows[b]
            cases += 1
    return cases


def main():
    start = time.monotonic()
    rows = []
    for q, max_b, max_s in [(2, 3, 3), (3, 2, 2), (4, 2, 2)]:
        for b in range(max_b + 1):
            for s in range(1, max_s + 1):
                row = direct_matrix_case(q, b, s)
                print(json.dumps(row), flush=True)
                rows.append(row)
    number = exact_identities()
    staircase_cases = check_triangular_cores()
    approximations = []
    for q in [2, 3, 4]:
        h, m, s = 30, 30, 35
        denominator = u_all(s, h + m, h, q)
        ratio = F(u_nil(s, h + m, h, q) * q ** m, denominator)
        approx = [float(F(u_nil(s, h + ell, h, q) * w(s, m - ell, q), denominator))
                  for ell in range(6)]
        limit = [float(phi(120, q) * F(1, q ** ell) / phi(ell, q)) for ell in range(6)]
        approximations.append(dict(q=q, normalized_nil_ratio=float(ratio),
                                   excess_probabilities=approx, limiting_probabilities=limit))
    result = dict(status='PASS', seconds=round(time.monotonic() - start, 3),
                  direct_matrix_cases=rows, exact_identity_cases=number,
                  triangular_staircase_cases=staircase_cases,
                  convergence_calibrations=approximations,
                  scope='Finite independent controls; general concentration and asymptotics require the written proof.')
    (Path(__file__).parent / 'head_fitting_results.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k not in ['direct_matrix_cases']}, indent=2))


if __name__ == '__main__':
    main()

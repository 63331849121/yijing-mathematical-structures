"""Direct small restricted-algebra enumeration for the third Paper S note.

Enumerates labelled metabelian Lie brackets and compatible restricted maps,
counts actual generating tuples through their linear spans, and divides by
GL_n. Also classifies unmarked targets by actual change-of-basis orbits.
No Paper S verification code is used. The finite controls are not proofs of
asymptotic smoothness or of the uncomputed global nilpotence rate.
"""
from collections import Counter
from fractions import Fraction as F
from functools import cache
from itertools import product
from pathlib import Path
import json
import time

from check_head_fitting import Field, gl, u_all, u_nil


class Space:
    def __init__(self, q, n):
        self.q, self.n = q, n
        self.field = f = Field(q)
        self.size = q ** n
        self.coords = [tuple((v // q ** i) % q for i in range(n))
                       for v in range(self.size)]
        self.encode = lambda c: sum(x * q ** i for i, x in enumerate(c))
        self.add = [[self.encode(tuple(f.add(x, y) for x, y in zip(a, b)))
                     for b in self.coords] for a in self.coords]
        self.scale = [[self.encode(tuple(f.mul(a, x) for x in c))
                       for c in self.coords] for a in range(q)]
        self.basis = tuple(q ** i for i in range(n))
        self.full = (1 << self.size) - 1
        self.pairs = tuple((i, j) for i in range(n) for j in range(i + 1, n))

    @cache
    def elements(self, mask):
        return tuple(v for v in range(self.size) if mask >> v & 1)

    @cache
    def extend(self, mask, v):
        if mask >> v & 1:
            return mask
        out = mask
        for a in range(1, self.q):
            for x in self.elements(mask):
                out |= 1 << self.add[x][self.scale[a][v]]
        return out

    def span(self, values):
        mask = 1
        for v in values:
            mask = self.extend(mask, v)
        return mask

    @cache
    def linear_basis(self, mask):
        out, generated = [], 1
        for v in self.elements(mask):
            if not (generated >> v & 1):
                out.append(v)
                generated = self.extend(generated, v)
        assert generated == mask
        return tuple(out)

    def subspaces(self):
        found, todo = {1}, [1]
        while todo:
            mask = todo.pop()
            for v in range(1, self.size):
                nxt = self.extend(mask, v)
                if nxt not in found:
                    found.add(nxt)
                    todo.append(nxt)
        return sorted(found)

    def bracket_table(self, pair_values):
        f = self.field
        basic = [[0] * self.n for _ in range(self.n)]
        for (i, j), v in zip(self.pairs, pair_values):
            basic[i][j] = basic[j][i] = v  # characteristic two
        table = [[0] * self.size for _ in range(self.size)]
        for a in range(self.size):
            for b in range(self.size):
                z = 0
                for i, ai in enumerate(self.coords[a]):
                    for j, bj in enumerate(self.coords[b]):
                        z = self.add[z][self.scale[f.mul(ai, bj)][basic[i][j]]]
                table[a][b] = z
        return table

    def power_table(self, pair_values, basis_powers):
        out = []
        f = self.field
        for c in self.coords:
            z = 0
            for a, v in zip(c, basis_powers):
                z = self.add[z][self.scale[f.sigma[a]][v]]
            for (i, j), v in zip(self.pairs, pair_values):
                z = self.add[z][self.scale[f.mul(c[i], c[j])][v]]
            out.append(z)
        return out


def is_nil(v, powers, n):
    for _ in range(n):
        v = powers[v]
    return v == 0


def closed_span(sp, start, brackets, powers):
    while True:
        basis = sp.linear_basis(start)
        new = start
        for a in basis:
            new = sp.extend(new, powers[a])
            for b in basis:
                new = sp.extend(new, brackets[a][b])
        if new == start:
            return start
        start = new


def enumerate_dimension(q, n, ds):
    sp = Space(q, n)
    subs = sp.subspaces()
    all_counts = {d: Counter() for d in ds}
    labelled = {}
    split_cases = bad_inner_examples = noncentral_examples = 0
    bracket_cases = pmap_cases = 0
    for pair_values in product(range(sp.size), repeat=len(sp.pairs)):
        brackets = sp.bracket_table(pair_values)
        if any(sp.add[brackets[a][brackets[b][c]]][
                sp.add[brackets[b][brackets[c][a]]][brackets[c][brackets[a][b]]]]
               for a in sp.basis for b in sp.basis for c in sp.basis):
            continue
        derived = sp.span(brackets[a][b] for a in sp.basis for b in sp.basis)
        dbasis = sp.linear_basis(derived)
        if any(brackets[a][b] for a in dbasis for b in dbasis):
            continue
        bracket_cases += 1
        current = derived
        for _ in range(n + 1):
            nxt = sp.span(brackets[a][b] for a in sp.basis for b in sp.linear_basis(current))
            if nxt == current:
                break
            current = nxt
        ordinary_nil = current == 1
        center = sp.span(v for v in range(sp.size)
                         if all(brackets[a][v] == 0 for a in sp.basis))
        options = []
        for a in sp.basis:
            options.append([v for v in range(sp.size)
                            if all(brackets[v][b] == brackets[a][brackets[a][b]]
                                   for b in sp.basis)])
        for basis_powers in product(*options):
            powers = sp.power_table(pair_values, basis_powers)
            assert all(brackets[powers[a]][b] == brackets[a][brackets[a][b]]
                       for a in range(sp.size) for b in sp.basis)
            assert all(powers[sp.add[a][b]] ==
                       sp.add[sp.add[powers[a]][powers[b]]][brackets[a][b]]
                       for a in range(sp.size) for b in range(sp.size))
            pmap_cases += 1
            inner = closed_span(sp, derived, brackets, powers)
            assert all(brackets[a][b] == 0 for a in sp.linear_basis(inner)
                       for b in sp.linear_basis(inner))
            inner_nil = all(is_nil(v, powers, n) for v in sp.linear_basis(inner))
            whole_nil = all(is_nil(v, powers, n) for v in range(sp.size))
            assert not whole_nil or ordinary_nil and inner_nil
            loc = ordinary_nil and inner_nil
            k = None
            if loc:
                torus = sp.span(iterate(v, powers, n) for v in sp.elements(center))
                nilset = {v for v in range(sp.size) if is_nil(v, powers, n)}
                nilmask = sp.span(nilset)
                assert set(sp.elements(nilmask)) == nilset
                assert closed_span(sp, nilmask, brackets, powers) == nilmask
                assert all(brackets[a][b] in nilset for a in range(sp.size)
                           for b in sp.linear_basis(nilmask))
                assert torus & nilmask == 1
                assert sp.span(sp.elements(torus) + sp.elements(nilmask)) == sp.full
                assert all(brackets[a][b] == 0 for a in sp.elements(torus)
                           for b in range(sp.size))
                k = len(sp.linear_basis(torus))
                split_cases += 1
            if ordinary_nil and not inner_nil:
                bad_inner_examples += 1
            if inner_nil and not ordinary_nil:
                noncentral_examples += 1
            gen_counts = {d: 0 for d in ds}
            for mask in subs:
                if closed_span(sp, mask, brackets, powers) != sp.full:
                    continue
                r = len(sp.linear_basis(mask))
                for d in ds:
                    count = 1
                    for j in range(r):
                        count *= q ** d - q ** j
                    gen_counts[d] += count
            # Independent tuple calibration on one small field/dimension.
            if q == 2 and n == 2:
                direct = sum(closed_span(sp, sp.span(tup), brackets, powers) == sp.full
                             for tup in product(range(sp.size), repeat=2))
                assert direct == gen_counts[2]
            for d, count in gen_counts.items():
                all_counts[d]['all'] += count
                if inner_nil:
                    all_counts[d]['inner_nil'] += count
                if whole_nil:
                    all_counts[d]['nil'] += count
                if loc:
                    all_counts[d]['local_inner_nil'] += count
                    all_counts[d][f'torus_{k}'] += count
            signature = tuple(pair_values) + tuple(basis_powers)
            labelled[signature] = (brackets, powers, gen_counts, whole_nil, loc, k,
                                   derived == 1 and all(iterate(v, powers, n) != 0
                                                       for v in range(1, sp.size)))
    # Change-of-basis orbits of actual labelled algebra structures.
    transforms = []
    for columns in product(range(sp.size), repeat=n):
        if sp.span(columns) != sp.full:
            continue
        forward = []
        for c in sp.coords:
            z = 0
            for a, v in zip(c, columns):
                z = sp.add[z][sp.scale[a][v]]
            forward.append(z)
        inverse = [0] * sp.size
        for i, v in enumerate(forward):
            inverse[v] = i
        transforms.append((columns, inverse))
    assert len(transforms) == gl(n, q)
    unseen = set(labelled)
    type_counts = {d: Counter() for d in ds}
    orbits = 0
    while unseen:
        signature = next(iter(unseen))
        brackets, powers, gen_counts, nil, loc, k, inv_ab = labelled[signature]
        orbit = set()
        for columns, inv in transforms:
            changed = tuple(inv[brackets[columns[i]][columns[j]]] for i, j in sp.pairs)
            changed += tuple(inv[powers[v]] for v in columns)
            assert changed in labelled
            orbit.add(changed)
        assert orbit <= unseen
        unseen.difference_update(orbit)
        orbits += 1
        for d, count in gen_counts.items():
            if not count:
                continue
            type_counts[d]['all'] += 1
            if nil:
                type_counts[d]['nil'] += 1
            if inv_ab:
                type_counts[d]['invertible_abelian'] += 1
            if loc:
                type_counts[d]['local_inner_nil'] += 1
                type_counts[d][f'torus_{k}'] += 1
    counts = {}
    for d in ds:
        counts[d] = {}
        for key, value in all_counts[d].items():
            quotient = F(value, gl(n, q))
            assert quotient.denominator == 1, (q, n, d, key, quotient)
            counts[d][key] = int(quotient)
    return dict(q=q, n=n, bracket_structures=bracket_cases,
                restricted_structures=pmap_cases, unmarked_orbits=orbits,
                canonical_split_cases=split_cases,
                ordinary_nil_but_inner_not_nil_cases=bad_inner_examples,
                inner_nil_but_ordinary_not_nil_cases=noncentral_examples,
                ideal_counts=counts, type_counts={d: dict(v) for d, v in type_counts.items()})


def iterate(v, powers, n):
    for _ in range(n):
        v = powers[v]
    return v


def w(d, k, q):
    return 1 if k == 0 else (q ** d - 1) * q ** (d * (k - 1))


def check_ratios():
    cases = 0
    # Constants 1/4 and 16 enclose the product bounds for q>=2.
    for q in [2, 3, 4]:
        for s in range(1, 9):
            for h in range(1, s + 1):
                for m in range(13):
                    for nil, func in [(0, u_all), (1, u_nil)]:
                        ratio = F(func(s, h + m + 1, h, q), func(s, h + m, h, q))
                        normalized = ratio / q ** (s - nil)
                        assert F(1, 4) <= normalized <= 16
                        cases += 1
    return cases


def main():
    start = time.monotonic()
    rows, convolution_cases = [], 0
    for q, maxn, ds in [(2, 3, [1, 2, 3]), (4, 2, [1, 2])]:
        by_n = {}
        for n in range(maxn + 1):
            row = enumerate_dimension(q, n, ds)
            by_n[n] = row
            for d in ds:
                counts = row['ideal_counts'][d]
                types = row['type_counts'][d]
                for k in range(n + 1):
                    expected = by_n[n-k]['ideal_counts'][d].get('nil', 0) * w(d, k, q)
                    actual = counts.get(f'torus_{k}', 0)
                    assert actual == expected, ('marked', q, n, d, k, actual, expected)
                    expected_type = (by_n[n-k]['type_counts'][d].get('nil', 0)
                                     * by_n[k]['type_counts'][d].get('invertible_abelian', 0))
                    actual_type = types.get(f'torus_{k}', 0)
                    assert actual_type == expected_type, ('types', q, n, d, k, actual_type, expected_type)
                    convolution_cases += 2
            rows.append(row)
            print(json.dumps(row), flush=True)
    ratio_cases = check_ratios()
    result = dict(status='PASS', seconds=round(time.monotonic()-start, 3),
                  direct_algebra_enumerations=rows, refined_convolution_identities=convolution_cases,
                  exact_head_ratio_controls=ratio_cases,
                  scope='Complete small labelled-algebra and GL orbit enumeration, not a proof of asymptotic statements.')
    (Path(__file__).parent/'toral_convolution_results.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print('ALL PASS', result['seconds'], 'convolutions', convolution_cases, 'ratios', ratio_cases)


if __name__ == '__main__':
    main()

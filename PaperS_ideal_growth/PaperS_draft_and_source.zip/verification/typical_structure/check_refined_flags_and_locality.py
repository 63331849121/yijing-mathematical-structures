"""Exact monomial-flag tangent controls and rank-two locality comparisons.

The tangent equations are formed directly from module syzygies and the two
flag inclusions. They have the form coefficient=coefficient or coefficient=0;
their solution dimension is therefore independent of characteristic.
Finite controls do not prove the general locality theorem.
"""
from itertools import combinations, product
from pathlib import Path
import json
import time

from check_head_fitting import Field, partitions


def add(a, b):
    return (a[0]+b[0], a[1]+b[1])


def sub(a, b):
    return (a[0]-b[0], a[1]-b[1])


def divides(a, b):
    return a[0] <= b[0] and a[1] <= b[1]


def minimal(gens):
    # In ascending X exponent, a new generator is minimal precisely when
    # its Y exponent is smaller than all previous Y exponents.
    out, best = [], None
    for g in sorted(set(gens)):
        if best is None or g[1] < best:
            out.append(g)
            best = g[1]
    return tuple(out)


def generators(rows):
    if not rows:
        return ((0, 0),)
    return minimal([(rows[0], 0)] + [(rows[j], j) for j in range(1, len(rows))]
                   + [(0, len(rows))])


def standards(gens):
    if (0, 0) in gens:
        return ()
    A = min(a for a, b in gens if b == 0)
    B = min(b for a, b in gens if a == 0)
    return tuple((a, b) for b in range(B) for a in range(A)
                 if not any(divides(g, (a, b)) for g in gens))


class Equalities:
    def __init__(self, n):
        self.parent = list(range(n+1))
        self.zero = n

    def root(self, i):
        while self.parent[i] != i:
            self.parent[i] = self.parent[self.parent[i]]
            i = self.parent[i]
        return i

    def equate(self, a, b):
        a = self.zero if a is None else a
        b = self.zero if b is None else b
        self.parent[self.root(a)] = self.root(b)

    def dimension(self):
        return len({self.root(i) for i in range(len(self.parent))})-1


def tangent_dimension(I, J):
    SI, SJ = standards(I), standards(J)
    istd, jstd = set(SI), set(SJ)
    ids = {}
    for tag, gens, std in [('I', I, SI), ('J', J, SJ)]:
        for f in gens:
            for s in std:
                ids[tag, f, s] = len(ids)
    equations = Equalities(len(ids))

    def image(tag, f, shift, target):
        # A monomial multiplication is injective until a term vanishes.
        std = SI if tag == 'I' else SJ
        return {add(s, shift): ids[tag, f, s] for s in std if add(s, shift) in target}

    def match(left, right):
        for mon in left.keys() | right.keys():
            equations.equate(left.get(mon), right.get(mon))

    for tag, gens, std in [('I', I, istd), ('J', J, jstd)]:
        for f, g in combinations(gens, 2):
            lcm = (max(f[0], g[0]), max(f[1], g[1]))
            match(image(tag, f, sub(lcm, f), std), image(tag, g, sub(lcm, g), std))
    # Inclusion J in I.
    for g in J:
        f = next(f for f in I if divides(f, g))
        match(image('J', g, (0, 0), istd), image('I', f, sub(g, f), istd))
    # Inclusion (X,Y) I in J.
    for f in I:
        for axis in [(1, 0), (0, 1)]:
            xf = add(f, axis)
            g = next(g for g in J if divides(g, xf))
            match(image('J', g, sub(xf, g), jstd), image('I', f, axis, jstd))
    return equations.dimension()


def flags():
    cases = 0
    by_h = {}
    for h in range(13):
        count = 0
        for rows in partitions(h):
            I = generators(rows)
            v = len(I)
            # A monomial J between mI and I omits a chosen set of the
            # minimal generator heads, and contains all their X/Y multiples.
            for r in range(1, v+1):
                for omitted in combinations(I, r):
                    J = minimal([f for f in I if f not in omitted]
                                + [add(f, axis) for f in I for axis in [(1,0),(0,1)]])
                    assert len(standards(J))-h == r
                    actual = tangent_dimension(I, J)
                    expected = 2*h-r*(r-1)
                    assert actual == expected, (h, rows, r, I, J, actual, expected)
                    cases += 1
                    count += 1
        by_h[h] = count
    return cases, by_h


def ceil_log(n, p):
    k, value = 0, 1
    while value < n:
        k += 1
        value *= p
    return k


def stretched_models():
    cases = 0
    for p in [2, 3, 5, 7]:
        for g in range(30, 241):
            r = g-1
            for e in [0, 1, r-1, r, r+1, 2*r-1, 2*r, 5*r+3, 10*r-1]:
                t, u = divmod(e, r)
                rows = tuple(r-i+t+(i<u) for i in range(r))
                h = r*(r+1)//2+e
                assert sum(rows) == h and all(rows[i] > rows[i+1] for i in range(r-1))
                I = generators(rows)
                assert len(I) == g
                A, B = rows[0], r
                ax, ay = ceil_log(A+2, p), ceil_log(B+2, p)
                threshold = 2*ceil_log(g+1, p)
                assert ax+ay <= threshold+1, (p, g, e, ax, ay, threshold)
                # The two outer commutators lie in mI, not merely I.
                mI = minimal([add(f, axis) for f in I for axis in [(1,0),(0,1)]])
                assert any(divides(f, (p**ax-1, 0)) for f in mI)
                assert any(divides(f, (0, p**ay-1)) for f in mI)
                cases += 1
    return cases


def boundary_ranks():
    cases = 0
    minima = []
    for q, g in [(2,2), (2,4), (2,8), (3,3), (4,2), (4,4)]:
        f = Field(q)
        # Homogeneous degree g-2 polynomials a,b, with coefficient indexed
        # by X exponent. Vectors below are degree g-1 polynomials.
        polys = list(product(range(q), repeat=g-1))
        low = g+1
        for a in polys:
            for b in polys:
                Xa = (0,)+a
                Ya = list(a+(0,))
                Ya[-1] = f.add(Ya[-1], f.neg(1))
                Xb = list((0,)+b)
                Xb[0] = f.add(Xb[0], f.neg(1))
                Yb = b+(0,)
                rank = f.rank((Xa, tuple(Ya), tuple(Xb), Yb))
                assert rank >= 2, (q, g, a, b, rank)
                low = min(low, rank)
                cases += 1
        minima.append(dict(q=q, g=g, minimum_rank=low))
    return cases, minima


def energy_controls():
    cases = 0
    for p in [2,3,5]:
        for n in [10000,40000,90000]:
            root = int(n**0.5)
            for g in [root-2, root, root+2]:
                for e in [0, 1, g-1, 3*(g-1)+1]:
                    h = g*(g-1)//2+e
                    rowsr = g-1
                    t,u = divmod(e,rowsr)
                    ap = ceil_log(rowsr+t+(u>0)+2,p)+ceil_log(rowsr+2,p)
                    threshold = 2*ceil_log(g+1,p)
                    for defect in range(5):
                        for extra in range(3):
                            a = max(0, threshold+1-defect)+extra
                            assert a+defect >= ap
                            m=n-a-h
                            mp=n-ap-h
                            S=h+g
                            full=(S-defect+1)*m
                            local=(S+1)*mp
                            assert full-local <= defect*(S+1-m)
                            cases+=1
    return cases


def semilinear_outer_reduction():
    cases = 0
    for q, maxdim in [(2,3), (3,2), (4,2)]:
        f = Field(q)
        for dim in range(1,maxdim+1):
            vecs = list(product(range(q),repeat=dim))
            zero = (0,)*dim
            basis = [tuple(int(i==j) for i in range(dim)) for j in range(dim)]
            def iterate(v,T,k):
                for _ in range(k):
                    v=f.apply(T,v)
                return v
            def height(v,T):
                for k in range(dim+1):
                    if v==zero:
                        return k
                    v=f.apply(T,v)
                raise AssertionError('not nilpotent')
            def combine(coeffs,vs):
                out=zero
                for a,v in zip(coeffs,vs):
                    out=tuple(f.add(x,f.mul(a,y)) for x,y in zip(out,v))
                return out
            for flat in product(range(q),repeat=dim*dim):
                T=tuple(tuple(flat[j*dim+i] for i in range(dim)) for j in range(dim))
                if any(iterate(v,T,dim)!=zero for v in basis):
                    continue
                for x,y in product(vecs,repeat=2):
                    if f.rank([iterate(v,T,j) for v in [x,y] for j in range(dim)])!=dim:
                        continue
                    if height(y,T)>height(x,T):
                        x,y=y,x
                    alpha=height(x,T)
                    beta=dim-alpha
                    assert beta<=alpha
                    chain=[iterate(x,T,j) for j in range(alpha)]
                    target=iterate(y,T,beta)
                    coeff=next(a for a in product(range(q),repeat=alpha)
                               if combine(a,chain)==target)
                    assert all(a==0 for a in coeff[:beta])
                    # t^beta g has sigma^beta applied to the coefficients of g.
                    gc=list(coeff[beta:])
                    for _ in range(beta):
                        gc=[f.sigma.index(a) for a in gc]
                    correction=combine(gc,chain)
                    yp=tuple(f.add(a,f.neg(b)) for a,b in zip(y,correction))
                    assert height(yp,T)==beta
                    assert f.rank(chain+[iterate(yp,T,j) for j in range(beta)])==dim
                    cases+=1
    return cases


def main():
    start=time.monotonic()
    nflags, by_h=flags()
    print('flag tangent cases PASS',nflags,flush=True)
    stretched=stretched_models()
    print('stretched local ideals PASS',stretched,flush=True)
    ranks,minima=boundary_ranks()
    energy=energy_controls()
    outer=semilinear_outer_reduction()
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),
                monomial_flag_tangent_cases=nflags,flag_cases_by_colength=by_h,
                stretched_primary_models=stretched,
                homogeneous_boundary_rank_cases=ranks,boundary_minima=minima,
                exact_energy_comparisons=energy,
                exact_semilinear_outer_reductions=outer,
                scope='Finite exact controls; the general entropy extension and locality rate require the written proof.')
    (Path(__file__).parent/'rank_two_locality_results.json').write_text(
        json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()

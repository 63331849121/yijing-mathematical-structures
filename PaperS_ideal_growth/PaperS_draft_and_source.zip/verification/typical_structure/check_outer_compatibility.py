"""Independent image/centralizer enumeration for the outer compatibility law.

The direct side uses finite semilinear quotient representatives, generator
images and linear center equations. It does not use the rank-mixture formula
to count lifts. Only new research files are imported/written.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import time

from check_head_fitting import Field, gl, u_all, u_nil, predicted_partition_count


def lin(field, cols, v):
    out = [0] * len(cols[0]) if cols else []
    for col, a in zip(cols, v):
        out = [field.add(x, field.mul(a, y)) for x, y in zip(out, col)]
    return tuple(out)


def model(q, s, r):
    f = Field(q)
    if s == -1:
        # Nonlocal relation module N=(X-1,Y). In U=R/mN use basis
        # c, v=(X-1)c. Then Xc=c+v, Yc=0, and Xv=Yv=0.
        # The outer basis is x^[p]-x, y^[p], so the outer quotient
        # is not p-nilpotent. This checks a nonradial compatible case.
        return f, 2, 1, (((1,1),), ((0,0),)), [
            [(0,0),(0,0)], [(0,f.neg(1)),(0,0)]]
    monos = [(a, t-a) for t in range(s + 1) for a in range(t + 1)]
    S = len(monos)
    h = s * (s + 1) // 2
    zero = (0,) * S
    X = []
    for axis in range(2):
        cols = []
        for a, b in monos[:h]:
            mon = (a + (axis == 0), b + (axis == 1))
            v = list(zero)
            v[monos.index(mon)] = 1
            cols.append(tuple(v))
        X.append(tuple(cols))
    comm = [[zero, zero], [zero, zero]]
    degree = f.p ** r - 1
    if degree <= s:
        v = list(zero)
        v[monos.index((degree, 0))] = f.neg(1)
        comm[1][0] = tuple(v)  # [y,x^[p^r]]
        v = list(zero)
        v[monos.index((0, degree))] = 1
        comm[0][1] = tuple(v)  # [x,y^[p^r]]
    return f, S, h, tuple(X), comm


def rank_mixture(q, s, r):
    f, S, h, X, comm = model(q, s, r)
    counts = Counter()
    for flat in product(range(q), repeat=2*h):
        alpha = [flat[:h], flat[h:]]
        columns = []
        valid = True
        for j in range(2):
            for i in range(2):
                v = lin(f, X[i], alpha[j])
                v = tuple(f.add(a, b) for a, b in zip(v, comm[i][j]))
                if any(v[:h]):
                    valid = False
                columns.append(v)
        if valid:
            counts[f.rank(columns)] += 1
    return counts


def operators(q, b, h):
    """Complete small Fitting representatives used in the controls."""
    z = [(0,) * b for _ in range(b)]
    m = b-h
    if m == 0:
        return [tuple(z)]
    if m == 1:
        nil = list(z)
        c = [0] * b
        c[h] = 1
        nil[0] = tuple(c)
        result = [tuple(nil)]
        # For square-Frobenius over F4 there is one 1D invertible class:
        # the norm takes values in F2*. For prime fields retain all scalars.
        for a in ([1] if q == 4 else range(1, q)):
            inv = list(z)
            c = [0] * b
            c[-1] = a
            inv[-1] = tuple(c)
            result.append(tuple(inv))
        return result
    assert q == 2 and b == 3 and h == 1
    result = []
    # Nilpotent chain of length three.
    result.append(((0,1,0),(0,0,1),(0,0,0)))
    # A nilpotent two-chain and one invertible direction.
    result.append(((0,1,0),(0,0,0),(0,0,1)))
    # One nilpotent singleton and the three conjugacy types of GL2(F2).
    for block in [((1,0),(0,1)), ((1,0),(1,1)), ((0,1),(1,1))]:
        result.append(((0,0,0),(0,)+block[0],(0,)+block[1]))
    return result


def automorphisms(f, T):
    b = len(T)
    result = 0
    for flat in product(range(f.q), repeat=b*b):
        G = tuple(tuple(flat[j*b+i] for i in range(b)) for j in range(b))
        if f.rank(G) != b:
            continue
        if all(lin(f,G,T[j]) == f.apply(T,G[j]) for j in range(b)):
            result += 1
    return result


def direct_for_operator(q, s, r, b, T):
    f, S, h, X, comm = model(q, s, r)
    assert f.rank(T) == b-h
    vectors = list(product(range(q), repeat=b))
    inside = [v for v in vectors if f.rank(T+(v,)) == b-h]
    weighted = count = 0
    for first in product(vectors, repeat=h):
        if f.rank(T+first) != b:
            continue
        for last in product(inside, repeat=S-h):
            phi = first+last
            span = list(phi)
            now = phi
            for _ in range(b):
                now = tuple(f.apply(T,v) for v in now)
                span.extend(now)
            if f.rank(span) != b:
                continue
            count += 1
            # Center map on C: the head basis first[] maps to ad-images;
            # tC is central, so it contributes b-h zero columns.
            center_cols = []
            for a in range(h):
                center_cols.append(tuple(x for i in range(2) for x in lin(f,phi,X[i][a])))
            rank = f.rank(center_cols)
            if all(f.rank(center_cols+[tuple(f.neg(x) for i in range(2)
                                            for x in lin(f,phi,comm[i][j]))]) == rank
                   for j in range(2)):
                weighted += q ** (2*(b-rank))
    aut = automorphisms(f,T)
    ranks = [b]
    now = [tuple(int(i==j) for i in range(b)) for j in range(b)]
    for _ in range(b):
        now = [f.apply(T,v) for v in now]
        ranks.append(f.rank(now))
    lp = [ranks[i]-ranks[i+1] for i in range(b)]
    lam = tuple(sum(x>=j for x in lp) for j in range(1,h+1))
    nu = tuple(x-1 for x in lam if x>1)
    return F(count,aut), F(weighted,aut), nu


def run_case(q,s,r,b):
    f,S,h,_,_ = model(q,s,r)
    coeffs = rank_mixture(q,s,r)
    unweighted = F(0)
    actual = Counter()
    for T in operators(q,b,h):
        plain,weighted,nu = direct_for_operator(q,s,r,b,T)
        unweighted += plain
        actual[nu] += weighted
    assert unweighted == u_all(S,b,h,q), (q,s,r,b,'representatives incomplete')
    m = b-h
    expected = q ** (2*m) * sum(c*u_all(S-j,b,h,q) for j,c in coeffs.items())
    expected_nil = q ** (2*m) * sum(c*u_nil(S-j,b,h,q) for j,c in coeffs.items())
    assert sum(actual.values()) == expected, (q,s,r,b,actual,expected)
    assert sum(v for nu,v in actual.items() if sum(nu)==m) == expected_nil
    for nu in actual:
        pred = q ** (2*m) * sum(c*predicted_partition_count(S-j,b,h,nu,q)
                                for j,c in coeffs.items())
        assert actual[nu] == pred, (q,s,r,b,nu,actual[nu],pred)
    assert all(v.denominator == 1 for v in actual.values())
    return dict(q=q,radial_degree=s,outer_height=r,inner_dimension=b,
                head_dimension=h,head_rank_mixture=dict(coeffs),
                ideal_count=expected,inner_nilpotent_ideal_count=expected_nil,
                outer_is_nilpotent=s!=-1,
                whole_nilpotent_ideal_count=expected_nil if s!=-1 else 0,
                fitting_counts={str(nu):int(v) for nu,v in actual.items()},status='PASS')


def main():
    start=time.monotonic()
    cases=[]
    for q,s,r,bs in [(2,1,1,[1,2,3]),(2,1,2,[1,2,3]),
                      (2,2,1,[3,4]),(2,2,2,[3,4]),
                      (3,1,1,[1,2]),(3,2,1,[3]),
                      (4,1,1,[1,2]),(4,1,2,[1,2]),
                      (2,-1,1,[1,2,3]),(3,-1,1,[1,2]),(4,-1,1,[1,2])]:
        for b in bs:
            result=run_case(q,s,r,b)
            cases.append(result)
            print(json.dumps(result),flush=True)
    result=dict(status='PASS',seconds=round(time.monotonic()-start,3),cases=cases,
                scope='Independent finite center-lift counts; not a proof of global asymptotics.')
    (Path(__file__).parent/'outer_compatibility_results.json').write_text(
        json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('ALL',len(cases),'PASS',result['seconds'])


if __name__=='__main__':
    main()

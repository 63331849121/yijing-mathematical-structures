$ErrorActionPreference = 'Stop'
$compiler = 'C:/Users/master/.codex/plugins/cache/openai-bundled/latex/0.2.4/bin/tectonic.exe'
$cache = 'C:/Users/master/Documents/Codex/mywebsite/output/pdf/Quadratic_orbit_sum_maps_2026-10-30/.tex_runtime_cache'
$savedCache = $env:TECTONIC_CACHE_DIR
try {
  $env:TECTONIC_CACHE_DIR = $cache
  Push-Location -LiteralPath $PSScriptRoot
  try {
    & $compiler -X compile PaperS.tex --only-cached --untrusted --keep-logs --keep-intermediates --reruns 3
    if ($LASTEXITCODE -ne 0) { throw 'Compilation failed.' }
  } finally { Pop-Location }
} finally { $env:TECTONIC_CACHE_DIR = $savedCache }

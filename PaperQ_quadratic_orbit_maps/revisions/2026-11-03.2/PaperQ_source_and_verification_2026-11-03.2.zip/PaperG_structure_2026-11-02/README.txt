Paper Q / 2026-11-03.2 / 81 pages / local unpublished submission revision
Wencong Huang, Baohua Li
Actual entry: PaperG_structure.tex. Read PaperG_structure.pdf.
No upload or new DOI. The prior 82-page 2026-11-03.1 sources/PDF and
its ZIP are preserved. The public 73-page predecessor has DOI
10.5281/zenodo.23882876; earlier public authorship versions are unchanged.

This revision sharpens the Bahturin--Olshanskii, Pakianathan--Yalcin and
Hochschild comparisons, keeps the final e(d)-1<=kappa(d)<=e(d) statement,
and removes the superseded conditional G.4 result from the article.
Its useful explicit family coordinates and all needed foundation proofs remain.
The Q current-family upper bound is independent; the separate metabelian
comparison explicitly uses E's published 80-page Theorem4.4, not a later draft.
DEPENDENCIES.json distinguishes core proof edges from this comparison edge.

Selected equality endpoints and the fixed subsequent cover-type obstruction
remain as Theorem13.3. Complete parameter classification and coefficient-ring
18s theory remain successor research. No new class-six optimum or strict R
penalty is asserted; costs over compact bottoms remain relative, not global m(5).

Build with standard XeLaTeX (two runs), or build.ps1. The author-specific
offline compiler/cache are excluded from this package. All article TeX
inputs, required font assets and exact finite certificate data are supplied.
Ten targeted checks were freshly replayed; inherited reports are labelled.
See verification/README.txt, PUBLICATION.json and INTEGRATION_REPORT.zh-CN.txt.
SUBMISSION_NOTES.zh-CN.txt lists remaining author metadata for actual submission.
manifest.json fingerprints all portable files except itself.
Manuscript/data: CC BY4.0. Original verification code: MIT.
Third-party assets retain their own licenses.

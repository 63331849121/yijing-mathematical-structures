"""Independent, lossless review of an explicit quadratic-map coefficient JSON.

No imports from the construction, compression or dimensions helpers.
Default read-only; --report creates a new JSON exclusively. Input is only
the explicit linear and quadratic Boolean coefficient table.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path


def echelon(vectors):
    pivots = {}
    for vector in vectors:
        while vector:
            bit = vector.bit_length() - 1
            if bit in pivots:
                vector ^= pivots[bit]
            else:
                pivots[bit] = vector
                break
    return pivots


def reduction(vector, pivots):
    for bit in sorted(pivots, reverse=True):
        if vector >> bit & 1:
            vector ^= pivots[bit]
    return vector


def kernel(columns):
    pivots = {}
    basis = []
    for i, column in enumerate(columns):
        label = 1 << i
        while column:
            bit = column.bit_length() - 1
            if bit in pivots:
                old_column, old_label = pivots[bit]
                column ^= old_column
                label ^= old_label
            else:
                pivots[bit] = (column, label)
                break
        if not column:
            basis.append(label)
    return basis


def xor_product(left, right):
    out = set()
    for a in left:
        for b in right:
            term = a | b  # Boolean relations x_i^2=x_i, not ordinary monomials.
            if term in out:
                out.remove(term)
            else:
                out.add(term)
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path(__file__).resolve().parent / "models" / "class6_36.json")
    parser.add_argument("--expected-class", type=int, default=6)
    parser.add_argument("--expected-lcs", default="36,30,24,14,6,2,0")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    data = json.loads(raw)
    n = data["binary_dimension"]
    linear = data["linear_coefficients"]
    quadratic = {int(key): value for key, value in data["quadratic_coefficients"].items()}
    expected_lower = [int(value) for value in args.expected_lcs.split(",")]
    assert n == expected_lower[0] and len(linear) == n
    assert all(0 <= value < 1 << n for value in linear)
    assert all(mask.bit_count() == 2 and mask < 1 << n and 0 < value < 1 << n
               for mask, value in quadratic.items())

    def f(value):
        out = 0
        for i, coefficient in enumerate(linear):
            if value >> i & 1:
                out ^= coefficient
        for mask, coefficient in quadratic.items():
            if value & mask == mask:
                out ^= coefficient
        return out

    polynomials = [set() for _ in range(n)]
    for i, value in enumerate(linear):
        for output in range(n):
            if value >> output & 1:
                polynomials[output].add(1 << i)
    for mask, value in quadratic.items():
        for output in range(n):
            if value >> output & 1:
                polynomials[output].add(mask)

    maximum_composed_degree = 0
    maximum_composed_terms = 0
    for output, outer in enumerate(polynomials):
        composition = set()
        for mask in outer:
            indices = [i for i in range(n) if mask >> i & 1]
            terms = polynomials[indices[0]] if len(indices) == 1 else xor_product(
                polynomials[indices[0]], polynomials[indices[1]])
            composition.symmetric_difference_update(terms)
        maximum_composed_degree = max(maximum_composed_degree,
                                      max((mask.bit_count() for mask in composition), default=0))
        maximum_composed_terms = max(maximum_composed_terms, len(composition))
        composition.symmetric_difference_update(outer)
        composition.symmetric_difference_update({1 << output})
        assert not composition, (output, sorted(composition))

    B = [[0] * n for _ in range(n)]
    for mask, coefficient in quadratic.items():
        i, j = [i for i in range(n) if mask >> i & 1]
        B[i][j] = B[j][i] = coefficient

    def bracket(left, right):
        result = 0
        while left:
            low = left & -left
            i = low.bit_length() - 1
            work = right
            while work:
                bit = work & -work
                result ^= B[i][bit.bit_length() - 1]
                work ^= bit
            left ^= low
        return result

    for i in range(n):
        assert B[i][i] == 0
        assert f(1 << i) == linear[i]
    for i, j in itertools.combinations(range(n), 2):
        assert f((1 << i) ^ (1 << j)) ^ f(1 << i) ^ f(1 << j) == B[i][j]
    jacobi_count = 0
    for i, j, k in itertools.combinations(range(n), 3):
        assert bracket(1 << i, B[j][k]) ^ bracket(1 << j, B[i][k]) ^ bracket(1 << k, B[i][j]) == 0
        jacobi_count += 1

    basis = [1 << i for i in range(n)]
    lower = [basis]
    while lower[-1]:
        next_basis = list(echelon(bracket(x, y) for x in basis for y in lower[-1]).values())
        lower.append(next_basis)
        assert len(lower) < n + 2
    lower_dims = [len(part) for part in lower]
    assert lower_dims == expected_lower
    assert lower_dims == data["lower_central_dimensions"]

    # The derived series and upper central series are computed afresh.
    derived = [basis]
    while derived[-1]:
        next_basis = list(echelon(bracket(x, y) for x in derived[-1] for y in derived[-1]).values())
        derived.append(next_basis)
        assert len(derived) < n + 2
    derived_dims = [len(part) for part in derived]
    assert len(derived[2]) > 0

    upper = [[]]
    while len(upper[-1]) < n:
        pivots = echelon(upper[-1])
        columns = []
        for x in basis:
            column = 0
            for j, y in enumerate(basis):
                column ^= reduction(bracket(x, y), pivots) << (n * j)
            columns.append(column)
        next_basis = kernel(columns)
        assert len(next_basis) > len(upper[-1])
        upper.append(next_basis)
    upper_dims = [len(part) for part in upper]
    center = upper[1]
    derived_center_intersection = len(lower[1]) + len(center) - len(echelon(lower[1] + center))

    # Independent checks of the new UEA/biderivation consequences on this
    # higher-class example, using only the explicit JSON coefficient table.
    D = [[bracket(f(1 << i), 1 << j) ^ bracket(1 << i, B[i][j])
          for j in range(n)] for i in range(n)]

    def dbracket(left, right):
        out = 0
        while left:
            low = left & -left
            i = low.bit_length() - 1
            work = right
            while work:
                bit = work & -work
                out ^= D[i][bit.bit_length() - 1]
                work ^= bit
            left ^= low
        return out

    assert all(D[i][i] == 0 and all(D[i][j] == D[j][i] for j in range(n)) for i in range(n))
    for i, j, k in itertools.combinations(range(n), 3):
        assert dbracket(1 << i, D[j][k]) ^ dbracket(1 << j, D[i][k]) ^ dbracket(1 << k, D[i][j]) == 0
        mixed = (bracket(1 << i, D[j][k]) ^ bracket(1 << j, D[i][k]) ^ bracket(1 << k, D[i][j]) ^
                 dbracket(1 << i, B[j][k]) ^ dbracket(1 << j, B[i][k]) ^ dbracket(1 << k, B[i][j]))
        assert mixed == 0
    for i, x in enumerate(basis):
        for j, y in enumerate(basis):
            z = B[i][j]
            g = (bracket(x, bracket(y, z)) ^ bracket(x, bracket(x, f(y))) ^
                 bracket(y, bracket(y, f(x))) ^ bracket(f(x), f(y)))
            assert g == B[i][j] ^ D[i][j]

    zpiv = echelon(center)
    jpiv = {}
    for i, j in itertools.combinations(range(n), 2):
        w, u = reduction(B[i][j], zpiv), reduction(D[i][j], zpiv)
        while w:
            bit = w.bit_length() - 1
            if bit in jpiv:
                old_w, old_u = jpiv[bit]
                w ^= old_w
                u ^= old_u
            else:
                jpiv[bit] = (w, u)
                break
        if not w:
            assert reduction(u, zpiv) == 0

    def J(w):
        w = reduction(w, zpiv)
        u = 0
        while w:
            bit = w.bit_length() - 1
            assert bit in jpiv
            old_w, old_u = jpiv[bit]
            w ^= old_w
            u ^= old_u
        return reduction(u, zpiv)

    wbar_basis = [w for w, u in jpiv.values()]
    assert len(wbar_basis) == len(lower[1]) - derived_center_intersection
    p_values = []
    for w in wbar_basis:
        jw = J(w)
        assert reduction(J(jw) ^ jw ^ w, zpiv) == 0
        for x in basis:
            assert reduction(J(bracket(w, x)) ^ bracket(jw, x), zpiv) == 0
            p = f(w) ^ jw
            assert bracket(p, x) == bracket(w, bracket(w, x))
        p_values.append(reduction(f(w) ^ jw, zpiv))
    p_span = echelon(p_values + [reduction(bracket(w, v), zpiv)
                               for w in wbar_basis for v in wbar_basis])

    def P(w):
        return reduction(f(w) ^ J(w), zpiv)

    for w in wbar_basis:
        assert reduction(P(J(w)) ^ J(J(P(w))), zpiv) == 0
    # Its possible semilinearity defect is linear; check its polar too.
    for w, v in itertools.combinations(wbar_basis, 2):
        assert reduction(bracket(J(w), J(v)) ^ J(J(bracket(w, v))), zpiv) == 0

    coordinate_at_pivot = {bit: i for i, bit in enumerate(jpiv)}

    def wbar_coordinates(w):
        w = reduction(w, zpiv)
        result = 0
        while w:
            bit = w.bit_length() - 1
            assert bit in jpiv
            w ^= jpiv[bit][0]
            result ^= 1 << coordinate_at_pivot[bit]
        return result

    qn = len(wbar_basis)
    ppoly = [set() for _ in range(qn)]
    for i, w in enumerate(wbar_basis):
        value = wbar_coordinates(P(w))
        for k in range(qn):
            if value >> k & 1:
                ppoly[k].add(1 << i)
    for i, j in itertools.combinations(range(qn), 2):
        value = wbar_coordinates(bracket(wbar_basis[i], wbar_basis[j]))
        for k in range(qn):
            if value >> k & 1:
                ppoly[k].add((1 << i) | (1 << j))
    for polynomial in ppoly:
        composition = set()
        for mask in polynomial:
            ids = [i for i in range(qn) if mask >> i & 1]
            terms = ppoly[ids[0]] if len(ids) == 1 else xor_product(ppoly[ids[0]], ppoly[ids[1]])
            composition.symmetric_difference_update(terms)
        assert not composition

    rho_columns = []
    for x in basis:
        column = 0
        for j, w in enumerate(wbar_basis):
            column ^= wbar_coordinates(bracket(x, w)) << (qn * j)
        rho_columns.append(column)
    matrix_kernel = kernel(rho_columns)
    kpiv = echelon(matrix_kernel)
    assert all(reduction(f(x), kpiv) == 0 for x in matrix_kernel)
    assert all(reduction(bracket(x, y), zpiv) == 0 for x in matrix_kernel for y in lower[1])
    kernel_lower = [matrix_kernel]
    while kernel_lower[-1]:
        next_basis = list(echelon(bracket(x, y) for x in matrix_kernel for y in kernel_lower[-1]).values())
        kernel_lower.append(next_basis)
        assert len(kernel_lower) <= 5
    for x in basis:
        fx = f(x)
        for w in wbar_basis:
            assert reduction(bracket(fx, w) ^ bracket(x, bracket(x, w)) ^ J(bracket(x, w)), zpiv) == 0

    # All series terms are checked invariant under the full quadratic map:
    # ideality plus images of basis vectors suffices for arbitrary sums.
    for part in lower + derived + upper:
        pivots = echelon(part)
        assert all(reduction(f(x), pivots) == 0 for x in part)
        assert all(reduction(bracket(x, y), pivots) == 0 for x in part for y in part)

    report = {
        "status": "PASS",
        "input_file": str(args.input.resolve()),
        "input_sha256": hashlib.sha256(raw).hexdigest(),
        "binary_dimension": n,
        "input_boolean_degree": 2,
        "nonzero_quadratic_vector_coefficients": len(quadratic),
        "exact_full_boolean_composition_identity": True,
        "composition_output_maximum_degree_after_cancellation": maximum_composed_degree,
        "composition_output_maximum_terms": maximum_composed_terms,
        "jacobi_basis_triples": jacobi_count,
        "lower_central_dimensions": lower_dims,
        "upper_central_dimensions": upper_dims,
        "derived_series_dimensions": derived_dims,
        "center_dimension": len(center),
        "derived_intersection_global_center_dimension": derived_center_intersection,
        "abelianization_dimension": n - lower_dims[1],
        "nilpotency_class": len(lower_dims) - 1,
        "nonmetabelian": True,
        "all_series_f_invariant": True,
        "new_derived_structure_controls": {
            "D_is_Lie": True,
            "mixed_CE_D_zero": True,
            "UEA_G_equals_B_plus_D_basis_pairs": n * n,
            "reduced_derived_binary_dimension": len(wbar_basis),
            "canonical_J_well_defined": True,
            "J_squared_plus_J_identity": True,
            "J_commutes_all_original_adjoint_actions": True,
            "canonical_reduced_derived_binary_restricted_square": True,
            "reduced_square_is_F4_semilinear": True,
            "reduced_square_squared_exact_boolean_identity_zero": True,
            "span_of_reduced_square_values_dimension": len(p_span),
            "canonical_matrix_kernel_dimension": len(matrix_kernel),
            "matrix_image_binary_dimension": n - len(matrix_kernel),
            "matrix_kernel_lower_central_dimensions": [len(part) for part in kernel_lower],
            "matrix_quotient_functional_rule": True,
        },
        "claim": f"Explicit certified upper bound m({args.expected_class})<={n}; no minimality or infinite-rank dimension law asserted",
        "independence": "Only explicit input coefficient table is read; no constructor or dimensions helper imported",
    }
    assert report["nilpotency_class"] == args.expected_class
    if args.report:
        with args.report.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

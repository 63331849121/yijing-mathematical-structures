"""Exact finite controls for the global-stability interfaces.

Standard library only; no network, construction helpers or research-directory
imports. The 48-bit coefficient table is embedded below for portable replay.
The new control is ad_z^3(W)=0, checked by every Boolean coefficient, not
another finite D-stability table. The 22-bit cycle retains the distinction
between quadratic stability and exact whole-derived factorization.

Read-only by default and with --no-write. --report creates one fresh JSON;
--output-dir requires a new or empty directory and writes the report there.
Finite controls accompany, and do not replace, the general written proof.
"""
from pathlib import Path
from itertools import combinations
import argparse
import hashlib
import json
import time

# Explicit binary ANF coefficients: bit i denotes the i-th coordinate.
# This table is a fixed 48-dimensional class-seven solution, rather than a
# claim of minimum dimension or a search over arbitrary classes.
MODEL48 = {'binary_dimension': 48,
 'linear_coefficients': [2,
                         3,
                         8,
                         12,
                         32,
                         48,
                         128,
                         192,
                         512,
                         768,
                         2048,
                         3072,
                         8192,
                         12288,
                         32768,
                         49152,
                         131072,
                         196608,
                         524288,
                         786432,
                         2097152,
                         3145728,
                         8388608,
                         12582912,
                         33554432,
                         50331648,
                         134217728,
                         201326592,
                         536870912,
                         805306368,
                         2147483648,
                         3221225472,
                         8589934592,
                         12884901888,
                         34359738368,
                         51539607552,
                         137438953472,
                         206158430208,
                         549755813888,
                         824633720832,
                         2199023255552,
                         3298534883328,
                         8796093022208,
                         13194139533312,
                         35184372088832,
                         52776558133248,
                         140737488355328,
                         211106232532992],
 'lower_central_dimensions': [48, 42, 36, 24, 14, 6, 2, 0],
 'quadratic_coefficients': {'10': 266432,
                            '10240': 281251638411264,
                            '1025': 65536,
                            '1026': 17196777472,
                            '1028': 4194304,
                            '1032': 8388608,
                            '1048577': 268435456,
                            '1048578': 275414777856,
                            '1048580': 5368709120,
                            '1048584': 10737418240,
                            '1048640': 74766790688768,
                            '1048704': 219902325555200,
                            '1052672': 70368744177664,
                            '1056768': 140737488355328,
                            '1073741825': 1099511627776,
                            '1073741826': 72567767433216,
                            '1073741828': 93819265613824,
                            '1073741832': 187638531227648,
                            '1073745920': 70368744177664,
                            '1073750016': 140737488355328,
                            '1088': 89357868335104,
                            '1099511627777': 70368744177664,
                            '1099511627778': 140737488355328,
                            '1099511627780': 18983755448320,
                            '1099511627784': 37967510896640,
                            '1099511627840': 70368744177664,
                            '1099511627904': 140737488355328,
                            '1152': 268068236296192,
                            '129': 8192,
                            '130': 12288,
                            '1310720': 89352499625984,
                            '131073': 34393292800,
                            '131074': 51589939200,
                            '131076': 8589934592,
                            '131080': 187651416129536,
                            '131136': 35768487641088,
                            '131200': 194390219816960,
                            '132': 524288,
                            '134217744': 186916976721920,
                            '134217760': 280375465082880,
                            '134217984': 175921860444160,
                            '134218240': 263882790666240,
                            '134218752': 178704999251968,
                            '134219776': 268057498877952,
                            '134283264': 140737488355328,
                            '134348800': 211106232532992,
                            '135168': 175921860444160,
                            '135266304': 140737488355328,
                            '136': 786432,
                            '136314880': 211106232532992,
                            '137438953473': 2783138807808,
                            '137438953474': 144912196567040,
                            '137438953536': 140737488355328,
                            '137438953600': 211106232532992,
                            '139264': 263882790666240,
                            '144': 280420598022144,
                            '1572864': 178704999251968,
                            '160': 93526187769856,
                            '16388': 285212672,
                            '16392': 93751116562432,
                            '16448': 88235808129024,
                            '16512': 176471616258048,
                            '16777220': 5497558138880,
                            '16777224': 29978871726080,
                            '16777280': 17592186044416,
                            '16777344': 35184372088832,
                            '17': 16640,
                            '17039360': 70368744177664,
                            '17179869188': 1391569403904,
                            '17179869192': 73151882985472,
                            '17179869248': 70368744177664,
                            '17179869312': 140737488355328,
                            '17301504': 140737488355328,
                            '17592186044420': 70368744177664,
                            '17592186044424': 140737488355328,
                            '18': 49664,
                            '20': 4195328,
                            '2049': 131072,
                            '2050': 34393489408,
                            '2052': 8388608,
                            '2056': 12582912,
                            '2097153': 536870912,
                            '2097154': 550561120256,
                            '2097156': 10737418240,
                            '2097160': 16106127360,
                            '2097216': 149533581377536,
                            '2097280': 83562883710976,
                            '2101248': 140737488355328,
                            '2105344': 211106232532992,
                            '2112': 178715736670208,
                            '2147483649': 2199023255552,
                            '2147483650': 144036023238656,
                            '2147483652': 187638531227648,
                            '2147483656': 281457796841472,
                            '2147487744': 140737488355328,
                            '2147491840': 211106232532992,
                            '2176': 89368605753344,
                            '2199023255553': 140737488355328,
                            '2199023255554': 211106232532992,
                            '2199023255556': 37967510896640,
                            '2199023255560': 56951266344960,
                            '2199023255616': 140737488355328,
                            '2199023255680': 211106232532992,
                            '2359296': 178704999251968,
                            '24': 12584960,
                            '257': 16384,
                            '258': 32768,
                            '260': 1048576,
                            '2621440': 268057498877952,
                            '262145': 67108864,
                            '262146': 134217728,
                            '262160': 365072220160,
                            '262176': 730144440320,
                            '262400': 292057776128,
                            '262656': 584115552256,
                            '263168': 4466765987840,
                            '264': 5370806272,
                            '264192': 8933531975680,
                            '268435457': 274877906944,
                            '268435458': 549755813888,
                            '268435460': 88252987998208,
                            '268435464': 195489731444736,
                            '268435520': 87960930222080,
                            '268435584': 175921860444160,
                            '274877906948': 87960930222080,
                            '274877906952': 246290604621824,
                            '278528': 87960930222080,
                            '294912': 175921860444160,
                            '320': 87978126868480,
                            '327680': 70368744177664,
                            '32772': 570425344,
                            '32776': 187501947912192,
                            '32832': 176471616258048,
                            '32896': 264707424387072,
                            '33': 33280,
                            '33554436': 10995116277760,
                            '33554440': 50062138802176,
                            '33554496': 35184372088832,
                            '33554560': 52776558133248,
                            '33816576': 140737488355328,
                            '34': 17152,
                            '34078720': 211106232532992,
                            '34359738372': 2783138807808,
                            '34359738376': 144912196567040,
                            '34359738432': 140737488355328,
                            '34359738496': 211106232532992,
                            '35184372088836': 140737488355328,
                            '35184372088840': 211106232532992,
                            '36': 8390656,
                            '384': 263917183959040,
                            '393216': 140737488355328,
                            '40': 4197376,
                            '4100': 67108864,
                            '4104': 134217728,
                            '4112': 93733634703360,
                            '4128': 187467269406720,
                            '4194305': 69793218560,
                            '4194306': 431644213248,
                            '4194368': 4466765987840,
                            '4194432': 8933531975680,
                            '4198400': 89352499625984,
                            '4202496': 178704999251968,
                            '4294967297': 4398046511104,
                            '4294967298': 26388279066624,
                            '4294967300': 93819265613824,
                            '4294967304': 187638531227648,
                            '4294967360': 89352499625984,
                            '4294967424': 178704999251968,
                            '4352': 88235808129024,
                            '4398046511105': 17592186044416,
                            '4398046511106': 35184372088832,
                            '4398046511168': 70368744177664,
                            '4398046511232': 140737488355328,
                            '4608': 176471616258048,
                            '5': 266304,
                            '5120': 93750546137088,
                            '513': 32768,
                            '514': 49152,
                            '516': 2097152,
                            '520': 10740563968,
                            '524289': 134217728,
                            '524290': 201326592,
                            '524304': 730144440320,
                            '524320': 1095216660480,
                            '524544': 584115552256,
                            '524800': 876173328384,
                            '525312': 8933531975680,
                            '526336': 13400297963520,
                            '536870913': 549755813888,
                            '536870914': 824633720832,
                            '536870916': 176505975996416,
                            '536870920': 231189499609088,
                            '536870976': 175921860444160,
                            '536871040': 263882790666240,
                            '540672': 175921860444160,
                            '549755813892': 175921860444160,
                            '549755813896': 123145302310912,
                            '557056': 263882790666240,
                            '576': 175956253736960,
                            '589824': 140737488355328,
                            '6': 536704,
                            '6144': 187501092274176,
                            '640': 88012520161280,
                            '65': 4096,
                            '655360': 211106232532992,
                            '65537': 17196646400,
                            '65538': 34393292800,
                            '65540': 4294967296,
                            '65544': 93827855548416,
                            '65600': 17884243820544,
                            '65664': 106137231818752,
                            '66': 8192,
                            '67108880': 93458488360960,
                            '67108896': 186916976721920,
                            '67109120': 87960930222080,
                            '67109376': 175921860444160,
                            '67109888': 89352499625984,
                            '67110912': 178704999251968,
                            '67174400': 70368744177664,
                            '67239936': 140737488355328,
                            '68': 262144,
                            '68157440': 70368744177664,
                            '68719476737': 1391569403904,
                            '68719476738': 73151882985472,
                            '68719476800': 70368744177664,
                            '68719476864': 140737488355328,
                            '69206016': 140737488355328,
                            '69632': 87960930222080,
                            '72': 524288,
                            '73728': 175921860444160,
                            '80': 93481054830592,
                            '8196': 134217728,
                            '8200': 201326592,
                            '8208': 187467269406720,
                            '8224': 281200904110080,
                            '8388609': 139586437120,
                            '8388610': 793495207936,
                            '8388672': 8933531975680,
                            '8388736': 13400297963520,
                            '8392704': 178704999251968,
                            '8396800': 268057498877952,
                            '8448': 176471616258048,
                            '8589934593': 8796093022208,
                            '8589934594': 48378511622144,
                            '8589934596': 187638531227648,
                            '8589934600': 281457796841472,
                            '8589934656': 178704999251968,
                            '8589934720': 268057498877952,
                            '8704': 264707424387072,
                            '8796093022209': 35184372088832,
                            '8796093022210': 52776558133248,
                            '8796093022272': 140737488355328,
                            '8796093022336': 211106232532992,
                            '9': 794752,
                            '9216': 187501092274176,
                            '96': 186962109661184}}
EXPECTED_TABLE_SHA256 = 'c04c27c09f5f2c2f8b52dd49a3b30616cced72546dfe74d58cc91fd49b40849a'


def echelon(vectors):
    pivots = {}
    for value in vectors:
        while value:
            bit = value.bit_length() - 1
            if bit in pivots:
                value ^= pivots[bit]
            else:
                pivots[bit] = value
                break
    return list(pivots.values())


def bracket(table, left, right):
    result = 0
    while left:
        bit = left & -left
        left ^= bit
        row = table[bit.bit_length() - 1]
        value = right
        while value:
            bit = value & -value
            value ^= bit
            result ^= row[bit.bit_length() - 1]
    return result


def xor_product(left, right):
    result = set()
    for a in left:
        for b in right:
            term = a | b  # Boolean x_i^2=x_i.
            if term in result:
                result.remove(term)
            else:
                result.add(term)
    return result


def check_original_equation(n, linear, polar):
    polys = [set() for _ in range(n)]
    for i, value in enumerate(linear):
        for j in range(n):
            if value >> j & 1:
                polys[j].add(1 << i)
    for i, j in combinations(range(n), 2):
        value = polar[i][j]
        for k in range(n):
            if value >> k & 1:
                polys[k].add((1 << i) | (1 << j))
    for i, polynomial in enumerate(polys):
        residual = set(polynomial)
        residual.symmetric_difference_update((1 << i,))
        for monomial in polynomial:
            ids = [j for j in range(n) if monomial >> j & 1]
            term = (polys[ids[0]] if len(ids) == 1 else
                    xor_product(polys[ids[0]], polys[ids[1]]))
            residual.symmetric_difference_update(term)
        assert not residual, ("f^2+f+I coefficient", i, residual)


def cube_control():
    raw = json.dumps(MODEL48, sort_keys=True, separators=(",", ":")).encode("utf-8")
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == EXPECTED_TABLE_SHA256, "embedded coefficient table changed"
    n = MODEL48["binary_dimension"]
    unit = [1 << i for i in range(n)]
    linear = MODEL48["linear_coefficients"]
    assert n == 48 and len(linear) == n
    assert all(0 <= value < 1 << n for value in linear)
    polar = [[0]*n for _ in range(n)]
    for mask_string, value in MODEL48["quadratic_coefficients"].items():
        mask = int(mask_string)
        assert mask.bit_count() == 2 and mask < 1 << n and 0 < value < 1 << n
        i, j = [i for i in range(n) if mask >> i & 1]
        polar[i][j] = polar[j][i] = value
    check_original_equation(n, linear, polar)
    b = lambda x, y: bracket(polar, x, y)
    jacobi_triples = 0
    for i, j, k in combinations(range(n), 3):
        assert b(unit[i], polar[j][k]) ^ b(unit[j], polar[i][k]) ^ b(unit[k], polar[i][j]) == 0
        jacobi_triples += 1
    derived = echelon(polar[i][j] for i, j in combinations(range(n), 2))
    lower = [unit, derived]
    while lower[-1]:
        lower.append(echelon(b(x, y) for x in unit for y in lower[-1]))
        assert len(lower) <= n + 1
    dimensions = [len(layer) for layer in lower]
    assert dimensions == MODEL48["lower_central_dimensions"]

    supports = values = 0
    for weight in range(1, 4):
        for ids in combinations(range(n), weight):
            action = [0]*n
            for i in ids:
                for j in range(n):
                    action[j] ^= polar[i][j]
            def apply(value):
                result = 0
                while value:
                    bit = value & -value
                    value ^= bit
                    result ^= action[bit.bit_length() - 1]
                return result
            supports += 1
            for w in derived:
                residual = apply(apply(apply(w)))
                assert residual == 0, ("ad_z^3(w)", ids, w, residual)
                values += 1
    assert supports == 18472 and values == 775824 and len(derived) == 42
    return {
        "binary_dimension": n, "coefficient_table_sha256": digest,
        "full_Boolean_f2_identity": True, "jacobi_basis_triples": jacobi_triples,
        "lower_central_dimensions": dimensions, "derived_dimension": len(derived),
        "new_interface": "ad_z^3(W)=0",
        "z_Boolean_degree_bound": 3, "complete_z_supports_of_weights_1_to_3": supports,
        "derived_basis_values_checked": values,
        "all_Boolean_coefficients_zero": True,
        "scope": "One fixed class-seven model, lossless coefficients; not an arbitrary-class proof."
    }


def f4_mul(a, b):
    result = 0
    for _ in range(2):
        if b & 1:
            result ^= a
        b >>= 1
        a <<= 1
        if a & 4:
            a ^= 7
    return result


def counterexample22(value):
    a, b, c, d, z, v, w, s1, s2, s3, t = [
        (value >> (2*i)) & 3 for i in range(11)]
    m = f4_mul
    coords = [a, b, c, d, z, v, w, s1, s2, s3, t]
    correction = [0, 0, 0, 0, m(a, b) ^ m(c, d), m(a, d), m(b, d),
                  m(a, z) ^ m(c, v) ^ m(m(a, a), b),
                  m(b, z) ^ m(c, w) ^ m(a, m(b, b)), m(a, w) ^ m(b, v),
                  m(a, s2) ^ m(b, s1) ^ m(c, s3)]
    return sum((m(2, x) ^ q) << (2*i)
               for i, (x, q) in enumerate(zip(coords, correction)))


def nonfactorization_control():
    n = 22
    unit = [1 << i for i in range(n)]
    linear = [counterexample22(e) for e in unit]
    polar = [[counterexample22(x ^ y) ^ linear[i] ^ linear[j]
              for j, y in enumerate(unit)] for i, x in enumerate(unit)]
    b = lambda x, y: bracket(polar, x, y)
    cycle = [(0, 2), (4, 6), (0, 8), (2, 8)]
    sum_b = sum_d = 0
    for i, j in cycle:
        value = polar[i][j]
        sum_b ^= value
        sum_d ^= b(linear[i], unit[j]) ^ b(unit[i], value)
    assert sum_b == 0 and sum_d == 1 << 20
    assert all(b(sum_d, e) == 0 for e in unit)
    return {
        "binary_dimension": n, "cycle_basis_pairs_zero_based": cycle,
        "cycle_B": sum_b, "cycle_D": sum_d, "cycle_D_globally_central": True,
        "no_linear_whole_derived_factor": True,
        "scope": "Short nonfactorization replay; the earlier full 22-bit model checker is retained.",
        "distinction": "Global quadratic stability does not force D=JB on an arbitrary solution."
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--report", type=Path, help="Create a fresh report; never overwrite an existing file.")
    group.add_argument("--output-dir", type=Path, help="Use a new or empty report directory.")
    group.add_argument("--no-write", action="store_true", help="Print results without persistent writes (also the default).")
    args = parser.parse_args()
    if args.report and args.report.exists():
        parser.error("--report must name a new file")
    if args.output_dir and args.output_dir.exists():
        if not args.output_dir.is_dir() or any(args.output_dir.iterdir()):
            parser.error("--output-dir must be new or empty")
    started = time.monotonic()
    report = {"status": "PASS", "cube_action_control": cube_control(),
              "nonfactorization_control": nonfactorization_control(),
              "scope": "Exact finite interface controls; not a proof of the global theorem or a Lean formalization.",
              "seconds": round(time.monotonic() - started, 3)}
    target = args.report
    if args.output_dir:
        args.output_dir.mkdir(parents=True, exist_ok=True)
        target = args.output_dir / "global_stability_interfaces.json"
    if target:
        with target.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2)
            handle.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

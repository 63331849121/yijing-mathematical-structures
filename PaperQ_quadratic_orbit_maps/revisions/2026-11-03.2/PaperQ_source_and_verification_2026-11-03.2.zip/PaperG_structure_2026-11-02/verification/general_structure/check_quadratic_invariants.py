"""Exact sparse Boolean identity control for quadratic first integrals.

No CE matrix and no full-state enumeration.  The input maps are the
published seven-prefix chain and the independent eighteen-bit class-four
seed.  Functions have zero constant term; all dimensions are over F2,
equivalently over F4 after scalar extension of the output coefficient.
Default read-only.  --report creates a NEW JSON path exclusively.
"""
import argparse
import json
from itertools import combinations
from pathlib import Path


def add(*polys):
    out = set()
    for p in polys:
        out.symmetric_difference_update(p)
    return frozenset(out)


def mul(p, q):
    out = set()
    for a in p:
        for b in q:
            mon = a | b
            if mon in out:
                out.remove(mon)
            else:
                out.add(mon)
    return frozenset(out)


ZERO = frozenset()


def fadd(*values):
    return add(*(x[0] for x in values)), add(*(x[1] for x in values))


def fmul(x, y):
    aa, bb = mul(x[0], y[0]), mul(x[1], y[1])
    return add(aa, bb), add(mul(x[0], y[1]), mul(x[1], y[0]), bb)


def square(x):
    return add(x[0], x[1]), x[1]


def omega(x):
    return x[1], add(x[0], x[1])


def variables(count):
    return [(frozenset({1 << (2*j)}), frozenset({1 << (2*j+1)}))
            for j in range(count)]


def chain(count):
    a,b,c,d,e,h,r,s = variables(8)
    out = [omega(a), omega(b), fadd(omega(c),fmul(a,b)),
           fadd(omega(d),fmul(a,c),fmul(square(a),b)),
           fadd(omega(e),fmul(b,c),fmul(a,square(b))),
           fadd(omega(h),fmul(a,e),fmul(b,d)),
           fadd(omega(r),fmul(a,square(c)),fmul(square(a),e),fmul(a,h),fmul(c,d)),
           fadd(omega(s),fmul(b,square(c)),fmul(square(b),d),fmul(b,h),fmul(c,e))]
    return out[:count], 2


def seed():
    a,b,c,z,w,v,h,k,r = variables(9)
    out=[omega(a),omega(b),omega(c),fadd(omega(z),fmul(a,b)),
         fadd(omega(w),fmul(a,c)),fadd(omega(v),fmul(b,c)),
         fadd(omega(h),fmul(a,v),fmul(c,z)),
         fadd(omega(k),fmul(a,w),fmul(square(a),c)),
         fadd(omega(r),fmul(z,w),fmul(a,h),fmul(b,k),fmul(square(a),v))]
    return out,3


def kernel(rows, cols):
    pivots = {}
    for row in rows:
        while row:
            p = row.bit_length()-1
            if p in pivots:
                row ^= pivots[p]
            else:
                pivots[p] = row
                break
    result=[]
    for free in range(cols):
        if free in pivots:
            continue
        v = 1 << free
        for p in sorted(pivots):
            if (pivots[p] & v).bit_count() & 1:
                v ^= 1 << p
        assert all(not ((r&v).bit_count()&1) for r in rows)
        result.append(v)
    return result, len(pivots)


def substitute(p, out):
    result=ZERO
    for mon in p:
        term=frozenset({0})
        for j in range(len(out)):
            if (mon >> j)&1:
                term=mul(term,out[j])
        result=add(result,term)
    return result


def control(name, field_out, abelian_rank):
    out=[p for pair in field_out for p in pair]
    n=len(out)
    # A separate polynomial identity checks the supplied model before Ig.
    for j,p in enumerate(out):
        assert not add(substitute(p,out),p,frozenset({1<<j}))
    masks=[1<<j for j in range(n)]+[(1<<i)|(1<<j) for i,j in combinations(range(n),2)]
    cols=[]
    for mon in masks:
        cols.append(add(substitute(frozenset({mon}),out),frozenset({mon})))
    rowdict={}
    for j,p in enumerate(cols):
        for mon in p:
            rowdict[mon]=rowdict.get(mon,0)^(1<<j)
    basis,rank=kernel(list(rowdict.values()),len(masks))
    u_mask=(1<<(2*abelian_rank))-1
    bad=[]
    for v in basis:
        support=[masks[j] for j in range(len(masks)) if (v>>j)&1]
        if any(mon & ~u_mask for mon in support):
            bad.append(support)
    assert not bad
    assert len(basis)==abelian_rank**2
    return {'name':name,'binary_dimension':n,'cochain_unknowns':len(masks),
            'nonzero_anf_equation_rows':len(rowdict),'invariance_rank':rank,
            'invariant_quadratic_dimension':len(basis),
            'abelianization_F4_rank':abelian_rank,
            'all_invariants_factor_through_abelianization':not bad,
            'basis_boolean_monomial_masks':[[masks[j] for j in range(len(masks)) if(v>>j)&1] for v in basis]}


def main():
    p=argparse.ArgumentParser();p.add_argument('--report',type=Path);args=p.parse_args()
    cases=[]
    for count in (7,8):
        out,d=chain(count);cases.append(control(f'chain_{2*count}',out,d))
    out,d=seed();cases.append(control('class4_seed_18',out,d))
    report={'status':'PASS','field':'F2 Boolean coefficients; F4 output by scalar extension',
            'scope':'Exact sparse ANF identities, no CE or full-state enumeration; finite controls only',
            'cases':cases}
    if args.report:
        with args.report.open('x',encoding='utf8') as stream:
            json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()

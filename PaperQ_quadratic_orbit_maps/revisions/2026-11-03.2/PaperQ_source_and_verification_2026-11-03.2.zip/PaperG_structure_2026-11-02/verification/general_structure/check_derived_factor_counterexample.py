"""Exact 22-bit counterexample to a whole-derived factor D=JB.

The displayed coordinate formula is constructed locally. Boolean polynomial
composition verifies f^2=f+I without state sampling. The polar and D tables
are rebuilt from this formula. Standard-library sibling linear algebra only.
"""
import argparse
import itertools
import json
from pathlib import Path
from check_explicit_model import echelon, xor_product


def mul(a, b):
    result = 0
    for _ in range(2):
        if b & 1:
            result ^= a
        b >>= 1
        a <<= 1
        if a & 4:
            a ^= 7
    return result


def f(value):
    a, b, c, d, z, v, w, s1, s2, s3, t = [
        (value >> (2*i)) & 3 for i in range(11)]
    coords = [a, b, c, d, z, v, w, s1, s2, s3, t]
    correction = [0, 0, 0, 0,
                  mul(a, b) ^ mul(c, d), mul(a, d), mul(b, d),
                  mul(a, z) ^ mul(c, v) ^ mul(mul(a, a), b),
                  mul(b, z) ^ mul(c, w) ^ mul(a, mul(b, b)),
                  mul(a, w) ^ mul(b, v),
                  mul(a, s2) ^ mul(b, s1) ^ mul(c, s3)]
    return sum((mul(2, x) ^ q) << (2*i)
               for i, (x, q) in enumerate(zip(coords, correction)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    n = 22
    basis = [1 << i for i in range(n)]
    linear = [f(x) for x in basis]
    polar = [[0]*n for _ in range(n)]
    polys = [set() for _ in range(n)]
    for i, value in enumerate(linear):
        for k in range(n):
            if value >> k & 1:
                polys[k].add(1 << i)
    for i, j in itertools.combinations(range(n), 2):
        value = f(basis[i] ^ basis[j]) ^ linear[i] ^ linear[j]
        polar[i][j] = polar[j][i] = value
        for k in range(n):
            if value >> k & 1:
                polys[k].add(basis[i] | basis[j])
    for k, polynomial in enumerate(polys):
        composition = set(polynomial)
        composition.symmetric_difference_update({1 << k})
        for mask in polynomial:
            indices = [i for i in range(n) if mask >> i & 1]
            term = (polys[indices[0]] if len(indices) == 1 else
                    xor_product(polys[indices[0]], polys[indices[1]]))
            composition.symmetric_difference_update(term)
        assert not composition

    def bracket(x, y):
        result = 0
        for i in range(n):
            if x >> i & 1:
                for j in range(n):
                    if y >> j & 1:
                        result ^= polar[i][j]
        return result

    triples = 0
    for x, y, z in itertools.combinations(basis, 3):
        assert bracket(x, bracket(y, z)) ^ bracket(y, bracket(z, x)) ^ bracket(z, bracket(x, y)) == 0
        triples += 1
    lower = [basis]
    while lower[-1]:
        lower.append(list(echelon(bracket(x, y) for x in basis for y in lower[-1]).values()))
        assert len(lower) < n + 2
    assert [len(v) for v in lower] == [22, 14, 8, 2, 0]
    assert not any(bracket(x, y) for x in lower[1] for y in lower[1])
    pairs = list(itertools.combinations(range(n), 2))
    bcols = [polar[i][j] for i, j in pairs]
    dcols = [bracket(linear[i], basis[j]) ^ bracket(basis[i], polar[i][j]) for i, j in pairs]
    rank_b = len(echelon(bcols))
    graph_rank = len(echelon(b | (d << n) for b, d in zip(bcols, dcols)))
    assert (rank_b, graph_rank) == (14, 16)
    cycle = [(0, 2), (4, 6), (0, 8), (2, 8)]
    cycle_b = cycle_d = 0
    for i, j in cycle:
        index = pairs.index((i, j))
        cycle_b ^= bcols[index]
        cycle_d ^= dcols[index]
    assert cycle_b == 0 and cycle_d == (1 << 20)
    assert all(bracket(cycle_d, x) == 0 for x in basis)
    report = {"status": "PASS", "binary_dimension": n,
              "exact_Boolean_composition_identity": True,
              "jacobi_basis_triples": triples,
              "lower_central_dimensions": [len(v) for v in lower],
              "metabelian": True, "rank_B": rank_b, "rank_B_D_graph": graph_rank,
              "cycle_basis_pairs_zero_based": cycle,
              "cycle_B": cycle_b, "cycle_D": cycle_d, "cycle_D_central": True,
              "consequence": "No binary-linear map on the whole derived space can satisfy D=JB",
              "scope": "One explicit obstruction; the reduced-derived theorem is not contradicted"}
    if args.report:
        with args.report.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2)
            handle.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

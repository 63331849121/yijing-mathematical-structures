"""Independent full-table audit; no inherited arithmetic or checker imports.

Reads archived tables only. Opposite (high-coordinate) pivot convention.
Checks actual extension algebras, not just incremental cocycle rows.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement,permutations
import json,time
HERE=Path(__file__).resolve().parent
M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
INV=(0,1,3,2)
def terms(v):
    while v:
        i=(v.bit_length()-1)//2;a=(v>>(2*i))&3
        yield i,a
        v^=a<<(2*i)
def scale(a,v):
    return sum(M[a][b]<<(2*i) for i,b in terms(v))
def add(v,piv,label=None):
    while v:
        i=(v.bit_length()-1)//2;a=(v>>(2*i))&3
        if i in piv:
            row,lab=piv[i];v^=scale(a,row)
            if label is not None:label^=scale(a,lab)
        else:
            piv[i]=(scale(INV[a],v),None if label is None else scale(INV[a],label))
            return None
    return label
def audit(name,t,expectedN,expected_class):
    start=time.monotonic();n=len(t);u=[1<<(2*i) for i in range(n)]
    def br(x,y):
        out=0
        for i,a in terms(x):
            for j,b in terms(y):out^=scale(M[a][b],t[i][j])
        return out
    for i in range(n):
        assert not t[i][i]
        for j in range(n):assert t[i][j]==t[j][i]
    for i,j,k in combinations(range(n),3):
        assert not (br(t[i][j],u[k])^br(t[j][k],u[i])^br(t[k][i],u[j]))
    d=[[[br(t[y][a],u[b]) for b in range(n)] for a in range(n)] for y in range(n)]
    for y in range(n):
        for tri in combinations_with_replacement(range(n),3):
            out=0
            for a,b,c in set(permutations(tri)):out^=br(d[y][a][b],u[c])
            assert not out,('Engel',name,y,tri)
    for a,b,c in combinations(range(n),3):
        out=br(d[a][b][c],d[b][c][a])
        for x,y,z in ((a,b,c),(b,c,a),(c,a,b)):
            out^=br(br(d[x][y][z],u[z]),t[x][y])
        assert not out,('R',name,a,b,c)
    pairs=list(combinations(range(n),2));cols=[t[i][j] for i,j in pairs]
    q=[br(d[i][j][j],u[i]) for i,j in pairs]
    piv={};cycles=[]
    for j,v in enumerate(cols):
        z=add(v,piv,1<<(2*j))
        if z is not None:cycles.append(z)
    image={}
    for z in cycles:
        out=0;part=0
        for j,a in terms(z):
            out^=scale(M[a][a],q[j]);v=scale(a,cols[j])
            out^=br(part,v);part^=v
        assert not part
        assert all(not br(out,x) for x in u)
        add(out,image)
    assert len(image)==expectedN,(name,'N',len(image),expectedN)
    spans={};[add(x,spans) for x in u];dims=[n]
    while spans:
        nxt={}
        for x,_ in spans.values():
            for y in u:add(br(x,y),nxt)
        dims.append(len(nxt));spans=nxt
    assert len(dims)-1==expected_class,(name,dims)
    row=dict(model=name,status='PASS',dimension=n,N=expectedN,lower_central_dimensions=dims,CE_cycles=len(cycles),Jacobi=n*(n-1)*(n-2)//6,full_Engel=n*n*(n+1)*(n+2)//6,R_basis=n*(n-1)*(n-2)//6,seconds=time.monotonic()-start)
    print(json.dumps(row),flush=True)
    return row
def main():
    records=[]
    for name,c in [('S2_class4',4),('S3_partial_repair',4),('mixed_F4_class5',5),('D45_nonmetabelian_class4',4),('class7_N0',7)]:
        d=json.loads((HERE/(name+'_minimum_repair.json')).read_text())
        records.append(audit(name,d['table'],0,c))
    d=json.loads((HERE/'S3_partial_repair_minimum_repair.json').read_text());n=d['base_dimension'];nc=len(d['base_N_basis'])
    base=[row[:n] for row in d['table'][:n]]
    for i in range(n):
        for j in range(n):base[i][j]&=(1<<(2*n))-1
    for s in (1,2):
        t=[row+[0]*s for row in base]+[[0]*(n+s) for _ in range(s)]
        for i in range(n):
            for j in range(n):t[i][j]^=(d['beta'][i][j]>>(2*(nc-s)))<<(2*n)
        records.append(audit('S3_partial_s'+str(s),t,nc-s,4))
    (HERE/'independent_repair_audit.json').write_text(json.dumps(dict(status='PASS',scope='Separate full-table implementation, no inherited arithmetic/checker modules; not external expert review.',cases=records),indent=2)+'\n')
if __name__=='__main__':main()

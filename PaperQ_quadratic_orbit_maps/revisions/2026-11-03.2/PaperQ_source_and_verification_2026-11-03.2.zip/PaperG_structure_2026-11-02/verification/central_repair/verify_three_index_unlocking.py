"""Independent literal formula for the cost-three all-r>=3 construction."""
from pathlib import Path
from itertools import combinations
import json
from verify_uniform_unlocking import model
from audit_repair_independent import audit,terms,scale,add,M
HERE=Path(__file__).resolve().parent

def triple_model(r):
    old,ow,names,a=model(r);mask=(1<<(2*a))-1
    n=a+3;t=[[0]*n for _ in range(n)]
    for i in range(a):
        for j in range(a):t[i][j]=old[i][j]&mask
    names=names[:a]+['P','Q','Z'];w=ow[:a]+[3,4,5];ids={s:i for i,s in enumerate(names)}
    for x,y,z in [('A1','U2_3','P'),('A2','U1_3','P'),('A1','T2_3','Q'),('A2','T1_3','Q'),('A3','P','Q'),('B3','Q','Z'),('U1_3','T2_3','Z'),('U2_3','T1_3','Z'),('V3','P','Z')]:
        i,j,k=ids[x],ids[y],ids[z];assert not t[i][j];t[i][j]=t[j][i]=1<<(2*k)
    return t,w,names,a
def main():
    reports=[];seed=json.loads((HERE/'rank3_cost_three_seed.json').read_text())
    for r in (3,4,5):
        t,w,names,a=triple_model(r);n=len(t);ids={s:i for i,s in enumerate(names)}
        if r==3:assert t==seed['table'] and w==seed['weights']
        rec=audit('literal_three_index_G'+str(r),t,0,5)
        def br(x,y):
            out=0
            for i,c in terms(x):
                for j,d in terms(y):out^=scale(M[c][d],t[i][j])
            return out
        span={}
        for h in range(2*r):add(1<<(2*h),span)
        while True:
            prev=len(span)
            for v,_ in list(span.values()):
                for h in range(2*r):add(br(v,1<<(2*h)),span)
            if len(span)==prev:break
        assert len(span)==n
        for cutoff,ker in [(a+1,[s for s in names if s.startswith('C')]+['P']),(a+2,['Q']),(a+3,['Z'])]:
            mm=(1<<(2*cutoff))-1
            for s in ker:
                for j in range(cutoff):assert not t[ids[s]][j]&mm
        # Explicit retraction onto the literal rank-three-index seed.
        base_names=seed['base_names'];target_names=base_names+['P','Q','Z'];target_ids={s:i for i,s in enumerate(target_names)}
        cols=[0]*n
        for i,name in enumerate(names):
            if name in target_ids:cols[i]=1<<(2*target_ids[name])
        def proj(v):
            out=0
            for i,c in terms(v):out^=scale(c,cols[i])
            return out
        st=seed['table']
        for i,j in combinations(range(n),2):
            v=0
            for x,c in terms(cols[i]):
                for y,d in terms(cols[j]):v^=scale(M[c][d],st[x][y])
            assert proj(t[i][j])==v
        m=r*(r-1)//2
        rec.update(point_rank=2*r,stages=[3*r*r-1,a+1,a+2,a+3],central_kernel_dimensions=[m+1,1,1],head_generation=True,retraction_to_seed=True)
        reports.append(rec)
        (HERE/f'three_index_G{r}_literal.json').write_text(json.dumps(dict(table=t,weights=w,names=names,A_dimension=a),indent=2)+'\n')
    (HERE/'three_index_unlocking_controls.json').write_text(json.dumps(dict(status='PASS',cases=reports,scope='Literal finite seed and controls; all-rank statement follows from the explicit A_r -> A3 retract and fiber products.'),indent=2)+'\n')
if __name__=='__main__':main()

"""Weight-profile CE/Engel matrices, independent of the inherited constructor.

Binary constants give the same ranks over F4; only possible weight profiles
are enumerated. Full cubic coefficients, including repeated variables.
"""
from itertools import combinations,combinations_with_replacement,permutations,product
from audit_repair_independent import terms,scale,M

def pivots(rows):
    p={}
    for v in rows:
        while v:
            i=(v&-v).bit_length()-1
            if i in p:v^=p[i]
            else:p[i]=v;break
    return p
def nullspace(rows,d):
    p=pivots(rows);out=[]
    for j in range(d):
        if j in p:continue
        v=1<<j
        for i in sorted(p,reverse=True):
            if (p[i]&v).bit_count()%2:v^=1<<i
        out.append(v)
    return out
def br(t,x,y):
    out=0
    for i,a in terms(x):
        for j,b in terms(y):out^=scale(M[a][b],t[i][j])
    return out
def profile_tuples(groups,total,length,repeats):
    weights=sorted(groups)
    for wt in combinations_with_replacement(weights,length):
        if sum(wt)!=total:continue
        blocks=[]
        for w in sorted(set(wt)):
            k=wt.count(w)
            blocks.append(list((combinations_with_replacement if repeats else combinations)(groups[w],k)))
        for block in product(*blocks):yield tuple(i for xs in block for i in xs)
def equations(t,w,q):
    n=len(t);groups={j:[i for i,v in enumerate(w) if v==j] for j in set(w)}
    pairs=[(i,j) for i,j in combinations(range(n),2) if w[i]+w[j]==q];look={p:i for i,p in enumerate(pairs)}
    def be(x,y):
        out=0
        for i,a in terms(x):
            for j,b in terms(y):
                if i==j:continue
                k=look.get(tuple(sorted((i,j))))
                if k is not None:
                    c=M[a][b];assert c in (0,1);out^=c<<k
        return out
    rows=[];jc=ec=0
    for i,j,k in profile_tuples(groups,q,3,False):
        rows.append(be(t[i][j],1<<(2*k))^be(t[j][k],1<<(2*i))^be(t[k][i],1<<(2*j)));jc+=1
    for y in range(n):
        for tri in profile_tuples(groups,q-w[y],3,True):
            v=0
            for a,b,c in set(permutations(tri)):v^=be(br(t,t[y][a],1<<(2*b)),1<<(2*c))
            rows.append(v);ec+=1
    return pairs,rows,dict(variables=len(pairs),Jacobi_rows=jc,Engel_rows=ec,equation_rank=len(pivots(rows)))
def representatives(t,w,q):
    pairs,rows,rec=equations(t,w,q);kb=nullspace(rows,len(pairs))
    cb=[]
    for z in range(len(t)):
        if w[z]!=q:continue
        v=0
        for j,(a,b) in enumerate(pairs):
            c=(t[a][b]>>(2*z))&3;assert c in (0,1);v^=c<<j
        cb.append(v)
    p=pivots(cb);reps=[]
    for v in kb:
        old=len(p)
        while v:
            i=(v&-v).bit_length()-1
            if i in p:v^=p[i]
            else:p[i]=v;break
        if len(p)>old:reps.append(v)
    rec.update(cocycles=len(kb),coboundaries=len(pivots(cb)),H2=len(reps))
    assert len(kb)+rec['equation_rank']==len(pairs)
    assert all(not (row&v).bit_count()%2 for row in rows for v in reps)
    return pairs,reps,rec
def simultaneous(t,w,q):
    pairs,kb,rec=representatives(t,w,q);n=len(t);d=len(kb)
    out=[row+[0]*d for row in t]+[[0]*(n+d) for _ in range(d)]
    for j,v in enumerate(kb,n):
        for k,(a,b) in enumerate(pairs):
            if v>>k&1:out[a][b]^=1<<(2*j);out[b][a]^=1<<(2*j)
    return out,w+[q]*d,rec

"""Fresh small CE/rotation controls; no 14-dimensional data or code used.

Models: C(a,b,c)=(omega*a,omega*b,omega*c+a*b) over F4, and the
abelian map omega*Id on F4^2. Binary CE systems are reconstructed from
point values. Scalar cochains have values in F4. Default is read-only;
--report exclusively creates a new JSON file. Standard library only.
"""
from itertools import combinations
from pathlib import Path
import argparse
import json
import platform


def gf_mul(a,b):
    a0,a1,b0,b1=a&1,a>>1,b&1,b>>1
    return ((a0*b0)^(a1*b1))|(((a0*b1)^(a1*b0)^(a1*b1))<<1)
M=[[gf_mul(a,b) for b in range(4)] for a in range(4)]
INV={1:1,2:3,3:2}


def f2_rank(vectors):
    p={}
    for value in vectors:
        while value:
            k=value.bit_length()-1
            if k in p:value^=p[k]
            else:p[k]=value;break
    return len(p)


def f2_kernel(rows,n):
    p={}
    for value in rows:
        while value:
            k=value.bit_length()-1
            if k in p:value^=p[k]
            else:p[k]=value;break
    result=[]
    for j in range(n):
        if j in p:continue
        value=1<<j
        for k in sorted(p):
            if (p[k]&value).bit_count()&1:value^=1<<k
        result.append(value)
    return result


def apply_f2(columns,value):
    result=0
    while value:
        bit=value&-value
        result^=columns[bit.bit_length()-1]
        value^=bit
    return result


def quotient_basis(subspace,generators):
    pivots={}
    def reduce(value):
        coord=0
        while value:
            k=value.bit_length()-1
            if k not in pivots:break
            v,label=pivots[k];value^=v;coord^=label
        return value,coord
    for original in subspace:
        value,coord=reduce(original)
        if value:pivots[value.bit_length()-1]=(value,0)
    chosen=[]
    for original in generators:
        value,coord=reduce(original)
        if value:
            j=len(chosen);chosen.append(original)
            pivots[value.bit_length()-1]=(value,coord^(1<<j))
    def coordinates(value):
        rest,coord=reduce(value)
        assert not rest
        return coord
    return chosen,coordinates


def gf_rref(rows,ncols):
    a=[row.copy() for row in rows if any(row)]
    pivots=[];r=0
    for col in range(ncols):
        target=next((i for i in range(r,len(a)) if a[i][col]),None)
        if target is None:continue
        a[r],a[target]=a[target],a[r]
        inv=INV[a[r][col]];a[r]=[M[inv][x] for x in a[r]]
        for i in range(len(a)):
            if i!=r and a[i][col]:
                c=a[i][col];a[i]=[x^M[c][y] for x,y in zip(a[i],a[r])]
        pivots.append(col);r+=1
        if r==len(a):break
    return a[:r],pivots


def gf_rank(rows,ncols):return len(gf_rref(rows,ncols)[1])


def gf_kernel(rows,ncols):
    a,piv=gf_rref(rows,ncols);out=[]
    for free in range(ncols):
        if free in piv:continue
        v=[0]*ncols;v[free]=1
        for row,p in zip(a,piv):v[p]=row[free]
        out.append(v)
    return out


def transpose(cols,nrows):return [[col[i] for col in cols] for i in range(nrows)]
def gf_mm(a,b):
    if not a:return []
    rows=len(a);mid=len(b);cols=len(b[0]) if b else 0
    out=[[0]*cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            for k in range(mid):out[i][j]^=M[a[i][k]][b[k][j]]
    return out
def gf_mv(a,v):
    out=[]
    for row in a:
        value=0
        for x,y in zip(row,v):value^=M[x][y]
        out.append(value)
    return out


def anf(values,n):
    out=values.copy()
    for j in range(n):
        bit=1<<j
        for mask in range(1<<n):
            if mask&bit:out[mask]^=out[mask^bit]
    return out


def make_model(kind):
    n=6 if kind=='class2_C' else 4
    def g(value):
        x=[(value>>(2*j))&3 for j in range(n//2)]
        y=[M[2][a] for a in x]
        if kind=='class2_C':y[2]^=M[x[0]][x[1]]
        return sum(a<<(2*j) for j,a in enumerate(y))
    return n,g


def control(kind):
    n,g=make_model(kind);size=1<<n
    pairs=list(combinations(range(n),2));pair_index={p:i for i,p in enumerate(pairs)}
    masks=[(1<<i)|(1<<j) for i,j in pairs];m=len(pairs)
    bracket=[[g((1<<i)^(1<<j))^g(1<<i)^g(1<<j) for j in range(n)] for i in range(n)]
    assert all(g(g(x))==g(x)^x for x in range(size))
    # Reconstruct CE d:C2->C3 and d:C1->C2 directly from binary polar.
    ce_rows=[]
    for i,j,k in combinations(range(n),3):
        row=0
        for a,b,c in ((i,j,k),(j,k,i),(k,i,j)):
            for ell in range(n):
                if bracket[a][b]>>ell&1 and ell!=c:
                    row^=1<<pair_index[tuple(sorted((ell,c)))]
        ce_rows.append(row)
    boundaries=[sum(((bracket[i][j]>>ell)&1)<<p for p,(i,j) in enumerate(pairs))
                for ell in range(n)]
    Z=f2_kernel(ce_rows,m);b_rank=f2_rank(boundaries)
    assert all(not ((row&b).bit_count()&1) for row in ce_rows for b in boundaries)
    # Canonical q_alpha has exactly the pair coefficients of alpha.
    composition=[]
    for i,j in pairs:
        values=[((g(x)>>i)&1)*((g(x)>>j)&1) for x in range(size)]
        a=anf(values,n)
        composition.append(sum(v<<mask for mask,v in enumerate(a)))
    high_masks=[mask for mask in range(size) if mask.bit_count()>=3]
    leakage_rows=[sum(((col>>mask)&1)<<p for p,col in enumerate(composition))
                  for mask in high_masks]
    raw_leakage_rank=f2_rank(leakage_rows)
    if kind=='class2_C':assert raw_leakage_rank>0
    K=f2_kernel(ce_rows+leakage_rows,m)
    assert all(not apply_f2(composition,b)&sum(1<<a for a in high_masks) for b in boundaries)
    quotient,coord=quotient_basis(boundaries,K);kdim=len(quotient)
    tau_cols_raw=[sum(((col>>mask)&1)<<p for p,mask in enumerate(masks)) for col in composition]
    for vector in K:
        image=apply_f2(tau_cols_raw,vector)
        assert all(not ((row&image).bit_count()&1) for row in ce_rows+leakage_rows)
    for b in boundaries:assert coord(apply_f2(tau_cols_raw,b))==0
    tau_cols=[coord(apply_f2(tau_cols_raw,q)) for q in quotient]
    tau=[[int(bool(tau_cols[j]&(1<<i))) for j in range(kdim)] for i in range(kdim)]
    tau2=gf_mm(tau,tau);tau3=gf_mm(tau,tau2)
    identity=[[int(i==j) for j in range(kdim)] for i in range(kdim)]
    assert tau3==identity
    eig={}
    for label,value in [('omega_squared',3),('one',1),('omega',2)]:
        test=[[tau[i][j]^(value if i==j else 0) for j in range(kdim)] for i in range(kdim)]
        eig[label]=kdim-gf_rank(test,kdim)
    projector=[[identity[i][j]^M[2][tau[i][j]]^M[3][tau2[i][j]]
                for j in range(kdim)] for i in range(kdim)]
    prank=gf_rank(projector,kdim)
    assert gf_mm(projector,projector)==projector
    assert gf_mm(tau,projector)==[[M[3][x] for x in row] for row in projector]
    assert prank==eig['omega_squared'] and sum(eig.values())==kdim
    # Independently solve q(gx)=omega^2*q(x), including all linear terms,
    # and quotient the actual linear-section gauge q->q+ell*g+omega*ell.
    low_masks=[1<<i for i in range(n)]+masks
    qcols=[]
    for mask in low_masks:
        vals=[int((g(x)&mask)==mask) for x in range(size)]
        a=anf(vals,n);qcols.append(a)
    admissible_rows=[[qcols[j][mask]^(3 if mask==low_masks[j] else 0)
                      for j in range(len(low_masks))] for mask in range(size)]
    admissible=gf_kernel(admissible_rows,len(low_masks))
    gauges=[]
    for ell in range(n):
        vals=qcols[ell]
        col=[vals[mask] for mask in low_masks];col[ell]^=2
        assert not any(gf_mv(admissible_rows,col))
        gauges.append(col)
    gauge_rank=gf_rank(transpose(gauges,len(low_masks)),n)
    direct_hg_dim=len(admissible)-gauge_rank
    polar_images=[]
    for q in admissible:
        alpha=q[n:]
        planes=[sum(((a>>bit)&1)<<j for j,a in enumerate(alpha)) for bit in range(2)]
        for plane in planes:
            assert all(not ((row&plane).bit_count()&1) for row in ce_rows+leakage_rows)
        c0,c1=(coord(plane) for plane in planes)
        image=[int(bool(c0&(1<<i)))|(int(bool(c1&(1<<i)))<<1) for i in range(kdim)]
        assert gf_mv(tau,image)==[M[3][v] for v in image]
        polar_images.append(image)
    polar_rank=gf_rank(transpose(polar_images,kdim),len(polar_images))
    assert direct_hg_dim==prank==polar_rank
    return {'model':kind,'binary_dimension':n,'points':size,'scalar_cochains':m,
            'derived_binary_rank':f2_rank([bracket[i][j] for i,j in pairs]),
            'CE_Z2_dimension_F4':len(Z),'CE_B2_dimension_F4':b_rank,
            'CE_H2_dimension_F4':len(Z)-b_rank,
            'raw_high_leakage_rank_on_all_C2':raw_leakage_rank,
            'raw_high_leakage_kernel_dimension_C2':m-raw_leakage_rank,
            'Theta_rank_on_H2':len(Z)-len(K),
            'K_dimension_F4':kdim,'tau_matrix_F2_entries':tau,
            'K_quotient_basis_pair_supports':[[list(pairs[j]) for j in range(m) if v>>j&1] for v in quotient],
            'tau_cubed_is_identity':True,'eigenspace_dimensions_F4':eig,
            'Pi_rank_F4':prank,'Pi_idempotent':True,
            'direct_equation_qg_equals_omega_squared_q':{
                'quadratic_plus_linear_coefficients':len(low_masks),
                'admissible_q_dimension_F4':len(admissible),
                'linear_section_gauge_rank_F4':gauge_rank,
                'H_g_dimension_F4':direct_hg_dim,
                'polarization_image_rank_on_H2':polar_rank}}


def controls():
    records=[control('class2_C'),control('abelian_F4_squared')]
    assert records[0]['direct_equation_qg_equals_omega_squared_q']['H_g_dimension_F4']==2
    assert records[1]['eigenspace_dimensions_F4']=={'omega_squared':1,'one':4,'omega':1}
    return {'status':'PASS','field':'F4=F2[omega]/(omega^2+omega+1)',
            'python_version':platform.python_version(),'dependencies':'Python standard library only',
            'scope':'Fresh six- and four-dimensional binary point/CE/ANF reconstruction; no 14-dimensional code or data.',
            'models':records}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report',type=Path);a=p.parse_args()
    result=controls()
    if a.report:
        with a.report.open('x',encoding='utf8') as out:out.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

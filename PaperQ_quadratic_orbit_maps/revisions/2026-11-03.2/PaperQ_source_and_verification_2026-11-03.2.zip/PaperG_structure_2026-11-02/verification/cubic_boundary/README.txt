Cubic boundary and intrinsic scalar locus / Q 2026-11-03.2
Run the portable cubic-boundary group with verification/run_replay.py.
The specification selects --paper-only for verify_scalar_line.py,
audit_selector_and_profile.py and audit_degree_boundary.py.
verify_intrinsic.py is unchanged. All four selected invocations passed.

Paper-only roles: complete orientation kernels, Hermitian m2/3 censuses,
four-bit quadratic encoder exclusions, zero-point selector uniqueness,
inverse leading terms, all-rank degree/defect controls, intrinsic binary
field/rank recovery, and head/readout interfaces.
The existing ordinary_reconstruction/small_sextic_detector.json is read
locally to obtain a new defect stencil, without rerunning its inherited
universal identity and Jacobi/Engel certificate as part of this group.

Removed from the default replay: full filtered character profiles,
rank-three exceptional conjugators, integer degree enumerators and
all-conjugator matrix strata. Original functions and historical bare-script
modes are retained; they are successor research, not extra theorem claims.
General proofs and arbitrary auxiliary-dimension exclusion are in Appendix L.

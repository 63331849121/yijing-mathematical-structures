"""Second implementation: coefficient-only checks, no imports from verifier.

Controls the zero-point ambiguity, the inverse-degree interface, and the
integer character enumerator. These finite checks do not replace proofs.
"""
from pathlib import Path
from math import comb
import json, sys

ARCHIVE=Path(__file__).resolve().parent
def rank(rows):
 piv={}
 for row in rows:
  while row:
   k=row.bit_length()-1
   if k in piv:row ^= piv[k]
   else:piv[k]=row;break
 return len(piv)

def selector_controls():
 results=[]
 for n in range(4,13):
  rows=[]
  for S in range(1<<n):
   if S.bit_count()<4:continue
   for i in range(n):
    if S>>i&1:rows.append((1<<S)^(1<<(S^(1<<i))))
  dim=(1<<n)-rank(rows);expected=2+n+comb(n,2);assert dim==expected
  parameters=[1<<S for S in range(1<<n) if S.bit_count()<=2]+[(1<<(1<<n))-1]
  assert rank(parameters)==dim
  results.append(dict(binary_dimension=n,unknown_ANF_coefficients=1<<n,
   complete_product_constraint_kernel_dimension=dim,quadratic_plus_delta_dimension=expected))
 # Every Boolean function of four binary variables, with literal products.
 n=4;allowed=0
 for coefficients in range(1<<(1<<n)):
  products=[]
  for i in range(n):
   value=0
   for S in range(1<<n):
    if coefficients>>S&1:value ^= 1<<(S|(1<<i))
   products.append(value)
  ok=all(all(not (p>>S&1) for S in range(1<<n) if S.bit_count()>3) for p in products)
  b=(coefficients>>7)&1;canonical=coefficients^(((1<<(1<<n))-1) if b else 0)
  claimed=all(not(canonical>>S&1) for S in range(1<<n) if S.bit_count()>=3)
  assert ok==claimed
  allowed+=ok
 assert allowed==4096
 return dict(full_four_bit_boolean_function_census=65536,accepted=allowed,linear_controls=results)

def leading_term_controls():
 out=[]
 for m in range(2,9):
  n=2*m
  for r in range(2,m+1):
   pairs=[(1<<(2*i))|(1<<(2*i+1)) for i in range(r)];cols=[]
   for i in range(n):
    terms=0
    for p in pairs:
     if not p>>i&1:terms ^= 1<<(p|(1<<i))
    cols.append(terms)
   actual=rank(cols);assert actual==n
   out.append(dict(ambient_F4_dimension=m,Hermitian_rank=r,leading_linear_multiplication_rank=actual))
 return out

def profile_controls():
 out=[]
 for m in range(1,41):
  # Characters: dynamic multiplication of (1+t*u+t*u^2+t^2)^m.
  char={(0,0):1}
  for _ in range(m):
   new={}
   for (d,j),a in char.items():
    for e,k in ((0,0),(1,1),(1,2),(2,0)):new[d+e,(j+k)%3]=new.get((d+e,(j+k)%3),0)+a
   char=new
  a=[sum(char.get((t,1),0) for t in range(d+1)) for d in range(2*m+1)]
  h=(2**m-(-1)**m)//3
  # Basis count independently assembled as a degree enumerator.
  increments=[0]*(2*m+1)
  for s in range(m):
   hs=(2**s-(-1)**s)//3
   for j in range(m-s):increments[s+2+2*j]+=2*comb(m,s)*hs*comb(m-s-1,j)
  increments[m]+=h
  e=[];total=0
  for d,inc in enumerate(increments):
   total+=inc;e.append(total)
   assert e[d]+(e[d-2] if d>=2 else 0)==2*(a[d-2] if d>=2 else 0)+(h if d in (m,m+1) else 0)
  assert e[-1]==(4**m-1)//3 and increments[-1]==0
  if m>=2:assert e[-1]-e[-3]==2*m
  out.append(dict(m=m,middle_character_dimension=h,total_character_dimension=e[-1],
   exact_recurrence=True,top_degree=next(d for d in range(2*m,-1,-1) if increments[d])))
 return out

if __name__=='__main__':
 paper_only='--paper-only' in sys.argv
 report={'selector_ambiguity':selector_controls(),'inverse_leading_degree':leading_term_controls(),
         'scope':'paper-only' if paper_only else 'paper plus retained successor controls','status':'PASS'}
 if not paper_only:report['independent_integer_profile']=profile_controls()
 (ARCHIVE/'selector_profile_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 print(json.dumps({'status':'PASS','scope':report['scope'],'full_selector_census':65536,
  'selector_constraint_dimensions':[x['complete_product_constraint_kernel_dimension'] for x in report['selector_ambiguity']['linear_controls']],
  'leading_interfaces':len(report['inverse_leading_degree'])},indent=2))

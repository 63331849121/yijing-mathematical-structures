import sys
"""Separate binary-row implementation and full matrix-stratum controls.

No imports from the exploratory checker; GF(4) uses direct polynomial bits.
General proofs are in notes 21 and 22. This file checks finite interfaces.
"""
from pathlib import Path
from itertools import combinations,product
import json,time

H=Path(__file__).resolve().parent
def gf(a,b):
 a0,a1=a&1,a>>1;b0,b1=b&1,b>>1
 return ((a0*b0)^(a1*b1))|(((a0*b1)^(a1*b0)^(a1*b1))<<1)
def sq(a):return gf(a,a)
def inv(a):assert a;return sq(a)
def tup(x,m):return tuple((x>>(2*i))&3 for i in range(m))
def pack(v):return sum(a<<(2*i) for i,a in enumerate(v))
def norm(v):
 out=0
 for a in v:out^=gf(a,sq(a))
 assert out in (0,1)
 return out
def fs(v):
 c=2^norm(v)
 return tuple(gf(c,a) for a in v)
def span_rank(rows):
 piv={}
 for v in rows:
  while v:
   k=v.bit_length()-1
   if k in piv:v^=piv[k]
   else:piv[k]=v;break
 return len(piv)
def mons(n,d):return [sum(1<<i for i in c) for e in range(d+1) for c in combinations(range(n),e)]
def eigen_binary_nullity(F,n,d):
 basis=mons(n,d);rows=[]
 for x,y in enumerate(F):
  r0=r1=0
  for j,s in enumerate(basis):
   a=int(y&s==s);b=int(x&s==s);w=a^(b<<1)
   mw=gf(2,w)
   r0|=(w&1)<<(2*j);r0|=(mw&1)<<(2*j+1)
   r1|=(w>>1)<<(2*j);r1|=(mw>>1)<<(2*j+1)
  rows.extend((r0,r1))
 nullity=2*len(basis)-span_rank(rows);assert nullity%2==0
 return nullity//2
def matvec(A,v):
 out=[]
 for row in A:
  a=0
  for x,y in zip(row,v):a^=gf(x,y)
  out.append(a)
 return tuple(out)
def identity(m):return [[int(i==j) for j in range(m)] for i in range(m)]
def mi(A):
 n=len(A);rows=[list(row)+[int(i==j) for j in range(n)] for i,row in enumerate(A)]
 for j in range(n):
  k=next((i for i in range(j,n) if rows[i][j]),None)
  if k is None:return None
  rows[j],rows[k]=rows[k],rows[j]
  a=inv(rows[j][j]);rows[j]=[gf(a,x) for x in rows[j]]
  for i in range(n):
   if i!=j and rows[i][j]:
    a=rows[i][j];rows[i]=[x^gf(a,y) for x,y in zip(rows[i],rows[j])]
 return [row[n:] for row in rows]
def mm(A,B):return [[matvec([r],col)[0] for col in zip(*B)] for r in A]
def unitary(A):
 return mm([[sq(A[j][i]) for j in range(len(A))] for i in range(len(A))],A)==identity(len(A))
def binary_degree(F):
 a=list(F);n=(len(a)-1).bit_length()
 for j in range(n):
  for x in range(len(a)):
   if x>>j&1:a[x]^=a[x^(1<<j)]
 return max((x.bit_count() for x,v in enumerate(a) if v),default=-1)
def cubic_basis_check(m):
 points=[tup(x,m) for x in range(4**m)]
 basis=[]
 for side in (0,1):
  for i in range(m):basis.append([v[i] if side==0 and norm(v)==0 else sq(v[i]) if side==1 and norm(v)==1 else 0 for v in points])
 # Independence over GF(4) checked by two binary columns per function.
 rows=[]
 for g in basis:
  rows.append(sum(a<<(2*j) for j,a in enumerate(g)))
  rows.append(sum(gf(2,a)<<(2*j) for j,a in enumerate(g)))
 assert span_rank(rows)==4*m
 for g in basis:
  assert all(g[pack(fs(v))]==gf(2,g[x]) for x,v in enumerate(points))
  assert binary_degree(g)==3
 return dict(m=m,complete_cubic_eigen_basis_functions=2*m,binary_basis_rank=4*m)
def matrix_controls(m):
 vs=[tup(x,m) for x in range(4**m)];positive=negative=0
 A=identity(m);A[0][-1]=2
 for block in product(range(4),repeat=4):
  C=identity(m);C[0][:2]=block[:2];C[1][:2]=block[2:]
  actual=[]
  for v in vs:
   u=v if norm(v)==0 else matvec(C,tuple(sq(a) for a in v))
   actual.append(pack(matvec(A,u)))
  expected=unitary(C);assert (len(set(actual))==len(vs))==expected
  if expected:positive+=1
  else:negative+=1
 assert positive==18 and negative==238
 # A unitary matrix mixing four coordinates, with a nonreal coefficient.
 M=identity(m)
 for i in range(4):
  for j in range(4):M[i][j]^=1
 D=identity(m);D[0][0]=2;C=mm(D,M);assert unitary(C)
 Ci=mi(C);Ai=mi(A);assert Ci and Ai
 F=[pack(fs(v)) for v in vs];encoded=[];decoded=[]
 for v in vs:
  u=v if norm(v)==0 else matvec(C,tuple(sq(a) for a in v))
  encoded.append(pack(matvec(A,u)))
  u=matvec(Ai,v)
  z=u if norm(u)==0 else tuple(sq(a) for a in matvec(Ci,u))
  decoded.append(pack(z))
 assert all(decoded[encoded[x]]==x and encoded[F[x]]==pack(tuple(gf(2,a) for a in tup(encoded[x],m))) for x in range(len(vs)))
 assert binary_degree(encoded)==binary_degree(decoded)==3
 return dict(m=m,all_embedded_2by2_blocks=256,unitary_bijective=positive,nonunitary_or_singular_rejected=negative,
    nonmonomial_unitary_inverse_and_roundtrip='PASS')
def readout_control(F,n):
 N=1<<n
 truth_rows=[sum(((x>>i)&1)<<x for x in range(N)) for i in range(n)]
 truth_rows += [sum(((F[x]>>i)&1)<<x for x in range(N)) for i in range(n)]
 lc=span_rank(truth_rows)
 defects=[F[x^y]^F[x]^F[y] for x in range(N) for y in range(N)]
 r=span_rank(defects);assert lc==n+r
 D={0}
 for v in defects:
  if v not in D:D|={z^v for z in list(D)}
 assert all(F[x] in D for x in D)
 return dict(n=n,additive_defect_rank=r,minimum_linear_readout_dimension=lc)
def main():
 start=time.monotonic();rows=[];paper_only='--paper-only' in sys.argv
 for m in range(1,6):
  n=2*m;F=[pack(fs(tup(x,m))) for x in range(1<<n)]
  ds={d:eigen_binary_nullity(F,n,d) for d in (1,2,3)}
  expected={1:(1,1,1),2:(0,1,5),3:(0,0,9),4:(0,0,8),5:(0,0,10)}[m]
  assert tuple(ds.values())==expected
  rows.append(dict(m=m,eigen_dimensions=ds,status='PASS'))
  print(json.dumps(rows[-1]),flush=True)
 bases=[] if paper_only else [cubic_basis_check(m) for m in (4,5)]
 matrices=[] if paper_only else [matrix_controls(m) for m in (4,5)]
 # All 2^5 invariant orientation switches on the five scalar lines in F4^2.
 points=list(range(16));orbits=[];seen=set()
 for x in points[1:]:
  if x not in seen:
   v=tup(x,2);o={x,pack(tuple(gf(2,a) for a in v)),pack(tuple(gf(3,a) for a in v))};seen|=o;orbits.append(o)
 assert len(orbits)==5
 readouts=[]
 for choice in range(32):
  F=[0]*16
  for i,o in enumerate(orbits):
   for x in o:F[x]=pack(tuple(gf(3 if choice>>i&1 else 2,a) for a in tup(x,2)))
  assert all(F[F[x]]==F[x]^x for x in points)
  readouts.append(readout_control(F,4))
 # The six-dimensional quadratic central model: its expected point rank is two.
 F=[]
 for x in range(64):
  a,b,z=tup(x,3);F.append(pack((gf(2,a),gf(2,b),gf(2,z)^gf(a,b))))
 assert all(F[F[x]]==F[x]^x for x in range(64))
 quad=readout_control(F,6);assert quad['additive_defect_rank']==2 and quad['minimum_linear_readout_dimension']==8
 out=dict(status='PASS',implementation='Independent bit-polynomial GF4 and doubled binary coefficient matrices; no imported checker modules.',
    scalar_eigen_spaces=rows,successor_controls_included=not paper_only,complete_cubic_basis_controls=bases,matrix_stratum_controls=matrices,
    complete_4bit_orientation_switch_readouts=readouts,quadratic_central_model=quad,seconds=round(time.monotonic()-start,3),
    scope='All specified input points and coefficient systems. The all-rank classification and arbitrary-dimension exclusion are written proofs, not enumeration claims.')
 (H/'independent_degree_boundary_audit.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
 print(json.dumps(dict(status='PASS',matrix_cases=0 if paper_only else 512,all_orientation_switches=32,seconds=out['seconds'])),flush=True)
if __name__=='__main__':main()

"""Independent finite controls for notes 25/26 (standard library only).

No imports from the round-four implementation. Complete orientation kernels
and complete polynomial coefficient systems, not random map sampling.
"""
from pathlib import Path
from itertools import product, combinations
from collections import Counter
from math import comb
import json, time, sys

HOME = Path(__file__).resolve().parent
MUL = ((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
def mul(a,b): return MUL[a][b]
def sq(a): return MUL[a][a]
def vec(x,m): return tuple((x >> (2*i)) & 3 for i in range(m))
def pack(x): return sum(a << (2*i) for i,a in enumerate(x))
def add(xs):
 r=0
 for x in xs:r ^= x
 return r
def q(v,r=None): return sum(a!=0 for a in v[:r]) & 1
def scale(c,x,m): return pack(tuple(mul(c,a) for a in vec(x,m)))
def anf(values):
 z=list(values);n=(len(z)-1).bit_length()
 for i in range(n):
  for x in range(len(z)):
   if x & (1<<i):z[x] ^= z[x^(1<<i)]
 return z
def degree(values):return max((i.bit_count() for i,v in enumerate(anf(values)) if v),default=-1)
def rank_binary(rows):
 piv={}
 for r in rows:
  while r:
   i=r.bit_length()-1
   if i in piv:r ^= piv[i]
   else:piv[i]=r;break
 return len(piv)
def rank4(A):
 A=[list(r) for r in A];j=0
 for c in range(len(A[0])):
  z=next((i for i in range(j,len(A)) if A[i][c]),None)
  if z is None:continue
  A[j],A[z]=A[z],A[j];a=sq(A[j][c]);A[j]=[mul(a,t) for t in A[j]]
  for i in range(len(A)):
   if i!=j and A[i][c]:
    a=A[i][c];A[i]=[x^mul(a,y) for x,y in zip(A[i],A[j])]
  j+=1
  if j==len(A):break
 return j
def mv(A,x):return tuple(add(mul(a,b) for a,b in zip(row,x)) for row in A)
def ident(m):return [[int(i==j) for j in range(m)] for i in range(m)]
def ftable(m,r,c=0):return [scale(2^c^q(vec(x,m),r),x,m) for x in range(4**m)]
def etable(m,r):
 return [pack(tuple(sq(a) for a in vec(x,m))) if q(vec(x,m),r) else x for x in range(4**m)]
def cubic_kernel(F,n,d):
 mons=[sum(1<<i for i in s) for k in range(d+1) for s in combinations(range(n),k)]
 rows=[]
 for x,y in enumerate(F):
  r0=r1=0
  for j,s in enumerate(mons):
   a=int(y&s==s);b=int(x&s==s)
   # g(y)+omega*g(x); unknown coefficient a_j=a0+omega*a1.
   w=a^(b<<1);ww=mul(2,w)
   r0|=(w&1)<<(2*j);r0|=(ww&1)<<(2*j+1)
   r1|=(w>>1)<<(2*j);r1|=(ww>>1)<<(2*j+1)
  rows.extend((r0,r1))
 null=2*len(mons)-rank_binary(rows);assert null%2==0
 return null//2

def orientation_kernel(m):
 N=4**m;seen={0};orbits=[]
 for x in range(1,N):
  if x not in seen:
   o=(x,scale(2,x,m),scale(3,x,m));orbits.append(o);seen.update(o)
 high=[s for s in range(N) if s.bit_count()>3];cols=[];allcols=[]
 for o in orbits:
  vals=[0]*N
  for x in o:vals[x]=x
  coeff=anf(vals);cols.append(sum(coeff[s]<<(2*m*j) for j,s in enumerate(high)))
  allcols.append(sum(v<<(2*m*s) for s,v in enumerate(coeff)))
 null=len(orbits)-rank_binary(cols)
 expected=1 if m==1 else m*m+1
 assert null==expected,(m,null,expected)
 vs=[vec(x,m) for x in range(N)]
 selectors=[[1]*N]+[[int(v[i]!=0) for v in vs] for i in range(m)]
 for i,j in combinations(range(m),2):
  for a in (1,2):
   selectors.append([add((mul(sq(v[i]),mul(a,v[j])),mul(v[i],mul(sq(a),sq(v[j]))))) for v in vs])
 bits=[]
 for p in selectors:
  assert all(v in (0,1) for v in p)
  assert all(p[scale(2,x,m)]==p[x] for x in range(N))
  assert degree([x if p[x] else 0 for x in range(N)])<=3
  bits.append(sum(p[o[0]]<<i for i,o in enumerate(orbits)))
 assert rank_binary(bits)==expected
 # Entire degree filtration of the orientation family, via all orientation bits.
 chars={(0,0):1}
 for _ in range(m):
  temp={}
  for (d,j),v in chars.items():
   for e,k in ((0,0),(1,1),(1,2),(2,0)):temp[d+e,(j+k)%3]=temp.get((d+e,(j+k)%3),0)+v
  chars=temp
 filtration=[]
 for D in range(1,2*m):
  mask=sum(((1<<(2*m))-1)<<(2*m*s) for s in range(N) if s.bit_count()>D)
  dimension=len(orbits)-rank_binary([c&mask for c in allcols])
  invariant=sum(chars.get((d,0),0) for d in range(D))
  assert dimension==invariant,(m,D,dimension,invariant)
  filtration.append(dict(maximum_map_degree=D,orientation_kernel_dimension=dimension))
 return dict(m=m,scalar_lines=len(orbits),orientation_unknowns=len(orbits),
             complete_binary_degree_constraint_rank=len(orbits)-null,
             kernel_dimension=null,Hermitian_selector_span_dimension=rank_binary(bits),
             complete_degree_filtration=filtration)

def hermitian_census(m):
 vs=[vec(x,m) for x in range(4**m)];pairs=list(combinations(range(m),2));counts=Counter()
 for diag in product(range(2),repeat=m):
  for cross in product(range(4),repeat=len(pairs)):
   A=[[0]*m for _ in range(m)]
   for i,a in enumerate(diag):A[i][i]=a
   for (i,j),a in zip(pairs,cross):A[i][j]=a;A[j][i]=sq(a)
   r=rank4(A);vals=[add(mul(sq(a),b) for a,b in zip(v,mv(A,v))) for v in vs]
   assert all(t in (0,1) for t in vals)
   for c in (0,1):
    F=[scale(2^c^vals[x],x,m) for x in range(4**m)]
    assert all(F[F[x]]==F[x]^x for x in range(len(F)))
    assert degree(F)==(1 if r==0 else 3)
    counts[r]+=1
 expected={2:{0:2,1:10,2:20},3:{0:2,1:42,2:420,3:560}}[m]
 assert dict(counts)==expected
 return dict(m=m,maps_checked=sum(counts.values()),rank_counts=dict(counts))

def base_quadratic_controls():
 vs=[vec(x,2) for x in range(16)];out=[]
 for r in (1,2):
  F=ftable(2,r)
  basis=([[sq(v[0]) for v in vs],[mul(v[0],v[1]) for v in vs]] if r==1
         else [[mul(sq(v[0]),sq(v[1])) for v in vs]])
  assert cubic_kernel(F,4,2)==len(basis)
  rows=[]
  for g in basis:
   assert degree(g)<=2 and all(g[F[x]]==mul(2,g[x]) for x in range(16))
   rows.extend((sum(v<<(2*x) for x,v in enumerate(g)),sum(mul(2,v)<<(2*x) for x,v in enumerate(g))))
  assert rank_binary(rows)==2*len(basis)
  witness=pack((0,1)) if r==1 else pack((1,0));orbit=(witness,F[witness],F[F[witness]])
  assert len(set(orbit))==3 and all(g[x]==0 for g in basis for x in orbit)
  out.append(dict(Hermitian_rank=r,complete_quadratic_scalar_dimension=len(basis),
                  collapsed_orbit=list(orbit),both_nontrivial_characters_vanish=True))
 return out

def predicted(m,d):
 out=0
 for s in range(m):
  h=(2**s-(-1)**s)//3;t=(d-s)//2-1
  out+=2*comb(m,s)*h*sum(comb(m-s-1,i) for i in range(max(0,min(t,m-s-1)+1)))
 return out+((2**m-(-1)**m)//3 if d>=m else 0)

def full_profile_basis(m):
 vs=[vec(x,m) for x in range(4**m)];functions=[];degrees=[]
 for sm in range(1<<m):
  S=[i for i in range(m) if sm>>i&1];J=[i for i in range(m) if not sm>>i&1]
  for eps in product((1,2),repeat=len(S)):
   weight=sum(eps)%3
   if weight==0:continue
   M=[]
   for v in vs:
    a=1
    for i,e in zip(S,eps):a=mul(a,v[i] if e==1 else sq(v[i]))
    M.append(a)
   if not J:
    if weight==(1 if m%2==0 else 2):functions.append(M);degrees.append(m)
    continue
   rest=J[1:];e=(len(S)+(weight==2))%2
   for rm in range(1<<len(rest)):
    R=[i for j,i in enumerate(rest) if rm>>j&1];values=[]
    for x,v in enumerate(vs):
     a=M[x] if (sum(v[i]!=0 for i in J)&1)==e and all(v[i]!=0 for i in R) else 0
     values.append(a)
    functions.append(values);degrees.append(len(S)+2*(len(R)+1))
 assert len(functions)==(4**m-1)//3
 F=ftable(m,m)
 for g,d in zip(functions,degrees):
  assert degree(g)==d
  assert all(g[F[x]]==mul(2,g[x]) for x in range(len(F)))
 rows=[]
 for g in functions:
  rows.append(sum(v<<(2*x) for x,v in enumerate(g)))
  rows.append(sum(mul(2,v)<<(2*x) for x,v in enumerate(g)))
 assert rank_binary(rows)==2*len(functions)
 profile=[sum(t<=d for t in degrees) for d in range(2*m+1)]
 assert profile==[predicted(m,d) for d in range(2*m+1)]
 cases=range(2*m+1) if m<=4 else (4,5,6)
 full=[]
 for d in cases:
  null=cubic_kernel(F,2*m,d);assert null==profile[d],(m,d,null,profile[d]);full.append(dict(d=d,dimension=null))
 return dict(m=m,full_basis_functions=len(functions),binary_basis_rank=rank_binary(rows),
             cumulative_degree_profile=profile,complete_coefficient_systems=full)

def diagonal_and_exception_controls(m, include_followup=True):
 N=4**m;cases=[]
 for r in range(m+1):
  E=etable(m,r)
  assert all(E[E[x]]==x for x in range(N))
  for c in (0,1):
   F=ftable(m,r,c);h=E if c==0 else [pack(tuple(sq(a) for a in vec(y,m))) for y in E]
   assert all(F[F[x]]==F[x]^x for x in range(N))
   assert all(h[F[x]]==scale(2,h[x],m) for x in range(N))
   assert len(set(h))==N
   actual=degree(h);assert actual==(3 if m>=2 and r>0 else 1)
  F=ftable(m,r)
  defect_dimension=rank_binary([v for i,v in enumerate(anf(F)) if i.bit_count()>=2])
  expected_defect=0 if r==0 else 2*(m-1) if r==1 else 2*m
  assert defect_dimension==expected_defect
  if m<=4:
   assert rank_binary([F[x^y]^F[x]^F[y] for x in range(N) for y in range(N)])==expected_defect
  cases.append(dict(r=r,forward_inverse_degree=actual,additive_defect_dimension=defect_dimension,
                    maximum_linear_quotient_dimension=2*m-defect_dimension,
                    minimum_linear_readout_dimension=2*m+defect_dimension))
 exc=None
 if m>=3 and include_followup:
  F=ftable(m,3);H=etable(m,3)
  for x in range(N):
   v=vec(x,m);t=mul(v[1],sq(v[2]))^mul(sq(v[1]),v[2]);assert t in (0,1)
   H[x]^=mul(2,mul(sq(v[0]),t))
  assert all(H[H[x]]==x for x in range(N))
  assert all(H[F[x]]==scale(2,H[x],m) for x in range(N))
  assert degree(H)==3
  witness=pack((1,1,2)+(0,)*(m-3));assert H[witness]!=etable(m,3)[witness]
  null=cubic_kernel(F,2*m,3);assert null==2*m+3
  exc=dict(H_involution=True,degree=3,cubic_scalar_dimension=null,
           non_two_piece_witness_input=witness,witness_output=H[witness])
 return dict(m=m,all_diagonal_ranks_and_both_constants=cases,rank_three_exception=exc)

def degenerate_matrix_controls():
 m=5;r=4;N=4**m;vs=[vec(x,m) for x in range(N)];F=ftable(m,r);good=bad=0
 for a,b,d in product(range(4),repeat=3):
  C=ident(m);C[0][-1]=a;C[-1][0]=b;C[-1][-1]=d
  H=[pack(mv(C,tuple(sq(v) for v in x))) if q(x,r) else pack(x) for x in vs]
  expected=(a==0 and d!=0)
  assert (len(set(H))==N)==expected
  if expected:
   good+=1;assert all(H[F[x]]==scale(2,H[x],m) for x in range(N))
   inv=[0]*N
   for x,y in enumerate(H):inv[y]=x
   assert degree(H)==degree(inv)==3
  else:bad+=1
 # A nonmonomial active unitary, lower-left radical shear, nonreal D.
 C=ident(m);v=(1,2,1,2)
 for i in range(r):
  for j in range(r):C[i][j]^=mul(v[i],sq(v[j]))
 C[-1]=[1,2,3,1,2]
 assert rank4(C)==m and all(q(mv(C,x),r)==q(x,r) for x in vs)
 H=[pack(mv(C,tuple(sq(a) for a in x))) if q(x,r) else pack(x) for x in vs]
 inv=[0]*N
 for x,y in enumerate(H):inv[y]=x
 assert len(set(H))==N and degree(H)==degree(inv)==3
 return dict(m=m,Hermitian_rank=r,complete_active_radical_block_stratum=64,
             bijective=good,rejected=bad,nonmonomial_unitary_radical_shear_and_inverse=True)

def main():
 start=time.time();paper_only='--paper-only' in sys.argv
 report={'implementation':'independent GF4 multiplication table, Boolean ANF, binary coefficient equations',
  'orientation_kernels':[orientation_kernel(m) for m in range(1,6)],
  'complete_Hermitian_censuses':[hermitian_census(m) for m in (2,3)],
  'quadratic_obstruction_base_cases':base_quadratic_controls(),
  'all_rank_controls':[diagonal_and_exception_controls(m,not paper_only) for m in range(1,7)],
  'scope':'paper-only' if paper_only else 'paper plus retained successor controls','status':'PASS'}
 if not paper_only:
  report['complete_degree_profiles']=[full_profile_basis(m) for m in range(1,6)]
  report['degenerate_matrix_controls']=degenerate_matrix_controls()
 report['elapsed_seconds']=round(time.time()-start,3)
 (HOME/'scalar_line_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'status':report['status'],'scope':report['scope'],'seconds':report['elapsed_seconds'],
  'orientation_dimensions':[v['kernel_dimension'] for v in report['orientation_kernels']]},indent=2))
if __name__=='__main__':main()

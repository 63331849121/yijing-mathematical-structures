"""Exact new-interface controls; no imports from earlier Q checkers."""
from pathlib import Path
from itertools import product,combinations
from collections import Counter
import json,time
ARCHIVE=Path(__file__).resolve().parent
ROOT=next((p for p in ARCHIVE.parents if (p/'output/pdf/PaperG_structure_2026-11-02/PaperG_structure.tex').exists()),None)
DETECTOR=ARCHIVE.parent/'ordinary_reconstruction/small_sextic_detector.json'
if not DETECTOR.exists():DETECTOR=ROOT/'output/pdf/PaperG_structure_2026-11-02/verification/ordinary_reconstruction/small_sextic_detector.json'
M=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
def mul(a,b):return M[a][b]
def sq(a):return M[a][a]
def xor(xs):
 z=0
 for x in xs:z^=x
 return z
def scale(c,x):
 z=0;i=0
 while x:z^=mul(c,x&3)<<(2*i);x>>=2;i+=1
 return z
def anf(F):
 a=list(F);n=(len(a)-1).bit_length()
 for i in range(n):
  for x in range(len(a)):
   if x>>i&1:a[x]^=a[x^(1<<i)]
 return a
def rank(rows):
 p={}
 for x in rows:
  while x:
   k=x.bit_length()-1
   if k in p:x^=p[k]
   else:p[k]=x;break
 return len(p)
def nullspace(rows,n):
 p={}
 for x in rows:
  while x:
   k=x.bit_length()-1
   if k in p:x^=p[k]
   else:p[k]=x;break
 free=[i for i in range(n) if i not in p];basis=[]
 for i in free:
  v=1<<i
  for k,r in sorted(p.items()):
   if (r&v).bit_count()%2:v^=1<<k
  assert all((r&v).bit_count()%2==0 for r in p.values());basis.append(v)
 return basis
def apply(A,x,n):return xor(((A>>(n*i))&((1<<n)-1)) for i in range(n) if x>>i&1)
def identity(n):return sum(1<<(n*i+i) for i in range(n))
def kernel(F):
 n=(len(F)-1).bit_length();seen={0};rows=[]
 for x in range(1,len(F)):
  if x in seen:continue
  y=F[x];assert F[y]==x^y;seen.update((x,y,x^y))
  ann=nullspace((x,y),n)
  for v in (x,y):
   for ell in ann:rows.append(sum(ell<<(n*i) for i in range(n) if v>>i&1))
 return nullspace(rows,n*n)
def normal(m,r,c=0):
 return [scale(2^c^(sum(((x>>(2*i))&3)!=0 for i in range(r))&1),x) for x in range(4**m)]
def matrix_rank4(A):
 A=[r[:] for r in A];k=0
 for j in range(len(A)):
  i=next((i for i in range(k,len(A)) if A[i][j]),None)
  if i is None:continue
  A[k],A[i]=A[i],A[k];c=sq(A[k][j]);A[k]=[mul(c,a) for a in A[k]]
  for i in range(len(A)):
   if i!=k and A[i][j]:
    c=A[i][j];A[i]=[a^mul(c,b) for a,b in zip(A[i],A[k])]
  k+=1
 return k
def recover(F):
 n=(len(F)-1).bit_length();basis=kernel(F);assert len(basis)==2
 Id=identity(n);J=next(x for x in basis if x!=Id)
 assert all(apply(J,apply(J,x,n),n)^apply(J,x,n)==x for x in range(len(F)))
 cols=[]
 for x in range(1,len(F)):
  if rank(cols+[x])>len(cols):cols.extend((x,apply(J,x,n)))
  if len(cols)==n:break
 assert rank(cols)==n
 S=[xor(cols[i] for i in range(n) if x>>i&1) for x in range(len(F))]
 back={y:x for x,y in enumerate(S)}
 G=[back[F[x]] for x in S];m=n//2
 p=[0]+[int(G[x]!=scale(2,x)) for x in range(1,len(F))]
 p[0]=sum(p)%2;assert max((s.bit_count() for s,a in enumerate(anf(p)) if a),default=0)<=2
 c=p[0];H=[[0]*m for _ in range(m)]
 for i in range(m):H[i][i]=p[1<<(2*i)]^c
 for i,j in combinations(range(m),2):
  t=p[(1<<(2*i))^(1<<(2*j))]^c^H[i][i]^H[j][j]
  u=p[(1<<(2*i))^(2<<(2*j))]^c^H[i][i]^H[j][j]
  a=next(a for a in range(4) if a^sq(a)==t and mul(2,a)^sq(mul(2,a))==u)
  H[i][j]=a;H[j][i]=sq(a)
 for x in range(len(F)):
  v=[(x>>(2*i))&3 for i in range(m)]
  q=c^xor(mul(sq(v[i]),mul(H[i][j],v[j])) for i in range(m) for j in range(m))
  assert q==p[x] and G[x]==scale(2^q,x)
 return matrix_rank4(H)
def conjugate(F,cols):
 n=len(cols);S=[xor(cols[i] for i in range(n) if x>>i&1) for x in range(1<<n)];assert len(set(S))==len(S)
 G=[0]*len(S)
 for x in range(len(S)):G[S[x]]=S[F[x]]
 return tuple(G)
def full_four_bit_census():
 # Every two-spread, by exact cover of all 15 nonzero points.
 planes=sorted({tuple(sorted((a,b,a^b))) for a,b in combinations(range(1,16),2)})
 covers=[]
 def visit(left,chosen):
  if not left:covers.append(chosen);return
  a=min(left)
  for P in planes:
   if a in P and set(P)<=left:visit(left-set(P),chosen+[P])
 visit(set(range(1,16)),[]);assert len(covers)==56
 maps=set();classes=Counter()
 for cover in covers:
  for choices in range(32):
   F=[0]*16
   for i,P in enumerate(cover):
    a,b,c=P
    if choices>>i&1:b,c=c,b
    F[a]=b;F[b]=c;F[c]=a
   F=tuple(F);maps.add(F);assert len(kernel(F))==2;classes[recover(F)]+=1
 assert len(maps)==1792 and dict(classes)=={0:112,1:560,2:1120}
 group=[cols for cols in product(range(1,16),repeat=4) if rank(cols)==4];assert len(group)==20160
 auto=[];generated=set()
 for r in range(3):
  F=tuple(normal(2,r));orbit={conjugate(F,S) for S in group};generated.update(orbit)
  aut=sum(conjugate(F,S)==F for S in group);assert aut==(180,36,18)[r]
  assert len(orbit)==classes[r];auto.append(aut)
 assert generated==maps
 return dict(two_spreads=56,all_strong_maps=1792,intrinsic_rank_counts=dict(classes),
             full_GL4_size=20160,binary_linear_automorphism_orders=auto)
def all_rank_controls():
 out=[]
 for m in range(2,7):
  n=2*m;cols=[1<<i for i in range(n)]
  # Two triangular binary sweeps and a permutation; generally not F4 linear.
  for i in range(n-1):cols[i]^=cols[i+1]
  for i in range(n-1,0,-1):cols[i]^=cols[i-1]
  cols=cols[1:]+cols[:1]
  for r in range(m+1):
   for c in (0,1):
    G=conjugate(normal(m,r,c),cols);assert recover(G)==r
   out.append(dict(m=m,r=r,both_orientations_and_dense_binary_coordinates=True))
 # A genuinely quadratic strong map from the six-bit central model.
 F=[scale(2,x)^mul(x&3,(x>>2)&3)<<4 for x in range(64)]
 assert all(F[F[x]]==F[x]^x for x in range(64));assert len(kernel(F))==1
 # Binary dimension two is an essential exception: its algebra is M_2(F2).
 assert len(kernel(normal(1,0)))==4
 return dict(all_ranks=out,nonlinear_quadratic_kernel_dimension=1,two_bit_exception_dimension=4)
def head_interface():
 # Genuine cubic 42-bit detector: span only NEW additive-defect stencil,
 # not a rerun of the archived Jacobi/Engel/third-difference certificates.
 d=json.loads(DETECTOR.read_text())
 t=d['table'];m=len(t);grades=d['grades']
 tt=[[sum(1<<(2*k) for k in range(m) if a>>k&1) for a in row] for row in t]
 def br(x,y):return xor(scale(mul((x>>(2*i))&3,(y>>(2*j))&3),tt[i][j]) for i in range(m) for j in range(m) if (x>>(2*i))&3 and (y>>(2*j))&3)
 def plus(x,y):
  b=br(x,y);return x^y^b^br(b,x)^br(b,y)^br(br(b,y),x)
 for i,j in product(range(m),repeat=2):
  for k in range(m):
   if t[i][j]>>k&1:assert grades[k]==grades[i]+grades[j]
 order=[2*i+b for i in sorted(range(m),key=lambda i:(grades[i],i)) for b in (0,1)]
 piv={}
 def insert(x):
  for i in order:
   if x>>i&1:
    if i in piv:x=plus(x,piv[i])
    else:piv[i]=x;return
  assert x==0
 units=[1<<i for i in range(2*m)]
 for x,y in combinations(units,2):insert(plus(plus(scale(2,plus(x,y)),scale(2,x)),scale(2,y)))
 derived=rank([v for row in t for v in row]);assert len(piv)==2*derived==36
 # Entirely exhaustive small Heisenberg encoding, using the boxplus chart.
 def hp(x,y):
  return x^y^(mul(x&3,(y>>2)&3)^mul((x>>2)&3,y&3))<<4
 chart=[]
 for a in range(64):
  x=0
  for i in range(6):
   if a>>i&1:x=hp(x,1<<i)
  chart.append(x)
 back={x:i for i,x in enumerate(chart)};assert len(back)==64
 F=[back[scale(2,x)] for x in chart];D=rank([F[x^y]^F[x]^F[y] for x in range(64) for y in range(64)])
 assert D==2 and all(F[F[x]]==F[x]^x for x in range(64))
 return dict(cubic_detector_binary_dimension=42,ordinary_derived_dimension=derived,
             binary_defect_span_dimension=len(piv),genuine_cubic_input='published detector',
             exhaustive_six_bit_Heisenberg_defect_dimension=D,fullness_scope='maps to lower-dimensional abelian targets')
if __name__=='__main__':
 start=time.time();report={'complete_four_bit_census':full_four_bit_census(),
  'intrinsic_all_rank_controls':all_rank_controls(),'exact_head_interfaces':head_interface(),
  'status':'PASS','seconds':round(time.time()-start,3)}
 (ARCHIVE/'intrinsic_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 print(json.dumps({'status':'PASS','seconds':report['seconds'],'census':report['complete_four_bit_census'],
                  'exact_head_interfaces':report['exact_head_interfaces']},indent=2))

def bits(v):
    while v:
        a=v&-v;yield a.bit_length()-1;v^=a

def mul(a,b):
    r=0
    while b:
        if b&1:r^=a
        b>>=1;a<<=1
        if a&4:a^=7
    return r

def scale4(c,v):
    r=0;i=0
    while v:r^=mul(c,v&3)<<(2*i);v>>=2;i+=1
    return r

def tensor(v):return sum(1<<(2*i) for i in bits(v))
def support4(x):
    while x:
        i=((x&-x).bit_length()-1)//2; c=(x>>(2*i))&3
        yield i,c
        x ^= c << (2*i)

def bracket(t,x,y):
    out=0
    for i,a in support4(x):
        for j,b in support4(y):
            out ^= scale4(mul(a,b),t[i][j])
    return out

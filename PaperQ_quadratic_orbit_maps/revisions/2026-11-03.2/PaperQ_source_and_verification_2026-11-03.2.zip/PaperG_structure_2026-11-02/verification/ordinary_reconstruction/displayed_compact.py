from itertools import combinations
def displayed_model(r,faithful):
    ij=list(combinations(range(r),2));names=[];weights=[]
    for prefix in ('A','B'):
        for i in range(r):names.append((prefix,i));weights.append(1)
    for prefix,degree in [('E',2),('U',2),('V',2),('R',3),('S',3),('T',3),('Z',4)]:
        for item in (range(1,r) if prefix=='V' else ij):
            names.append((prefix,item));weights.append(degree)
    if faithful:
        for pair in ij:names.append(('C',pair));weights.append(2)
    index={v:i for i,v in enumerate(names)};n=len(names);t=[[0]*n for _ in range(n)]
    def put(a,b,*cs):
        i,j=index[a],index[b];v=0
        for c in cs:v^=1<<(2*index[c])
        t[i][j]^=v;t[j][i]^=v
    for i,j in ij:
        put(('A',i),('A',j),('E',(i,j)),*([('C',(i,j))] if faithful else []))
        put(('B',i),('B',j),('E',(i,j)))
        put(('A',i),('B',j),('U',(i,j)))
        for a,b,c in [(('A',i),('E',(i,j)),('R',(i,j))),
                      (('B',i),('U',(i,j)),('R',(i,j))),
                      (('A',j),('E',(i,j)),('S',(i,j))),
                      (('B',i),('V',j),('S',(i,j))),
                      (('A',j),('U',(i,j)),('T',(i,j))),
                      (('A',i),('V',j),('T',(i,j))),
                      (('A',i),('S',(i,j)),('Z',(i,j))),
                      (('A',j),('R',(i,j)),('Z',(i,j))),
                      (('B',i),('T',(i,j)),('Z',(i,j)))]:put(a,b,c)
    for j in range(1,r):put(('A',j),('B',j),('V',j))
    return t,weights,names

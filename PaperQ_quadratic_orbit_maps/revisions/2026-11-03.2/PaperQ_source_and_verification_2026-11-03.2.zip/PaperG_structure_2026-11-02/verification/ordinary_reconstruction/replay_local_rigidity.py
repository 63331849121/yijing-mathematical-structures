from pathlib import Path
from itertools import combinations,permutations
import json,hashlib
from displayed_compact import displayed_model
from arithmetic import bracket,support4
def independent_rank(rows):
    piv={}
    for v in rows:
        while v:
            i=(v&-v).bit_length()-1
            if i in piv:v^=piv[i]
            else:piv[i]=v;break
    return len(piv)

def replay(path):
    c=json.loads(path.read_text());t,w,names=displayed_model(c['r'],c['family']=='A')
    assert hashlib.sha256(json.dumps(t,separators=(',',':')).encode()).hexdigest()==c['base_table_SHA256']
    pairs=[tuple(v) for v in c['cochain_variable_pairs']]
    assert pairs==[(i,j) for i,j in combinations(range(len(t)),2) if w[i]+w[j]==c['weight']]
    lookup={v:i for i,v in enumerate(pairs)}
    def symbolic_beta(x,y):
        row=0
        for i,a in support4(x):
            for j,b in support4(y):
                if i==j:continue
                key=(i,j) if i<j else (j,i)
                if key in lookup:
                    assert a==b==1
                    row^=1<<lookup[key]
        return row
    br=lambda x,y:bracket(t,x,y)
    def original_equation(label):
        if label[0]=='J':
            _,i,j,k=label
            return symbolic_beta(t[i][j],1<<(2*k))^symbolic_beta(t[j][k],1<<(2*i))^symbolic_beta(t[k][i],1<<(2*j))
        _,y,a,b,d=label
        row=0
        for tri in set(permutations((a,b,d))):
            value=1<<(2*y)
            for z in tri[:2]:value=br(value,1<<(2*z))
            row^=symbolic_beta(value,1<<(2*tri[2]))
        return row
    selected=[]
    for eq in c['independent_equation_rows']:
        row=original_equation(eq['label'])
        assert row==int(eq['row'],16)
        selected.append(row)
    rank=independent_rank(selected)
    assert rank==len(selected)==c['equation_rank']
    supplied=[int(v,16) for v in c['coboundary_basis']]
    if c['weight']==4:
        actual=[]
        for z in range(len(t)):
            if w[z]==4:
                actual.append(sum(((t[i][j]>>(2*z))&3)<<k for k,(i,j) in enumerate(pairs)))
        assert actual==supplied
    else:assert not supplied
    assert independent_rank(supplied)==len(supplied)==c['kernel_dimension']
    assert rank+len(supplied)==len(pairs)
    assert all(not ((v&row).bit_count()&1) for v in supplied for row in selected)
    return {'file':path.name,'status':'PASS','checked_original_equations':rank,
            'variables':len(pairs),'kernel_dimension':len(supplied)}

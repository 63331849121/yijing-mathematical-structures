"""Independent coefficient-DAG replay, including free-Lie membership checks.
Uses integer word codes and low-pivot elimination. No imports from generator.
"""
from pathlib import Path
from functools import lru_cache
import itertools,json,time
ROOT=Path(__file__).resolve().parent

def toggle(items):
    out=set()
    for i in items:
        if i in out:out.remove(i)
        else:out.add(i)
    return frozenset(out)

def bracket(a,b):return toggle(w for x in a for y in b for w in (x+y,y+x))
def word(y,*f):
    for x in f:y=bracket(y,x)
    return y
def xor(polys):return toggle(w for p in polys for w in p)
def parse(data):return frozenset(tuple(w) for w in data)

def expected(name):
    a,b,c,d=[frozenset({(i,)}) for i in range(4)]
    z=lambda x,y:word(x,y,y,x,x)
    Z=lambda x,y,v:xor((word(x,v,v,y,y),word(y,v,v,x,y),word(y,v,v,y,x)))
    q=lambda x,y:word(x,y,y,x)
    def R(x,y,v):return xor((q(word(x,y),v),q(word(y,v),x),q(word(v,x),y),word(word(x,y,v),word(y,v,x))))
    return {
      'Z_additive':lambda:xor((Z(a,xor((b,c)),d),Z(a,b,d),Z(a,c,d))),
      'Z_symmetry':lambda:xor((Z(a,b,c),Z(a,c,b))),
      'Z_third_additive':lambda:xor((Z(a,b,xor((c,d))),Z(a,b,c),Z(a,b,d))),
      'Z_alternating':lambda:Z(a,b,b),
      'Z_first_derived':lambda:Z(word(a,b),c,d),
      'Z_second_derived':lambda:Z(a,word(b,c),d),
      'R_additive':lambda:xor((R(xor((a,b)),c,d),R(a,c,d),R(b,c,d))),
      'R_symmetry':lambda:xor((R(a,b,c),R(b,a,c))),
      'R_other_symmetry':lambda:xor((R(a,b,c),R(a,c,b))),
      'R_alternating':lambda:R(a,a,b),
      'R_derived':lambda:R(word(a,b),c,d),
      'R_central':lambda:word(R(a,b,c),d),
      'z_central':lambda:word(z(a,b),c),
      'z_leading_cube':lambda:xor((z(a,b),word(word(a,b),word(a,word(a,b))))),
    }[name]()

@lru_cache(None)
def ordered_words(m):
    if not any(m):return ((),)
    return tuple((i,)+w for i,x in enumerate(m) if x for w in ordered_words(tuple(v-(i==j) for j,v in enumerate(m))))

@lru_cache(None)
def lie_rows(m):
    ws=ordered_words(m);index={w:i for i,w in enumerate(ws)};rows={}
    for seq in ws:
        p=word(frozenset({(seq[0],)}),*(frozenset({(x,)}) for x in seq[1:]))
        v=sum(1<<index[w] for w in p)
        for k in sorted(rows):
            if (v>>k)&1:v^=rows[k]
        if v:rows[(v&-v).bit_length()-1]=v
    return index,rows

def is_lie(p):
    if not p:return True
    degrees={tuple(w.count(i) for i in range(4)) for w in p}
    for m in degrees:
        part=[w for w in p if tuple(w.count(i) for i in range(4))==m]
        index,rows=lie_rows(m);v=sum(1<<index[w] for w in part)
        for k in sorted(rows):
            if (v>>k)&1:v^=rows[k]
        if v:return False
    return True

def main():
    start=time.monotonic();report=[];membership=set()
    for path in sorted((ROOT/'identity_certificates').glob('*.json')):
        data=json.loads(path.read_text());status=data['status']
        if status=='IDENTICALLY_ZERO_FREE_ASSOCIATIVE':
            assert not data['target'] and not expected(data['name'])
            report.append({'name':data['name'],'status':'FREE_ASSOCIATIVE_ZERO'});continue
        assert status=='PROVED';values=[]
        def member(p):
            if p not in membership:assert is_lie(p);membership.add(p)
        for i,node in enumerate(data['nodes']):
            kind=node['kind']
            if kind=='xor':
                assert all(j<i for j in node['children']);v=xor(values[j] for j in node['children'])
            elif kind=='bracket':
                assert node['left']<i;right=parse(node['right']);member(right)
                v=bracket(values[node['left']],right)
            elif kind=='engel_coefficient':
                y=parse(node['y']);fs=[parse(v) for v in node['factors']];member(y)
                for p in fs:member(p)
                pattern=node['index_pattern'];distinct={z:fs[k] for k,z in enumerate(pattern)}
                assert all(distinct[z]==fs[k] for k,z in enumerate(pattern))
                v=xor(word(y,*(distinct[z] for z in seq)) for seq in set(itertools.permutations(pattern)))
            else:raise ValueError(kind)
            values.append(v)
        target=parse(data['target']);assert values[data['root']]==target==expected(data['name'])
        report.append({'name':data['name'],'status':'PASS','DAG_nodes':len(values),
          'associative_target_terms':len(target),'multidegree':data['multidegree']})
    out={'status':'PASS','certificates':report,'independent_free_Lie_membership_checks':len(membership),
      'seconds':time.monotonic()-start,'scope':'Each proof is a sum of universally valid full cubic Engel coefficients and their Lie brackets. No finite-field enumeration or GAP universality is used.'}
    (ROOT/'identity_certificate_replay.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()

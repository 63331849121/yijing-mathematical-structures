Ordinary Lie reconstruction: exact finite proof inputs
====================================================
Run from the PaperG project directory with Python 3.10 or later:
  python verification/ordinary_reconstruction/run_checks.py --no-write
or
  python verification/ordinary_reconstruction/run_checks.py --output-dir replay_output

The first option uses a temporary directory under the working directory's
tmp/PaperG_replay and removes it afterwards. The second additionally saves
the report to the selected destination. Neither overwrites certificate inputs.
No third-party Python libraries are required. Recorded replay: CPython 3.12.14.

Fresh replay coverage:
- Seven universal ordinary three-Engel identities. The DAG checker verifies
  full Engel-coefficient leaves, Lie membership, operations and final target.
- The 21-dimensional detector: every basis Jacobi triple, all 37191 full
  cubic Engel coefficients, nonzero sextic R, the zero associator coefficient,
  and the third-difference coefficient one.
- The 45-dimensional class-four factor: Jacobi, full Engel coefficients,
  generation by the four heads, a reconstructed surjection to S_2, and
  nonmetabelianity. The separate associative-word functional is also checked.
- Twelve local central-rigidity certificates, rebuilding 3903 independent
  original CE/Engel equations and checking exact complementary dimensions.

The all-rank support/gluing argument, quotient descent, PBW construction,
degree bounds and homology formula are in Sections 7--8 and Appendices Z--AA.
The finite checks are proof inputs at their specified interfaces, rather
than a replacement for these general arguments.

archived_controls/ preserves earlier exact Boolean-coefficient and family
reports used during discovery. Those reports are not recomputed by this
entry point. Earlier verification groups remain available independently.
REPLAY_REPORT.json records the fresh integration replay; original sources
are fingerprinted there. No proof-assistant formalization is claimed.

"""Literal all-rank table formula controls, separate from the search seed."""
from pathlib import Path
from itertools import combinations
import json,time
from audit_repair_independent import audit,terms,scale,add
HERE=Path(__file__).resolve().parent

def seed():
    t=[[0]*7 for _ in range(7)]
    for i,j,k in [(0,1,2),(0,2,3),(1,2,4),(0,4,5),(1,3,5),(0,5,6),(2,3,6)]:
        t[i][j]=t[j][i]=1<<(2*k)
    return t
def model(r):
    names=[f'A{i}' for i in range(1,r+1)]+[f'B{i}' for i in range(1,r+1)]
    weights=[1]*(2*r)
    pairs=list(combinations(range(1,r+1),2))
    for tag,wt in [('E',2),('U',2)]:
        names += [f'{tag}{i}_{j}' for i,j in pairs];weights += [wt]*len(pairs)
    names += [f'V{j}' for j in range(2,r+1)];weights += [2]*(r-1)
    for tag in ('R','S','T'):
        names += [f'{tag}{i}_{j}' for i,j in pairs];weights += [3]*len(pairs)
    names += [f'Z{i}_{j}' for i,j in pairs];weights += [4]*len(pairs)
    names += [f'C{i}_{j}' for i,j in pairs];weights += [2]*len(pairs)
    a_dim=len(names)
    names += ['p','q','w','z'];weights += [3,3,4,5]
    ids={s:i for i,s in enumerate(names)};n=len(names);t=[[0]*n for _ in range(n)]
    def put(a,b,*cs):
        i,j=ids[a],ids[b];out=sum(1<<(2*ids[c]) for c in cs)
        assert not t[i][j];t[i][j]=t[j][i]=out
    for i,j in pairs:
        E,U,R,S,T,Z,C=[f'{tag}{i}_{j}' for tag in ('E','U','R','S','T','Z','C')]
        put(f'A{i}',f'A{j}',E,C);put(f'B{i}',f'B{j}',E);put(f'A{i}',f'B{j}',U)
        put(f'A{i}',E,R);put(f'B{i}',U,R);put(f'A{j}',E,S);put(f'B{i}',f'V{j}',S)
        put(f'A{j}',U,T);put(f'A{i}',f'V{j}',T)
        put(f'A{i}',S,Z);put(f'A{j}',R,Z);put(f'B{i}',T,Z)
    for j in range(2,r+1):put(f'A{j}',f'B{j}',f'V{j}')
    put('A1','U1_2','p');put('B2','U1_2','q');put('A1','q','w');put('B2','p','w');put('A1','w','z');put('U1_2','p','z')
    return t,weights,names,a_dim

def main():
    st=seed();reports=[audit('literal_L7',st,0,5)]
    for r in (2,3,4):
        t,w,names,a_dim=model(r);n=len(t);ids={s:i for i,s in enumerate(names)}
        rec=audit('uniform_G'+str(r),t,0,5)
        # Literal map onto L7 and its split Heisenberg restriction.
        cols=[0]*n
        for name,j in [('A1',0),('B2',1),('U1_2',2),('p',3),('q',4),('w',5),('z',6)]:cols[ids[name]]=1<<(2*j)
        def project(v):
            out=0
            for i,a in terms(v):out^=scale(a,cols[i])
            return out
        def br(table,x,y):
            out=0
            for i,a in terms(x):
                for j,b in terms(y):
                    from audit_repair_independent import M
                    out^=scale(M[a][b],table[i][j])
            return out
        for i,j in combinations(range(n),2):assert project(t[i][j])==br(st,cols[i],cols[j])
        # Verify generation from the exact 2r head points.
        span={}
        for i in range(2*r):add(1<<(2*i),span)
        while True:
            old=len(span)
            for x,_ in list(span.values()):
                for h in range(2*r):add(br(t,x,1<<(2*h)),span)
            if len(span)==old:break
        assert len(span)==n
        # Last two kernels and the first kernel over S_r are central
        # in their respective quotient tables.
        for cutoff,kernel_names in [(a_dim+2,[s for s in names if s.startswith('C')]+['p','q']),(a_dim+3,['w']),(a_dim+4,['z'])]:
            mask=(1<<(2*cutoff))-1
            for name in kernel_names:
                for j in range(cutoff):assert not (t[ids[name]][j]&mask)
        m=r*(r-1)//2
        rec.update(point_rank=2*r,A_dimension=a_dim,stages=[3*r*r-1,a_dim+2,a_dim+3,a_dim+4],central_kernel_dimensions=[m+2,1,1],explicit_fiber_projection=True,generation=True)
        reports.append(rec)
        (HERE/f'uniform_G{r}_literal.json').write_text(json.dumps(dict(table=t,weights=w,names=names,A_dimension=a_dim),indent=2)+'\n')
    (HERE/'uniform_unlocking_controls.json').write_text(json.dumps(dict(status='PASS',cases=reports,scope='Direct literal table controls; all-rank existence and generation are proved via fiber products.'),indent=2)+'\n')
if __name__=='__main__':main()

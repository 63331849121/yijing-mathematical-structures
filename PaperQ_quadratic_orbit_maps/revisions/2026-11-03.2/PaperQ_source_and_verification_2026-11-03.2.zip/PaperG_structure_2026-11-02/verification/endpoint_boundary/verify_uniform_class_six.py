"""Rebuild the short forty-dimensional seed and its first larger-rank lift."""
from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
from audit_repair_independent import audit,terms,scale,M
from verify_three_index_unlocking import triple_model
from weighted_cover_core import br
HERE=Path(__file__).resolve().parent

def model(r):
    t,w,names,a=triple_model(r);n=len(t);tail=['u','v','w','a','b','c','d','z6']
    t=[row+[0]*8 for row in t]+[[0]*(n+8) for _ in range(8)];w=w+[3,3,3,4,4,4,5,6];names=names+tail;ix={v:i for i,v in enumerate(names)}
    entries=[('A3','U1_3','v'),('A3','U2_3','w'),('A3','V3','u'),('A1','u','a'),('A2','u','b'),('A3','v','a'),('A3','w','b'),('A1','w','c'),('A2','v','c'),('B3','C1_3','v'),('B3','C2_3','w'),('U1_3','C2_3','c'),('U2_3','C1_3','c'),('V3','C1_3','a'),('V3','C2_3','b'),('A1','b','d'),('A2','a','d'),('A3','c','d'),('A3','Q','d'),('T1_3','C2_3','d'),('T2_3','C1_3','d')]
    entries += [(x,y,'z6') for x,y in [('A3','Z'),('B3','d'),('U1_3','b'),('U2_3','a'),('V3','c'),('T1_3','w'),('T2_3','v'),('P','u')]]
    for x,y,z in entries:
        i,j,k=ix[x],ix[y],ix[z];t[i][j]^=1<<(2*k);t[j][i]^=1<<(2*k)
    return t,w,names,n

def square_basis_check(t,names):
    n=len(t);ix={v:i for i,v in enumerate(names)};pb=[0]*n
    for s,i in ix.items():
        if s.startswith('C') and '_' in s:pb[i]=1<<(2*ix['Z'+s[1:]])
    def p(v):
        out=0;part=0
        for i,a in terms(v):
            out^=scale(M[a][a],pb[i]);ai=a<<(2*i);out^=br(t,part,ai);part^=ai
        return out
    head=sum(1 for s in names if (s.startswith('A') or s.startswith('B')) and s[1:].isdigit())
    for i in range(head,n):
        assert not p(pb[i])
        for j in range(n):assert br(t,pb[i],1<<(2*j))==br(t,1<<(2*i),t[i][j])
    for i in range(n):
        for j in range(i+1,n):assert p(t[i][j])==br(t,br(t,t[i][j],1<<(2*j)),1<<(2*i))
    return {names[i]:[(names[j],a) for j,a in terms(v)] for i,v in enumerate(pb) if v}

def main():
    d=json.loads((HERE/'class_six_compressed_seed.json').read_text());t,w,names,base=model(3)
    assert t==d['table'] and w==d['weights'];squares=square_basis_check(t,names)
    print('literal_seed_matches; specified square basis checks PASS',flush=True)
    records=[d['check']]
    t,w,names,base=model(4);pvals=square_basis_check(t,names);records.append(audit('uniform_class6_r4',t,0,6))
    source_t,source_w,source_names,source_base=model(3);target={v:i for i,v in enumerate(source_names)}
    def retract(v):
        return sum(a<<(2*target[names[i]]) for i,a in terms(v) if names[i] in target)
    for i in range(len(t)):
        for j in range(len(t)):assert retract(t[i][j])==br(source_t,retract(1<<(2*i)),retract(1<<(2*j)))
    out=dict(status='PASS',cases=records,square_basis=squares,r4_square_basis=pvals,r4_retraction_to_seed=True,scope='Short seed reconstructed by names, matched byte for byte; one new larger-rank full-table control; general validity uses the fiber-product proof.')
    (HERE/'uniform_class_six_controls.json').write_text(json.dumps(out,indent=2)+'\n')
    (HERE/'uniform_class6_r4_literal.json').write_text(json.dumps(dict(status='PASS',table=t,weights=w,names=names,base_dimension=base),indent=2)+'\n')
if __name__=='__main__':main()

"""Independent literal F2 reconstruction of the ordinary obstruction certificate.

All coefficient matrices have F2 entries; their kernels are then extended
to F4. Boolean evaluations determine only homogeneous quadratic coefficients,
whose homogeneity is supplied by the filtration proof, not by sampling.
"""
from pathlib import Path
from itertools import permutations,combinations
import json,time
HERE=Path(__file__).resolve().parent
seed=json.loads((HERE/'class_six_compressed_seed.json').read_text())
def unpack(x):
 out=0
 while x:
  i=(x.bit_length()-1)//2;v=(x>>(2*i))&3;assert v==1;out^=1<<i;x^=1<<(2*i)
 return out
T=[[unpack(v) for v in row] for row in seed['table']];n=len(T)
def bits(x):
 while x:
  j=(x&-x).bit_length()-1;yield j;x^=1<<j
def br(t,x,y):
 out=0
 for i in bits(x):
  for j in bits(y):out^=t[i][j]
 return out
def identity(t,tag):
 if tag[0]=='J':
  i,j,k=tag[1:4];return br(t,t[i][j],1<<k)^br(t,t[j][k],1<<i)^br(t,t[k][i],1<<j)
 y=tag[1];out=0
 for a,b,c in set(permutations(tag[2:5])):out^=br(t,br(t,t[y][a],1<<b),1<<c)
 return out
def rank(rows):
 p={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in p:v^=p[j]
   else:p[j]=v;break
 return len(p)
layer=json.loads((HERE/'eight_cost_lift_excess1.json').read_text());m=layer['kernel_variables'];rows=layer['rows'];tags=layer['row_tags'];tick=time.monotonic()
descriptors={tuple(tag[:-1]) for tag in tags}
for q,(i,j,k) in enumerate(layer['variables']):
 t=[r[:] for r in T];t[i][j]^=1<<k;t[j][i]^=1<<k
 values={tag:identity(t,list(tag)+[0]) for tag in descriptors}
 assert all(((values[tuple(tag[:-1])]>>tag[-1])&1)==((row>>q)&1) for tag,row in zip(tags,rows))
 if q%100==0:print('independent literal columns',q,'/',m,flush=True)
mask=(1<<m)-1;matrix=[v&mask for v in rows];assert rank(matrix)==465
sd=json.loads((HERE/'cover_self_deformation_ordinary.json').read_text());reps=sd['representatives'];assert len(reps)==15
# Reconstruct the complete gauge image from linear section changes.
W=seed['weights'];base=32;sections=[(i,k) for i in range(n) for k in range(base,n) if W[k]-W[i]==1];cb=[]
for f,k in sections:
 v=0
 for p,(i,j,z) in enumerate(layer['variables']):
  bit=((T[i][j]>>f)&1) if z==k else 0
  if i==f:bit^=(T[k][j]>>z)&1
  if j==f:bit^=(T[i][k]>>z)&1
  if bit:v^=1<<p
 cb.append(v)
assert rank(cb)==81 and rank(cb+reps)==96
assert all(not (r&v).bit_count()%2 for r in matrix for v in cb+reps)
cert=json.loads((HERE/'second_layer_obstruction_2_ordinary_certificate.json').read_text());second=json.loads((HERE/'eight_cost_lift_excess2.json').read_text())
functional=cert['row_functional'];six=[tag for i,tag in enumerate(second['row_tags']) if functional>>i&1];assert len(six)==6
def F(t):return __import__('functools').reduce(int.__xor__,((identity(t,tag)>>tag[-1])&1 for tag in six),0)
assert F(T)==0
for i,j,k in second['variables']:
 t=[r[:] for r in T];t[i][j]^=1<<k;t[j][i]^=1<<k;assert F(t)==0
def source(coeff):
 t=[r[:] for r in T]
 for c,rep in zip(coeff,reps):
  if not c:continue
  for pos,(i,j,k) in enumerate(sd['variables']):
   if rep>>pos&1:t[i][j]^=1<<k;t[j][i]^=1<<k
 t[0][9]^=1<<31;t[9][0]^=1<<31 # [A1,U12] += Z.
 return t
assert F(source([0]*15))==1
for i in range(15):
 coeff=[0]*15;coeff[i]=1;assert F(source(coeff))==1
for i,j in combinations(range(15),2):
 coeff=[0]*15;coeff[i]=coeff[j]=1;assert F(source(coeff))==1
out={'status':'PASS','first_layer_unknown_columns_rebuilt':m,'first_layer_rank':465,'kernel':96,'full_gauge_rank':81,'essential_self_parameters':15,'functional_identity_count':6,'second_layer_unknown_columns_annihilated':len(second['variables']),'quadratic_coefficient_checks':120,'scope':'No ordinary class-six lift of H* with associated-graded cover equal to the selected X->G3. Does not exclude other cost-eight graded covers. No SAT result is a proof input.','seconds':time.monotonic()-tick}
(HERE/'eight_cover_obstruction_independent_audit.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out),flush=True)

Q endpoint-boundary inputs, version 2026-11-03.1.
Proofs: Appendix eqb-app:proofs of the actual PaperG_structure.tex.
verify_equality_family.py reconstructs the short X table and the selected
one-parameter equality family; full literal CE/Engel/R and N controls.
audit_cover_obstruction.py independently reconstructs every first-layer
ordinary column, the full gauge quotient, and the six-identity certificate.
Its first/second-layer JSON matrices are stripped of research-only endpoint
classification parameters; no 48-parameter classification is required.
The fifteen-coordinate source space is necessary to cover arbitrary ordinary
filtered corrections; a fixed-square normalization is not assumed.
The programs write reports in their isolated replay copy.
No SAT, external network, companion manuscript or research path is needed.

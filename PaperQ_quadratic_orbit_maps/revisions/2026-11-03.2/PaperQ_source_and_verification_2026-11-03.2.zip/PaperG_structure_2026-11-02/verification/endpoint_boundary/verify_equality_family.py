"""Literal nonhomogeneous optimal endpoints and same-cost class-six lifts."""
from pathlib import Path
from itertools import combinations
import sys,json,time
HERE=Path(__file__).resolve().parent
from verify_three_index_unlocking import triple_model
from audit_repair_independent import audit,terms
from verify_uniform_class_six import model as six_model

def twist5(r,params):
 t,w,names,a=triple_model(r);ids={s:i for i,s in enumerate(names)}
 for (i,j),v in params.items():
  x,y=ids[f'A{i}'],ids[f'B{j}'];assert t[x][y]==0
  t[x][y]=t[y][x]=v<<(2*ids['Z'])
 return t,w,names,a
def twist6(r,params):
 t,w,names,base= six_model(r);ids={s:i for i,s in enumerate(names)}
 for (i,j),v in params.items():
  x,y=ids[f'A{i}'],ids[f'B{j}'];assert t[x][y]==0
  t[x][y]=t[y][x]=v<<(2*ids['Z'])
  if i!=3:
   c=ids[f'C{min(i,3)}_{max(i,3)}'];b=ids[f'B{j}']
   t[c][b]^=v<<(2*ids['z6']);t[b][c]^=v<<(2*ids['z6'])
 return t,w,names
if __name__=='__main__':
 cases=[]
 for r,params in [(3,{(1,1):0}),(3,{(1,1):1}),(3,{(1,1):2}),(4,{(1,1):3})]:
  t,w,n,a=twist5(r,params);cases.append(audit('twisted_class5_r'+str(r),t,0,5))
  s,ww,nn=twist6(r,params);cases.append(audit('twisted_class6_r'+str(r),s,0,6))
  ids={s:i for i,s in enumerate(nn)}
  assert all(s[ids[x]][ids[y]]&((1<<(2*len(t)))-1)==t[i][j] for i,x in enumerate(n) for j,y in enumerate(n))
 t,w,n,a=triple_model(3);ix={s:i for i,s in enumerate(n)};t[ix['A1']][ix['U1_2']]=t[ix['U1_2']][ix['A1']]=1<<(2*ix['Z']);cases.append(audit('Hstar_class5',t,0,5))
 (HERE/'twisted_endpoint_controls.json').write_text(json.dumps({'status':'PASS','cases':cases,'scope':'Full literal identities and N; general proof supplied separately, finite controls not extrapolation.'},indent=2)+'\n',encoding='utf-8')

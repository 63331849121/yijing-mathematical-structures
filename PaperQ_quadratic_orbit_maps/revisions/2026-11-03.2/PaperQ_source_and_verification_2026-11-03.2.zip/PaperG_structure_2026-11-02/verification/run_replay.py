"""Independent-manuscript replay in an isolated copy, with failure collection."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys,time,tempfile,platform,re
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output-dir',type=Path);ap.add_argument('--no-write',action='store_true');ap.add_argument('--extended',action='store_true');ap.add_argument('--extended-only',action='store_true')
    ap.add_argument('--group',choices=['all','central-repair','merge-review','cubic-boundary','endpoint-boundary'],default='all')
    ap.add_argument('--temp-root',type=Path,help='Short writable parent for the isolated verification copy')
    a=ap.parse_args()
    if a.output_dir and a.no_write:ap.error('choose --output-dir or --no-write')
    spec=json.loads((HERE/'REPLAY_TASKS.json').read_text())
    if a.extended_only:tasks=spec['extended']
    elif a.group=='central-repair':tasks=spec['central_repair']
    elif a.group=='merge-review':tasks=spec['merge_review']
    elif a.group=='cubic-boundary':tasks=spec['cubic_boundary']
    elif a.group=='endpoint-boundary':tasks=spec['endpoint_boundary']
    else:tasks=spec['core']+spec.get('central_repair',[])+spec.get('cubic_boundary',[])+spec.get('endpoint_boundary',[])+(spec['extended'] if a.extended else [])
    # Keep import paths short even when a source ZIP is extracted deep on Windows.
    parent=(a.temp_root if a.temp_root else Path(tempfile.gettempdir())/'paper_q_replay').resolve();parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='paper_',dir=parent) as tmp:
        tmp=Path(tmp);assert tmp.resolve().is_relative_to(parent)
        if a.output_dir:
            out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
            assert not any(out.iterdir()),'Use a new or empty output directory'
        else:out=tmp/'reports';out.mkdir()
        dest=tmp/'verification';shutil.copytree(HERE,dest,ignore=shutil.ignore_patterns('__pycache__','tmp'))
        start=time.monotonic();results=[]
        for i,(name,args) in enumerate(tasks,1):
            tick=time.monotonic();log=out/f'{i:02d}_{Path(name).stem}.log'
            with log.open('w',encoding='utf8') as f:
                p=subprocess.run([sys.executable,'-B','-X','utf8',str(dest/name),*args],cwd=dest,stdout=f,stderr=subprocess.STDOUT)
            text=log.read_text(encoding='utf8',errors='replace')
            bad=bool(re.search(r'BOUNDED_BUDGET_STOP|Traceback|AssertionError|"status"\s*:\s*"FAIL"',text))
            status='PASS' if p.returncode==0 and not bad else 'FAIL'
            row={'program':name,'args':args,'status':status,'exit_code':p.returncode,'seconds':round(time.monotonic()-tick,3),'log':log.name}
            results.append(row);print(json.dumps(row),flush=True)
            for report_name in spec.get('reports',{}).get(name,[]):
                source=dest/Path(name).parent/report_name
                assert source.is_file(),f'Missing task report: {source}'
                shutil.copyfile(source,out/report_name)
            report={'paper':spec['paper'],'status':'PASS' if all(r['status']=='PASS' for r in results) else 'FAIL',
              'completed':len(results),'expected':len(tasks),'group':a.group,'extended':a.extended or a.extended_only,'extended_only':a.extended_only,'python':platform.python_version(),
              'seconds':round(time.monotonic()-start,3),'results':results,
              'scope':'Only the listed tasks were rerun in this split; general proofs and inherited reports have their separately stated scope.'}
            (out/'SPLIT_REPLAY.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
        assert all(r['status']=='PASS' for r in results),'Replay failures: inspect collected logs'
if __name__=='__main__':main()

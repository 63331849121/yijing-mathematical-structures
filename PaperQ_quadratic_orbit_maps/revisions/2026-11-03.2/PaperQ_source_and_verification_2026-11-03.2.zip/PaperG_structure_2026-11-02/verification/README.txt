Independent verification materials for Q 2026-11-03.2
Fresh targeted replays: merge-review six tasks and cubic-boundary four tasks,
all PASS. Reports are replay/submission_merge_20261103 and
replay/submission_cubic_20261103. The endpoint-boundary scripts and inputs
are unchanged; their two-task report replay/endpoint_boundary_20261103 is
inherited from the preceding revision and was not freshly rerun here.
No old whole-paper suite rerun is asserted. Default all selects 18 tasks;
REPLAY_TASKS.json gives the exact specification and arguments.

The default cubic group passes --paper-only to three checkers. It omits
complete character profiles, exceptional rank-three conjugators and
all-conjugator matrix strata. The standalone scripts retain historical
followup modes for archival use; those modes are not main-paper inputs.
General arbitrary-rank, quotient and filtration arguments are written proofs.

Run python -B -X utf8 verification/run_replay.py --group cubic-boundary
--output-dir NEW_REPORT_DIRECTORY. The directory must be new or empty.
Use --temp-root SHORT_WRITABLE_ABSOLUTE_PATH when system temp is restricted.
The runner copies inputs into an isolated directory and preserves originals.
Omit --output-dir and use --no-write for a disposable replay.
Reports record Python and exact task scope. Inherited rank tasks may use
SymPy1.14.0; the cubic and endpoint controls use the standard library.
No external research directory or companion source is needed to replay.

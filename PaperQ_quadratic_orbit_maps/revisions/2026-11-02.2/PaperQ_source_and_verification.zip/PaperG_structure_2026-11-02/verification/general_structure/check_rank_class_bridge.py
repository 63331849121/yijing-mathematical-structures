"""Self-contained finite controls of the rank--class bridge.

The displayed F16 polynomial is authenticated against the normalized map
in the supplied original n16 rank certificate. No research file, model
constructor, external package, or network is imported. We reconstruct its
exact derived scalar, form a genuine ordinary F4-3-Engel input algebra H,
and replay the reverse restricted-envelope/binary-subsolution construction.
The final two controls check finite commutative-module and integer-bound
interfaces. None substitutes for the arbitrary-rank proofs in the paper.

Default/--no-write prints only. --report creates a fresh file exclusively;
--output-dir must be new or empty. Existing reports are never overwritten.
"""
from pathlib import Path
from itertools import combinations, product
from functools import reduce
import argparse
import hashlib
import json
import time

MUL = ((0, 0, 0, 0), (0, 1, 2, 3), (0, 2, 3, 1), (0, 3, 1, 2))
EXPECTED_MAP_SHA256 = '3d2fcbc4ac4411d8e46a4b587857a1cdb86e278f32c8eff4971d6c561602cfdc'


def model16(v):
    a, b, c, d, e, h, r, s = ((v >> (2*i)) & 3 for i in range(8))
    m = lambda x, y: MUL[x][y]
    sq = lambda x: m(x, x)
    y = (m(2, a), m(2, b), m(2, c) ^ m(a, b),
         m(2, d) ^ m(a, c) ^ m(sq(a), b),
         m(2, e) ^ m(b, c) ^ m(a, sq(b)),
         m(2, h) ^ m(a, e) ^ m(b, d),
         m(2, r) ^ m(a, sq(c)) ^ m(sq(a), e) ^ m(a, h) ^ m(c, d),
         m(2, s) ^ m(b, sq(c)) ^ m(sq(b), d) ^ m(b, h) ^ m(c, e))
    return sum(x << (2*i) for i, x in enumerate(y))


def basis(vectors):
    pivots = {}
    for v in vectors:
        while v:
            j = v.bit_length()-1
            if j in pivots:
                v ^= pivots[j]
            else:
                pivots[j] = v
                break
    return list(pivots.values())


def lin(columns, x):
    result = 0
    while x:
        b = x & -x
        x ^= b
        result ^= columns[b.bit_length()-1]
    return result


def add(a, b):
    return tuple(x ^ y for x, y in zip(a, b))


def comp(a, b):
    return tuple(lin(a, x) for x in b)


def bracket(a, b):
    return add(comp(a, b), comp(b, a))


def pack(a, n):
    return sum(x << (n*i) for i, x in enumerate(a))


def unpack(a, n):
    return tuple((a >> (n*i)) & ((1 << n)-1) for i in range(n))


def span_values(bs):
    values = [0]
    for b in bs:
        values += [v ^ b for v in values]
    return values


def coordinates(bs):
    piv = {a.bit_length()-1: (a, 1 << i) for i, a in enumerate(bs)}
    def coordinate(a):
        out = 0
        while a:
            p = a.bit_length()-1
            assert p in piv, 'vector outside the declared span'
            b, c = piv[p]
            a ^= b
            out ^= c
        return out
    return coordinate


def lie_closure(gens, n):
    h = basis(pack(a, n) for a in gens)
    while True:
        arrays = [unpack(a, n) for a in h]
        new = basis(h + [pack(bracket(a, b), n) for a in arrays for b in arrays])
        if len(new) == len(h):
            return h
        h = new


def lower_dimensions(h, n):
    ambient = [unpack(a, n) for a in h]
    dims, layer = [len(h)], h
    while layer:
        layer = basis(pack(bracket(a, unpack(b, n)), n) for a in ambient for b in layer)
        dims.append(len(layer))
        assert len(dims) <= len(h)+2, 'nonterminating lower-central calculation'
    return dims


def reverse_control():
    units = [1 << i for i in range(16)]
    masks = units + [x | y for x, y in combinations(units, 2)]
    coeff = [model16(x) for x in units]
    coeff += [model16(x ^ y) ^ model16(x) ^ model16(y) for x, y in combinations(units, 2)]
    raw = {'n': 16, 'masks': masks, 'coefficients': coeff}
    digest = hashlib.sha256(json.dumps(raw, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    assert digest == EXPECTED_MAP_SHA256, 'displayed model differs from authenticated original'
    truth = [model16(x) for x in range(1 << 16)]
    assert all(truth[truth[x]] == truth[x] ^ x for x in range(1 << 16))
    polar = [[truth[x ^ y] ^ truth[x] ^ truth[y] for y in units] for x in units]
    def b(x, y):
        return lin([lin(row, y) for row in polar], x)
    w = basis(polar[i][j] for i, j in combinations(range(16), 2))
    assert len(w) == 12 and all(x & 15 == 0 for x in w)

    # Reconstruct exact J from every basis-pair B/D relation, not from
    # the ambient displayed-coordinate omega (which is a different map).
    piv = {}
    for i, j in combinations(range(16), 2):
        value = polar[i][j]
        a = value >> 4
        image = (b(truth[units[i]], units[j]) ^ b(units[i], value)) >> 4
        while a:
            p = a.bit_length()-1
            if p in piv:
                v, z = piv[p]
                a ^= v
                image ^= z
            else:
                piv[p] = (a, image)
                break
        else:
            assert image == 0, 'inconsistent exact derived factor'
    assert len(piv) == 12
    def jimage(a):
        out = 0
        while a:
            p = a.bit_length()-1
            v, z = piv[p]
            a ^= v
            out ^= z
        return out
    j12 = tuple(jimage(1 << i) for i in range(12))
    assert add(comp(j12, j12), j12) == tuple(1 << i for i in range(12))
    actions = [tuple(b(x, 1 << (i+4)) >> 4 for i in range(12)) for x in units]
    assert all(comp(j12, a) == comp(a, j12) for a in actions)
    h = lie_closure([actions[0], actions[2], comp(j12, actions[0]), comp(j12, actions[2])], 12)
    assert len(h) == 10 and lower_dimensions(h, 12) == [10, 6, 4, 0]
    hcoord = coordinates(h)
    jh = tuple(hcoord(pack(comp(j12, unpack(a, 12)), 12)) for a in h)
    assert add(comp(jh, jh), jh) == tuple(1 << i for i in range(10))
    # The ordinary input H is genuine 3-Engel: the cube of every
    # displayed operator is zero, hence all its inner cubes are zero.
    for a in span_values(h):
        a = unpack(a, 12)
        assert comp(a, comp(a, a)) == (0,)*12

    xcols = [tuple(hcoord(pack(bracket(unpack(a, 12), unpack(c, 12)), 12)) for c in h) for a in h]
    x = basis(pack(a, 10) for a in xcols)
    nspace = basis([pack(a, 10) for a in xcols] + [pack(comp(a, a), 10) for a in xcols])
    assert len(x) == 6 and len(nspace) == 10
    assert all(comp(jh, a) == comp(a, jh) for a in xcols)
    xset = set(span_values(x))
    for a in xset:
        a = unpack(a, 10)
        assert comp(a, comp(a, a)) == (0,)*10
    nset = set(span_values(nspace))
    for a in nset:
        arr = unpack(a, 10)
        assert pack(comp(jh, arr), 10) in nset
        square = comp(arr, arr)
        assert pack(square, 10) in nset
        assert comp(square, square) == (0,)*10
    arrays = [unpack(a, 10) for a in nspace]
    assert all(pack(bracket(a, b), 10) in nset for a in arrays for b in arrays)

    def rho(old):
        return lin(tuple(pack(a, 10) for a in xcols), hcoord(pack(old, 12)))
    seeds = [rho(actions[0]), rho(actions[2])]
    def orbit(a):
        return add(comp(jh, a), comp(a, a))
    y = basis(seeds)
    while True:
        ya = [unpack(a, 10) for a in y]
        new = basis(y + [pack(orbit(a), 10) for a in ya] + [pack(bracket(a, b), 10) for a in ya for b in ya])
        if len(new) == len(y):
            break
        y = new
    assert len(y) == 6
    ky = basis(y + [pack(comp(jh, unpack(a, 10)), 10) for a in y])
    assert len(ky) == len(nspace) == len(basis(ky+nspace))
    yd, nd = lower_dimensions(y, 10), lower_dimensions(nspace, 10)
    assert yd == [6, 2, 0] and nd == [10, 2, 0]
    values = set(span_values(y))
    for v in values:
        a = unpack(v, 10)
        assert pack(orbit(a), 10) in values
        assert add(orbit(orbit(a)), orbit(a)) == a
    return {'authenticated_F16_map_sha256': digest, 'F16_all_inputs': 65536,
            'H_binary_dimension': 10, 'H_lower_central_dimensions': [10, 6, 4, 0],
            'H_cube_checks': len(span_values(h)), 'adjoint_X_binary_rank': 6,
            'H_inner_cube_checks': len(xset), 'H_original_F4_bracket_bilinear': True,
            'restricted_N_binary_dimension': 10, 'N_fourth_power_checks': len(nset),
            'Y_binary_dimension': 6, 'Y_point_generator_count': len(seeds),
            'Y_intrinsic_point_rank': (yd[0]-yd[1])//2,
            'Y_lower_central_dimensions': yd, 'N_lower_central_dimensions': nd,
            'all_Y_inputs': len(values), 'scalar_saturation_kY_equals_N': True,
            'class_H_minus_one_preserved': len(yd)-1 == len([10, 6, 4, 0])-2,
            'scope': 'One complete input H and its reverse realization; not all ordinary 3-Engel algebras.'}


def commuting_module_control():
    records = []
    for d in range(1, 9):
        # Normal monomials of the explicit quotient
        # k[t_i]/(t_i^3,t_i^2*t_j for i!=j).
        monomials = [tuple((mask >> i) & 1 for i in range(d)) for mask in range(1 << d)]
        monomials += [tuple(2 if i == j else 0 for i in range(d)) for j in range(d)]
        normal = set(monomials)
        assert len(normal) == (1 << d)+d
        unit = (0,)*d
        def multiply(a, b):
            c = tuple(x+y for x, y in zip(a, b))
            return c if c in normal else None
        generators = [tuple(1 if i == j else 0 for i in range(d)) for j in range(d)]
        for a in generators:
            assert multiply(multiply(a, a), a) is None
            for c in generators:
                assert multiply(multiply(a, a), c) is None
        witness = reduce(multiply, generators, unit)
        assert witness == (1,)*d
        maximum_degree = max(map(sum, normal))
        expected_index = max(d, 2)+1
        assert maximum_degree+1 == expected_index
        assert all(sum(m) <= d for m in normal) if d >= 2 else maximum_degree == 2
        records.append({'d': d, 'quotient_dimension': len(normal),
                        'positive_ideal_nilpotence_index': expected_index,
                        'all_distinct_generator_product_nonzero': True})
    return {'status': 'PASS', 'cases': records,
            'small_rank_exception_retained': True,
            'scope': 'Finite normal-monomial controls; the general commuting-action lemma has a written proof.'}


def arithmetic_control():
    for d in range(2, 513):
        q = (d+1)**4 // 2
        final = q+d+1
        bootstrap = q+d+2
        assert final+1 == bootstrap
        assert final <= (d+1)**4
        assert 2*final <= (d+2)**4
        assert final < ((2*d+1)**4 // 2 + 6*(2*d+1)**6)
    return {'d_min': 2, 'd_max': 512, 'integer_cases': 511,
            'rank_zero_class': 0, 'rank_one_class': 1,
            'safe_derived_length_and_dimension_inequalities': True,
            'scope': 'Finite exact integer arithmetic, not a proof of an all-rank bound.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--report', type=Path, help='Create one fresh report; existing files are refused.')
    group.add_argument('--output-dir', type=Path, help='Use a new or empty directory.')
    group.add_argument('--no-write', action='store_true', help='Print only (the default).')
    args = parser.parse_args()
    if args.report and args.report.exists():
        parser.error('--report must name a new file')
    if args.output_dir and args.output_dir.exists():
        if not args.output_dir.is_dir() or any(args.output_dir.iterdir()):
            parser.error('--output-dir must be new or empty')
    started = time.monotonic()
    report = {'status': 'PASS', 'reverse_realization': reverse_control(),
              'commuting_module': commuting_module_control(), 'integer_bounds': arithmetic_control(),
              'scope': 'Finite controls accompanying general proofs; no all-rank inference or proof-assistant formalization.',
              'seconds': round(time.monotonic()-started, 3)}
    target = args.report
    if args.output_dir:
        args.output_dir.mkdir(parents=True, exist_ok=True)
        target = args.output_dir/'rank_class_bridge.json'
    if target:
        with target.open('x', encoding='utf-8') as handle:
            json.dump(report, handle, indent=2)
            handle.write('\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

"""Portable exact checks for the ordinary reconstruction and central covers.

Reports are written only to an explicitly chosen output directory. With
--no-write, all generated files stay in a temporary directory.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement,permutations
import argparse,json,sys,time,tempfile,shutil,subprocess,hashlib,platform
sys.dont_write_bytecode=True
from arithmetic import bits,mul,scale4,tensor,bracket,support4
from displayed_compact import displayed_model
from replay_local_rigidity import replay
HERE=Path(__file__).resolve().parent

def binary_br(t,x,y):
    out=0
    for i in bits(x):
        for j in bits(y):out^=t[i][j]
    return out

def check_table(t,binary=False):
    n=len(t);br=(lambda x,y:binary_br(t,x,y)) if binary else (lambda x,y:bracket(t,x,y))
    unit=(lambda i:1<<i) if binary else (lambda i:1<<(2*i))
    assert all(len(row)==n for row in t)
    assert all(t[i][i]==0 for i in range(n))
    assert all(t[i][j]==t[j][i] for i,j in combinations(range(n),2))
    for i,j,k in combinations(range(n),3):
        assert br(t[i][j],unit(k))^br(t[j][k],unit(i))^br(t[k][i],unit(j))==0
    count=0
    for y in range(n):
        for tri in combinations_with_replacement(range(n),3):
            v=0
            for a,b,c in set(permutations(tri)):
                v^=br(br(t[y][a],unit(b)),unit(c))
            assert not v,(y,tri,v)
            count+=1
    return {'dimension':n,'Jacobi_triples':n*(n-1)*(n-2)//6,'full_Engel_coefficients':count}

def small_detector():
    d=json.loads((HERE/'small_sextic_detector.json').read_text())
    t=d['table'];ans=check_table(t,True)
    kt=[[tensor(v) for v in row] for row in t]
    br=lambda x,y:bracket(kt,x,y)
    def plus(x,y):
        c=br(x,y)
        return x^y^c^br(c,x)^br(c,y)^br(br(c,y),x)
    def total(xs):
        out=0
        for v in xs:out=plus(out,v)
        return out
    a,b,c=map(tensor,d['parent_generators_in_quotient'])
    q=lambda x,y:br(br(br(x,y),y),x)
    R=q(br(a,b),c)^q(br(b,c),a)^q(br(c,a),b)^br(br(br(a,b),c),br(br(b,c),a))
    assert R and R==tensor(d['R_in_quotient'])
    assert plus(plus(a,b),c)==plus(a,plus(b,c))
    values=(total((a,b,c)),plus(a,b),plus(a,c),plus(b,c),a,b,c)
    assert total(scale4(2,x) for x in values)==R
    ans.update(status='PASS',R_nonzero=True,associator_coefficient=0,third_difference_coefficient=1)
    return ans

def class4_factor():
    d=json.loads((HERE/'H45_nonmetabelian_factor.json').read_text());t=d['table']
    ans=check_table(t);n=len(t)
    assert n==45
    br=lambda x,y:bracket(t,x,y)
    heads=[1<<(2*i) for i in range(4)]
    assert br(heads[0],heads[1])==br(heads[2],heads[3])
    assert br(br(heads[0],heads[1]),br(heads[0],heads[2]))
    # Reconstruct the quotient map to the displayed eleven-dimensional J.
    jt,jw,jn=displayed_model(2,False)
    idx={v:i for i,v in enumerate(jn)}
    jheads=[1<<(2*idx[v]) for v in [('A',0),('A',1),('B',0),('B',1)]]
    piv={}
    def insert(x,y):
        for p,(v,w) in sorted(piv.items()):
            c=(x>>(2*p))&3
            if c:x^=scale4(c,v);y^=scale4(c,w)
        if not x:
            assert not y
            return False
        p=((x&-x).bit_length()-1)//2;c=(x>>(2*p))&3
        inv=(0,1,3,2)[c];piv[p]=(scale4(inv,x),scale4(inv,y));return True
    for x,y in zip(heads,jheads):insert(x,y)
    changed=True
    while changed:
        changed=False
        for x,y in list(piv.values()):
            for a,b in zip(heads,jheads):
                changed=insert(br(a,x),bracket(jt,b,y)) or changed
    assert len(piv)==45
    def image(x):
        y=0
        for p,(v,w) in sorted(piv.items()):
            c=(x>>(2*p))&3
            if c:x^=scale4(c,v);y^=scale4(c,w)
        assert not x
        return y
    ims=[image(1<<(2*i)) for i in range(n)]
    assert all(image(t[i][j])==bracket(jt,ims[i],ims[j]) for i,j in combinations(range(n),2))
    # Check the separating free-associative functional, independently of t.
    def add(*ps):
        out=set()
        for p in ps:
            for w in p:
                if w in out:out.remove(w)
                else:out.add(w)
        return out
    def wb(p,q):return add({a+b for a in p for b in q},{b+a for a in p for b in q})
    def left(p,*args):
        for q in args:p=wb(p,q)
        return p
    es=[{(i,)} for i in range(4)]
    support={(2,0,1,0),(2,1,0,0),(3,0,2,2),(3,2,0,2)}
    ell=lambda p:len(p&support)%2
    relation=add(wb(es[0],es[1]),wb(es[2],es[3]))
    for u,v in [(u,v) for u in es for v in es]:assert ell(left(relation,u,v))==0
    for y in es:
        for tri in combinations_with_replacement(range(4),3):
            assert ell(add(*(left(y,*(es[i] for i in seq)) for seq in set(permutations(tri)))))==0
    assert ell(wb(wb(es[0],es[1]),wb(es[0],es[2])))==1
    ans.update(status='PASS',generated_by_four_heads=True,surjection_to_J=True,nonmetabelian=True,word_functional=True)
    return ans

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--no-write',action='store_true');ap.add_argument('--output-dir',type=Path)
    args=ap.parse_args()
    if args.no_write and args.output_dir:ap.error('choose --no-write or --output-dir')
    started=time.monotonic()
    temp_parent=(Path.cwd()/'tmp'/'PaperG_replay').resolve()
    temp_parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ordinary_',dir=temp_parent) as tmp:
        work=Path(tmp)
        assert work.resolve().is_relative_to(temp_parent)
        # The universal checker writes its own report: isolate it from inputs.
        shutil.copy2(HERE/'replay_identity_certificates.py',work/'replay_identity_certificates.py')
        shutil.copytree(HERE/'identity_certificates',work/'identity_certificates')
        run=subprocess.run([sys.executable,'-B',str(work/'replay_identity_certificates.py')],capture_output=True,text=True)
        assert run.returncode==0,run.stdout+run.stderr
        dag=json.loads((work/'identity_certificate_replay.json').read_text())
        assert dag['status']=='PASS' and len(dag['certificates'])==7
        print('Universal Engel identities: PASS (7)',flush=True)
        detector=small_detector();print('Sextic detector: PASS',flush=True)
        factor=class4_factor();print('Class-four nonmetabelian factor: PASS',flush=True)
        paths=sorted((HERE/'local_rigidity_certificates').glob('*.json'));assert len(paths)==12
        rows=[replay(p) for p in paths]
        for path,row in zip(paths,rows):
            c=json.loads(path.read_text());expected=0 if c['weight']==5 else c['r']*(c['r']-1)//2
            assert row['kernel_dimension']==expected
        assert sum(v['checked_original_equations'] for v in rows)==3903
        print('Central rigidity: PASS (12 certificates, 3903 independent equations)',flush=True)
        sources={str(p.relative_to(HERE)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in HERE.rglob('*') if p.is_file() and p.suffix in {'.json','.py'} and '__pycache__' not in p.parts}
        out={'status':'PASS','python':platform.python_version(),'implementation':platform.python_implementation(),
             'universal_Engel_DAGs':dag,'sextic_detector':detector,'nonmetabelian_factor':factor,
             'local_rigidity':rows,'source_SHA256':sources,'seconds':time.monotonic()-started,
             'scope':'Finite coefficient inputs of the new proofs; general PBW, quotient descent and all-rank gluing are proved in the manuscript. Prior control groups are not rerun here.'}
        if args.output_dir:
            dest=args.output_dir.resolve();dest.mkdir(parents=True,exist_ok=True)
            (dest/'ordinary_reconstruction_replay.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'status':'PASS','python':out['python'],'seconds':out['seconds'],'no_input_writes':True}))
if __name__=='__main__':main()

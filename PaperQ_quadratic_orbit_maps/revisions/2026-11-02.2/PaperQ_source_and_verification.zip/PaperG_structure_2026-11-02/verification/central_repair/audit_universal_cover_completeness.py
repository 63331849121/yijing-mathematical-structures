"""Independent CE/Engel matrix completeness and 7225-case replay."""
from pathlib import Path
from itertools import product
import json,time
from weighted_cover_core import equations,pivots,nullspace
from audit_repair_independent import M,scale,terms
HERE=Path(__file__).resolve().parent

def low_field_insert(v,p):
    while v:
        i=((v&-v).bit_length()-1)//2;a=(v>>(2*i))&3
        if i in p:v^=scale(a,p[i])
        else:p[i]=scale((0,1,3,2)[a],v);return
def field_reduce(v,p):
    for i,row in sorted(p.items()):
        a=(v>>(2*i))&3
        if a:v^=scale(a,row)
    return v
def main():
    start=time.monotonic();d=json.loads((HERE/'A2_unlock_step2.json').read_text());t=d['base_table'];w=d['base_weights']
    levels=[]
    for a,b in [(12,23),(23,43)]:
        mask=(1<<(2*a))-1;tb=[[x&mask for x in row[:a]] for row in t[:a]];wa=w[:a]
        for q in (2,3,4):
            pairs,rows,rec=equations(tb,wa,q);kb=nullspace(rows,len(pairs))
            cb=[sum(((tb[i][j]>>(2*z))&3)<<k for k,(i,j) in enumerate(pairs)) for z in range(a) if wa[z]==q]
            new=[sum(((t[i][j]>>(2*z))&3)<<k for k,(i,j) in enumerate(pairs)) for z in range(a,b) if w[z]==q]
            assert all(not (v&row).bit_count()%2 for v in new for row in rows)
            assert len(pivots(cb+new))==len(kb)
            assert len(new)==len(kb)-len(pivots(cb))
            levels.append(dict(source=a,target=b,weight=q,**rec,cocycles=len(kb),coboundaries=len(pivots(cb)),new_independent=len(new),complete=True))
    pairs,rows,rec=equations(t,w,5);kb=nullspace(rows,len(pairs));assert len(kb)==28
    # Reconstruct the action coefficient tensors directly from the table,
    # using our independently generated top cocycle basis and low pivots.
    look={p:i for i,p in enumerate(pairs)};js3=[i for i in range(12,len(t)) if w[i]==3];js4=[i for i in range(12,len(t)) if w[i]==4]
    r4=[[] for _ in range(4)];r3=[[[] for _ in range(4)] for _ in range(4)]
    for h in range(4):
        for v in js4:
            pos=look[tuple(sorted((v,h)))]
            r4[h].append(sum(((c>>pos)&1)<<(2*j) for j,c in enumerate(kb)))
    for h in range(4):
        for k in range(4):
            for v in js3:
                row=0
                for a,c in terms(t[v][h]):
                    assert c==1
                    row^=r4[k][js4.index(a)]
                r3[h][k].append(row)
    vectors=[]
    for i in range(4):
        for tail in product(range(4),repeat=3-i):vectors.append((0,)*i+(1,)+tail)
    checked=0;hist={}
    for c in vectors:
        k=c.index(1);base=[]
        for h in range(4):base += [x^scale(c[h],y) for x,y in zip(r4[h],r4[k])]
        for b in vectors:
            h0=b.index(1);p={}
            for row in base:low_field_insert(row,p)
            for h in range(4):
                for x,y in zip(r3[h][k],r3[h0][k]):low_field_insert(x^scale(b[h],y),p)
            assert all(not field_reduce(v,p) for v in r4[k])
            hist[len(p)]=hist.get(len(p),0)+1;checked+=1
    report=dict(status='PASS',universal_steps=levels,top5=dict(**rec,cocycles=len(kb)),rank_one_F4_pairs=checked,rank_histogram=hist,seconds=time.monotonic()-start,scope='Independent weight-profile equation generator, low-pivot nullspace and F4 replay; input table only.')
    (HERE/'universal_completeness_and_independent_rank_one_replay.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
if __name__=='__main__':main()

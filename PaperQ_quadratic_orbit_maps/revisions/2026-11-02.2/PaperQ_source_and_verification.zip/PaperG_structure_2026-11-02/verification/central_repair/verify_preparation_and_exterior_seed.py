"""Check the exterior seed, fiber projections, and attained n+1 repair."""
from pathlib import Path
from itertools import combinations
import json
from audit_repair_independent import audit,terms,scale,M
from verify_three_index_unlocking import triple_model
from verify_uniform_unlocking import model
HERE=Path(__file__).resolve().parent

def quotient(t,keep):
    ids={v:j for j,v in enumerate(keep)}
    def project(v):return sum(c<<(2*ids[i]) for i,c in terms(v) if i in ids)
    return [[project(t[i][j]) for j in keep] for i in keep]
def exterior_seed():
    t=[[0]*12 for _ in range(12)]
    def put(i,j,k):assert not t[i][j];t[i][j]=t[j][i]=1<<(2*k)
    for i in range(3):put(i,3,4+i)
    es={(0,1):7,(0,2):8,(1,2):9}
    for (i,j),k in es.items():put(i,4+j,k);put(j,4+i,k)
    for i in range(3):
        rest=tuple(j for j in range(3) if j!=i);put(i,es[rest],10);put(4+i,es[rest],11)
    put(3,10,11)
    return t
def main():
    st=exterior_seed();reports=[audit('exterior_E12',st,0,5)]
    for r in (2,3,4):
        if r==2:
            t,w,names,a=model(2);prep=['p','q'];top='w';last='z'
        else:
            t,w,names,a=triple_model(r);prep=['P'];top='Q';last='Z'
        ids={s:i for i,s in enumerate(names)};m=r*(r-1)//2
        remove={i for i,s in enumerate(names) if s.startswith('C') or s in (top,last)}
        keep=[i for i in range(len(t)) if i not in remove]
        h=quotient(t,keep);reports.append(audit('prepared_bottom_r'+str(r),h,m,4))
        b=quotient(t,[i for i in range(len(t)) if names[i]!=last]);reports.append(audit('attaining_repair_r'+str(r),b,0,4))
        if r>=3:
            cols=[0]*len(t)
            for name,j in [('A1',0),('A2',1),('A3',2),('B3',3),('U1_3',4),('U2_3',5),('V3',6),('P',7),('T1_3',8),('T2_3',9),('Q',10),('Z',11)]:cols[ids[name]]=1<<(2*j)
            def project(v):
                out=0
                for i,c in terms(v):out^=scale(c,cols[i])
                return out
            for i,j in combinations(range(len(t)),2):
                v=0
                for x,c in terms(cols[i]):
                    for y,d in terms(cols[j]):v^=scale(M[c][d],st[x][y])
                assert project(t[i][j])==v
        for rec in reports[-2:]:rec.update(preparation_dimension=len(prep),scalar_N=m,repair_kernel_dimension=m+1,effective_pairing_rank=1,final_scalar_kernel=1)
    (HERE/'prepared_rank_one_attainment_controls.json').write_text(json.dumps(dict(status='PASS',cases=reports),indent=2)+'\n')
if __name__=='__main__':main()

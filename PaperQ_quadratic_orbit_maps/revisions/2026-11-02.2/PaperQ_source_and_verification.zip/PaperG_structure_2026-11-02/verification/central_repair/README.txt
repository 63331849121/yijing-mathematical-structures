Central repair and first ascent: proof and certificate correspondence
===================================================================
All dimensions in this directory are ordinary F4 dimensions. Read
Sections 11 and 13 and Appendix J of PaperG_structure.tex first.

Theorem 11.1 / Appendix J.1: exact minimum dim N(H), partial tradeoff,
same class/head, and extension-isomorphism equality over a fixed bottom.
This is a general written proof using free covers and CE transgression.
audit_repair_independent.py independently checks five literal full repair
models and two partial repairs, including all Engel coefficients, R and
the complete CE cycle image. The finite controls do not prove the general
claim or uniqueness. Their inputs are the five *_minimum_repair.json files.

Proposition 11.2, Theorem 11.3 / Appendix J.2: the general same-head
factorization, half weights, central rigidity transfer and dim Z >= n+r_eff
are proved in writing. The associated-graded reduction uses the induced
kernel filtration; the p^2=0 mixed terms are explicitly treated.

Theorem 13.1 / Appendix J.3-J.6: D2=5 and D_r=binom(r,2)+3 (r>=3),
over the specified S_r and over arbitrary-length towers. This is not a
global formula for m(5). The two-arrow obstruction and all-rank exterior
fiber-product construction are proved in writing. Inherited rigidity
inputs are rechecked by ordinary_reconstruction/run_checks.py.

Necessary finite rank-four exception (Appendix J.4):
  audit_universal_cover_completeness.py, weighted_cover_core.py,
  A2_unlock_step2.json, A2_no_cost_three_certificate.json.
The independent matrices check completeness of the 23/43-dimensional
preserving sources in weights 2,3,4. The last system has 172 variables,
rank 144, and a 28-dimensional solution space. Every one of the 85 x 85
F4 projective head-covector pairs gives rank 28 (7225 systems). This is
full F4 coverage, not a binary sample or a restriction to graded inputs;
the written graded reduction supplies the link to arbitrary inputs.

Attainment controls (written mechanism in Appendix J.5-J.6):
  verify_uniform_unlocking.py: only the r=2 seven-dimensional attachment,
    retained for its necessary rank-four boundary case.
  verify_three_index_unlocking.py: literal G_r tables at r=3,4,5;
    rank3_cost_three_seed.json and the twelve-dimensional exterior seed.
  verify_preparation_and_exterior_seed.py: r=2,3,4 preparation and the
    exterior seed, controlling Theorem 13.2 and equality in n+r_eff.
The all-rank proof uses shared head words to generate the entire actual
fiber-product kernel. It does not infer arbitrary r from these tables.

Run the five tasks via verification/run_replay.py --group central-repair.
Generated report names are specified in REPLAY_TASKS.json. The independent
repair audit uses its own arithmetic; other tasks share the explicit local
cover helper. PASS records the stated computational input, not an external
certification of all proofs. INPUTS.json gives file-level SHA256 values.

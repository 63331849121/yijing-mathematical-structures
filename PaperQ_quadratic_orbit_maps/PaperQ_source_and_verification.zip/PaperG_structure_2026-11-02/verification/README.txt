Independent verification materials for paper Q / local 73-page revision
======================================================================
Run from the manuscript directory:
  python -B -X utf8 verification/run_replay.py --group merge-review --output-dir replay_new
  python -B -X utf8 verification/run_replay.py --group central-repair --no-write
  python -B -X utf8 verification/run_replay.py --output-dir replay_all

merge-review: one inherited ordinary-reconstruction task and the five new
central_repair tasks (six invocations). central-repair: only those five.
The default all group contains the seven inherited core tasks plus the
five new tasks (twelve). The retained extended group is empty for Q.
REPLAY_TASKS.json is the authoritative task list.

The runner uses an isolated copy under the system temporary directory
(paper_q_replay), keeping Windows import paths short, and collects failures.
Use --temp-root with a short writable absolute path to select another parent
when the system temporary directory is restricted.
Literal input certificates and archived reports are not overwritten. Always use a
new report directory. All local imports are included; no other paper or
research directory is used by the supplied Python entry points.

New proofs: Sections 11 and 13, Appendix J. The full-rank mechanisms are
written proofs, not extrapolations of the finite controls. The complete
r=2 exclusion uses the full F4 coefficient systems and is a necessary
finite proof input. See central_repair/README.txt for its coverage.

The fresh six-task integration replay is
replay/merge_integration_20261102/SPLIT_REPLAY.json.
The earlier SPLIT_REPLAY.json and replay directories are retained as
historical records, without claiming their complete rerun in this merge.
INHERITED_INPUTS.json fingerprints the original split inputs;
central_repair/INPUTS.json fingerprints the new code and literal data.
This is exact computational verification, not proof-assistant formalization
or external expert review. The separate class-six followup is not part
of this manuscript's proof chain or default replay.

Dependencies: SymPy 1.14.0 plus the standard library. The current targeted
replay used Python 3.14.6; exact versions and task scope are in its report.

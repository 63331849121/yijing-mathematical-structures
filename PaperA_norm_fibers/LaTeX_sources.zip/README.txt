Compile with python build.py and pdflatex. Keep main.pdf and supplement.pdf in the same directory. Research data and formalization are in the separate research artifact.

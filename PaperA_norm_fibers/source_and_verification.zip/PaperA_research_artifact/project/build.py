"""Build the two PDFs and resolve their reciprocal references."""
from pathlib import Path
import shutil, subprocess, re, json, hashlib

root=Path(__file__).resolve().parent
engine=shutil.which('pdflatex')
if not engine:
    raise SystemExit('pdflatex is required (TeX Live or MiKTeX).')
previous=None
for cycle in range(1,5):
    for name in ('main','supplement'):
        proc=subprocess.run([engine,'-interaction=nonstopmode','-halt-on-error','-file-line-error',name+'.tex'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if proc.returncode:
            print(proc.stdout.decode('utf-8',errors='replace'))
            raise SystemExit(proc.returncode)
    state=hashlib.sha256(b''.join((root/f).read_bytes() for f in ('main.aux','supplement.aux','main.out','supplement.out','supplement.toc'))).hexdigest()
    if state==previous:break
    previous=state
result=[]
for name in ('main','supplement'):
    log=(root/(name+'.log')).read_text(encoding='utf-8',errors='replace')
    errors=[line for line in log.splitlines() if re.search(r'LaTeX Warning:.*(?:undefined|multiply)|Overfull|^!',line)]
    if 'There were undefined references' in log:errors.append('Unresolved references')
    if 'Rerun to get' in log or 'Label(s) may have changed' in log:errors.append('References are not stable')
    result.append(dict(document=name,compilation_cycles=cycle,issues=errors,pdf_bytes=(root/(name+'.pdf')).stat().st_size))
report=root/'verification/editorial_v21_2026-10-29/compilation.json';report.parent.mkdir(parents=True,exist_ok=True)
report.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
if any(x['issues'] for x in result):raise SystemExit('Review the reported compilation issues.')

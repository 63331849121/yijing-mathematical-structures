from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'delivery_manifest.json').read_text(encoding='utf-8'))
for row in manifest['files']:
    assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
data=json.loads((root/'data_deposit/deposit_manifest.json').read_text(encoding='utf-8'))
for row in data['files']:
    assert hashlib.sha256((root/'data_deposit'/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS: all selected public sources and data hashes verified.')

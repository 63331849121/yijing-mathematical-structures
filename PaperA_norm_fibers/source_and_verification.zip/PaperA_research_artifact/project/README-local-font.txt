Local preview font resource

lmmi12.pfb is an unmodified Latin Modern Math Italic font from the installed Latin Modern distribution. It is supplied only to make the desktop PDF driver able to find the physical font used by the supplement. The GUST Font License and LPPL are included in GUST-FONT-LICENSE.txt and LPPL.txt. No font file was modified.

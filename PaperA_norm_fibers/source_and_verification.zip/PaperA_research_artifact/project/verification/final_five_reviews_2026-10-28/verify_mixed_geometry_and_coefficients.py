"""Exact algebraic audit aids for the eight-boundary norm-fiber proof.

The general geometric proof is documented separately. These checks do not
turn finite character samples into a proof of a Weil estimate.
"""
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PROJECT = HERE.parents[1] if (HERE.parents[1]/'main.tex').is_file() else ROOT/'output/pdf/PaperA_restructured_2026-10-26'

def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)

def factors(n):
    ans, p = [], 2
    while p*p <= n:
        if n % p == 0:
            ans.append(p)
            while n % p == 0:
                n //= p
        p = 3 if p == 2 else p+2
    if n > 1:
        ans.append(n)
    return ans

def add(*a):
    return tuple(sum(z) for z in zip(*a))

def scale(n, a):
    return tuple(n*z for z in a)

# All pairs represent constant + coefficient*t. No finite t substitution.
basic = [
    ('P01',1,0,0,0,1), ('P0bi',1,0,0,0,0),
    ('Pi1',-1,0,-1,-1,1), ('Pibi',-1,0,-1,-1,0),
    ('Q10',0,1,1,0,0), ('Qb0',0,1,0,1,0),
    ('Q1i',0,-1,1,0,-1), ('Qbi',0,-1,0,1,-1)]
expected = [(-1,(-1,-1),(-1,0)),(-1,(-1,-1),(0,-1)),
            (-1,(1,1),(0,1)),(-1,(1,1),(1,0)),
            (1,(-1,1),(-1,0)),(1,(-1,1),(0,1)),
            (1,(1,-1),(0,-1)),(1,(1,-1),(1,0))]
valuation_rows = []
for (name,vx,vy,vxp,vxb,vyp), want in zip(basic, expected):
    vw = vxp+vxb-vx
    vg1 = add(scale(vy,(-1,1)),scale(-vx,(1,1)))
    vg2 = add((0,vw),scale(vyp,(-1,1)),scale(-vxp,(1,1)))
    require((vw,vg1,vg2)==want, 'symbolic valuation: '+name)
    valuation_rows.append({'point':name,'w0':vw,'g1_constant_t':vg1,'g2_constant_t':vg2,
                           'actual_first_Kummer_function_w0_inverse':-vw})

# b is nonzero, b != 1 and b^t=b^-1. Use b exponents rather than
# a specific finite-field representation. Zero/infinity remain separate.
zero, infinity = '0','infinity'
one, b, bi = ('b',0),('b',1),('b',-1)
points = [(zero,one),(zero,bi),(infinity,one),(infinity,bi),
          (one,zero),(b,zero),(one,infinity),(b,infinity)]
def frob_coord(x):
    return x if isinstance(x,str) else ('b',-x[1])
def F(point):
    x,y = point
    first = infinity if y==zero else zero if y==infinity else ('b',1+y[1])
    return first,frob_coord(x)
permutation = [points.index(F(p)) for p in points]
cycles, unseen = [], set(range(8))
while unseen:
    j = min(unseen)
    cycle = []
    while j in unseen:
        unseen.remove(j)
        cycle.append(j)
        j = permutation[j]
    require(j==cycle[0], 'boundary Frobenius cycle')
    cycles.append(cycle)
require(sorted(map(len,cycles))==[4,4], 'two closed boundary points of degree four')

rows = []
for s in range(2,13):
    t = 1 << s
    A,B = t+1,t*t+1
    require(math.gcd(A,B)==math.gcd(B,t-1)==1, 'odd coprime orders')
    # Correct Kummer convention: functions (w0^-1,g1,g2).
    v1, v2 = (1,-A,-1),(1,-A,-t)
    delta = tuple(v2[j]-v1[j] for j in range(3))
    z = pow(1-t,-1,B)
    mod = (A,B,B)
    third = tuple(delta[j]*z % mod[j] for j in range(3))
    require(third==(0,0,1), 'third coordinate generated')
    base = tuple((v1[j]+third[j]) % mod[j] for j in range(3))
    require(base==(1,(-A)%B,0), 'coprime first two coordinates')
    m1 = B*pow(B,-1,A)
    m2 = A*(-pow(A*A,-1,B))
    require(tuple(base[j]*m1%mod[j] for j in range(3))==(1,0,0), 'first coordinate generated')
    require(tuple(base[j]*m2%mod[j] for j in range(3))==(0,1,0), 'second coordinate generated')
    primes = factors(A)
    theta2A = math.prod([Fraction(p*p-1,p*p) for p in primes])
    H = math.prod([Fraction(p+2,p+1) for p in primes])
    mean, weighted = Fraction(0),Fraction(0)
    for j in range(A):
        J = [p for p in primes if j%p==0]
        lam = math.prod([Fraction(p-1,p) for p in J])
        mean += lam
        weighted += lam*(1<<len(J))
    require(mean/A==theta2A and weighted/A==theta2A*H, 'exact local coefficient averages')
    rows.append({'s':s,'A':A,'B':B,'inertia_generation':'PASS',
                 'mean_lambda':[theta2A.numerator,theta2A.denominator],
                 'weighted_mean':[weighted.numerator,weighted.denominator*A]})

files = [PROJECT/'main.tex',PROJECT/'supplement.tex',PROJECT/'preamble.tex']
files += sorted((PROJECT/'main').glob('*.tex'))+sorted((PROJECT/'supplement').glob('*.tex'))
snapshot = {'revision':'v13-submission-clarifications','files':{
    p.relative_to(PROJECT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
freeze = HERE/'v13_frozen_input.json'
if not freeze.exists():
    freeze.write_text(json.dumps(snapshot,indent=2),encoding='utf-8')
result = {'status':'PASS','symbolic_valuation_rows':valuation_rows,
          'boundary_Frobenius_cycles':cycles,'boundary_closed_point_degrees':[4,4],
          'Kummer_inertia_convention':'(w0^-1,g1,g2); first two vectors (1,-A,-1),(1,-A,-t)',
          'finite_integer_checks':rows,
          'general_argument':'gcd(A,B)=gcd(t-1,B)=1; the third coordinate and the coprime product of first two factors are generated',
          'general_sheaf_theorem_formalized':False,
          'proves_Weil_estimate_by_computation':False,
          'source_hashes_at_run':snapshot['files']}
(HERE/'mixed_geometry_and_coefficients.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'status':'PASS','symbolic_rows':8,'boundary_cycles':[4,4],
                  'local_average_and_inertia_cases':len(rows),'scope':'algebraic and finite audit aids, not a formalized Weil theorem'}))

"""Generate norm-class supports from reciprocal traces, without old E-coverage witnesses.

Uses only the published polynomial-field models and one V generator in each
field. The old conclusions, coverage masks and individual trace witnesses are
not used to generate the new certificates.
"""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import math
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def primes(n):
    out, p = [], 2
    while p*p <= n:
        if n % p == 0:
            out.append(p)
            while n % p == 0:
                n //= p
        p = 3 if p == 2 else p+2
    if n > 1:
        out.append(n)
    return out


def mul(a,b,f):
    out=0
    while b:
        if b&1: out^=a
        b>>=1
        a<<=1
        if a.bit_length()==f.bit_length(): a^=f
    return out


def power(a,n,f):
    z=1
    while n:
        if n&1:z=mul(z,a,f)
        a=mul(a,a,f)
        n>>=1
    return z


def main():
    started=time.monotonic()
    source=ROOT/'verification/extended_trace_2026-10-26/extended_trace_certificates.json'
    data=json.loads(source.read_text(encoding='utf-8'))
    results=[]
    for old in data['rows']:
        s,t=old['s'],old['t']
        R,A,B=t-1,t+1,t*t+1
        N=t*t-1
        P=primes(A);rad=math.prod(P);kap=A//rad
        f=int(old['E_modulus_hex'],16)
        gen=int(old['primitive_E_generator_hex'],16)
        values=[];logs={};x=1
        for j in range(N):
            assert x not in logs
            values.append(x);logs[x]=j;x=mul(x,gen,f)
        assert x==1 and len(logs)==N
        gu,gv=(int(x,16) for x in old['V_generator_hex'])
        cq=int(old['quadratic_c_hex'],16)
        tau1=mul(gv,cq,f)
        tau_prev,tau=0,tau1
        support=[{} for _ in range(R)]
        for k in range(1,(B+1)//2):
            assert tau!=0
            if math.gcd(k,B)==1:
                j=logs[tau]
                h=(j*pow(4,-1,R))%R
                assert (j-2*A*h)%R==0
                z=((j-2*A*h)//R)%A
                assert z not in support[h]
                support[h][z]={'gamma_exponent':k,'tau_E_hex':hex(tau),'z_exponent':z}
            tau_prev,tau=tau,mul(tau1,tau,f)^tau_prev
        assert sum(len(T) for T in support)==sum(math.gcd(k,B)==1 for k in range(1,(B+1)//2))
        allowed={z:sum(1<<u for u in range(A) if math.gcd(z-2*u,A)==1) for z in range(rad)}
        rows=[];central_count=separator_count=zero_count=0
        for h,T in enumerate(support):
            assert {(-z)%A for z in T}==set(T)
            S=sorted({z%rad for z in T})
            central=next((v for z,v in T.items() if math.gcd(z,A)==1),None)
            separator=None
            if central:
                central_count+=1
                a=central['z_exponent']%rad
                if len(P)==2:
                    separator=next((v for z,v in T.items() if z%rad not in {a,(-a)%rad}),None)
                    assert separator is not None
                    separator_count+=1
            else:
                assert (s,h) in {(3,0),(5,0)}
            mask=0
            for z in S:mask|=allowed[z]
            zeros=[u for u in range(A) if not ((mask>>u)&1)]
            if not central:
                assert (s==3 and not T and len(zeros)==A) or (s==5 and S==[3*j for j in range(1,11)] and len(zeros)==11)
            else:
                assert not zeros
            # Regression only: the new reduction above does not use this expected zero formula.
            for u in range(A):
                c_log=(A*h+R*u)%N
                expected=(s==3 and 9*c_log%N==0) or (s==5 and 11*c_log%N==0)
                assert (u in zeros)==expected
            zero_count+=len(zeros)
            rows.append({'h_exponent':h,'h_E_hex':hex(values[A*h]),
                'support_size':len(T),'radical_support_size':len(S),
                'M_h':2*sum(math.gcd(z,A)==1 for z in T),
                'central_witness':central,'separator_witness':separator,
                'zero_u_exponents':zeros,
                'exceptional_support_exponents':sorted(T) if not central else None})
        result={'s':s,'t':t,'R':R,'A':A,'B':B,'radical_A':rad,'kernel_size':kap,
            'A_prime_divisors':P,'E_modulus_hex':hex(f),'primitive_E_generator_hex':hex(gen),
            'quadratic_b_hex':old['quadratic_b_hex'],'quadratic_c_hex':old['quadratic_c_hex'],
            'V_generator_hex':old['V_generator_hex'],'central_witnesses':central_count,
            'separator_witnesses':separator_count,'zero_nonzero_relative_traces':zero_count,
            'minimum_radical_support_size_for_nonexceptional_h':min(x['radical_support_size'] for x in rows if x['central_witness']),
            'norm_classes':rows}
        results.append(result)
        print(json.dumps({k:result[k] for k in ['s','A','radical_A','central_witnesses','separator_witnesses','minimum_radical_support_size_for_nonexceptional_h','zero_nonzero_relative_traces']}),flush=True)
    output={'status':'GENERATED_EXACT_SUPPORT_CERTIFICATES','rows':results,
        'central_witnesses_all_eight_fields':sum(x['central_witnesses'] for x in results),
        'separator_witnesses':sum(x['separator_witnesses'] for x in results),
        'proof_central_witnesses_excluding_analytic_s8':sum(x['central_witnesses'] for x in results if x['s']!=8),
        'old_coverage_masks_or_old_witnesses_used':False,
        'source_model_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'source_model_scope':'Only field moduli, quadratic defining coefficients and initial generators',
        'elapsed_seconds':round(time.monotonic()-started,3)}
    (HERE/'support_certificates.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print('GENERATED',output['central_witnesses_all_eight_fields'],output['separator_witnesses'],output['elapsed_seconds'],flush=True)


if __name__=='__main__':main()

"""Independent flat-field witness checks and exhaustive cyclic-group checks.

Does not import the producer or any older arithmetic implementation. The
proof verification uses selected central/separating witnesses, not the
producer's full support counts or previous all-E coverage masks.
"""
from pathlib import Path
import hashlib
import json
import math
import time
from functools import lru_cache

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
FLAT={2:0x17b,3:0x1773,4:0x16ac3,5:0x1540b5,6:0x170ceb1,
      7:0x13265ed7,8:0x160862e9d,9:0x1afb8d3f89}


def require(ok,msg):
    if not ok:raise RuntimeError(msg)


def primes(n):
    out=[];p=2
    while p*p<=n:
        if n%p==0:
            out.append(p)
            while n%p==0:n//=p
        p+=1
    if n>1:out.append(n)
    return out


def reduce_poly(x,f):
    while x.bit_length()>=f.bit_length():x^=f<<(x.bit_length()-f.bit_length())
    return x


def rawmul(a,b):
    out=0
    while b:
        v=b&-b
        out^=a<<(v.bit_length()-1)
        b-=v
    return out


def mul(a,b,f):return reduce_poly(rawmul(a,b),f)


def power(a,n,f):
    out=1
    for bit in bin(n)[2:]:
        out=mul(out,out,f)
        if bit=='1':out=mul(out,a,f)
    return out


def pgcd(a,b):
    while b:a,b=b,reduce_poly(a,b)
    return a


@lru_cache(None)
def cyclotomic(n):
    value=(1<<n)|1
    for d in range(1,n):
        if n%d:continue
        divisor=cyclotomic(d);q=0;r=value
        while r.bit_length()>=divisor.bit_length():
            k=r.bit_length()-divisor.bit_length()
            q^=1<<k;r^=divisor<<k
        require(r==0,'exact cyclotomic division')
        value=q
    return value


def q_transform(f):
    n=f.bit_length()-1;out=0
    for i in range(n+1):
        if (f>>i)&1:
            for j in range(i+1):
                if math.comb(i,j)&1:out^=1<<(n+i-2*j)
    return out


def polynomial_checks():
    rows=[]
    for B,js in [(65,[1,3,9]),(1025,[1,3,33])]:
        for j in js:
            H=q_transform(cyclotomic(j))
            require(pgcd(H,cyclotomic(B))==1,'primitive reciprocal-trace exclusion')
            rows.append({'B':B,'trace_order':j,'gcd_with_Phi_B_hex':'0x1'})
    H=q_transform(cyclotomic(11))
    require(reduce_poly(cyclotomic(1025),H)==0,'complete C11 primitive support')
    H33=q_transform(cyclotomic(33))
    g=pgcd(H33,(1<<1025)|1)
    require(g==pgcd(H33,(1<<205)|1) and g.bit_length()-1==20,'order drop to 205')
    require(pgcd(H33,(1<<41)|1)==pgcd(H33,(1<<5)|1)==1,'exact order 205')
    require(q_transform(cyclotomic(1))==cyclotomic(3),'H1=Phi3')
    require(q_transform(cyclotomic(3))==cyclotomic(5),'H3=Phi5')
    return {'status':'PASS','primitive_exclusions':rows,'H11_divides_Phi1025':True,
            'H33_order_drop_gcd_hex':hex(g),'H33_order_drop_degree':20}


def irreducible(f,n):
    require(f.bit_length()-1==n,'modulus degree')
    require(power(2,1<<n,f)==2,'field Frobenius')
    for p in primes(n):require(pgcd(power(2,1<<(n//p),f)^2,f)==1,'irreducibility')


def order(a,n,f):
    require(power(a,n,f)==1,'order divides target')
    for p in primes(n):require(power(a,n//p,f)!=1,'exact order')


def field_embedding(b,bflat,old,flat,n):
    pivots={};x=y=1
    for _ in range(n):
        c,image=x,y
        while c:
            j=c.bit_length()-1
            if j not in pivots:
                pivots[j]=(c,image)
                break
            c^=pivots[j][0];image^=pivots[j][1]
        require(c!=0,'embedding basis independent')
        x,y=mul(x,b,old),mul(y,bflat,flat)
    def transport(v):
        out=0
        while v:
            c,image=pivots[v.bit_length()-1]
            v^=c;out^=image
        return out
    z=transport(2);ans=0
    for bit in bin(old)[2:]:ans=mul(ans,z,flat)^int(bit)
    require(ans==0,'embedding respects defining polynomial')
    return transport


def inverse_subsets(n):
    # Every inversion-stable subset of Z/nZ, represented by a bit mask.
    pairs=[(1<<a)|(1<<(n-a)) for a in range(1,(n+1)//2)]
    for k in range(1<<(len(pairs)+1)):
        mask=k&1
        for j,v in enumerate(pairs):
            if (k>>(j+1))&1:mask|=v
        yield mask


def check_cyclic_case(n,S):
    P=primes(n);rad=math.prod(P);kap=n//rad
    residues={z%rad for z in S}
    zeros={u for u in range(n) if all(math.gcd(z-2*u,n)!=1 for z in S)}
    positive_at_one=any(math.gcd(z,n)==1 for z in S)
    if len(P)==1:
        expected=set(range(n)) if not residues else ({u for u in range(n) if u%P[0]==0} if residues=={0} else set())
        require(zeros==expected,'one-prime zero classification')
    elif len(P)==2 and positive_at_one:
        if len(residues)==2:
            a=next(x for x in residues if math.gcd(x,rad)==1)
            p,q=P
            expected={u for u in range(n) if ((2*u)%p,(2*u)%q) in {(a%p,-a%q),(-a%p,a%q)}}
            require(residues=={a,(-a)%rad},'inverse pair support')
            require(zeros==expected and len(zeros)==2*kap,'sharp mixed-corner exception')
        else:require(not zeros,'three residue central-to-class positivity')
    if len(P)==2:
        for p in P:
            if residues and len(residues)>=2 and all(z%p==0 for z in residues):
                require(zeros=={u for u in range(n) if u%p==0},'single prime-coordinate obstruction')


def abstract_checks():
    rows=[]
    for n in [3,5,7,9,15,21,25,27,33]:
        masks=list(inverse_subsets(n))
        # Quotient-only checks avoid pretending that huge prime-power subsets were enumerated.
        if len(masks)>200000:raise RuntimeError('unexpected exhaustive range')
        neighbors=[sum(1<<z for z in range(n) if math.gcd(z-2*u,n)==1) for u in range(n)]
        P=primes(n);rad=math.prod(P)
        for mask in masks:
            S={z for z in range(n) if (mask>>z)&1}
            # For the largest quotient use bit tests for the direct zero set.
            if n==33:
                zeros={u for u in range(n) if not (mask&neighbors[u])}
                if mask&neighbors[0]:
                    if len(S)==2:
                        require(len(zeros)==2,'two-point sharpness on C33')
                    else:require(not zeros,'inversion-stable C33 reduction')
                for p in P:
                    if len(S)>=2 and all(z%p==0 for z in S):
                        require(zeros=={u for u in range(n) if u%p==0},'C33 prime confinement')
            else:check_cyclic_case(n,S)
        rows.append({'cyclic_order':n,'all_inversion_stable_subsets_checked':len(masks)})
    lifts=0
    for n in [45,63,75,99]:
        rad=math.prod(primes(n))
        for mask in inverse_subsets(rad):
            S={z for z in range(n) if (mask>>(z%rad))&1}
            check_cyclic_case(n,S);lifts+=1
    cases=[(15,{1,14},'dropping the three-residue condition'),
           (15,{1,2,7},'dropping inversion symmetry'),
           (105,{1,104,22,83},'allowing three distinct prime divisors')]
    counter=[]
    for n,S,why in cases:
        zeros=[u for u in range(n) if all(math.gcd(z-2*u,n)!=1 for z in S)]
        require(any(math.gcd(z,n)==1 for z in S) and zeros,'counterexample exists')
        counter.append({'n':n,'support':sorted(S),'zero_u_exponents':zeros,'failed_extension':why})
    return {'status':'PASS','exhaustive_rows':rows,'prime_power_lifts_checked':lifts,
            'counterexamples':counter,'finite_checks_do_not_replace_general_CRT_proof':True}


def flat_witness_checks():
    path=HERE/'support_certificates.json'
    data=json.loads(path.read_text(encoding='utf-8'))
    rows=[]
    for row in data['rows']:
        s,t=row['s'],row['t'];R,A,B=t-1,t+1,t*t+1
        d=A*B;N=t*t-1;flat=FLAT[s];old=int(row['E_modulus_hex'],16)
        rad=math.prod(primes(A));kap=A//rad
        irreducible(flat,4*s);irreducible(old,2*s);order(2,d,flat)
        b=int(row['quadratic_b_hex'],16)
        transport=field_embedding(b,power(2,B,flat),old,flat,2*s)
        require(mul(2,2,flat)^mul(transport(int(row['quadratic_c_hex'],16)),2,flat)^transport(b)==0,'quadratic embedding')
        gE=transport(int(row['primitive_E_generator_hex'],16));order(gE,N,flat)
        gamma=power(2,A,flat);order(gamma,B,flat)
        Ugen=power(gE,R,flat);order(Ugen,A,flat)
        gu,gv=(int(x,16) for x in row['V_generator_hex'])
        require(transport(gu)^mul(transport(gv),2,flat)==gamma,'V initial value')
        central=separator=0
        require(len(row['norm_classes'])==R,'every K* class represented')
        for k,item in enumerate(row['norm_classes']):
            require(item['h_exponent']==k,'K indexing')
            h=transport(int(item['h_E_hex'],16))
            require(h==power(gE,A*k,flat) and power(h,t,flat)==h,'K* representative')
            witnesses=[('central',item['central_witness']),('separator',item['separator_witness'])]
            zcentral=None
            for kind,w in witnesses:
                if w is None:continue
                e=w['gamma_exponent'];require(math.gcd(e,B)==1,'primitive gamma index')
                g=power(gamma,e,flat)
                tau=g^power(gamma,B-e,flat)
                require(tau==transport(int(w['tau_E_hex'],16)),'independent reciprocal trace')
                z=mul(tau,power(h,R-2,flat),flat)
                require(z==power(Ugen,w['z_exponent'],flat),'independent support exponent')
                require(power(z,A,flat)==1,'support lies in U')
                if kind=='central':
                    require(math.gcd(w['z_exponent'],A)==1,'central z has exact order A')
                    a=mul(h,power(1^g,t**4-2,flat),flat)
                    require(a^power(a,t*t,flat)==h,'direct central trace')
                    order(a,d,flat)
                    zcentral=w['z_exponent']%rad;central+=1
                else:
                    require(zcentral is not None,'separator has a central witness')
                    require(w['z_exponent']%rad not in {zcentral,(-zcentral)%rad},'third radical residue')
                    separator+=1
            if item['central_witness'] is None:
                require((s,k) in {(3,0),(5,0)},'only independently handled exceptional classes omitted')
            elif len(primes(A))==2:
                require(item['separator_witness'] is not None,'two-prime class has separation certificate')
        # Independently enumerate only the two exceptional primitive-V supports.
        exceptional=None
        if s in (3,5):
            ulogs={power(Ugen,j,flat):j for j in range(A)}
            S=set()
            for e in range(1,(B+1)//2):
                if math.gcd(e,B)==1:
                    tau=power(gamma,e,flat)^power(gamma,B-e,flat)
                    if tau in ulogs:S.add(ulogs[tau])
            expected=set() if s==3 else {3*j for j in range(1,11)}
            require(S==expected,'exact exceptional primitive support')
            exceptional=sorted(S)
        rows.append({'s':s,'flat_modulus_hex':hex(flat),'central_witnesses_verified':central,
            'separator_witnesses_verified':separator,'all_nonexceptional_K_classes_verified':True,
            'support_cardinality_claims_not_needed_by_verifier':True,
            'exceptional_support_exponents_independently_enumerated':exceptional})
        print('FLAT_WITNESSES',s,central,separator,'PASS',flush=True)
    return {'status':'PASS','rows':rows,'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'central_witnesses':sum(x['central_witnesses_verified'] for x in rows),
        'separator_witnesses':sum(x['separator_witnesses_verified'] for x in rows),
        'primary_proof_central_witnesses':sum(x['central_witnesses_verified'] for x in rows if x['s']!=8),
        'uses_old_E_coverage_masks_or_Theorem_54_truth_as_input':False,
        'every_nonzero_E_trace_follows_from_the_proved_lemma_not_a_coverage_loop':True}


if __name__=='__main__':
    started=time.monotonic()
    result={'abstract_cyclic_checks':abstract_checks(),'independent_flat_witness_checks':flat_witness_checks(),
        'exceptional_polynomial_checks':polynomial_checks(),
        'status':'PASS','external_human_peer_review_claimed':False}
    result['elapsed_seconds']=round(time.monotonic()-started,3)
    result['verifier_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE/'independent_checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print('RADICAL_SUPPORT_ALL_PASS',result['elapsed_seconds'],flush=True)

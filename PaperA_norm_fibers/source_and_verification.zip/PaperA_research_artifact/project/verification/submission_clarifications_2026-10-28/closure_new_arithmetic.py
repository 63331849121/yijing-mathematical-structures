"""Fresh closure audit: reads raw certificates and manuscript tables only.

No imports from producers, historical verifiers, or historical PASS reports.
Witness arithmetic uses E[Z]/(Z^2+cZ+b), not the existing flat-field checker.
"""
from pathlib import Path
from fractions import Fraction
from functools import lru_cache
import hashlib
import json
import math
import re
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent

def check(v, msg):
    if not v:
        raise RuntimeError(msg)

def factors(n):
    ans=[]
    p=2
    while p*p<=n:
        if n%p==0:
            ans.append(p)
            while n%p==0:
                n//=p
        p+=1
    if n>1:
        ans.append(n)
    return ans

def rawmul(a,b):
    z=0
    while a:
        if a&1:
            z^=b
        a>>=1
        b<<=1
    return z

def divmod2(a,b):
    check(b!=0,'nonzero divisor')
    q=0
    while a.bit_length()>=b.bit_length():
        d=a.bit_length()-b.bit_length()
        a^=b<<d
        q^=1<<d
    return q,a

def gcd2(a,b):
    while b:
        a,b=b,divmod2(a,b)[1]
    return a

def epow(a,n,f):
    z=1
    while n:
        if n&1:
            z=divmod2(rawmul(z,a),f)[1]
        a=divmod2(rawmul(a,a),f)[1]
        n//=2
    return z

def irreversible(f,n):
    check(f.bit_length()==n+1,'field modulus degree')
    check(epow(2,1<<n,f)==2,'Rabin Frobenius')
    for p in factors(n):
        check(gcd2(f,epow(2,1<<(n//p),f)^2)==1,'Rabin gcd')

def witness_audit():
    cert_path=ROOT/'verification/radical_support_2026-10-26/support_certificates.json'
    data=json.loads(cert_path.read_text(encoding='utf-8'))
    rows=[]
    check([r['s'] for r in data['rows']]==list(range(2,10)),'s=2..9 all represented')
    for row in data['rows']:
        s=row['s'];t=1<<s;q=t*t;A=t+1;B=t*t+1;d=A*B
        f=int(row['E_modulus_hex'],16)
        irreversible(f,2*s)
        def mul(a,b):
            return divmod2(rawmul(a,b),f)[1]
        def power(a,n):
            return epow(a,n,f)
        def exact_order(a,n):
            check(power(a,n)==1,'E order divides target')
            for p in factors(n):
                check(power(a,n//p)!=1,'E exact order')
        bb=int(row['quadratic_b_hex'],16)
        cc=int(row['quadratic_c_hex'],16)
        check(cc!=0,'quadratic nonzero trace coefficient')
        v=mul(bb,power(cc,q-3));tr=0
        for _ in range(2*s):
            tr^=v;v=mul(v,v)
        check(tr==1,'quadratic irreducibility absolute trace')
        def lmul(x,y):
            vv=mul(x[1],y[1])
            return (mul(x[0],y[0])^mul(vv,bb),mul(x[0],y[1])^mul(x[1],y[0])^mul(vv,cc))
        def lpow(a,n):
            z=(1,0)
            while n:
                if n&1:
                    z=lmul(z,a)
                a=lmul(a,a);n//=2
            return z
        def lorder(a,n):
            check(lpow(a,n)==(1,0),'L order divides target')
            for p in factors(n):
                check(lpow(a,n//p)!=(1,0),'L exact order')
        g=int(row['primitive_E_generator_hex'],16)
        exact_order(g,q-1)
        Ugen=power(g,t-1);Kgen=power(g,A)
        exact_order(Ugen,A);exact_order(Kgen,t-1)
        gamma=tuple(int(z,16) for z in row['V_generator_hex'])
        lorder(gamma,B)
        check(len(row['norm_classes'])==t-1,'all K* representatives')
        rad=math.prod(factors(A));cn=sn=0;omitted=[]
        for j,item in enumerate(row['norm_classes']):
            check(item['h_exponent']==j,'representative indexing')
            h=power(Kgen,j)
            check(h==int(item['h_E_hex'],16) and power(h,t)==h,'K* representative value')
            inverse_h2=power(h,q-3)
            central_residue=None
            for kind,key in [('central','central_witness'),('separator','separator_witness')]:
                w=item[key]
                if w is None:
                    continue
                k=w['gamma_exponent'];e=w['z_exponent']
                check(0<k<B and math.gcd(k,B)==1,'primitive reciprocal trace input')
                check(0<=e<A,'support exponent canonical')
                gam=lpow(gamma,k);gami=lpow(gamma,B-k)
                tau=(gam[0]^gami[0],gam[1]^gami[1])
                check(tau[1]==0 and tau[0]==int(w['tau_E_hex'],16),'reciprocal trace in E')
                z=mul(tau[0],inverse_h2)
                check(z==power(Ugen,e) and power(z,A)==1,'support element equality')
                if kind=='central':
                    check(math.gcd(e,A)==1,'central full A order')
                    den=(gam[0]^1,gam[1])
                    check(den!=(0,0),'construction denominator')
                    a=lmul((h,0),lpow(den,t**4-2))
                    lorder(a,d)
                    at=lpow(a,t*t)
                    check((a[0]^at[0],a[1]^at[1])==(h,0),'direct central relative trace')
                    central_residue=e%rad;cn+=1
                else:
                    check(central_residue is not None,'separator depends on a prior central witness')
                    check(e%rad not in {central_residue,(-central_residue)%rad},'third radical support point')
                    sn+=1
            if item['central_witness'] is None:
                omitted.append(j)
                check((s,j) in {(3,0),(5,0)},'only two exceptional representatives omitted')
            elif len(factors(A))==2:
                check(item['separator_witness'] is not None,'every two-prime class separated')
        rows.append({'s':s,'K_star_representatives':t-1,'central':cn,'separator':sn,'omitted_h_exponents':omitted,'A_prime_divisors':factors(A)})
        print('NEW_TOWER_WITNESSES',s,cn,sn,flush=True)
    return {'raw_certificate_sha256':hashlib.sha256(cert_path.read_bytes()).hexdigest(),'rows':rows,
            'primary_central':sum(r['central'] for r in rows if r['s']!=8),
            'separators':sum(r['separator'] for r in rows),
            'redundant_s8_central':next(r['central'] for r in rows if r['s']==8),
            'uses_support_populations_or_claimed_zeros':False}

@lru_cache(None)
def phi(n):
    z=(1<<n)|1
    for j in range(1,n):
        if n%j==0:
            z,r=divmod2(z,phi(j));check(r==0,'exact cyclotomic quotient')
    return z

def H(n):
    f=phi(n);m=f.bit_length()-1;term=1;ans=0
    for i in range(m+1):
        if (f>>i)&1:
            ans^=term<<(m-i)
        term=rawmul(term,5)
    return ans

def polynomial_audit():
    rows=[]
    for n,js in [(65,[1,3,9]),(1025,[1,3,33])]:
        for j in js:
            check(gcd2(phi(n),H(j))==1,'primitive reciprocal support exclusion')
            rows.append({'B':n,'trace_order':j,'gcd':1})
    check(divmod2(phi(1025),H(11))[1]==0,'H11 divides Phi1025')
    x=gcd2(H(33),(1<<1025)|1)
    check(x==gcd2(H(33),(1<<205)|1) and x.bit_length()-1==20,'all remaining roots lose factor five')
    check(gcd2(H(33),(1<<41)|1)==gcd2(H(33),(1<<5)|1)==1,'remaining exact order205')
    return {'primitive_exclusions':rows,'H11_degree':H(11).bit_length()-1,'Phi1025_degree':phi(1025).bit_length()-1,'remaining_support_gcd_degree':20}

def arithmetic_ranges():
    raw=json.loads((ROOT/'verification/author_runtime/inner_critical_certificates.json').read_text(encoding='utf-8'))
    pc=raw['prime_certificates']
    @lru_cache(None)
    def certified_prime(p):
        if p==2:
            return True
        row=pc[str(p)];ff=row['factors'];v=row['witness']
        check(math.prod(ff)==p-1,'complete Lucas factorization')
        for q in ff:
            check(q<p and certified_prime(q),'recursive Lucas subprime')
        check(pow(v,p-1,p)==1,'Lucas Fermat equality')
        for q in set(ff):
            check(math.gcd(pow(v,(p-1)//q,p)-1,p)==1,'Lucas exact order gcd')
        return True
    bys={row['s']:row for row in raw['certificates']}
    for s,row in bys.items():
        A=(1<<s)+1;B=(1<<(2*s))+1
        check(math.prod(row['A_factors'])==A and math.prod(row['B_factors'])==B,'complete A,B factor products')
        for p in row['A_factors']+row['B_factors']:
            certified_prime(p)
    trace=(ROOT/'main/trace_certificates.tex').read_text(encoding='utf-8')
    table=trace.split(r'\begin{tabular}{rrr|rrr}',1)[1].split(r'\end{tabular}',1)[0]
    sieve=[]
    for line in table.splitlines():
        vals=re.findall(r'\d+',line)
        if len(vals)!=6 or not re.match(r'^\s*\d+&',line):
            continue
        for s,e,C in [tuple(map(int,vals[:3])),tuple(map(int,vals[3:]))]:
            row=bys[s];P=set(row['A_factors']+row['B_factors']);core=set(factors(e))
            check(math.prod(core)==e and core<=P,'squarefree sieve core')
            omitted=P-core;r=len(omitted)
            delta=1-sum((Fraction(1,q) for q in omitted),Fraction(0))
            check(delta>0,'positive delta')
            Lambda=Fraction(1) if r==0 else 2+Fraction(r-1,1)/delta
            c=4*(1<<len(core))*Lambda-2;t=1<<s
            check(c<=C and (t+1)**2>t*C*C,'exact prime-sieve positive margin')
            sieve.append({'s':s,'e':e,'C':C,'exact_C':str(c),'delta':str(delta),'positive_integer_margin':(t+1)**2-t*C*C})
    check(sorted(r['s'] for r in sieve)==[8]+list(range(10,33)),'all 24 sieve parameters')
    cert=(ROOT/'main/certificates.tex').read_text(encoding='utf-8')
    tb=cert.split('The following table lists all 81 bounds;',1)[1].split(r'\end{tabular}',1)[0]
    recorded={}
    for line in tb.splitlines():
        vals=re.findall(r'\d+',line)
        if len(vals)!=6 or not re.match(r'^\s*\d+&',line):
            continue
        vals=list(map(int,vals))
        for s,r in zip(vals[::2],vals[1::2]):
            check(s not in recorded,'unique tail parameter')
            recorded[s]=r
    check(sorted(recorded)==list(range(33,114)),'all 81 tail parameters')
    small=[q for q in range(2,4097) if factors(q)==[q]]
    def omega_upper(n):
        j=0
        for q in small:
            if n%q==0:
                j+=1
                while n%q==0:
                    n//=q
        k=0
        while 4097**(k+1)<=n:
            k+=1
        return j+k
    tail=[]
    for s,recorded_r in sorted(recorded.items()):
        r=omega_upper((1<<s)+1)+omega_upper((1<<(2*s))+1)
        check(r<=recorded_r and s>=4+2*recorded_r,'tail omega and threshold')
        tail.append({'s':s,'fresh_r':r,'printed_r':recorded_r,'threshold_margin':s-4-2*recorded_r})
    odd_primes=[q for q in range(3,256,2) if factors(q)==[q]]
    check(len(odd_primes)==53 and 256**53<4096**8*math.prod(odd_primes),'uniform small-prime product bound')
    # 4W(d) < 2^(113/8)t^(3/8); s>=114 makes this <sqrt(t).
    check(114>113,'uniform exponent threshold')
    return {'Lucas_primes_verified':certified_prime.cache_info().currsize,'sieve_rows':sorted(sieve,key=lambda r:r['s']),'tail_rows':tail,'uniform_bound_small_prime_count':53,'uniform_tail_start':114,'uniform_tail_reason':'4W(d)<2^(113/8)t^(3/8)<sqrt(t) for s>=114'}

def support_spot_checks():
    rows=[]
    for n in [3,5,9,15,21]:
        rad=math.prod(factors(n));P=factors(n)
        pair=[{j,n-j} for j in range(1,(n+1)//2)]
        for mask in range(1<<(len(pair)+1)):
            T={0} if mask&1 else set()
            for j,z in enumerate(pair):
                if mask>>(j+1)&1:
                    T|=z
            zeros={u for u in range(n) if all(math.gcd(z-2*u,n)!=1 for z in T)}
            S={z%rad for z in T}
            if len(P)==1:
                wanted=set(range(n)) if not T else ({u for u in range(n) if u%P[0]==0} if S=={0} else set())
                check(zeros==wanted,'one-prime support conclusion')
            elif any(math.gcd(z,n)==1 for z in T):
                if len(S)==2:
                    check(len(zeros)==2*n//rad,'two-point mixed-corner count')
                else:
                    check(not zeros,'three-residue positivity')
        rows.append({'n':n,'inverse_stable_subsets':1<<(len(pair)+1)})
    return {'rows':rows,'role':'finite sanity checks only; general CRT argument reviewed separately'}

started=time.monotonic()
result={'assumption':'Theorem 5.1 is valid; the algebraic construction part is checked directly at witnesses',
        'witnesses':witness_audit(),'polynomials':polynomial_audit(),'integer_ranges':arithmetic_ranges(),
        'support_checks':support_spot_checks(),'new_implementation':True,'historical_PASS_reports_used':False,
        'does_not_replace_general_proofs':True}
result['elapsed_seconds']=round(time.monotonic()-started,3)
(OUT/'closure_new_arithmetic_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':'all explicitly specified checks completed','seconds':result['elapsed_seconds'],'central':result['witnesses']['primary_central'],'separator':result['witnesses']['separators'],'sieve_rows':len(result['integer_ranges']['sieve_rows']),'tail_rows':len(result['integer_ranges']['tail_rows'])},ensure_ascii=False))

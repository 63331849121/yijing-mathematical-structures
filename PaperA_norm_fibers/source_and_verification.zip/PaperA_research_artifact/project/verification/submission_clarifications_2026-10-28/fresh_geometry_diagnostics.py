"""New finite diagnostics for Theorem 5.1, without importing old arithmetic.

Exact counts and rational inequalities are rigorous finite checks. FFT character
sums are explicitly numerical diagnostics, not certificates of the general bound.
The primitive binary moduli are searched afresh by Rabin and exact order tests.
"""
from pathlib import Path
from fractions import Fraction
import hashlib
import json
import math
import time
import numpy as np

OUT = Path(__file__).resolve().parent

def factors(n):
    out = []
    p = 2
    while p*p <= n:
        if n % p == 0:
            out.append(p)
            while n % p == 0:
                n //= p
        p += 1
    if n > 1:
        out.append(n)
    return out

def remainder(a, b):
    while a.bit_length() >= b.bit_length():
        a ^= b << (a.bit_length()-b.bit_length())
    return a

def pgcd(a, b):
    while b:
        a, b = b, remainder(a, b)
    return a

def mul(a, b, poly):
    n = poly.bit_length()-1
    high = 1 << n
    out = 0
    while b:
        if b & 1:
            out ^= a
        b >>= 1
        a <<= 1
        if a & high:
            a ^= poly
    return out

def power(a, n, poly):
    out = 1
    while n:
        if n & 1:
            out = mul(out, a, poly)
        n >>= 1
        if n:
            a = mul(a, a, poly)
    return out

def primitive_modulus(n):
    primes = factors((1 << n)-1)
    targets = {n//p for p in factors(n)}
    for tail in range(1, 1 << n, 2):
        poly = (1 << n) | tail
        z = 2
        ok = True
        for i in range(1, n+1):
            z = mul(z, z, poly)
            if i in targets and pgcd(z ^ 2, poly) != 1:
                ok = False
                break
        if not ok or z != 2:
            continue
        if all(power(2, ((1 << n)-1)//p, poly) != 1 for p in primes):
            return poly, primes
    raise RuntimeError('No primitive modulus found')

def phi(n):
    out = n
    for p in factors(n):
        out = out // p * (p-1)
    return out

def check(s):
    start = time.monotonic()
    t = 1 << s
    A, B = t+1, t*t+1
    d, n = A*B, 4*s
    q = 1 << n
    poly, q_primes = primitive_modulus(n)
    g = 2
    assert power(g, q-1, poly) == 1
    assert all(power(g, (q-1)//p, poly) != 1 for p in q_primes)
    Cgen = power(g, t-1, poly)
    Ugen = power(g, (q-1)//A, poly)
    Vgen = power(g, (q-1)//B, poly)
    Kgen = power(g, d, poly)
    assert power(Cgen, d, poly) == 1
    assert all(power(Cgen, d//p, poly) != 1 for p in factors(d))

    # Compute the relative trace on a binary basis, then use linearity while
    # enumerating the entire C, independently of the reciprocal parametrization.
    trace_basis = []
    for j in range(n):
        b = 1 << j
        z = b
        for _ in range(2*s):
            z = mul(z, z, poly)
        trace_basis.append(b ^ z)
    def trace(a):
        out = 0
        while a:
            low = a & -a
            out ^= trace_basis[low.bit_length()-1]
            a ^= low
        return out
    direct_q, direct_m = {}, {}
    a = 1
    for k in range(d):
        c = trace(a)
        direct_q[c] = direct_q.get(c, 0)+1
        if math.gcd(k, d) == 1:
            direct_m[c] = direct_m.get(c, 0)+1
        a = mul(a, Cgen, poly)
    assert a == 1 and direct_q[0] == A and direct_m.get(0, 0) == 0

    us = [power(Ugen, j, poly) for j in range(A)]
    ulog = {v: j for j, v in enumerate(us)}
    vs = [power(Vgen, j, poly) for j in range(B)]
    theta = Fraction(phi(d), d)
    W = 1 << len(factors(d))
    seen = set()
    max_fft = 0.0
    max_fft_where = None
    zeros = []
    total_points = 0
    tested_pairs = 0
    c0 = 1
    for h in range(t-1):
        assert power(c0, t, poly) == c0
        invc02 = power(mul(c0, c0, poly), q-2, poly)
        grid = np.zeros((A, B), dtype=np.int64)
        parameter_points = []
        for j in range(1, B):
            tau = vs[j] ^ vs[B-j]
            w = mul(tau, invc02, poly)
            if w in ulog:
                i = ulog[w]
                grid[i, j] += 1
                parameter_points.append((i, j))
        population = len(parameter_points)
        assert population == direct_q.get(c0, 0)
        S = np.fft.fft2(grid)
        assert abs(S[0, 0]-population) < 1e-8
        S[0, 0] = 0
        freq = tuple(int(v) for v in np.unravel_index(np.argmax(np.abs(S)), S.shape))
        amplitude = float(abs(S[freq]))
        if amplitude > max_fft:
            max_fft, max_fft_where = amplitude, {'K_exponent': h, 'character_indices': freq}
        assert amplitude <= 4*math.sqrt(t)+1e-8
        tested_pairs += A*B-1
        for j, u in enumerate(us):
            c = mul(c0, u, poly)
            assert c not in seen
            seen.add(c)
            # Squaring u shifts the U coordinate by exactly 2j.
            m = sum(math.gcd(i-2*j, A) == 1 and math.gcd(k, B) == 1
                    for i, k in parameter_points)
            Q = direct_q.get(c, 0)
            M = direct_m.get(c, 0)
            assert Q == population and m == M
            assert (Q-(t+1))**2 <= 4*t
            assert (Fraction(M)-theta*Q)**2 <= 16*theta**2*(W-1)**2*t
            assert (Fraction(M)-theta*(t+1))**2 <= theta**2*(4*W-2)**2*t
            if M == 0:
                zeros.append(hex(c))
            total_points += Q
        c0 = mul(c0, Kgen, poly)
    assert len(seen) == t*t-1 and c0 == 1
    assert total_points == d-A
    return {'s': s, 't': t, 'modulus': hex(poly),
            'primitive_modulus_selected_by_fresh_search': True,
            'exact_C_elements_enumerated': d,
            'all_nonzero_E_traces_exactly_checked': len(seen),
            'exact_parametrization_and_count_bounds': 'PASS',
            'zero_trace_values_observed': zeros,
            'character_pairs_numerically_checked_over_K': tested_pairs,
            'max_nontrivial_character_sum_numerical': max_fft,
            'max_location': max_fft_where,
            'four_sqrt_t': 4*math.sqrt(t),
            'FFT_is_numerical_not_a_proof_certificate': True,
            'elapsed_seconds': round(time.monotonic()-start, 3)}

if __name__ == '__main__':
    rows = []
    for s in range(2, 6):
        result = check(s)
        rows.append(result)
        print('NEW_GEOMETRY_DIAGNOSTIC', s, result['modulus'],
              result['all_nonzero_E_traces_exactly_checked'],
              result['max_nontrivial_character_sum_numerical'], 'PASS', flush=True)
    report = {'scope': 'Finite independent diagnostics only, s=2..5; does not prove the all-parameter theorem',
              'uses_old_certificates_or_arithmetic_modules': False,
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'rows': rows, 'status': 'PASS'}
    (OUT / 'fresh_geometry_diagnostics.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

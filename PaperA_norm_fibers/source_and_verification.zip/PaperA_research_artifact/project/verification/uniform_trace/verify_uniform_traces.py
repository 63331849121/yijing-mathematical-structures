"""Exact checks for the new nonzero-relative-trace results (standard library).

Run without -O. This verifies finite certificates and independent small-field
identities; the uniform geometric character bound is proved in the manuscript.
Hex integers encode binary polynomials, least significant bit constant.
"""
from pathlib import Path
from functools import lru_cache
from fractions import Fraction
from itertools import combinations
from collections import Counter
import importlib.util
import json
import math
import hashlib
import time

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('exact_fields', ROOT/'verification/independent_exact_audit.py')
F = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(F)


def pmul(a, b):
    result = 0
    while b:
        if b & 1:
            result ^= a
        a <<= 1
        b >>= 1
    return result


def pdivmod(a, b):
    assert b
    q = 0
    while a and a.bit_length() >= b.bit_length():
        j = a.bit_length()-b.bit_length()
        q ^= 1 << j
        a ^= b << j
    return q, a


def xpow(n, modulus):
    a, result = 2, 1
    while n:
        if n & 1:
            result = pdivmod(pmul(result, a), modulus)[1]
        n >>= 1
        a = pdivmod(pmul(a, a), modulus)[1]
    return result


def pgcd(a, b):
    while b:
        a, b = b, pdivmod(a, b)[1]
    return a


def bezout(a, b):
    u0, u1, v0, v1 = 1, 0, 0, 1
    aa, bb = a, b
    while bb:
        q, r = pdivmod(aa, bb)
        aa, bb = bb, r
        u0, u1 = u1, u0 ^ pmul(q, u1)
        v0, v1 = v1, v0 ^ pmul(q, v1)
    assert pmul(u0, a) ^ pmul(v0, b) == aa
    return aa, u0, v0


@lru_cache(None)
def cyclotomic(n):
    result = (1 << n) ^ 1
    for d in range(1, n):
        if n % d == 0:
            result, r = pdivmod(result, cyclotomic(d))
            assert r == 0
    return result


def reciprocal_trace_polynomial(A):
    phi = cyclotomic(A)
    degree = phi.bit_length()-1
    result, term = 0, 1
    for j in range(degree+1):
        if (phi >> j) & 1:
            result ^= term << (degree-j)
        term = pmul(term, 5)  # (X^2+1)^j
    assert result.bit_length()-1 == 2*degree
    assert result & 1
    return result


def squarefree_divisors(primes):
    for r in range(len(primes)+1):
        for subset in combinations(primes, r):
            yield math.prod(subset), (-1)**r


def finite_trace_one_counts():
    expected = {2:8, 3:0, 4:16, 5:0, 6:24, 7:84, 8:288, 9:216}
    rows = []
    for s in range(2, 10):
        t = 1 << s
        A, B = t+1, t*t+1
        H = reciprocal_trace_polynomial(A)
        terms, count = [], 0
        for e, mu in squarefree_divisors(F.factors(B)):
            g = pgcd(H, xpow(B//e, H) ^ 1)
            degree = g.bit_length()-1
            count += mu*degree
            terms.append(dict(e=e, mu=mu, gcd_degree=degree, gcd_hex=hex(g)))
        assert count == expected[s]
        row = dict(s=s, A=A, B=B, H_hex=hex(H), H_degree=H.bit_length()-1,
                   Delta=count, mobius_terms=terms)
        if s in (3, 5):
            phiB = cyclotomic(B)
            g, u, v = bezout(H, phiB)
            assert g == 1
            row['primitive_coprimality_certificate'] = dict(
                phiB_hex=hex(phiB), u_hex=hex(u), v_hex=hex(v),
                identity='u*H + v*Phi_B = 1 in F_2[X]')
        if s == 3:
            assert pgcd(H, xpow(65, H) ^ 1) == 1
        if s == 5:
            G = pgcd(H, xpow(1025, H) ^ 1)
            assert G == pgcd(H, xpow(205, H) ^ 1)
            assert G.bit_length()-1 == 20
            assert pgcd(H, xpow(41, H) ^ 1) == 1
            assert pgcd(H, xpow(5, H) ^ 1) == 1
            row['exceptional_order_drop'] = dict(
                gcd_hex=hex(G), degree=20, all_candidate_gamma_orders=205,
                required_order=1025,
                explanation='All primitive-tau candidates lose the extra factor 5 in the order of gamma.')
        rows.append(row)
        print('EXACT_TRACE_ONE', s, count, flush=True)
    return rows


def full_factorization(n):
    result = []
    remaining = n
    for p in F.factors(n):
        exponent = 0
        while remaining % p == 0:
            remaining //= p
            exponent += 1
        assert exponent and F.prime(p) and p < 2**64
        result.append([p, exponent])
    assert remaining == 1
    assert math.prod(p**e for p, e in result) == n
    return result


def finite_sieve_certificates():
    rows = []
    for s in [8] + list(range(10, 33)):
        t = 1 << s
        A, B = t+1, t*t+1
        af, bf = full_factorization(A), full_factorization(B)
        original = json.loads((ROOT/'verification/author_runtime/inner_critical_certificates.json').read_text(encoding='utf-8'))
        archived = next(row for row in original['certificates'] if row['s']==s)
        assert sorted(p for p, ex in af for _ in range(ex)) == sorted(archived['A_factors'])
        assert sorted(p for p, ex in bf for _ in range(ex)) == sorted(archived['B_factors'])
        all_primes = sorted({p for p, exponent in af+bf})
        # A core of 1 or 3 suffices for the claimed finite interval.
        choices = [1, 3] if 3 in all_primes else [1]
        options = []
        for core in choices:
            omitted = [p for p in all_primes if core % p != 0]
            delta = 1-sum((Fraction(1, p) for p in omitted), Fraction(0))
            if delta <= 0:
                continue
            W = 1 if core == 1 else 2
            Lambda = Fraction(len(omitted)-1, 1)/delta + 2
            C = 4*W*Lambda-2
            options.append((C, core, delta, Lambda, omitted))
        C, core, delta, Lambda, omitted = min(options)
        upper = math.ceil(C)
        assert A*A > t*C*C
        assert A*A > t*upper*upper
        row = dict(s=s, core=core, A_factorization=af, B_factorization=bf,
                   omitted_primes=omitted, delta=str(delta), Lambda=str(Lambda),
                   C=str(C), C_integer_upper=upper, A_squared=A*A,
                   t_times_C_upper_squared=t*upper*upper,
                   positivity='PASS')
        rows.append(row)
        print('UNIFORM_SIEVE', s, 'core', core, 'ceil_C', upper, 'PASS', flush=True)
    return rows


def theta(n):
    return math.prod([Fraction(p-1, p) for p in F.factors(n)])


def all_slices_small_fields():
    rows = []
    for line in F.TABLE.splitlines()[:5]:
        ss, ff, bb, ee = line.split()
        s, f, b = int(ss), int(ff, 16), int(bb, 16)
        n, t = 2*s, 1 << s
        A, B = t+1, t*t+1
        d = A*B
        w = F.power(b, int(ee), f, n)
        quadratic_c = 1 ^ b ^ w
        assert F.irreducible(f, n)
        assert F.epow((0, 1), d, b, quadratic_c, f, n) == (1, 0)
        assert all(F.epow((0, 1), d//p, b, quadratic_c, f, n) != (1, 0)
                   for p in F.factors(d))
        values, a = [], (1, 0)
        for j in range(d):
            values.append(a[0] | (a[1] << n))
            a = (F.mul(b, a[1], f, n), a[0] ^ F.mul(quadratic_c, a[1], f, n))
        assert a == (1, 0) and len(set(values)) == d
        Q, M = Counter(), Counter()
        for j, key in enumerate(values):
            relative = key ^ values[j*t*t % d]
            if relative >= 1 << n:
                continue
            if F.power(relative, t, f, n) != relative:
                continue
            Q[relative] += 1
            M[relative] += math.gcd(j, d) == 1
        assert Q[0] == A and M[0] == 0
        nonzero = sorted(k for k in Q if k)
        assert len(nonzero) == t-1
        QQ, MM = Counter(), Counter()
        # Independent reciprocal-trace parameterization: enumerate only V.
        inverse_four = pow(4, -1, t-1)
        for k in range(1, B):
            tau = values[k*A] ^ values[((B-k) % B)*A]
            assert 0 < tau < 1 << n
            norm_tau = F.power(tau, A, f, n)
            c = F.power(norm_tau, inverse_four, f, n)
            assert c in nonzero
            c_inverse = F.power(c, (1 << n)-2, f, n)
            primitive_argument = F.mul(tau, F.mul(c_inverse, c_inverse, f, n), f, n)
            assert F.power(primitive_argument, A, f, n) == 1
            QQ[c] += 1
            MM[c] += math.gcd(k, B) == 1 and all(
                F.power(primitive_argument, A//p, f, n) != 1 for p in F.factors(A))
        assert all(Q[c] == QQ[c] and M[c] == MM[c] for c in nonzero)
        def absolute_trace_K(x):
            result = 0
            for _ in range(s):
                result ^= x
                x = F.mul(x, x, f, n)
            assert result in (0, 1)
            return result
        details = []
        th = theta(d)
        W = 1 << len(F.factors(d))
        for c in nonzero:
            lam = F.power(c, (-4) % (t-1), f, n)
            kloosterman = 0
            for z in nonzero:
                z_inverse = F.power(z, (1 << n)-2, f, n)
                argument = z ^ F.mul(lam, z_inverse, f, n)
                kloosterman += (-1)**absolute_trace_K(argument)
            assert Q[c] == A+kloosterman
            assert (Q[c]-A)**2 <= 4*t
            assert (Fraction(M[c])-th*Q[c])**2 <= 16*th*th*(W-1)**2*t
            assert (Fraction(M[c])-th*A)**2 <= th*th*(4*W-2)**2*t
            details.append(dict(c_hex=hex(c), unfiltered=Q[c], primitive=M[c],
                                binary_Kloosterman=kloosterman))
        rows.append(dict(s=s, t=t, base_modulus_hex=hex(f), quadratic_b_hex=hex(b),
                         quadratic_c_hex=hex(quadratic_c), all_nonzero_slices=details,
                         trace_zero_primitive=M[0], Delta=M[1],
                         aggregate=sum(M[c] for c in nonzero),
                         independent_parameterization='PASS',
                         Kloosterman_identity_and_error_bounds='PASS'))
        print('ALL_NONZERO_SLICES', s, 'count', t-1, 'PASS', flush=True)
    return rows


def main():
    started = time.monotonic()
    from finite_slice_witnesses import verify_all_slices
    small_rows = all_slices_small_fields()
    output = dict(status='PASS', finite_certificates_only=True,
        infinite_range='s>=33 uses the proved integer bounds; s=8,10..32 use the prime sieve; s=2..9 have 1010 witnesses and two polynomial emptiness certificates.',
        geometric_proof='main/trace_slices.tex; finite checks do not substitute for this proof.',
        exact_trace_one=finite_trace_one_counts(),
        prime_sieve_certificates=finite_sieve_certificates(),
        small_field_slices=small_rows,
        complete_finite_slice_certificates=verify_all_slices(F, small_rows))
    output['elapsed_seconds'] = round(time.monotonic()-started, 3)
    output['arithmetic_module_sha256'] = hashlib.sha256((ROOT/'verification/independent_exact_audit.py').read_bytes()).hexdigest()
    Path(__file__).with_name('uniform_trace_checks.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    print('ALL_UNIFORM_TRACE_CHECKS_PASS',output['elapsed_seconds'],flush=True)

if __name__=='__main__':
    main()

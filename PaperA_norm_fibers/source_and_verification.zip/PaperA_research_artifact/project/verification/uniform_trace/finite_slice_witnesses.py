"""Exact positivity certificates for every nonexceptional trace at s=2..9.

The trace recurrence supplies counts; independent direct powering of each
archived witness supplies the positivity certificates used in the proof.
"""
import math


def verify_all_slices(F, small_rows):
    rows = []
    old = {row['s']: {x['c_hex']: (x['unfiltered'], x['primitive'])
                    for x in row['all_nonzero_slices']} for row in small_rows}
    expected_min = {2:4, 3:0, 4:12, 5:0, 6:24, 7:40, 8:228, 9:200}
    expected_delta = {2:8, 3:0, 4:16, 5:0, 6:24, 7:84, 8:288, 9:216}
    for line in F.TABLE.splitlines()[:8]:
        ss, ff, bb, ee = line.split()
        s, f, b = int(ss), int(ff, 16), int(bb, 16)
        n, t = 2*s, 1 << s
        A, B, N = t+1, t*t+1, t*t-1
        d = A*B
        cquad = 1 ^ b ^ F.power(b, int(ee), f, n)
        assert F.irreducible(f, n) and cquad
        inverse_cquad = F.power(cquad, (1 << n)-2, f, n)
        assert F.trace(F.mul(b, F.mul(inverse_cquad, inverse_cquad, f, n), f, n), n, f) == 1
        primes_E = F.factors(N)
        generator_E = next(z for z in range(2, 100)
                           if all(F.power(z, N//p, f, n) != 1 for p in primes_E))
        logs, powers, z = [-1]*(N+1), [], 1
        for j in range(N):
            assert logs[z] == -1
            logs[z] = j
            powers.append(z)
            z = F.mul(z, generator_E, f, n)
        assert z == 1 and len(powers) == N
        gamma = F.epow((0, 1), A, b, cquad, f, n)
        primes_B = F.factors(B)
        assert F.epow(gamma, B, b, cquad, f, n) == (1, 0)
        assert all(F.epow(gamma, B//p, b, cquad, f, n) != (1, 0) for p in primes_B)
        inverse_gamma = F.epow(gamma, B-1, b, cquad, f, n)
        assert gamma[1] == inverse_gamma[1]
        tau1 = gamma[0] ^ inverse_gamma[0]
        previous, tau = 0, tau1
        Q = {A*j: 0 for j in range(t-1)}
        M = Q.copy()
        witnesses = {}
        inverse_four = pow(4, -1, t-1)
        for k in range(1, (B-1)//2+1):
            j = logs[tau]
            assert j >= 0
            log_c = A*((j*inverse_four) % (t-1))
            log_w = (j-2*log_c) % N
            assert log_w % (t-1) == 0
            Q[log_c] += 2
            if math.gcd(k, B) == 1 and math.gcd(log_w//(t-1), A) == 1:
                M[log_c] += 2
                witnesses.setdefault(log_c, k)
            previous, tau = tau, F.mul(tau, tau1, f, n) ^ previous
        zero_slices = sorted(powers[log_c] for log_c, count in M.items() if count == 0)
        assert zero_slices == ([1] if s in (3, 5) else [])
        assert min(M.values()) == expected_min[s] and M[0] == expected_delta[s]
        details = []
        prime_d = F.factors(d)
        for log_c in sorted(Q):
            c = powers[log_c]
            assert F.power(c, t, f, n) == c
            if s in old:
                assert old[s][hex(c)] == (Q[log_c], M[log_c])
            item = dict(c_hex=hex(c), Q=Q[log_c], M=M[log_c])
            if M[log_c]:
                k = witnesses[log_c]
                g = F.epow(gamma, k, b, cquad, f, n)
                # Conjugation sends Z to Z+cquad, and inverts elements of V.
                conjugate_g = (g[0] ^ F.mul(cquad, g[1], f, n), g[1])
                assert F.emul(g, conjugate_g, b, cquad, f, n) == (1, 0)
                tr = g[0] ^ conjugate_g[0]
                multiplier = F.mul(c, F.power(tr, (1 << n)-2, f, n), f, n)
                a = (F.mul(multiplier, conjugate_g[0] ^ 1, f, n),
                     F.mul(multiplier, conjugate_g[1], f, n))
                assert F.epow(a, t*t, b, cquad, f, n) == (a[0] ^ c, a[1])
                assert F.epow(a, d, b, cquad, f, n) == (1, 0)
                assert all(F.epow(a, d//p, b, cquad, f, n) != (1, 0) for p in prime_d)
                item['witness_gamma_exponent'] = k
                item['full_order_witness_a_hex'] = [hex(x) for x in a]
                item['direct_trace_norm_and_order_check'] = 'PASS'
            details.append(item)
        rows.append(dict(s=s, t=t, E_modulus_hex=hex(f), quadratic_b_hex=hex(b),
                         quadratic_c_hex=hex(cquad), primitive_E_generator_hex=hex(generator_E),
                         A_prime_divisors=F.factors(A), B_prime_divisors=primes_B,
                         V_generator_hex=[hex(x) for x in gamma],
                         minimum_M_c=min(M.values()), zero_slices_hex=[hex(x) for x in zero_slices],
                         Delta=M[0], total_slices=t-1, full_order_witnesses=len(witnesses),
                         slices=details))
        print('ALL_FINITE_SLICE_WITNESSES', s, 'minimum', min(M.values()),
              'witnesses', len(witnesses), 'PASS', flush=True)
    assert sum(r['full_order_witnesses'] for r in rows) == 1010
    return rows

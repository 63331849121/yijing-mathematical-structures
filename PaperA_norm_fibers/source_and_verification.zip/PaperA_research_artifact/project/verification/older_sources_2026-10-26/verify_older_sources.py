"""Exact checks for Ozbudak05 bounds and Hachenberger15 aggregate counts.

No claim to re-enumerate the whole quartic field in this stage. The geometric
aggregate comparison uses the independently enumerated norm-kernel data from
the CSTC26 stage. The binary BCH example is separately counted in F_(2^s).
"""
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def primes(n):
    out, p = [], 2
    while p*p <= n:
        if n % p == 0:
            out.append(p)
            while n % p == 0:
                n //= p
        p = 3 if p == 2 else p+2
    if n > 1:
        out.append(n)
    return out


def phi(n):
    ans = n
    for p in primes(n):
        ans = ans//p*(p-1)
    return ans


def squarefree_cores(n):
    P = primes(n)
    for mask in range(1 << len(P)):
        u = math.prod(p for i, p in enumerate(P) if (mask >> i) & 1)
        v = math.prod(p for i, p in enumerate(P) if not ((mask >> i) & 1))
        yield u, v


def oz_rhs(Q, genus, pole_degree):
    # Q=q^r=t^2, q^(km)=t^4=Q^2 and q^(km/2)=Q.
    return (Fraction(Q-1, Q)+
            Fraction(2*genus*Q+Q*(2+pole_degree)-2, Q*(Q*Q-1)))


def oz_bounds():
    rows = []
    for s in range(2, 10):
        t, Q = 1 << s, 1 << (2*s)
        R, d, total = t-1, (t+1)*(t*t+1), t**4-1
        direct, lift, two_coordinate = [], [], []
        for u, v in squarefree_cores(d):
            z = u*R
            g_exact = (Q-1)*(z-1)//2
            require((Q-1)*(z-1) % 2 == 0, 'integral exact AS genus')
            printed = oz_rhs(Q, (Q-1)*(z-1), z)
            exact = oz_rhs(Q, g_exact, z)
            coordinate2 = oz_rhs(Q, g_exact, 2*z)
            require(exact > 1 and printed > exact and coordinate2 > exact,
                    'all direct and two-coordinate thresholds exceed one')
            require(Fraction(phi(v), v) <= 1 < exact,
                    'every legal direct core fails')
            direct.append((printed, exact))
            two_coordinate.append(coordinate2)
        for u, v in squarefree_cores(total):
            z = u*R
            g_exact = (Q-1)*(z-1)//2
            g_printed = (Q-1)*(u*(R-1)//2+u-1)
            printed = oz_rhs(Q, g_printed, z)
            exact = oz_rhs(Q, g_exact, z)
            require(g_printed >= g_exact and printed >= exact > 1,
                    'primitive lift fails even with exact genus')
            require(Fraction(phi(v), v) <= 1 < exact,
                    'every legal primitive-lift core fails')
            lift.append((printed, exact))
        require(math.gcd(R, d) == 1 and d % R != 0,
                'the quotient-divisibility premise is not satisfied by a=t-1')
        rows.append({'s': s, 't': t,
            'direct_core_splits_checked': len(direct),
            'primitive_lift_core_splits_checked': len(lift),
            'min_direct_printed_rhs': str(min(x[0] for x in direct)),
            'min_direct_exact_genus_rhs': str(min(x[1] for x in direct)),
            'min_primitive_lift_printed_rhs': str(min(x[0] for x in lift)),
            'min_primitive_lift_exact_genus_rhs': str(min(x[1] for x in lift)),
            'min_two_K_coordinate_exact_genus_rhs': str(min(two_coordinate)),
            'left_side_theta_v_at_most': 1})
    return rows


def ha_aggregate():
    path = ROOT/'verification/cstc26_fulltext_2026-10-26/independent_specialization_checks.json'
    earlier = json.loads(path.read_text(encoding='utf-8'))
    published_PN = {4: 96, 8: 1512, 16: 30720, 32: 465000}
    published_G = {4: 96, 8: 1440, 16: 30720, 32: 456000}
    rows = []
    for row in earlier['fields']:
        t = row['t']
        R, A, B = t-1, t+1, t*t+1
        primitive_normal = phi(R)*row['full_order_elements_with_trace_outside_K']
        nonnormal = row['full_order_elements_with_Kvalued_trace']
        bound = phi(t**4-1)-phi(R)*phi(B)
        require(phi(t**4-1) == phi(R)*phi(A)*phi(B), 'coprime totient factorization')
        require(primitive_normal >= bound and nonnormal <= phi(B),
                'aggregate theorem and equivalent missing-trace inequality')
        if t in published_PN:
            require(primitive_normal == published_PN[t] and bound == published_G[t],
                    'published Table 1 matches independent enumeration')
        if t in (8, 32):
            require(primitive_normal > 0 and row['M_1'] == 0,
                    'aggregate positivity coexists with an empty fixed slice')
        rows.append({'t': t, 'PN4_from_independent_norm_kernel_data': primitive_normal,
                     'Ha15_Theorem_1_lower_bound': bound,
                     'published_Table_1_PN4': published_PN.get(t),
                     'sum_M_c_over_K_star': nonnormal,
                     'upper_bound_phi_B': phi(B), 'M_1': row['M_1']})
    return {'input': str(path), 'input_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'fresh_quartic_enumeration_claimed': False, 'rows': rows}


def rem(a, b):
    while a.bit_length() >= b.bit_length():
        a ^= b << (a.bit_length()-b.bit_length())
    return a


def mul(a, b, f):
    z = 0
    while b:
        if b & 1:
            z ^= a
        b >>= 1
        a <<= 1
    return rem(z, f)


def power(a, e, f):
    z = 1
    while e:
        if e & 1:
            z = mul(z, a, f)
        a = mul(a, a, f)
        e >>= 1
    return z


def pgcd(a, b):
    while b:
        a, b = b, rem(a, b)
    return a


def bch_example_comparison():
    deltas = {2: 8, 3: 0, 4: 16, 5: 0, 6: 24, 7: 84, 8: 288, 9: 216}
    rows = []
    for s, delta in deltas.items():
        t = 1 << s
        f = next(f for f in range(t+1, 2*t, 2)
                 if power(2, t, f) == 2 and
                 all(pgcd(power(2, 1 << (s//p), f) ^ 2, f) == 1 for p in primes(s)))

        def trace(a):
            z = 0
            for _ in range(s):
                z ^= a
                a = mul(a, a, f)
            require(z in (0, 1), 'binary trace')
            return z

        good, poles = 0, 0
        for a in range(1, t):
            if any(power(a, (t-1)//p, f) == 1 for p in primes(t-1)):
                continue
            D = power(a, 2, f) ^ a ^ 1
            if D == 0:
                poles += 1
                continue
            f1 = mul(a, power(D, t-2, f), f)
            numerator = 0
            for j in range(2, 7):
                numerator ^= power(a, j, f)
            f2 = mul(numerator, power(power(D, 4, f), t-2, f), f)
            good += int(trace(f1) == trace(f2) == 1)
        require((good == 0) == (s in (2, 3, 5)), 'published base-field example in checked range')
        rows.append({'s': s, 'base_field_size': t, 'base_field_modulus_hex': hex(f),
                     'primitive_base_field_elements_satisfying_Oz05_Example_5_1': good,
                     'primitive_base_field_elements_at_a_pole': poles,
                     'manuscript_Delta_t_in_quartic_field': delta,
                     'counts_identical': good == delta})
    require(rows[0]['manuscript_Delta_t_in_quartic_field'] > 0 and
            rows[0]['primitive_base_field_elements_satisfying_Oz05_Example_5_1'] == 0,
            'the two existence predicates are not identical for s>=2')
    return {'scope': 'Comparison of distinct counting problems; does not disprove a future new one-way construction',
            'rows': rows}


if __name__ == '__main__':
    result = {'Oz05': oz_bounds(), 'Ha15': ha_aggregate(),
              'shared_exception_labels_checked': bch_example_comparison(),
              'general_core_exclusion_is_proved_symbolically_in_report': True,
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE/'independent_checks.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS',
        'Oz05_direct_core_splits': sum(x['direct_core_splits_checked'] for x in result['Oz05']),
        'Oz05_primitive_lift_core_splits': sum(x['primitive_lift_core_splits_checked'] for x in result['Oz05']),
        'Ha15_published_table_rows_matched': 4, 'BCH_small_fields_checked': 8}))

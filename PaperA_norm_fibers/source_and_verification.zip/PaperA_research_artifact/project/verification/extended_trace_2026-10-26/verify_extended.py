"""Independent verification of all E-valued relative-trace certificates.

Arithmetic uses a single binary polynomial field of degree 4s, unlike the
producer's logarithms and quadratic-tower recurrence.  Coverage is checked
by gcds for every residue, not by rotating the producer's bit mask.
"""
from pathlib import Path
from collections import Counter
from fractions import Fraction
from functools import lru_cache
import hashlib
import json
import math
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def require(test, description):
    if not test:
        raise RuntimeError(description)


def raw(a, b):
    out = 0
    while b:
        bit = b & -b
        out ^= a << (bit.bit_length()-1)
        b ^= bit
    return out


def divide(a, b):
    require(b != 0, 'division by zero')
    q = 0
    while a.bit_length() >= b.bit_length():
        k = a.bit_length()-b.bit_length()
        q ^= 1 << k
        a ^= b << k
    return q, a


def mul(a, b, f):
    return divide(raw(a, b), f)[1]


def power(a, n, f):
    out = 1
    for bit in bin(n)[2:]:
        out = mul(out, out, f)
        if bit == '1':
            out = mul(out, a, f)
    return out


def pgcd(a, b):
    while b:
        a, b = b, divide(a, b)[1]
    return a


def xgcd(a, b):
    aa, bb, u, v = a, b, 1, 0
    u2, v2 = 0, 1
    while bb:
        q, rem = divide(aa, bb)
        aa, bb = bb, rem
        u, u2 = u2, u ^ raw(q, u2)
        v, v2 = v2, v ^ raw(q, v2)
    require(raw(u, a) ^ raw(v, b) == aa, 'Bezout identity')
    return aa, u, v


def primes(n):
    out, p = [], 2
    while p*p <= n:
        if n % p == 0:
            out.append(p)
            while n % p == 0:
                n //= p
        p = 3 if p == 2 else p+2
    if n > 1:
        out.append(n)
    return out


def irreducible(f):
    n = f.bit_length()-1
    require(power(2, 1 << n, f) == 2, 'field Frobenius')
    for p in primes(n):
        require(pgcd(power(2, 1 << (n//p), f) ^ 2, f) == 1,
                'field irreducibility')


def orbit_polynomial(b, c, f, n):
    coefficients = [1]
    bb, cc = b, c
    for _ in range(n):
        nxt = [0]*(len(coefficients)+2)
        for i, x in enumerate(coefficients):
            nxt[i] ^= mul(x, bb, f)
            nxt[i+1] ^= mul(x, cc, f)
            nxt[i+2] ^= x
        coefficients = nxt
        bb, cc = mul(bb, bb, f), mul(cc, cc, f)
    require(set(coefficients) <= {0, 1}, 'binary orbit polynomial')
    return sum(x << i for i, x in enumerate(coefficients))


def isomorphism(b, bflat, old, flat, n):
    pivots, x, y = {}, 1, 1
    for i in range(n):
        column, image = x, y
        while column:
            j = column.bit_length()-1
            if j not in pivots:
                pivots[j] = column, image
                break
            other, other_image = pivots[j]
            column ^= other
            image ^= other_image
        require(column != 0, 'full-degree E basis')
        x, y = mul(x, b, old), mul(y, bflat, flat)

    def transport(value):
        result = 0
        while value:
            column, image = pivots[value.bit_length()-1]
            value ^= column
            result ^= image
        return result

    z = transport(2)
    acc = 0
    for bit in bin(old)[2:]:
        acc = mul(acc, z, flat) ^ int(bit)
    require(acc == 0, 'transport is a field map')
    for i in range(n):
        require(transport(1 << i) == power(z, i, flat), 'basis field map')
    return transport


@lru_cache(None)
def cyclotomic(n):
    value = (1 << n) | 1
    for d in range(1, n):
        if n % d == 0:
            value, rem = divide(value, cyclotomic(d))
            require(rem == 0, 'cyclotomic division')
    return value


def q_transform(poly):
    degree = poly.bit_length()-1
    value = 0
    for i in range(degree+1):
        if (poly >> i) & 1:
            j = i
            while True:
                value ^= 1 << (degree-i+2*j)
                if j == 0:
                    break
                j = (j-1) & i
    return value


def empty_certificates():
    out = []
    for A, B in [(9, 65), (33, 1025)]:
        H, P = q_transform(cyclotomic(A)), cyclotomic(B)
        g, u, v = xgcd(H, P)
        require(g == 1, 'primitive reciprocal-trace obstruction')
        item = dict(A=A, B=B, H_hex=hex(H), Phi_B_hex=hex(P),
                    u_hex=hex(u), v_hex=hex(v),
                    identity='u*H + v*Phi_B = 1 over F2')
        if A == 9:
            require(pgcd(H, (1 << 65) | 1) == 1, 'strong s=3 obstruction')
        else:
            G = pgcd(H, (1 << 1025) | 1)
            require(G == pgcd(H, (1 << 205) | 1), 's=5 order drop')
            require(G.bit_length()-1 == 20, 's=5 candidate count')
            require(pgcd(H, (1 << 41) | 1) == 1, 'exclude order 41')
            require(pgcd(H, (1 << 5) | 1) == 1, 'exclude order 5')
            item['order_drop_gcd_hex'] = hex(G)
        out.append(item)
    return out


def direct_counts(s, t, d, A, N, z, flat):
    values, x = [], 1
    degree = flat.bit_length()-1
    for _ in range(d):
        values.append(x)
        x <<= 1
        if x >> degree:
            x ^= flat
    require(x == 1 and len(set(values)) == d, 'direct subgroup cycle')
    Q, M = Counter(), Counter()
    for j, x in enumerate(values):
        trace = x ^ values[(j*t*t) % d]
        Q[trace] += 1
        if math.gcd(j, d) == 1:
            M[trace] += 1
    require(Q[0] == A and M[0] == 0, 'zero trace slice')
    E, x = [], 1
    for _ in range(N):
        E.append(x)
        x = mul(x, z, flat)
    require(x == 1 and len(set(E)) == N, 'direct E cycle')
    theta = Fraction(math.prod(p-1 for p in primes(d)),
                     math.prod(primes(d)))
    W = 1 << len(primes(d))
    empty = []
    phase_example = None
    norm1 = Counter()
    for j, c in enumerate(E):
        require(c in Q, 'all nonzero unfiltered E traces occur')
        h = E[(j*A*(t//2)) % N]
        require(Q[c] == Q[h], 'unfiltered norm-class identity')
        require((Q[c]-A)**2 <= 4*t, 'Hasse bound')
        require((Fraction(M[c])-theta*Q[c])**2 <= 16*theta**2*(W-1)**2*t,
                'exact-center error')
        require((Fraction(M[c])-theta*A)**2 <= theta**2*(4*W-2)**2*t,
                'linear-center error')
        expected_zero = (s == 3 and (9*j) % N == 0) or (s == 5 and (11*j) % N == 0)
        require((M[c] == 0) == expected_zero, 'direct empty-slice classification')
        if M[c] == 0:
            empty.append(hex(c))
        if M[c] != M[h] and phase_example is None:
            phase_example = dict(c_flat_hex=hex(c), h_flat_hex=hex(h), M_c=M[c], M_h=M[h])
        if (A*j) % N == 0:
            norm1[M[c]] += 1
    phi_d = d
    for p in primes(d):
        phi_d = phi_d//p*(p-1)
    require(sum(M.values()) == phi_d, 'total primitive population')
    return dict(s=s, subgroup_elements=d, nonzero_E_slices=N,
                empty_slices=empty, minimum_M=min(M[c] for c in E),
                primitive_total=phi_d, error_bounds='PASS',
                full_order_not_invariant_under_unit_scaling=phase_example,
                norm_one_M_distribution=dict(norm1))


def main():
    started = time.monotonic()
    data = json.loads((HERE/'extended_trace_certificates.json').read_text(encoding='utf-8'))
    rows, direct, total_direct_witnesses = [], [], 0
    for row in data['rows']:
        s, t = row['s'], row['t']
        n, r, A, B, N = 2*s, t-1, t+1, t*t+1, t*t-1
        d = A*B
        old = int(row['E_modulus_hex'], 16)
        b, cq = int(row['quadratic_b_hex'], 16), int(row['quadratic_c_hex'], 16)
        irreducible(old)
        flat = orbit_polynomial(b, cq, old, n)
        require(flat.bit_length()-1 == 4*s, 'flat extension degree')
        irreducible(flat)
        require(power(2, d, flat) == 1, 'subgroup generator')
        require(all(power(2, d//p, flat) != 1 for p in primes(d)), 'exact subgroup order')
        transfer = isomorphism(b, power(2, B, flat), old, flat, n)
        require(mul(2, 2, flat) ^ mul(transfer(cq), 2, flat) ^ transfer(b) == 0,
                'quadratic tower map')
        z = transfer(int(row['primitive_E_generator_hex'], 16))
        require(power(z, N, flat) == 1, 'E generator norm')
        require(all(power(z, N//p, flat) != 1 for p in primes(N)), 'primitive E generator')
        gamma = power(2, A, flat)
        require(power(gamma, B, flat) == 1, 'V generator')
        require(all(power(gamma, B//p, flat) != 1 for p in primes(B)), 'primitive V generator')
        gu, gv = (int(x, 16) for x in row['V_generator_hex'])
        require(transfer(gu) ^ mul(transfer(gv), 2, flat) == gamma, 'V seed transport')
        zeros, covered, witness_count = [], 0, 0
        require(len(row['coverage_certificates']) == r, 'all radial classes')
        for h, family in enumerate(row['coverage_certificates']):
            require(family['residue'] == h, 'radial indexing')
            mask = 0
            for witness in family['witnesses']:
                k, j = witness['k'], witness['tau_log']
                require(math.gcd(k, B) == 1, 'primitive gamma exponent')
                g, gi = power(gamma, k, flat), power(gamma, B-k, flat)
                tau = g ^ gi
                require(tau == transfer(int(witness['tau_hex'], 16)), 'independent tau field value')
                require(power(z, j, flat) == tau, 'independent tau logarithm')
                require((j-2*h) % r == 0, 'norm class')
                mask_new = 0
                for m in range(A):
                    if math.gcd(((j-2*(h+r*m))//r) % A, A) == 1:
                        mask_new |= 1 << m
                added = mask_new & ~mask
                require(added != 0, 'nonredundant family witness')
                first = (added & -added).bit_length()-1
                log_c = h+r*first
                c = power(z, log_c, flat)
                a = mul(power(z, (log_c-j) % N, flat), 1 ^ gi, flat)
                require(a ^ power(a, t*t, flat) == c, 'constructed witness trace')
                require(power(a, d, flat) == 1, 'constructed witness norm')
                require(all(power(a, d//p, flat) != 1 for p in primes(d)),
                        'constructed witness exact order')
                total_direct_witnesses += 1
                witness_count += 1
                mask |= mask_new
            require(mask == int(family['mask_hex'], 16), 'independent gcd coverage mask')
            for m in range(A):
                exponent = h+r*m
                expected_zero = (s == 3 and (9*exponent) % N == 0) or (s == 5 and (11*exponent) % N == 0)
                require(((mask >> m) & 1) == (not expected_zero), 'every E trace classified')
                if expected_zero:
                    zeros.append(exponent)
                else:
                    covered += 1
        rows.append(dict(s=s, flat_modulus_hex=hex(flat), nonzero_E_slices=N,
                         covered_nonempty=covered, exceptional_empty=len(zeros),
                         coverage_family_witnesses=witness_count,
                         all_residues_checked=True))
        if s <= 6:
            direct.append(direct_counts(s, t, d, A, N, z, flat))
        print('INDEPENDENT_EXTENDED',s,'covered',covered,'empty',len(zeros),
              'family_witnesses',witness_count,'PASS',flush=True)
    empty = empty_certificates()
    old_checks = json.loads((ROOT/'verification/uniform_trace/uniform_trace_checks.json').read_text(encoding='utf-8'))
    sieve_rows = []
    for row in old_checks['prime_sieve_certificates']:
        delta = 1-sum((Fraction(1,p) for p in row['omitted_primes']),Fraction())
        Lambda = 2+Fraction(len(row['omitted_primes'])-1,1)/delta
        W = 1 << len(primes(row['core']))
        C = 4*W*Lambda-2
        t = 1 << row['s']
        require(delta>0 and delta==Fraction(row['delta']), 'retained sieve delta')
        require(C<=row['C_integer_upper'], 'retained sieve constant')
        require((t+1)**2>t*row['C_integer_upper']**2, 'retained sieve positivity')
        sieve_rows.append(dict(s=row['s'],core=row['core'],C_upper=row['C_integer_upper']))
    output = dict(status='PASS',all_nonzero_E_slices=sum(x['nonzero_E_slices'] for x in rows),
                  certified_nonempty=sum(x['covered_nonempty'] for x in rows),
                  exceptional_empty=sum(x['exceptional_empty'] for x in rows),
                  direct_full_order_witnesses=total_direct_witnesses,
                  coverage_rows=rows, independent_direct_counts=direct,
                  emptiness_polynomial_certificates=empty,
                  analytic_extension='All-c phase reduction and same prime sieve; existing s>=10 and s=8 ranges apply unchanged.',
                  retained_prime_sieve_rows=sieve_rows,
                  source_certificate_sha256=hashlib.sha256((HERE/'extended_trace_certificates.json').read_bytes()).hexdigest(),
                  verifier_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  elapsed_seconds=round(time.monotonic()-started,3))
    (HERE/'independent_checks.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print('EXTENDED_ALL_PASS',output['all_nonzero_E_slices'],output['direct_full_order_witnesses'],
          output['elapsed_seconds'],flush=True)


if __name__ == '__main__':
    main()

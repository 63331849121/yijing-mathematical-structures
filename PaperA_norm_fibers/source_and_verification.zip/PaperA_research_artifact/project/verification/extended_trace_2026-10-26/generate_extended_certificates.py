"""Generate exact witness families for all E-valued nonzero relative traces."""
from pathlib import Path
import importlib.util
import json
import math
import time

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('old_arithmetic', ROOT/'verification/independent_exact_audit.py')
F = importlib.util.module_from_spec(spec)
spec.loader.exec_module(F)


def rotate(mask, shift, width):
    shift %= width
    return ((mask << shift) | (mask >> (width-shift))) & ((1 << width)-1)


def main():
    started = time.monotonic()
    old = json.loads((ROOT/'verification/uniform_trace/uniform_trace_checks.json').read_text(encoding='utf-8'))
    rows = []
    for seed in old['complete_finite_slice_certificates']:
        s = seed['s']
        t, n = 1 << s, 2*s
        r, A, B, N = t-1, t+1, t*t+1, t*t-1
        f = int(seed['E_modulus_hex'], 16)
        generator = int(seed['primitive_E_generator_hex'], 16)
        b = int(seed['quadratic_b_hex'], 16)
        cq = int(seed['quadratic_c_hex'], 16)
        gamma = tuple(int(x, 16) for x in seed['V_generator_hex'])
        inverse_gamma = (gamma[0] ^ F.mul(cq, gamma[1], f, n), gamma[1])
        assert F.emul(gamma, inverse_gamma, b, cq, f, n) == (1, 0)
        tau1 = gamma[0] ^ inverse_gamma[0]
        powers, logs, z = [], [-1]*(N+1), 1
        for j in range(N):
            assert logs[z] == -1
            logs[z] = j
            powers.append(z)
            z = F.mul(z, generator, f, n)
        assert z == 1
        unit_mask = sum(1 << j for j in range(A) if math.gcd(j, A) == 1)
        full = (1 << A)-1
        masks, witnesses = [0]*r, [[] for _ in range(r)]
        unfilled = r
        inv2r, inv2A = pow(2, -1, r), pow(2, -1, A)
        previous, tau = 0, tau1
        log_tau1 = logs[tau1]
        last_k = 0
        for k in range(1, (B-1)//2+1):
            j = logs[tau]
            assert j >= 0
            if math.gcd(k, B) == 1:
                h = (j*inv2r) % r
                w_exp = ((j-2*h)//r) % A
                shift = (w_exp*inv2A) % A
                added = rotate(unit_mask, shift, A)
                if added & ~masks[h]:
                    witnesses[h].append(dict(k=k, tau_hex=hex(tau), tau_log=j, shift=shift))
                    masks[h] |= added
                    if masks[h] == full:
                        unfilled -= 1
            last_k = k
            if unfilled == 0:
                break
            previous, tau = tau, powers[(j+log_tau1) % N] ^ previous
        zeros = []
        for h, mask in enumerate(masks):
            for m in range(A):
                if not ((mask >> m) & 1):
                    exponent = h+r*m
                    c = powers[exponent]
                    zeros.append(dict(c_hex=hex(c), log_c=exponent,
                                      norm_hex=hex(powers[exponent*A % N])))
        row = dict(s=s, t=t, E_modulus_hex=seed['E_modulus_hex'],
                   quadratic_b_hex=seed['quadratic_b_hex'], quadratic_c_hex=seed['quadratic_c_hex'],
                   primitive_E_generator_hex=seed['primitive_E_generator_hex'],
                   V_generator_hex=seed['V_generator_hex'],
                   all_nonzero_E_slices=N, primitive_gamma_recurrence_until=last_k,
                   primitive_gamma_half_range=(B-1)//2,
                   covered_slices=N-len(zeros), zero_slices=zeros,
                   empty_norms=sorted(set(z['norm_hex'] for z in zeros)),
                   coverage_witness_count=sum(map(len, witnesses)),
                   coverage_certificates=[dict(residue=h, mask_hex=hex(masks[h]), witnesses=ws)
                                          for h,ws in enumerate(witnesses)])
        rows.append(row)
        print('EXTENDED',s,'zeros',len(zeros),'norms',row['empty_norms'],
              'certificate_gammas',row['coverage_witness_count'],'last_k',last_k,flush=True)
    output = dict(status='GENERATED_EXACT_CERTIFICATES',rows=rows,
                  elapsed_seconds=round(time.monotonic()-started,3))
    Path(__file__).with_name('extended_trace_certificates.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print('ELAPSED',output['elapsed_seconds'],flush=True)


if __name__ == '__main__':
    main()

"""Rerun the two stored certificates used by the shortened existence proof.

Uses the existing deterministic certificate checker. No new search,
all-field enumeration or independent new character estimate is performed.
"""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
RUNTIME = PROJECT / 'verification/author_runtime'
sys.path.insert(0, str(RUNTIME))
from verify_inner_mixed import check_double, check_primes


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert __debug__, 'Do not run certificate checks with -O.'
    old_path = RUNTIME / 'inner_critical_certificates.json'
    double_path = RUNTIME / 'inner_double_order_certificates.json'
    old = json.loads(old_path.read_text(encoding='utf-8'))
    double = json.loads(double_path.read_text(encoding='utf-8'))
    original = {row['s']: row for row in old['certificates']}
    prove = check_primes(old['prime_certificates'])
    rows = []
    for row in double['certificates']:
        if row['s'] not in (3, 5):
            continue
        assert row['w_exponent'] == 4 and int(row['c_hex'], 16) != 1
        checked = check_double(row, original[row['s']], prove)
        checked.update({key: row[key] for key in ('E_modulus_hex', 'b_hex', 'w_hex', 'c_hex', 'w_exponent')})
        rows.append(checked)
    assert [row['s'] for row in rows] == [3, 5]
    report = {'status': 'PASS', 'checked_parameters': [3, 5],
        'role': 'Off-trace-one endpoint certificates in the shortened proof of Theorem 4.4',
        'new_search_or_full_enumeration': False,
        'checker': 'Existing check_double, with recursively certified prime factors',
        'input_hashes': {p.name: sha(p) for p in (old_path, double_path)},
        'checker_hashes': {name: sha(RUNTIME / name) for name in ('verify_inner_mixed.py', 'verify_inner_critical.py')},
        'rows': rows}
    (HERE / 'two_exceptional_certificates.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS', 'parameters': [3, 5], 'off_trace_one': True}))


if __name__ == '__main__':
    main()

"""Exact checks for the published CSTC26 counting specialization.

Independent binary-polynomial arithmetic; no imported producer/verifier code.
Enumerates the norm kernel, not the whole ambient multiplicative group.
The all-parameter criterion obstruction is proved in the report/manuscript;
the finite checks here verify the arithmetic and the nontrivial count identity.
"""
from array import array
from collections import Counter
from fractions import Fraction
from pathlib import Path
import hashlib
import itertools
import json
import math
import time

HERE = Path(__file__).resolve().parent
MODULI = {2: 0x17b, 3: 0x1773, 4: 0x16ac3, 5: 0x1540b5, 6: 0x170ceb1}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def primes(n):
    ans, p = [], 2
    while p*p <= n:
        if n % p == 0:
            ans.append(p)
            while n % p == 0:
                n //= p
        p = 3 if p == 2 else p+2
    if n > 1:
        ans.append(n)
    return ans


def phi(n):
    v = n
    for p in primes(n):
        v = v//p*(p-1)
    return v


def rem(a, b):
    while a.bit_length() >= b.bit_length():
        a ^= b << (a.bit_length()-b.bit_length())
    return a


def mul(a, b, f):
    v = 0
    while b:
        if b & 1:
            v ^= a
        b >>= 1
        a <<= 1
        if a.bit_length() == f.bit_length():
            a ^= f
    return v


def power(a, n, f):
    v = 1
    while n:
        if n & 1:
            v = mul(v, a, f)
        a = mul(a, a, f)
        n >>= 1
    return v


def pgcd(a, b):
    while b:
        a, b = b, rem(a, b)
    return a


def field_identity(s, f):
    t = 1 << s
    q, A, B, R = t*t, t+1, t*t+1, t-1
    d = A*B
    n = 4*s
    require(f.bit_length()-1 == n, 'modulus degree')
    require(power(2, 1 << n, f) == 2, 'field Frobenius')
    for p in primes(n):
        require(pgcd(power(2, 1 << (n//p), f) ^ 2, f) == 1,
                'modulus irreducibility')
    require(power(2, d, f) == 1, 'norm-kernel generator order divides d')
    for p in primes(d):
        require(power(2, d//p, f) != 1, 'norm-kernel generator exact order')

    powers, a = array('I', [0])*d, 1
    for j in range(d):
        powers[j] = a
        a <<= 1
        if a.bit_length() == f.bit_length():
            a ^= f
    require(a == 1 and len(set(powers)) == d, 'complete norm-kernel cycle')
    pairs = Counter()
    Mc = Counter()
    Qc = Counter()
    trace_one_unfiltered, actual_rational_checks = 0, 0
    Kvalued, outsideK = 0, 0
    for j, a in enumerate(powers):
        aq = powers[(j*q) % d]
        c = a ^ aq
        Qc[c] += 1
        if c == 1:
            trace_one_unfiltered += 1
        if math.gcd(j, d) != 1:
            continue
        require(c != 0, 'primitive norm-kernel element not in E')
        b = powers[-j % d] ^ powers[(-j*q) % d]
        require(b != 0, 'nonzero trace implies nonzero inverse trace')
        w = powers[-j*B % d]
        require(d//math.gcd(j*B, d) == A, 'inverse norm has exact order A')
        require(mul(c, w, f) == b, 'inverse trace equals c times inverse norm')
        require(mul(a ^ c, a, f) == powers[j*B % d], 'quadratic norm relation')

        # This evaluates F_c(a)=a/(a+c), not just its order formula.
        inv_denominator = powers[-j*q % d]
        Fc = mul(a, inv_denominator, f)
        exponent = j*(1-q) % d
        require(Fc == powers[exponent], 'F_c(a) is the conjugate ratio')
        require(d//math.gcd(exponent, d) == B, 'F_c(a) has exact order B')
        require(Fc ^ powers[(exponent*q) % d] != 0,
                'F_c(a) is normal over E')
        require(Fc ^ powers[(exponent*t) % d] ^ powers[(exponent*q) % d]
                ^ powers[(exponent*q*t) % d] != 0,
                'F_c(a) has nonzero K-trace')
        ck = power(c, t, f)
        absolute_relative = a ^ powers[j*t % d] ^ aq ^ powers[j*q*t % d]
        require(absolute_relative == c ^ ck, 'K-trace is c+c^t')
        if c == ck:
            require(absolute_relative == 0, 'K-valued relative trace gives zero K-trace')
            Kvalued += 1
        else:
            require(absolute_relative != 0, 'outside K gives nonzero K-trace')
            outsideK += 1
        actual_rational_checks += 1
        pairs[c, b] += 1
        Mc[c] += 1
    require(sum(Mc.values()) == phi(d), 'all full-order elements counted')
    require(set(pairs.values()) == {2}, 'nonempty two-trace counts are exactly two')
    aggregated = Counter()
    for (c, b), value in pairs.items():
        aggregated[c] += value
    require(len(Qc) == q, 'unfiltered traces cover all of E')
    zero_slices = 0
    for c in Qc:
        require(power(c, q, f) == c, 'relative trace belongs to E')
        require(aggregated[c] == Mc[c], 'sum of specialized CSTC26 counts equals M_c')
        if c:
            zero_expected = ((s == 3 and power(c, 9, f) == 1) or
                             (s == 5 and power(c, 11, f) == 1))
            require((aggregated[c] == 0) == zero_expected,
                    'complete nonzero relative-trace exception classification')
            zero_slices += int(aggregated[c] == 0)
    return {'s': s, 't': t, 'modulus_hex': hex(f),
            'norm_kernel_elements_enumerated': d,
            'full_order_elements_and_rational_checks': actual_rational_checks,
            'nonempty_two_trace_pairs': len(pairs), 'two_trace_pair_count': 2,
            'nonzero_trace_populations_checked': q-1,
            'zero_nonzero_trace_slices': zero_slices,
            'full_order_elements_with_Kvalued_trace': Kvalued,
            'full_order_elements_with_trace_outside_K': outsideK,
            'M_1': Mc[1], 'Q_1': trace_one_unfiltered,
            'specialized_CSTC26_sum_M_1': sum(v for (c, b), v in pairs.items() if c == 1)}


def sieve_factor(q, P1, P2, core1, core2, keep_second_additive,
                 first_trace_atom_counted=True):
    # Theorem 3.3 as printed lists the first X-1 atom although L=1.
    # Also record the more favorable interpretation dropping that automatic atom.
    omitted = [p for p in P1 if p not in core1]+[p for p in P2 if p not in core2]
    additive_omissions = int(first_trace_atom_counted)+int(not keep_second_additive)
    ell = len(omitted)+additive_omissions
    delta = Fraction(1)-sum((Fraction(1, p) for p in omitted), Fraction(0))
    delta -= Fraction(additive_omissions, q)
    if delta <= 0:
        return None
    Delta = 2+Fraction(ell-1, 1)/delta
    require(Delta >= 1, 'legal sieve Delta is at least one')
    return Delta*(1 << (len(core1)+len(core2)+int(keep_second_additive)))


def subsets(P):
    return [tuple(x for i, x in enumerate(P) if (mask >> i) & 1)
            for mask in range(1 << len(P))]


def criterion_tables():
    out = []
    for t in [8, 32, 64]:
        q, A, B, R = t*t, t+1, t*t+1, t-1
        d, N = A*B, 5
        r2 = q-1
        Wd, WB = 1 << len(primes(d)), 1 << len(primes(B))
        lhs = Fraction(1, q)
        full_rhs = 2*N*R*r2*Wd*WB
        best = {}
        for mode, first_atom in [('printed_first_atom', True), ('automatic_first_atom_removed', False)]:
            values = []
            for c1, c2, ha in itertools.product(subsets(primes(d)), subsets(primes(B)), [False, True]):
                v = sieve_factor(q, primes(d), primes(B), c1, c2, ha, first_atom)
                if v is not None:
                    values.append((N*R*r2*v, c1, c2, ha))
            v, c1, c2, ha = min(values)
            require(lhs < v, 'even best numerical sieve fails')
            best[mode] = {'minimum_rhs': str(v), 'multiplicative_core_primes': [c1, c2],
                          'second_additive_atom_retained': ha}
        # F=X+c is only a conditional denominator-one interpretation of Definition 1.1.
        polynomial_rhs = 4*R*R*Wd*Wd
        require(lhs < full_rhs and lhs < polynomial_rhs, 'displayed criteria fail')
        out.append({'t': t, 'q': q, 'm': 2, 'r1': R, 'r2': r2, 'N': N,
                    'W_d': Wd, 'W_B': WB, 'lhs': str(lhs),
                    'Corollary_3_2_rhs_legal_rational_function': full_rhs,
                    'Corollary_3_2_rhs_conditional_linear_polynomial': polynomial_rhs,
                    'best_Theorem_3_3_sieves': best})
    return out


if __name__ == '__main__':
    start = time.time()
    results = {'method': 'independent exact binary polynomial arithmetic and rational sieve arithmetic',
               'fields': [], 'criterion_tables': criterion_tables()}
    for s, f in MODULI.items():
        r = field_identity(s, f)
        results['fields'].append(r)
        print(json.dumps(r), flush=True)
    results['elapsed_seconds'] = round(time.time()-start, 3)
    results['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE/'independent_specialization_checks.json').write_text(json.dumps(results, indent=2)+'\n', encoding='utf-8')
    print('All specialization and criterion checks passed.', flush=True)

import sys, math, time, re
from pathlib import Path
from fractions import Fraction
sys.stdout.reconfigure(encoding='utf-8')

def mul(a,b,f,n):
    z=0
    while b:
        if b&1:z^=a
        b>>=1;a<<=1
        if a>>n:a^=f
    return z
def power(a,e,f,n):
    z=1
    while e:
        if e&1:z=mul(z,a,f,n)
        e>>=1;a=mul(a,a,f,n)
    return z
def pmod(a,b):
    while a.bit_length()>=b.bit_length():a^=b<<(a.bit_length()-b.bit_length())
    return a
def pgcd(a,b):
    while b:a,b=b,pmod(a,b)
    return a
def smallprimes(n):
    return [p for p in range(2,n+1) if all(p%q for q in range(2,math.isqrt(p)+1))]
def prime(n):
    if n<2:return False
    for p in (2,3,5,7,11,13,17,19,23,29,31,37):
        if n%p==0:return n==p
    if n>=1<<64:return False
    d=n-1;s=0
    while d%2==0:d//=2;s+=1
    for a in (2,325,9375,28178,450775,9780504,1795265022):
        if a%n==0:continue
        x=pow(a,d,n)
        if x in (1,n-1):continue
        for _ in range(s-1):
            x=x*x%n
            if x==n-1:break
        else:return False
    return True
def rho(n):
    if n%2==0:return 2
    for c in range(1,100):
        y=2;r=1;g=1
        while g==1:
            x=y
            for _ in range(r):y=(y*y+c)%n
            k=0
            while k<r and g==1:
                ys=y;q=1
                for _ in range(min(128,r-k)):
                    y=(y*y+c)%n;q=q*abs(x-y)%n
                g=math.gcd(q,n);k+=128
            r*=2
        if g==n:
            g=1
            while g==1:
                ys=(ys*ys+c)%n;g=math.gcd(abs(x-ys),n)
        if g!=n:return g
    raise ArithmeticError('rho did not split')
def factors(n):
    out=[]
    def rec(v):
        if v==1:return
        if prime(v):out.append(v);return
        g=rho(v);rec(g);rec(v//g)
    for p in smallprimes(100):
        while n%p==0:out.append(p);n//=p
    rec(n)
    assert all(prime(p) for p in out)
    return sorted(set(out))
def irreducible(f,n):
    v=2
    for i in range(1,n+1):
        v=mul(v,v,f,n)
        if i<=n//2 and pgcd(v^2,f)!=1:return False
    return v==2
def trace(a,n,f):
    z=0
    for _ in range(n):z^=a;a=mul(a,a,f,n)
    return z
def emul(x,y,b,c,f,n):
    u,v=x;w,z=y;vz=mul(v,z,f,n)
    return mul(u,w,f,n)^mul(vz,b,f,n),mul(u,z,f,n)^mul(v,w,f,n)^mul(vz,c,f,n)
def epow(x,e,b,c,f,n):
    z=(1,0)
    while e:
        if e&1:z=emul(z,x,b,c,f,n)
        e>>=1;x=emul(x,x,b,c,f,n)
    return z

TABLE='''2 13 8 1
3 43 6 4
4 11b 2f 1
5 409 9b 4
6 1009 c78 3
7 4021 3e8a 1
8 1002b 2878 4
9 40009 303be 26
10 100009 a3085 1
11 400003 662cc 7
12 100001b d0842d 1
13 400001b 32f9317 1
14 10000003 15a3baa 8
15 40000003 317d6a85 4
16 10000008d 4893e13d 4
17 40000001b dcbd299 7
18 1000000035 78c0283c4 1
19 4000000063 1153a3d1ef 5
20 10000000039 1f9215dca7 1
21 40000000027 2657c0cd035 5
22 100000000021 fe622270c1c 1
23 400000000003 17c45ffbd76 8
24 100000000002d fed891dbe6c9 4
25 400000000001d 2907b6c341c09 1
26 10000000000009 c6d27ccd2b0df 3
27 4000000000007d 28047cef28c34e 1
28 100000000000095 a586528c5b1c9 1
29 400000000000063 243f16ec4e21119 1
30 1000000000000003 8c388b10c413f59 1
31 4000000000000069 12dfcd22c3b1728b 1
32 1000000000000001b ae3111b3bb81428f 3'''

if __name__=='__main__':
    start=time.monotonic();rows={}
    cert = (Path(__file__).resolve().parents[1]/'main/certificates.tex').read_text(encoding='utf-8')
    first = {int(ss):(ff,bb) for ss,ff,bb,ww in re.findall(r'^([0-9]+) & \\texttt\{([0-9a-f]+)\} & \\texttt\{([0-9a-f]+)\} & \\texttt\{([0-9a-f]+)\}',cert,re.M)}
    extra = cert.split('Additional double-order certificates.')[1].split('\\end{tabular}')[0]
    exponents = {}
    for ss,ee,tt,uu in re.findall(r'^([0-9]+)&([0-9]+)&([0-9]*)&([0-9]*)\\\\',extra,re.M):
        exponents[int(ss)]=int(ee)
        if tt:exponents[int(tt)]=int(uu)
    assert len(first)==len(exponents)==31
    for row in TABLE.splitlines():
        ss,ff,bb,ee=row.split()
        assert first[int(ss)]==(ff,bb) and exponents[int(ss)]==int(ee)
    print('CURRENT_MANUSCRIPT_CERTIFICATE_TABLES_MATCH',flush=True)
    for line in TABLE.splitlines():
        ss,ff,bb,ee=line.split();s=int(ss);n=2*s;t=1<<s;A=t+1;B=t*t+1;d=A*B
        f=int(ff,16);b=int(bb,16);e=int(ee);w=power(b,e,f,n);c=1^b^w
        assert f.bit_length()-1==n and irreducible(f,n)
        pa,pb=factors(A),factors(B)
        assert power(b,A,f,n)==1 and all(power(b,A//p,f,n)!=1 for p in pa)
        assert math.gcd(e,A)==1 and c!=0
        cinv=power(c,(1<<n)-2,f,n)
        assert trace(mul(b,mul(cinv,cinv,f,n),f,n),n,f)==1
        a=(0,1);ap=(1,1)
        assert epow(a,B,b,c,f,n)==(b,0) and epow(ap,B,b,c,f,n)==(w,0)
        assert epow(a,d,b,c,f,n)==epow(ap,d,b,c,f,n)==(1,0)
        for p in pa+pb:
            assert epow(a,d//p,b,c,f,n)!=(1,0)
            assert epow(ap,d//p,b,c,f,n)!=(1,0)
        rows[s]=(f,b,w,c,n,t,A,B,d,pa,pb)
        print('DOUBLE_ORDER_CERTIFICATE',s,'PASS','A_primes',pa,'B_primes',pb,flush=True)
    expected={2:(24,24,16,8,8),3:(86,72,48,24,0),4:(240,240,224,208,16),5:(1214,960,520,240,0),6:(4104,3960,2928,1992,24)}
    for s in range(2,7):
        f,b,w,c,n,t,A,B,d,pa,pb=rows[s]
        vals=[];lookup={};x=(1,0)
        for j in range(d):
            key=x[0]|(x[1]<<n);assert key not in lookup
            lookup[key]=j;vals.append(key)
            x=(mul(b,x[1],f,n),x[0]^mul(c,x[1],f,n))
        assert x==(1,0)
        T=R=N=D=delta=0;fibers=[0]*A;prim=[0]*A;dfib=[0]*A
        for j,key in enumerate(vals):
            k=lookup.get(key^1)
            if k is None:continue
            T+=1;fibers[j%A]+=1
            R+=math.gcd(d,math.gcd(j,k))==1
            jp=math.gcd(d,j)==1;kp=math.gcd(d,k)==1
            N+=jp;D+=jp and kp;prim[j%A]+=jp;dfib[j%A]+=jp and kp
            delta+=jp and kp and k==(j*t*t)%d
        assert (T,R,N,D,delta)==expected[s]
        for j in range(A):
            if 3*j%A:
                assert (fibers[j]-A)**2<=4*t and fibers[j]%4==0 and prim[j]%4==0
            if math.gcd(j,A)!=1:assert dfib[j]==0
        # Exact local averages in (27).
        lam=Fraction(0);weighted=Fraction(0)
        for j in range(A):
            value=Fraction(1);cnt=0
            for p in pa:
                if j%p==0:value*=Fraction(p-1,p);cnt+=1
            lam+=value;weighted+=value*(1<<cnt)
        theta=math.prod([]) if False else Fraction(1);H=Fraction(1)
        for p in pa:theta*=Fraction(p*p-1,p*p);H*=Fraction(p+2,p+1)
        assert lam/A==theta and weighted/A==theta*H
        print('FULL_FAMILY_COUNTS',s,{'T':T,'R':R,'N_prim':N,'D':D,'trace_one_D':delta,'fibers_and_local_averages':'PASS'},flush=True)
    # Read the 81 integer bounds directly from the reorganized source table.
    pdftext=re.sub(r'\\\\[^\n]*', '', cert).replace('&',' ')
    listed={}
    for line in pdftext.splitlines():
        bits=line.split()
        if len(bits)==6 and all(z.isdecimal() for z in bits):
            for j in (0,2,4):
                ss,rr=map(int,bits[j:j+2])
                if 33<=ss<=113:listed[ss]=rr
    assert len(listed)==81
    ps=smallprimes(4096)
    for s in range(33,114):
        t=1<<s;bound=0
        for value in (t+1,t*t+1):
            small=0
            for p in ps:
                if value%p==0:
                    small+=1
                    while value%p==0:value//=p
            k=0
            while value>=4097:value//=4097;k+=1
            bound+=small+k
        assert bound==listed[s] and s>=4+2*bound
    P=math.prod(p for p in smallprimes(255) if p!=2)
    assert len([p for p in smallprimes(255) if p!=2])==53
    assert 256**53<4096**8*P
    print('INTEGER_RANGE_33_TO_113','ALL_81_PASS')
    print('UNIFORM_BOUND_S_GE_114','PASS')
    print('ALL_CHECKS_PASS_SECONDS',round(time.monotonic()-start,3))

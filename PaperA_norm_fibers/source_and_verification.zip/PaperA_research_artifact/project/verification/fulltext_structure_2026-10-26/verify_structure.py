"""Independent arithmetic checks for the norm and relative-trace refinements.

Uses all elements of one binary polynomial field for s=2,...,5.
No arithmetic or counting implementation is imported from the manuscript's
certificate generators. Polynomial identities and a published-criterion
comparison are checked separately using exact integer/rational arithmetic.
"""
from array import array
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
import hashlib
import json
import math
import time

HERE = Path(__file__).resolve().parent
MODULI = {2: 0x17b, 3: 0x1773, 4: 0x16ac3, 5: 0x1540b5}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def factors(n):
    ans, p = [], 2
    while p*p <= n:
        if n % p == 0:
            ans.append(p)
            while n % p == 0:
                n //= p
        p = 3 if p == 2 else p+2
    if n > 1:
        ans.append(n)
    return ans


def phi(n):
    a = n
    for p in factors(n):
        a = a//p*(p-1)
    return a


def product(values):
    return math.prod(values)


def rem(a, b):
    while a.bit_length() >= b.bit_length():
        a ^= b << (a.bit_length()-b.bit_length())
    return a


def raw(a, b):
    x = 0
    while b:
        if b & 1:
            x ^= a
        a <<= 1
        b >>= 1
    return x


def divmod_poly(a, b):
    q = 0
    while a.bit_length() >= b.bit_length():
        shift = a.bit_length()-b.bit_length()
        q ^= 1 << shift
        a ^= b << shift
    return q, a


def pgcd(a, b):
    while b:
        a, b = b, rem(a, b)
    return a


def mul(a, b, f):
    return rem(raw(a, b), f)


def power(a, e, f):
    out = 1
    while e:
        if e & 1:
            out = mul(out, a, f)
        a = mul(a, a, f)
        e >>= 1
    return out


def check_irreducible(f, n):
    require(f.bit_length()-1 == n, 'modulus degree')
    require(power(2, 1 << n, f) == 2, 'Frobenius identity')
    for p in factors(n):
        require(pgcd(power(2, 1 << (n//p), f) ^ 2, f) == 1,
                'irreducible modulus')


@lru_cache(None)
def cyclotomic(n):
    v = (1 << n) | 1
    for j in range(1, n):
        if n % j == 0:
            v, r = divmod_poly(v, cyclotomic(j))
            require(r == 0, 'cyclotomic division')
    return v


def q_transform(f):
    # Integer binomial coefficients reduced modulo two; independent formula.
    n = f.bit_length()-1
    ans = 0
    for i in range(n+1):
        if (f >> i) & 1:
            for j in range(i+1):
                if math.comb(i, j) & 1:
                    ans ^= 1 << (n+i-2*j)
    return ans


def polynomial_profiles():
    rows = []
    for A, B in [(9, 65), (33, 1025)]:
        for m in range(1, A+1):
            if A % m:
                continue
            H = q_transform(cyclotomic(m))
            G = pgcd(H, (1 << B) | 1)
            counts = {}
            # Phi_e is squarefree for odd e; gcd degrees count distinct roots.
            for e in range(1, B+1):
                if B % e == 0:
                    count = pgcd(H, cyclotomic(e)).bit_length()-1
                    if count:
                        counts[str(e)] = count
            require(sum(counts.values()) == G.bit_length()-1, 'order partition')
            if A == 33 and m == 11:
                require(G == H, 'all H_11 roots belong to V')
                require(rem(cyclotomic(1025), H) == 0,
                        'H_11 divides Phi_1025')
                require(counts == {'1025': 20}, 'C_11 primitive support')
            rows.append({'A': A, 'B': B, 'tau_order': m, 'H_hex': hex(H),
                         'roots_by_gamma_order': counts})
    return rows


def field_checks(s, f):
    t = 1 << s
    A, B, r = t+1, t*t+1, t-1
    d, total = A*B, t**4-1
    check_irreducible(f, 4*s)
    g = next(v for v in range(2, 100)
             if all(power(v, total//p, f) != 1 for p in factors(total)))
    require(power(g, total, f) == 1, 'primitive ambient generator')
    powers, v = array('I', [0])*total, 1
    logs = array('i', [-1])*(total+1)
    for j in range(total):
        require(logs[v] == -1, 'ambient cycle is injective')
        powers[j], logs[v] = v, j
        v = mul(v, g, f)
    require(v == 1, 'ambient cycle closes')

    def pmul(a, b):
        return 0 if a == 0 or b == 0 else powers[(logs[a]+logs[b]) % total]

    def ppower(a, e):
        return 0 if a == 0 else powers[(logs[a]*e) % total]

    E = [0] + [powers[j] for j in range(0, total, t*t+1)]
    Kstar = [powers[j] for j in range(0, total, d)]
    U = [powers[j*r*B] for j in range(A)]
    Vprim = [powers[j*r*A] for j in range(B) if math.gcd(j, B) == 1]
    require(len(set(E)) == t*t and len(Kstar) == r, 'subfield sizes')
    counts = [Counter() for _ in range(r)]
    unfiltered = [Counter() for _ in range(r)]
    full_order_checks = 0
    for j in range(total):
        nu_index = j % r
        c = powers[j] ^ powers[(j*t*t) % total]
        unfiltered[nu_index][c] += 1
        if math.gcd(j, d) == 1:
            counts[nu_index][c] += 1
            e = r//math.gcd(j, r)
            require(total//math.gcd(j, total) == e*d, 'maximal norm-fiber order')
            full_order_checks += 1
    require(counts[0][0] == 0, 'zero trace has no full order')

    def psi_K(x):
        z, tr = x, 0
        for _ in range(s):
            tr ^= z
            z = pmul(z, z)
        require(tr in (0, 1), 'absolute K-trace is binary')
        return 1 if tr == 0 else -1

    kloosterman = {lam: sum(psi_K(z ^ pmul(lam, ppower(z, -1)))
                           for z in Kstar) for lam in Kstar}
    lift_checks, norm_classification_checks, kloosterman_checks = 0, 0, 0
    for k in range(r):
        require(sum(counts[k].values()) == phi(d), 'full-order total in each norm fiber')
        lam_log = d*((k*pow(4, -1, r)) % r) % total
        lam_inv = powers[-lam_log % total]
        nu = powers[d*k]
        for c in E:
            cc = pmul(c, lam_inv)
            require(counts[k][c] == counts[0][cc], 'norm and trace scaling')
            require(unfiltered[k][c] == unfiltered[0][cc], 'unfiltered scaling')
            lift_checks += 1
            if c:
                zero_expected = ((s == 3 and ppower(c, 36) == ppower(nu, 9)) or
                                 (s == 5 and ppower(c, 44) == ppower(nu, 11)))
                require((counts[k][c] == 0) == zero_expected,
                        'exceptional cosets in polynomial form')
                norm_classification_checks += 1
                nc = ppower(c, t+1)
                parameter = pmul(nu, ppower(nc, -2))
                require(unfiltered[k][c] == t+1+kloosterman[parameter],
                        'arbitrary-norm Kloosterman formula')
                kloosterman_checks += 1

    thetaA, thetaB = Fraction(phi(A), A), Fraction(phi(B), B)
    WB = 1 << len(factors(B))
    bound = 16*thetaA*(1-thetaA)*thetaB**2*WB**2*t
    moments, convolution_checks, period_checks = [], 0, 0
    radA = product(factors(A))
    H0 = [U[j] for j in range(0, A, radA)]
    up_indices = {j for j in range(A) if math.gcd(j, A) == 1}
    u_logs = {u: j for j, u in enumerate(U)}
    for h in Kstar:
        h2inv = ppower(h, -2)
        taus = Counter()
        for gamma in Vprim:
            tau = gamma ^ ppower(gamma, -1)
            z = pmul(tau, h2inv)
            if z in u_logs:
                taus[u_logs[z]] += 1
        require(set(taus.values()) <= {2}, 'reciprocal map has two preimages')
        nh = sum(taus.values())
        profile = []
        for j, u in enumerate(U):
            c = pmul(h, u)
            expected = sum(num for z, num in taus.items()
                           if (z-2*j) % A in up_indices)
            require(counts[0][c] == expected, 'exact cyclic convolution')
            convolution_checks += 1
            profile.append(counts[0][c])
            for v in H0:
                require(counts[0][pmul(c, v)] == counts[0][c], 'radical period')
                period_checks += 1
        mu = thetaA*nh
        require(sum(profile) == A*mu, 'exact norm-class mean')
        var = sum((Fraction(x)-mu)**2 for x in profile)/A
        require(var <= bound, 'variance bound')
        zeros = sum(x == 0 for x in profile)
        if mu:
            require(Fraction(zeros, A)*mu**2 <= var, 'zero proportion bound')
        if h == 1 and s == 3:
            require(nh == 0 and profile == [0]*9, 's=3 norm-one profile')
        if h == 1 and s == 5:
            require(set(taus) == set(range(3, 33, 3)), 'T_1=C_11 minus identity')
            require(Counter(profile) == {0: 11, 20: 2, 18: 20}, 's=5 profile')
            for j, x in enumerate(profile):
                require(x == (0 if j % 3 == 0 else 20 if j % 11 == 0 else 18),
                        's=5 exact subgroup profile')
        moments.append({'h': h, 'n_h': nh, 'mean': str(mu),
                        'variance': str(var), 'zero_slices': zeros})
    require(convolution_checks == t*t-1, 'all nonzero trace convolution checks')
    return {'s': s, 't': t, 'field_modulus_hex': hex(f), 'primitive_generator': g,
            'all_field_elements_enumerated': total,
            'maximal_order_elements_checked': full_order_checks,
            'norm_trace_scaling_checks': lift_checks,
            'norm_trace_exception_classification_checks': norm_classification_checks,
            'arbitrary_norm_kloosterman_checks': kloosterman_checks,
            'convolution_checks': convolution_checks, 'period_checks': period_checks,
            'variance_upper_bound': str(bound), 'moments': moments}


def st26_counterexample():
    # F16 / F4, using X^4+X+1. Target trace is 1.
    f, q, n = 0x13, 4, 2
    check_irreducible(f, 4)
    C = D = set(range(2, 16))
    H1 = {x for x in range(1, 16) if x ^ power(x, 4, f) == 1}
    E = set(range(1, 16))-H1-{1}
    CD = {mul(c, d, f) for c in C for d in D}
    require(len(E) == 10 and len(C) == len(D) == 14, 'counterexample cardinalities')
    require(E <= CD and all(power(y, 2, f) != 1 for y in E), 'all Thm 1.2 hypotheses')
    lhs_sq = len(E)*len(C)*len(D)
    rhs_sq = 2*(q**n-1)**2*(q-Fraction(1, q**(n-1)))
    require(lhs_sq > rhs_sq, 'printed criterion is strictly satisfied')
    require(not E & H1, 'the claimed nonzero trace is absent')
    return {'q': q, 'n': n, 'target_trace': 1, 'binary_modulus_hex': hex(f),
            'E': sorted(E), 'C': sorted(C), 'D': sorted(D), 'H1': sorted(H1),
            'product_set_size': len(CD), 'lhs_squared': lhs_sq,
            'rhs_squared': str(rhs_sq), 'E_target_trace_count': 0,
            'status': 'counterexample to Theorem 1.2 as printed; not an erratum check'}


def st26_criterion_bounds():
    # Proof in the accompanying audit covers all t, not just these integer checks.
    # For odd k>=3, k*(2/3)^(k-1)<=4/3.
    for k in range(3, 1001, 2):
        require(k*Fraction(2, 3)**(k-1) <= Fraction(4, 3), 'all-k upper bound')
    rows = []
    for s in range(2, 33):
        t = 1 << s
        theta_d_bound = Fraction(64, 85) if s == 2 else Fraction(1)
        ratio_bound = Fraction(2, 3)*theta_d_bound*Fraction(t, t-1)**2
        require(ratio_bound < 1, 'all decomposition criterion failure')
        rows.append({'s': s, 'squared_ratio_upper_bound': str(ratio_bound)})
    return rows


if __name__ == '__main__':
    start = time.time()
    result = {'arithmetic': 'independent binary polynomial field; exact integers and fractions',
              'polynomial_profiles': polynomial_profiles(),
              'ST26_printed_Theorem_1_2_counterexample': st26_counterexample(),
              'ST26_Theorem_1_5_all_decomposition_bounds': st26_criterion_bounds(),
              'fields': []}
    for s, f in MODULI.items():
        row = field_checks(s, f)
        result['fields'].append(row)
        print(json.dumps({k: row[k] for k in ['s', 'all_field_elements_enumerated',
                          'norm_trace_scaling_checks', 'convolution_checks']}), flush=True)
    result['elapsed_seconds'] = round(time.time()-start, 3)
    result['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE/'structure_verification.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print('All structural checks passed.', flush=True)

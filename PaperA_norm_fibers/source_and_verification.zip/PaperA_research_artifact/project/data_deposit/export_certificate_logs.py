"""Recompute descriptive logs from unchanged, original finite certificates.

Explicit norms, fiber markers and relative traces in quadratic-tower encoding.
This is a new run, not a replacement of the archived certificate history.
"""
from functools import lru_cache
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import math
import sys
import time

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent if (HERE.parent/'main.tex').is_file() else HERE.parents[2]/'output/pdf/PaperA_restructured_2026-10-26'
OUT=HERE/'data'
OUT.mkdir(parents=True,exist_ok=True)

def check(v,msg):
    if not v:raise RuntimeError(msg)

def factors(n):
    ans=[]
    p=2
    while p*p<=n:
        if n%p==0:
            ans.append(p)
            while n%p==0:n//=p
        p=3 if p==2 else p+2
    if n>1:ans.append(n)
    return ans

@lru_cache(None)
def prime(n):
    check(n<=10**14,'large prime needs a different explicit certificate; no probabilistic fallback')
    if n<2:return False
    if n in (2,3):return True
    if n%2==0 or n%3==0:return False
    p=5
    while p*p<=n:
        if n%p==0 or n%(p+2)==0:return False
        p+=6
    return True

def emul(a,b,f):
    raw=0
    while a:
        bit=a&-a
        raw^=b<<(bit.bit_length()-1)
        a^=bit
    while raw.bit_length()>=f.bit_length():raw^=f<<(raw.bit_length()-f.bit_length())
    return raw

def epow(a,e,f):
    z=1
    while e:
        if e&1:z=emul(z,a,f)
        e>>=1
        a=emul(a,a,f)
    return z

def pgcd(a,b):
    while b:
        while a and a.bit_length()>=b.bit_length():a^=b<<(a.bit_length()-b.bit_length())
        a,b=b,a
    return a

class Tower:
    def __init__(self,s,f,b,c):
        self.s,self.f,self.b,self.c=s,f,b,c
        self.t=1<<s
        self.q=self.t*self.t
        check(epow(2,1<<(2*s),f)==2,'E Frobenius')
        for p in factors(2*s):
            check(pgcd(f,epow(2,1<<((2*s)//p),f)^2)==1,'E irreducibility')
        check(c!=0,'nonzero quadratic trace coefficient')
        z=emul(b,epow(c,self.q-3,f),f)
        tr=0
        for _ in range(2*s):tr^=z;z=emul(z,z,f)
        check(tr==1,'irreducible quadratic tower')

    def mul(self,x,y):
        v=emul(x[1],y[1],self.f)
        return (emul(x[0],y[0],self.f)^emul(v,self.b,self.f),
                emul(x[0],y[1],self.f)^emul(x[1],y[0],self.f)^emul(v,self.c,self.f))

    def power(self,x,n):
        z=(1,0)
        while n:
            if n&1:z=self.mul(z,x)
            n>>=1
            x=self.mul(x,x)
        return z

    def order_evidence(self,x,n,primes):
        check(self.power(x,n)==(1,0),'target order divides')
        evidence={str(p):self.power(x,n//p) for p in sorted(set(primes)) if n%p==0}
        check(all(v!=(1,0) for v in evidence.values()),'exact multiplicative order')
        return {p:[hex(a),hex(b)] for p,(a,b) in evidence.items()}

def read(rel):
    p=PROJECT/rel
    return json.loads(p.read_text(encoding='utf-8')),hashlib.sha256(p.read_bytes()).hexdigest()

def pair(x):return [hex(x[0]),hex(x[1])]

def main():
    check(not sys.flags.optimize,'run without -O')
    started=time.monotonic()
    critical,ch=read('verification/author_runtime/inner_critical_certificates.json')
    double,dh=read('verification/author_runtime/inner_double_order_certificates.json')
    support,sh=read('verification/radical_support_2026-10-26/support_certificates.json')
    critical={r['s']:r for r in critical['certificates']}
    double_rows=[]
    for row in double['certificates']:
        s=row['s'];t=1<<s;A=t+1;B=t*t+1;d=A*B
        old=critical[s]
        primes=old['A_factors']+old['B_factors']
        check(math.prod(old['A_factors'])==A and math.prod(old['B_factors'])==B,'complete factors')
        check(all(prime(p) for p in set(primes)),'exact trial division for all prime factors')
        f,b,w,c=[int(row[k],16) for k in ['E_modulus_hex','b_hex','w_hex','c_hex']]
        check(c==1^b^w,'quadratic coefficient matches norms')
        F=Tower(s,f,b,c)
        a,y=(0,1),(1,1)
        ab,yb=F.power(a,B),F.power(y,B)
        check(ab==(b,0) and yb==(w,0),'actual relative norms')
        aq=F.power(a,t*t)
        check((aq[0]^a[0],aq[1]^a[1])==(c,0),'actual relative trace')
        evidence_a=F.order_evidence(a,d,primes)
        evidence_y=F.order_evidence(y,d,primes)
        double_rows.append({'s':s,'t':t,'A':str(A),'B':str(B),'d':str(d),
            'field_encoding_id':'double-tower-s%d'%s,'E_modulus_hex':hex(f),
            'L_quadratic_b_hex':hex(b),'L_quadratic_c_hex':hex(c),'a_L_pair_hex':pair(a),
            'a_plus_1_L_pair_hex':pair(y),'N_L_E_a_hex':hex(b),'N_L_E_a_plus_1_hex':hex(w),
            'relative_trace_E_hex':hex(c),'N_L_K_a_L_pair_hex':pair(F.power(a,d)),
            'N_L_K_a_plus_1_L_pair_hex':pair(F.power(y,d)),
            'norm_fiber_id':'double-tower-s%d:nu:1'%s,'geometric_b_fiber_id':'double-tower-s%d:b:%x'%(s,b),
            'order_a':str(d),'order_a_plus_1':str(d),'prime_factors':list(map(str,sorted(set(primes)))),
            'a_power_d_over_p':evidence_a,'a_plus_1_power_d_over_p':evidence_y,
            'source_certificate_s':s,'role':'one exact witness for D_d>0; not a full field enumeration'})
    check([x['s'] for x in double_rows]==list(range(2,33)),'all 31 double-order certificates')
    (OUT/'double_order_witness_logs_s2_to32.json').write_text(json.dumps(double_rows,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'double_order_witnesses':len(double_rows),'prime_factors_checked_by_exact_trial_division':prime.cache_info().currsize}),flush=True)

    witnesses=[]
    counts={'central_primary':0,'central_redundant_s8':0,'separator':0}
    for row in support['rows']:
        s=row['s'];t=1<<s;A=t+1;B=t*t+1;d=A*B
        f=int(row['E_modulus_hex'],16)
        F=Tower(s,f,int(row['quadratic_b_hex'],16),int(row['quadratic_c_hex'],16))
        gamma_seed=tuple(int(z,16) for z in row['V_generator_hex'])
        primesB=factors(B)
        F.order_evidence(gamma_seed,B,primesB)
        Ugen=epow(int(row['primitive_E_generator_hex'],16),t-1,f)
        for nc in row['norm_classes']:
            h=int(nc['h_E_hex'],16)
            for role,key in [('central','central_witness'),('separator','separator_witness')]:
                w=nc[key]
                if w is None:continue
                k,e=w['gamma_exponent'],w['z_exponent']
                gam=F.power(gamma_seed,k)
                gi=F.power(gamma_seed,B-k)
                tau=(gam[0]^gi[0],gam[1]^gi[1])
                check(tau==(int(w['tau_E_hex'],16),0),'actual reciprocal trace')
                z=emul(tau[0],epow(h,t*t-3,f),f)
                check(z==epow(Ugen,e,f),'actual support element')
                a=F.mul((h,0),F.power((gam[0]^1,gam[1]),t**4-2))
                aq=F.power(a,t*t)
                check((a[0]^aq[0],a[1]^aq[1])==(h,0),'actual representative relative trace')
                check(F.power(a,d)==(1,0),'actual K norm one')
                ap=(a[0]^1,a[1])
                apb,apd=F.power(ap,B),F.power(ap,d)
                check(apb[1]==0 and apd[1]==0,'second norms lie in E')
                actual_order=B*(A//math.gcd(e,A))
                F.order_evidence(a,actual_order,factors(actual_order))
                if role=='central':check(actual_order==d,'central full-order requirement')
                label='separator' if role=='separator' else 'central_redundant_s8' if s==8 else 'central_primary'
                counts[label]+=1
                witnesses.append({'s':s,'t':t,'A':A,'B':B,'d':str(d),'role':label,
                    'field_encoding_id':'support-tower-s%d'%s,'E_modulus_hex':hex(f),
                    'L_quadratic_b_hex':hex(F.b),'L_quadratic_c_hex':hex(F.c),
                    'h_exponent':nc['h_exponent'],'relative_trace_E_hex':hex(h),
                    'norm_fiber_id':'support-tower-s%d:nu:1'%s,
                    'relative_norm_b_label':'support-tower-s%d:b:%x'%(s,F.power(a,B)[0]),
                    'is_in_X_b':apd==(1,0),
                    'gamma_exponent':k,'gamma_L_pair_hex':pair(gam),'reciprocal_trace_E_hex':hex(tau[0]),
                    'support_z_exponent':e,'support_z_E_hex':hex(z),'a_L_pair_hex':pair(a),
                    'N_L_E_a_L_pair_hex':pair(F.power(a,B)),'N_L_K_a_L_pair_hex':pair(F.power(a,d)),
                    'a_plus_1_L_pair_hex':pair(ap),'N_L_E_a_plus_1_L_pair_hex':pair(apb),
                    'N_L_K_a_plus_1_L_pair_hex':pair(apd),
                    'order_a':str(actual_order),'central_full_order_promised':role=='central'})
    check(counts=={'central_primary':755,'central_redundant_s8':255,'separator':731},'support witness counts')
    (OUT/'support_witness_logs_s2_to9.json').write_text(json.dumps(witnesses,indent=2)+'\n',encoding='utf-8')
    report={'status':'PASS','run_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'unchanged_raw_inputs_sha256':{'inner_critical_certificates.json':ch,'inner_double_order_certificates.json':dh,'support_certificates.json':sh},
            'double_order_witnesses':31,'support_witness_counts':counts,'support_witnesses':len(witnesses),
            'prime_test':'exact trial division, cached, no probabilistic primality assumption',
            'new_run_not_historical_output':True,'infinite_ranges_enumerated':False,
            'seconds':round(time.monotonic()-started,3)}
    (OUT/'certificate_log_check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','support_witnesses':len(witnesses),'seconds':report['seconds']}),flush=True)

if __name__=='__main__':main()

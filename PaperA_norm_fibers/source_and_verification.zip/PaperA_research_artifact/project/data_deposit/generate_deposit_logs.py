"""Exact, deterministic publication-deposit logs; Python standard library only.

New enumerations, not recovered historical experiment logs. No historical PASS
file or asserted population is used as an input. Run without python -O.
"""
from array import array
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
import gzip
import hashlib
import io
import json
import math
import platform
import sys
import time

HERE = Path(__file__).resolve().parent
OUT = HERE / 'data'
MODULI = {2: 0x17b, 3: 0x1773, 4: 0x16ac3, 5: 0x1540b5, 6: 0x170ceb1}
TABLE = {2: (24,24,16,8,8), 3: (86,72,48,24,0),
         4: (240,240,224,208,16), 5: (1214,960,520,240,0),
         6: (4104,3960,2928,1992,24)}

def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)

def factors(n):
    ans, p = [], 2
    while p*p <= n:
        if n % p == 0:
            ans.append(p)
            while n % p == 0:
                n //= p
        p = 3 if p == 2 else p+2
    if n > 1:
        ans.append(n)
    return ans

def phi(n):
    for p in factors(n):
        n = n//p*(p-1)
    return n

def rem(a, b):
    while a.bit_length() >= b.bit_length():
        a ^= b << (a.bit_length()-b.bit_length())
    return a

def pgcd(a, b):
    while b:
        a, b = b, rem(a, b)
    return a

def mul(a, b, f):
    z, bit = 0, 1 << (f.bit_length()-1)
    while b:
        if b & 1:
            z ^= a
        b >>= 1
        a <<= 1
        if a & bit:
            a ^= f
    return z

def power(a, n, f):
    z = 1
    while n:
        if n & 1:
            z = mul(z, a, f)
        a = mul(a, a, f)
        n >>= 1
    return z

def validate_modulus(f, n):
    require(f.bit_length()-1 == n, 'modulus degree')
    require(power(2, 1 << n, f) == 2, 'Frobenius modulus test')
    for p in factors(n):
        require(pgcd(f, power(2, 1 << (n//p), f)^2) == 1, 'Rabin irreducibility')

def exact_order(a, n, f):
    return power(a, n, f) == 1 and all(power(a, n//p, f) != 1 for p in factors(n))

@contextmanager
def jsonlines(path):
    with path.open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=6) as gz:
            with io.TextIOWrapper(gz, encoding='utf-8', newline='\n') as txt:
                def emit(row):
                    txt.write(json.dumps(row, separators=(',', ':'), ensure_ascii=True)+'\n')
                yield emit

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run_field(s):
    start = time.monotonic()
    t, f = 1 << s, MODULI[s]
    A, B, r = t+1, t*t+1, t-1
    d, N = A*B, t**4-1
    validate_modulus(f, 4*s)
    g = next(v for v in range(2, 100) if exact_order(v, N, f))
    Egen, Kgen = power(g, B, f), power(g, d, f)
    require(exact_order(Egen, t*t-1, f), 'E generator')
    require(exact_order(Kgen, r, f), 'K generator')
    E, x = [], 1
    for _ in range(t*t-1):
        E.append(x)
        x = mul(x, Egen, f)
    require(x == 1 and len(set(E)) == t*t-1, 'E cycle')
    K = [power(Kgen, j, f) for j in range(r)]
    normE = {0: 0, **{v: power(v, A, f) for v in E}}
    params = {'s': s, 't': t, 'K_size': t, 'E_size': t*t, 'L_size': t**4,
              'A': A, 'B': B, 'd': d, 'ambient_group_order': N,
              'L_binary_degree': 4*s, 'modulus_hex': hex(f),
              'ambient_generator_hex': hex(g), 'E_generator_hex': hex(Egen),
              'K_generator_hex': hex(Kgen),
              'relative_trace_definition': 'c=a+a^(t^2)',
              'relative_norm_definition': 'b=a^(t^2+1)',
              'absolute_to_K_norm_definition': 'nu=a^((t+1)(t^2+1))'}
    Q, M = Counter(), Counter()
    bstats = {power(Egen, r*j, f): [0,0,0,0] for j in range(A)}
    # Stats in each b fiber: membership, joint generation, a full, both full.
    totals = [0,0,0,0]
    rawname = 'ambient_elements_s%d.jsonl.gz' % s if s <= 5 else 'norm_one_elements_s6.jsonl.gz'
    rawpath = OUT / rawname
    if s <= 5:
        values = array('I', [0])*N
        logs = array('i', [-1])*(N+1)
        v = 1
        for j in range(N):
            require(logs[v] == -1, 'ambient cycle injectivity')
            values[j], logs[v] = v, j
            v = mul(v, g, f)
        require(v == 1, 'ambient cycle closure')
        def pp(a, e):
            return 0 if a == 0 else values[(logs[a]*e) % N]
        params['raw_enumeration'] = 'all nonzero L elements; a=g^j'
        params['norm_one_generator_hex'] = hex(values[r])
        iterator = enumerate(values)
        with jsonlines(rawpath) as emit:
            for j, a in iterator:
                y, b, nu = a^1, values[j*B % N], values[j*d % N]
                c = a ^ values[j*t*t % N]
                w = 1 ^ b ^ c
                nuplus = normE[w]
                oa = N//math.gcd(j, N)
                oy = None if y == 0 else N//math.gcd(logs[y], N)
                maximal = math.gcd(j, d) == 1
                Q[nu,c] += 1
                if maximal:
                    M[nu,c] += 1
                joint = nu == nuplus == 1
                gen = joint and math.gcd(math.gcd(j//r, logs[y]//r), d) == 1
                both = joint and oa == oy == d
                if joint:
                    flags = (1, int(gen), int(oa == d), int(both))
                    totals = [a0+b0 for a0,b0 in zip(totals, flags)]
                    bstats[b] = [a0+b0 for a0,b0 in zip(bstats[b], flags)]
                # Independent binary-power spot checks, including both ends.
                if j < 16 or j % 4093 == 0 or j == N-1:
                    require(power(a,d,f) == nu and power(a,B,f) == b, 'direct norm spot check')
                    require(a ^ power(a,t*t,f) == c, 'direct relative trace spot check')
                    require(power(y,d,f) == nuplus and power(y,B,f) == w, 'a+1 norms')
                emit({'s':s,'t':t,'j':j,'a_hex':hex(a),'nu_hex':hex(nu),
                      'norm_fiber_id':'s%d:nu:%x' % (s,nu),
                      'b_hex':hex(b),'b_fiber_id':'s%d:b:%x' % (s,b),
                      'relative_trace_hex':hex(c),'trace_norm_hex':hex(normE[c]),
                      'a_plus_1_hex':hex(y),'w_hex':hex(w),'nu_plus_1_hex':hex(nuplus),
                      'order_a':oa,'order_a_plus_1':oy,'full_kernel_part':int(maximal),
                      'both_in_Cd':int(joint),'joint_generates_Cd':int(gen),'both_order_d':int(both)})
    else:
        # Avoid an unnecessary 16-million-element ambient-field table at s=6.
        Cgen = 2
        require(exact_order(Cgen, d, f), 'norm-one generator')
        values, v = array('I', [0])*d, 1
        for j in range(d):
            values[j] = v
            v = mul(v, Cgen, f)
        clogs = {v:j for j,v in enumerate(values)}
        require(v == 1 and len(clogs) == d, 'norm-one cycle')
        params['raw_enumeration'] = 'all Cd elements; a=norm_one_generator^j'
        params['norm_one_generator_hex'] = hex(Cgen)
        params['order_a_plus_1_scope'] = 'recorded only when a+1 is nonzero and in Cd; otherwise null'
        with jsonlines(rawpath) as emit:
            for j, a in enumerate(values):
                y, b = a^1, values[j*B % d]
                c = a ^ values[j*t*t % d]
                w = 1 ^ b ^ c
                nuplus, k = normE[w], clogs.get(y)
                oa = d//math.gcd(j,d)
                oy = None if k is None else d//math.gcd(k,d)
                joint = nuplus == 1
                require(joint == (k is not None), 'independent a+1 membership')
                gen = joint and math.gcd(math.gcd(j,k),d) == 1
                both = joint and oa == oy == d
                Q[1,c] += 1
                if oa == d:
                    M[1,c] += 1
                if joint:
                    flags = (1,int(gen),int(oa==d),int(both))
                    totals = [a0+b0 for a0,b0 in zip(totals,flags)]
                    bstats[b] = [a0+b0 for a0,b0 in zip(bstats[b],flags)]
                if j < 16 or j % 4093 == 0 or j == d-1:
                    require(power(a,d,f)==1 and power(a,B,f)==b, 'norm-one direct norm')
                    require(a ^ power(a,t*t,f)==c and power(y,d,f)==nuplus, 'norm-one trace and second norm')
                emit({'s':s,'t':t,'j':j,'a_hex':hex(a),'nu_hex':'0x1',
                      'norm_fiber_id':'s6:nu:1','b_hex':hex(b),'b_fiber_id':'s6:b:%x'%b,
                      'relative_trace_hex':hex(c),'trace_norm_hex':hex(normE[c]),
                      'a_plus_1_hex':hex(y),'w_hex':hex(w),'nu_plus_1_hex':hex(nuplus),
                      'order_a':oa,'order_a_plus_1':oy,'full_kernel_part':int(oa==d),
                      'both_in_Cd':int(joint),'joint_generates_Cd':int(gen),'both_order_d':int(both)})
        def pp(a,e):
            return power(a,e,f)

    # The known discussion table is a comparison target, never an input to counts.
    found = tuple(totals+[M[1,1]])
    require(found == TABLE[s], 'main Section 7 finite table comparison')
    theta = Fraction(phi(d),d)
    W = 1 << len(factors(d))
    normlist = K if s <= 5 else [1]
    populations, empty = 0, []
    with jsonlines(OUT / ('norm_trace_populations_s%d.jsonl.gz' % s)) as emit:
        for nu in normlist:
            require(sum(Q[nu,c] for c in [0]+E) == d, 'norm-fiber total')
            require(sum(M[nu,c] for c in [0]+E) == phi(d), 'maximal-kernel-order total')
            for c in [0]+E:
                q, m = Q[nu,c], M[nu,c]
                if c:
                    expected_zero = (s==3 and pp(c,36)==pp(nu,9)) or (s==5 and pp(c,44)==pp(nu,11))
                    require((m==0)==expected_zero, 'arbitrary-norm exceptional cosets')
                    if nu==1:
                        require((q-A)**2 <= 4*t, 'unfiltered Hasse bound')
                        require((m-theta*q)**2 <= 16*theta**2*(W-1)**2*t, 'exact-center error')
                        require((m-theta*A)**2 <= theta**2*(4*W-2)**2*t, 'linear-center error')
                        if m==0:
                            empty.append(hex(c))
                else:
                    require(m==0 and q==A, 'zero trace special case')
                emit({'s':s,'t':t,'nu_hex':hex(nu),'norm_fiber_id':'s%d:nu:%x'%(s,nu),
                      'relative_trace_hex':hex(c),'trace_norm_hex':hex(normE[c]),
                      'unfiltered_count_Q':q,'maximal_kernel_order_count_M':m})
                populations += 1
    with jsonlines(OUT / ('geometric_b_fibers_s%d.jsonl.gz' % s)) as emit:
        for b, counts in sorted(bstats.items()):
            regular = power(b,3,f) != 1
            if regular:
                require((counts[0]-A)**2 <= 4*t, 'genus-one b-fiber Hasse bound')
            emit({'s':s,'t':t,'b_hex':hex(b),'b_fiber_id':'s%d:b:%x'%(s,b),
                  'smooth_genus_one_hypothesis_b_cubed_ne_one':regular,
                  'membership_count':counts[0],'joint_generation_count':counts[1],
                  'a_order_d_count':counts[2],'both_order_d_count':counts[3]})
    params['raw_record_count'] = N if s<=5 else d
    params['population_record_count'] = populations
    params['norm_fibers_in_population_log'] = len(normlist)
    result = {'s':s,'T_d':found[0],'R_d':found[1],'N_d_prim':found[2],
              'D_d':found[3],'Delta_t':found[4],'empty_norm_one_nonzero_traces':empty,
              'raw_records':params['raw_record_count'],'population_records':populations,
              'geometric_b_fibers':A,'seconds':round(time.monotonic()-start,3)}
    print(json.dumps(result), flush=True)
    return params, result

def main():
    require(not sys.flags.optimize, 'Run without -O: retain validation checks')
    OUT.mkdir(parents=True,exist_ok=True)
    started = datetime.now(timezone.utc).isoformat()
    results = [run_field(s) for s in range(2,7)]
    parameters, summaries = zip(*results)
    (OUT/'parameters.json').write_text(json.dumps(list(parameters),indent=2)+'\n',encoding='utf-8')
    report = {'status':'PASS','record_type':'new deterministic exact enumeration; not original historical run logs',
              'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),
              'python':sys.version,'platform':platform.platform(),'generator_sha256':sha(Path(__file__)),
              'historical_PASS_reports_used_as_input':False,'floating_point_arithmetic_used':False,
              'scope':{'all_nonzero_L_elements_s':list(range(2,6)),
                       'norm_one_subgroup_elements_s':list(range(2,7)),
                       'all_nonzero_norm_fibers_s':list(range(2,6)),
                       'all_E_trace_values_including_zero':True,
                       'infinite_parameter_ranges_enumerated':False},
              'rows':list(summaries),
              'norm_one_nonzero_trace_populations':sum((1<<(2*s))-1 for s in range(2,7)),
              'all_norm_trace_populations_s2_to5_including_zero':sum(((1<<s)-1)*(1<<(2*s)) for s in range(2,6))}
    report['output_files'] = {p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.name!='enumeration_check.json' and p.is_file()}
    (OUT/'enumeration_check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','raw_records':sum(r['raw_records'] for r in summaries),
                      'norm_one_nonzero_trace_populations':report['norm_one_nonzero_trace_populations'],
                      'all_norm_trace_populations_s2_to5_including_zero':report['all_norm_trace_populations_s2_to5_including_zero']}),flush=True)

if __name__ == '__main__':
    main()

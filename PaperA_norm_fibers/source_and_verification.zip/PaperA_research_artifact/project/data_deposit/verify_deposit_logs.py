"""Read back every deposited record using separate polynomial arithmetic.

No import from the log producer; no historical PASS input. The reported
finite ranges do not prove the paper's all-parameter theorems.
"""
from array import array
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import gzip
import hashlib
import json
import math
import platform
import sys

HERE=Path(__file__).resolve().parent
OUT=HERE/'data'

def check(ok,msg):
    if not ok:raise RuntimeError(msg)

def product(a,b,f):
    raw=0
    while a:
        bit=a&-a
        raw^=b << (bit.bit_length()-1)
        a^=bit
    while raw.bit_length()>=f.bit_length():
        raw^=f << (raw.bit_length()-f.bit_length())
    return raw

def power(a,e,f):
    z=1
    for bit in bin(e)[2:]:
        z=product(z,z,f)
        if bit=='1':z=product(z,a,f)
    return z

def cycle(g,n,f):
    values=array('I',[0])*n
    a=1
    for j in range(n):
        values[j]=a
        a=product(a,g,f)
    check(a==1 and len(set(values))==n,'independent generator cycle')
    return values

def records(p):
    with gzip.open(p,'rt',encoding='utf-8') as f:
        for line in f:yield json.loads(line)

def verify(p):
    s,t=p['s'],p['t']
    A,B,d,N,r=p['A'],p['B'],p['d'],p['ambient_group_order'],t-1
    f=int(p['modulus_hex'],16)
    E=cycle(int(p['E_generator_hex'],16),t*t-1,f)
    K=cycle(int(p['K_generator_hex'],16),r,f)
    normE={0:0,**{v:K[k%r] for k,v in enumerate(E)}}
    size=N if s<=5 else d
    gen=int(p['ambient_generator_hex'] if s<=5 else p['norm_one_generator_hex'],16)
    values=cycle(gen,size,f)
    logs={v:j for j,v in enumerate(values)}
    U=cycle(power(gen,B,f),A,f) if s==6 else None
    Q,M=Counter(),Counter()
    bcounts={}
    source=OUT/('ambient_elements_s%d.jsonl.gz'%s if s<=5 else 'norm_one_elements_s6.jsonl.gz')
    n=0
    for j,row in enumerate(records(source)):
        a=values[j]
        b=E[j%(t*t-1)] if s<=5 else U[j%A]
        nu=K[j%r] if s<=5 else 1
        c=a^values[j*t*t%size]
        y=a^1
        w=1^b^c
        k=logs.get(y)
        nuplus=normE[w]
        oa=size//math.gcd(j,size)
        oy=None if k is None else size//math.gcd(k,size)
        joint=nu==nuplus==1
        genpair=joint and math.gcd(math.gcd(j//r,k//r),d)==1 if s<=5 else joint and math.gcd(math.gcd(j,k),d)==1
        both=joint and oa==oy==d
        maximal=math.gcd(j,d)==1
        expected={'s':s,'t':t,'j':j,'a_hex':hex(a),'b_hex':hex(b),'nu_hex':hex(nu),
                  'norm_fiber_id':'s%d:nu:%x'%(s,nu),'b_fiber_id':'s%d:b:%x'%(s,b),
                  'relative_trace_hex':hex(c),'trace_norm_hex':hex(normE[c]),
                  'a_plus_1_hex':hex(y),'w_hex':hex(w),'nu_plus_1_hex':hex(nuplus),
                  'order_a':oa,'order_a_plus_1':oy,'full_kernel_part':int(maximal),
                  'both_in_Cd':int(joint),'joint_generates_Cd':int(genpair),'both_order_d':int(both)}
        check(row==expected,'record field mismatch at s=%d j=%d'%(s,j))
        Q[nu,c]+=1
        if maximal:M[nu,c]+=1
        if joint:
            old=bcounts.get(b,[0,0,0,0])
            flags=(1,int(genpair),int(oa==d),int(both))
            bcounts[b]=[a0+b0 for a0,b0 in zip(old,flags)]
        n+=1
    check(n==size,'complete raw record coverage')
    seen=set()
    for row in records(OUT/('norm_trace_populations_s%d.jsonl.gz'%s)):
        nu,c=int(row['nu_hex'],16),int(row['relative_trace_hex'],16)
        check((nu,c) not in seen,'unique population key')
        check(nu in K and (c==0 or c in normE),'valid population labels')
        check(s<=5 or nu==1,'declared s6 scope')
        check(row['unfiltered_count_Q']==Q[nu,c] and row['maximal_kernel_order_count_M']==M[nu,c],'population aggregation')
        check(row['trace_norm_hex']==hex(normE[c]),'population trace norm')
        seen.add((nu,c))
    check(len(seen)==(r if s<=5 else 1)*t*t,'all declared norm/trace pairs, including zero')
    bf=0
    for row in records(OUT/('geometric_b_fibers_s%d.jsonl.gz'%s)):
        b=int(row['b_hex'],16)
        counts=[row[k] for k in ['membership_count','joint_generation_count','a_order_d_count','both_order_d_count']]
        check(counts==bcounts.get(b,[0,0,0,0]),'geometric fiber aggregation')
        check(row['smooth_genus_one_hypothesis_b_cubed_ne_one']==(power(b,3,f)!=1),'geometric hypothesis flag')
        bf+=1
    check(bf==A,'all U-valued geometric b labels')
    print(json.dumps({'s':s,'raw_records_verified':n,'population_rows':len(seen),'b_fiber_rows':bf}),flush=True)
    return {'s':s,'raw_records_verified':n,'population_rows':len(seen),'b_fiber_rows':bf}

def main():
    check(not sys.flags.optimize,'use Python without -O')
    rows=[verify(p) for p in json.loads((OUT/'parameters.json').read_text(encoding='utf-8'))]
    result={'status':'PASS','checked_utc':datetime.now(timezone.utc).isoformat(),
            'python':sys.version,'platform':platform.platform(),'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'producer_arithmetic_imported':False,'arithmetic':'carryless multiplication plus polynomial long division',
            'rows':rows,'total_raw_records':sum(r['raw_records_verified'] for r in rows),
            'scope':'every deposited row, exact norms/traces/orders/flags and aggregate readback; not a proof in unenumerated ranges'}
    (OUT/'readback_check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','total_raw_records':result['total_raw_records']}),flush=True)

if __name__=='__main__':main()

Paper A: exact finite-field data deposit, 28 October 2026
Current associated manuscript: v21-editorial-final (29 October 2026)
Data originally generated 28 October 2026; raw bytes unchanged from public v17.

Contents and scope
1. data/parameters.json lists t, A, B, d, all field sizes, the binary modulus,
   and explicit ambient/subfield/subgroup generators for every s=2,...,6.
2. ambient_elements_s2,...,s5.jsonl.gz enumerate all nonzero elements of L.
   norm_one_elements_s6.jsonl.gz enumerates every Cd element at s=6 only.
   Total: 1,384,765 exact element-level records; no random sampling.
3. norm_trace_populations_s*.jsonl.gz contain the declared norm/trace pairs,
   including zero traces and zero populations. All nonzero K norms at s=2..5
   give 36,080 pairs. The additional norm-one s=6 log gives 4,096 pairs.
   Across s=2..6 there are 5,451 nonzero norm-one trace slices.
4. geometric_b_fibers_s*.jsonl.gz cover all 129 b labels in U at s=2..6.
   Membership, joint-generation and double-full-order populations are separate.
5. data_dictionary.json defines every field, encoding and null value.

Two fiber labels must be distinguished: nu=N(L/K)(a) labels a norm fiber;
b=N(L/E)(a) labels the geometric X_b(K) fiber after both K norms equal 1.
An integer bit mask is a binary polynomial coefficient vector, not a real
number or a field value that can be multiplied as an ordinary integer.

Reproduction (Python 3 standard library; run without -O)
  python generate_deposit_logs.py
  python verify_deposit_logs.py
The verifier imports no producer arithmetic. It uses carryless multiplication
and polynomial long division, recomputes every record and reads back all
aggregate logs. enumeration_check.json and readback_check.json identify the
actual environment, source hashes, finite ranges and outcomes.
Re-running a checker may change its timestamp/environment report. Gzip data
headers use mtime=0; the mathematical records have deterministic ordering.

Provenance and limits
These are newly regenerated exact logs, not historical experimental notebooks.
The accompanying project retains the original raw certificates separately in
verification/author_runtime/, radical_support_2026-10-26/ and the other paths
specified in REPRODUCE.txt. Historical records are not rewritten as new runs.
The infinite ranges are proved in the manuscript and supported by finite
integer/polynomial certificates; they cannot be exhaustively enumerated.
No numerical FFT output is used as a rigorous character-sum certificate.
Formalization is selective, as stated in the manuscript and formalization/.

Deposit status
These unchanged data and verification code were publicly archived with
preprint v17 at https://doi.org/10.5281/zenodo.23721670 on 28 October 2026.
That is a preprint record with data/code, not a separate dataset DOI.
Current-version archive target: https://doi.org/10.5281/zenodo.23757428.
The older versioned record retains its preceding PDFs. No institutional filing or journal submission is represented as done.
Existing CC BY 4.0 manuscript, MIT code/Lean and separate font terms remain;
no new dataset-specific license is assigned. See the project LICENSES.txt.

Additional original-certificate logs
  python export_certificate_logs.py
data/double_order_witness_logs_s2_to32.json supplies all 31 finite existence
witnesses, with explicit tower parameters, both relative norms, relative trace,
and exact orders. Every prime factor was checked by exact trial division.
data/support_witness_logs_s2_to9.json supplies 1,741 support records: 755 primary
central, 731 separating and 255 redundant s=8 central witnesses. A separating
witness is not promised to have full order d. Its actual order is recorded.
The relative-norm b label does not assert membership in X_b; is_in_X_b records
the second K-norm condition. This avoids confusing trace-support witnesses
with geometric-fiber points. Tower and flat-field encodings are different.
data/certificate_log_check.json records the actual new run and input hashes.

Analytic ranges
The unchanged integer certificates cover s=33..113, and the general product
bound covers s>=114. The prime-sieve rows cover s=8 and s=10..32. These have
integer/polynomial proof inputs rather than fictitious full-field output logs.

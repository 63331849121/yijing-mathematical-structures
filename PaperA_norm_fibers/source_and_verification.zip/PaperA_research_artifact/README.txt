Read project/REPRODUCE.txt, then verify_public_payload.py. Manuscript PDFs are separate. This is a selected public research edition.

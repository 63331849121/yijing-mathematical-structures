论文A v20，2026年10月29日

先读 main.pdf，再按需要查阅 supplement.pdf 和中文综述_范数纤维与相对迹.txt。
两份PDF保留这两个文件名并放在同一目录，以便跨文件链接定位。
编辑入口为main.tex、supplement.tex；运行python build.py可稳定两稿相互引用。

本版采用v19的材料分工：主稿集中必要证书和证明输入图谱，补充S7保留迹一几何，S.B为完整证书表，S.C为前驱比较，S.D为核验、数据与选择性Lean记录。
相较v19，摘要强调有效误差和明确存在量词，修正旧指向，清理正文改版经过，同步中文导读和数据关联说明。数学陈述与证明正文、原数据、核验器及Lean源码没有改动。

历史版本保留在provenance/v19_editorial_snapshot/和provenance/editorial_history/；完整v18、v19另存于工作区output/archive/PaperA_before_editorial_v20_2026-10-29/。历史审计记录的命令和版本条件只适用于其对应版本，当前复现命令见REPRODUCE.txt。
公开v17版本DOI为10.5281/zenodo.23721670，仍对应早期PDF及未改变的研究数据、代码；本版没有进行新上传或期刊投递。
本轮不扩展Lean，不声称整篇形式化；必要假设、前驱归属和1/4指数的对数缺口均保留。
当前主稿37页、补充稿40页，合计77页。当前清单为delivery_manifest.json，核对记录在verification/editorial_v20_2026-10-29/。

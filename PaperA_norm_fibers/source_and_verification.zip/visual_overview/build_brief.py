"""Create a vector-first Chinese scholarly review from the verified manuscripts."""
from pathlib import Path
from math import sin, cos, pi, atan2
from html import escape
import hashlib
import json
import re
import subprocess

from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, Color
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from pypdf import PdfReader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE.parent / 'PaperA_中文图解学术综述.pdf'
RENDER = ROOT / 'tmp/pdfs/paperA-visual-brief'
PAPER = HERE.parent / 'PaperA_restructured_2026-10-26'
W, H = 1080, 675
M, CW = 56, 968
TOTAL = 22

INK = '#183447'
NAVY = '#102A3A'
TEAL = '#087E83'
BLUE = '#3777A5'
GOLD = '#D59B38'
RED = '#BD5752'
CREAM = '#F7F5EF'
WHITE = '#FFFFFF'
MUTED = '#617582'
LINE = '#D8E1E3'
LT = '#E7F2EE'
LB = '#EAF0F7'
LG = '#F8EFD9'
LR = '#F7EAE7'

for name, path, index in [
    ('CN', 'C:/Windows/Fonts/msyh.ttc', 0),
    ('CNB', 'C:/Windows/Fonts/msyhbd.ttc', 0),
    ('CNL', 'C:/Windows/Fonts/msyhl.ttc', 0),
    ('EN', 'C:/Windows/Fonts/segoeui.ttf', 0),
    ('ENB', 'C:/Windows/Fonts/segoeuib.ttf', 0),
    ('Math', 'C:/Windows/Fonts/cambria.ttc', 1),
]:
    pdfmetrics.registerFont(TTFont(name, path, subfontIndex=index))
pdfmetrics.registerFontFamily('CN', normal='CN', bold='CNB', italic='CN', boldItalic='CNB')
pdfmetrics.registerFontFamily('Math', normal='Math', bold='Math', italic='Math', boldItalic='Math')

OUT.parent.mkdir(parents=True, exist_ok=True)
RENDER.mkdir(parents=True, exist_ok=True)
C = canvas.Canvas(str(OUT), pagesize=(W, H), pageCompression=1)
C.setTitle('范数纤维、精确阶与例外迹群 | 中文图解学术综述')
C.setAuthor('Baohua Li')
C.setSubject('主稿与补充稿的理论价值、新性定位、意向期刊对标及研究前景')
C.setCreator('Research brief, 2026-10-26')
C.setViewerPreference('DisplayDocTitle', 'true')
TEXT_BOXES = []
PAGES = []
PAGE = 0


def col(s):
    return HexColor(s) if isinstance(s, str) else s


def rect(x, y, w, h, fill, radius=16, stroke=None, lw=1):
    C.saveState()
    C.setFillColor(col(fill))
    C.setStrokeColor(col(stroke or fill))
    C.setLineWidth(lw)
    C.roundRect(x, H-y-h, w, h, radius, fill=1, stroke=bool(stroke))
    C.restoreState()


def line(x1, y1, x2, y2, color=LINE, width=1):
    C.saveState()
    C.setStrokeColor(col(color))
    C.setLineWidth(width)
    C.line(x1, H-y1, x2, H-y2)
    C.restoreState()


def dot(x, y, r, fill, stroke=None, lw=1):
    C.saveState()
    C.setFillColor(col(fill))
    C.setStrokeColor(col(stroke or fill))
    C.setLineWidth(lw)
    C.circle(x, H-y, r, fill=1, stroke=bool(stroke))
    C.restoreState()


def arrow(x1, y1, x2, y2, color=TEAL, width=2.2, head=8):
    line(x1, y1, x2, y2, color, width)
    a = atan2(y2-y1, x2-x1)
    for d in [-0.48, 0.48]:
        line(x2, y2, x2-head*cos(a+d), y2-head*sin(a+d), color, width)


def rich(s, font):
    if font == 'Math':
        return s
    pieces = re.split(r'(<[^>]+>)', s)
    base = pdfmetrics.getFont('CN').face.charToGlyph
    math = pdfmetrics.getFont('Math').face.charToGlyph
    result = []
    for part in pieces:
        if part.startswith('<'):
            result.append(part)
            continue
        for char in part:
            if char.isspace() or ord(char) in base:
                result.append(char)
            elif ord(char) in math:
                result.append('<font name="Math">'+char+'</font>')
            else:
                raise RuntimeError('Unsupported character: '+repr(char))
    return ''.join(result)


def text(s, x, y, w, size=18, leading=None, color=INK, font='CN', align=0, maxh=None):
    style = ParagraphStyle('p', fontName=font, fontSize=size,
        leading=leading or size*1.5, textColor=col(color), wordWrap='CJK',
        alignment=align, spaceBefore=0, spaceAfter=0, splitLongWords=True,
        allowWidows=0, allowOrphans=0)
    p = Paragraph(rich(s, font), style)
    aw, ah = p.wrap(w, H)
    if maxh is not None and ah > maxh + 0.2:
        raise RuntimeError(f'Text overflow p{PAGE}: {s[:65]} ({ah:.1f}>{maxh})')
    if x < -0.1 or x+w > W+0.1 or y < -0.1 or y+ah > H+0.1:
        raise RuntimeError(f'Page bounds p{PAGE}: {s[:50]}')
    for frag in p.frags:
        if hasattr(frag, 'text') and frag.text:
            cmap = pdfmetrics.getFont(frag.fontName).face.charToGlyph
            if any(not ch.isspace() and ord(ch) not in cmap for ch in frag.text):
                raise RuntimeError('Missing font glyph in '+repr(frag.text))
    p.drawOn(C, x, H-y-ah)
    TEXT_BOXES.append(dict(page=PAGE, x=x, y=y, w=w, h=ah,
                           text=re.sub('<[^>]*>', '', s)))
    return ah


def tag(s, x, y, w, color=TEAL, bg=LT):
    rect(x, y, w, 29, bg, 8)
    text(s, x+8, y+4, w-16, 12, 20, color, 'CNB', 1, 22)


def card(x, y, w, h, title, body='', bg=WHITE, accent=TEAL, size=18, title_size=22):
    rect(x, y, w, h, bg)
    rect(x, y+20, 4, h-40, accent, 2)
    th = text(title, x+23, y+20, w-46, title_size, title_size*1.35, INK, 'CNB')
    if body:
        text(body, x+23, y+th+33, w-46, size, size*1.55, INK, maxh=h-th-49)


def formula(s, x, y, w, size=27, color=INK, align=1, maxh=70):
    return text(s, x, y, w, size, size*1.45, color, 'Math', align, maxh)


def small(s, x, y, w, color=MUTED, size=13):
    return text(s, x, y, w, size, size*1.5, color)


def banner(s, y=545, bg=LT, color=TEAL, size=19, h=60):
    rect(M, y, CW, h, bg, 13)
    text(s, M+20, y+13, CW-40, size, size*1.4, color, 'CNB', maxh=h-18)


def footer(source, part, dark=False):
    fg = '#A8BAC4' if dark else MUTED
    line(M, 628, W-M, 628, '#345162' if dark else LINE)
    text('图解学术综述 / 2026.10', M, 643, 220, 10.5, 15, fg, 'CN')
    text(source, 275, 643, 630, 10.5, 15, fg, 'CN', 1)
    text(f'{PAGE:02d} / {TOTAL}', W-M-82, 640, 82, 13, 19, fg, 'ENB', 2)
    colors = [TEAL, BLUE, GOLD, RED, TEAL]
    for i in range(5):
        rect(M+i*20, 620, 13, 3, colors[i] if i == part else ('#345162' if dark else LINE), 1)


def start(title, subtitle, part, source):
    global PAGE
    if PAGE:
        C.showPage()
    PAGE += 1
    C.setFillColor(col(CREAM))
    C.rect(0, 0, W, H, fill=1, stroke=0)
    C.bookmarkPage(f'p{PAGE:02d}')
    C.addOutlineEntry(title, f'p{PAGE:02d}', 0, False)
    PAGES.append(dict(page=PAGE, title=title, source=source))
    labels = ['VALUE / 理论价值', 'FRAMEWORK / 研究框架', 'RESULTS / 核心结果',
              'EXTENSIONS / 补充结果', 'PERSPECTIVE / 研究定位']
    text(labels[part], M, 29, 750, 12, 18, TEAL, 'ENB' if part == -1 else 'CNB')
    text(title, M, 65, CW, 34, 46, INK, 'CNB', maxh=50)
    text(subtitle, M, 119, CW, 16.5, 25, MUTED, maxh=50)
    footer(source, part)


def cover():
    global PAGE
    PAGE = 1
    C.setFillColor(col(NAVY))
    C.rect(0, 0, W, H, fill=1, stroke=0)
    C.bookmarkPage('p01')
    C.addOutlineEntry('研究价值与核心结果速览', 'p01', 0, False)
    PAGES.append(dict(page=1, title='研究价值与核心结果速览', source='主稿与补充稿'))
    text('VISUAL RESEARCH REVIEW   /   FINITE FIELDS AND PERMUTATION GROUPS', M, 42, 920, 12, 18, '#A7C6CF', 'ENB')
    rect(M, 98, 77, 5, GOLD, 2)
    text('范数纤维、精确阶<br/>与例外迹群', M, 131, 700, 47, 67, WHITE, 'CNB', maxh=140)
    text('把有效估计推进到完整分类，<br/>并解释两组例外为何出现。', M+2, 310, 670, 24, 38, '#D5E6E9', 'CN', maxh=82)
    text('特征二有限域 · 规定伴随置换 · 理论价值与研究前景', M+2, 424, 720, 17, 27, '#A7C6CF')
    text('Norm-fiber densities and relative traces in characteristic two', M+2, 478, 700, 16, 24, WHITE, 'EN')
    text('主稿与补充稿中文图解 / Baohua Li', M+2, 515, 700, 16, 25, '#A7C6CF')
    cx, cy = 870, 332
    for r, c in [(156, '#24485B'), (111, '#326172'), (65, '#24485B')]:
        C.setStrokeColor(col(c)); C.setLineWidth(1.2)
        C.circle(cx, H-cy, r, fill=0, stroke=1)
    pts=[]
    for i in range(33):
        a=2*pi*i/33-pi/2
        x,y=cx+111*cos(a),cy+111*sin(a)
        color=GOLD if i%3==0 else ('#62B8BA' if i in [11,22] else '#7198AC')
        dot(x,y,5.5,color)
        pts.append((x,y))
    for i in range(0,33,3):
        a,b=pts[i],pts[(i+12)%33]
        line(*a,*b,'#345B68',0.8)
    text('C₉', 814, 270, 112, 40, 55, '#E8F1F2', 'Math', 1)
    text('C₁₁', 815, 342, 112, 40, 55, GOLD, 'Math', 1)
    text('两组可解释的例外', 758, 490, 266, 15, 24, '#A7C6CF', align=1)
    footer('学术交流材料 · 当前主稿与补充稿', 0, True)


def page02():
    start('先看价值：最值得读的三件事', '核心判断：这是一项有明确专业领域增量的研究，亮点在有效尺度、完整例外及结构解释。', 0, '判断依据：主稿 §§3-6；附录D')
    rect(M,177,CW,73,NAVY,14)
    text('优先关注：定理5.1的统一估计 + 定理5.4的全参数分类',M+24,196,CW-48,24,35,WHITE,'CNB',maxh=40)
    items=[('01  有效尺度','把环境域尺度的误差，降到能分辨主项的基域尺度。<br/><br/>价值：从形式上的计数界，进入可用的密度与存在性结论。',LT,TEAL),
           ('02  完整例外','全部非零相对迹都被覆盖；零值只出现在两组明确的子群。<br/><br/>价值：从“大参数存在”，推进到精确的全参数描述。',LB,BLUE),
           ('03  结构解释','循环卷积与取逆支持揭示空切片机制，并连接规定的仿射群生成。<br/><br/>价值：结果可以被理解、核查，并为推广提供接口。',LG,GOLD)]
    for i,(a,b,bg,ac) in enumerate(items):
        card(M+i*329,274,310,257,a,b,bg,ac,size=17,title_size=22)
    banner('进一步的理论价值：从具体参数族的强结果，走向更可复用的结构定理。',552,h=56)


def page03():
    start('理论新性应落在什么位置？', '把已有对象、经典工具和本文建立的具体结果分开，才能准确判断论文的分量。', 0, '主稿引言、§7、附录D；补充稿 S7')
    rows=[('计数对象','规定阶、范数、迹；相邻满阶元素','已有长期研究背景',LB,BLUE),
          ('基本工具','本原元指示函数、曲线特征和、Lang覆盖、CRT','经典工具的严格特化',WHITE,MUTED),
          ('实质增量','基域尺度有效误差；全部 E* 上的统一估计','需要具体几何与算术验证',LT,TEAL),
          ('核心亮点','C₉/C₁₁完整分类；支持机制；精确分布','可明确陈述、核查与继续推广',LG,GOLD)]
    for i,(a,b,c,bg,ac) in enumerate(rows):
        y=176+i*86
        rect(M,y,CW,74,bg,12)
        text(a,M+20,y+23,145,19,27,ac,'CNB')
        text(b,M+182,y+17,470,17,25,INK,maxh=52)
        text(c,M+697,y+22,250,15.5,24,MUTED,maxh=49)
    banner('价值定位：专门领域的定量推进与完整分类；更一般的方法论仍是可争取的提升。',548,h=62,size=18)


def page04():
    start('一张图看懂研究如何连起来', '同一个“规定伴随关系”，把置换群问题转化为有限域计数，再进入几何与精确分类。', 1, '主稿 §§2-6；补充稿 S1-S8')
    titles=['规定的伴随对','仿射群结构','相邻元素的阶','范数纤维与迹','有效估计与分类']
    bodies=['f 与 F(f)<br/>并非任取两生成元','平移模 + 线性补群<br/>给出可检验条件','共同生成<br/>或各自满阶','四次范数塔<br/>亏格一曲线','密度 / 全部例外<br/>分布 / 指数边界']
    for i in range(5):
        x=M+i*197
        card(x,221,180,176,titles[i],bodies[i],LT if i in [0,4] else WHITE,TEAL if i in [0,4] else BLUE,size=16,title_size=19)
        if i<4: arrow(x+183,307,x+193,307,TEAL,1.8,5)
    for i,(title,body,target) in enumerate([
        ('有限域研究者','先看统一迹估计与例外分类',10),
        ('群论 / 组合研究者','先看伴随生成、线展与非线性例子',5),
        ('关注研究定位的读者','先看价值判断、期刊对标与开放问题',18)]):
        x=M+i*329
        card(x,454,310,122,title,body,LB,BLUE,16,20)
        C.linkRect('',f'p{target:02d}',(x,H-576,x+310,H-454),relative=0,thickness=0)


def page05():
    start('规定伴随对：群论问题的入口', '完全映射要求 f 与 id+f 都是置换；伴随 F(f) 由 f 唯一确定。',1,'主稿 §2；补充稿 S3')
    card(M,179,464,142,'完全映射','x ↦ f(x) 是置换<br/>x ↦ x+f(x) 也是置换',LT,TEAL,19,22)
    card(560,179,464,142,'经典三重对称','F(f)=(id+f)⁻¹<br/>施加三次伴随操作，回到 f。',LB,BLUE,19,22)
    rect(M,337,CW,104,WHITE,15)
    small('一般仿射映射 f(x)=Mx+c 的精确生成公式',M+24,350,CW-48)
    formula('⟨f,F(f)⟩ = F<sub>2</sub>[M]c ⋊ ⟨M,(I+M)<super>−1</super>⟩',M+20,381,CW-40,30)
    card(M,468,464,124,'平移部分','由 c、Mc、M²c 等张成；决定能到达哪些点。',LT,TEAL,17,21)
    card(560,468,464,124,'线性部分','适用于可约与非半单矩阵；导出群作用判据。',WHITE,BLUE,17,21)


def page06():
    start('先分清：“共同生成”与“各自满阶”', '两个要求不同，因而主项系数、计数对象和群实现条件也不同。',1,'主稿引言、§2及§4')
    card(M,182,464,280,'共同生成 C<sub>d</sub>','允许两元素分别提供不同的素因子贡献。<br/><br/>判据是二者的阶合起来覆盖 d。',LT,TEAL,19,24)
    formula('lcm(ord(a),ord(1+a)) = d',M+20,376,424,26)
    card(560,182,464,280,'二者各自都有阶 d','每一个元素都必须独立满足全部素因子的阶要求。<br/><br/>这是更强的条件。',LB,BLUE,19,24)
    formula('ord(a) = ord(1+a) = d',580,376,424,27)
    rect(M,488,CW,100,WHITE,13)
    text('抽象示意',M+20,506,135,19,28,TEAL,'CNB')
    text('在 C₁₅ 中，阶为3与5的两个元素可以共同生成 C₁₅，但各自都没有阶15。',M+170,503,770,19,29,INK,maxh=60)
    small('这里仅说明循环群概念差别，不把该抽象示意认作具体相邻元素对。',M,602,CW,size=11)


def page07():
    start('四次范数塔：把加法和乘法放到一起', 't=2ˢ，s≥2。研究对象是 L 到 K 的范数为1的乘法子群。',1,'主稿 §3')
    xs=[M,399,742]
    for x,name,field,size in [(xs[0],'基域 K','F<sub>t</sub>','t 个元素'),(xs[1],'中间域 E','F<sub>t²</sub>','t² 个元素'),(xs[2],'环境域 L','F<sub>t⁴</sub>','t⁴ 个元素')]:
        rect(x,191,282,155,WHITE,16)
        text(name,x+20,211,242,22,31,TEAL,'CNB')
        formula(field,x+20,251,242,34)
        small(size,x+20,309,242)
    arrow(391,274,345,274,TEAL);arrow(734,274,688,274,TEAL)
    small('范数',347,237,50,TEAL,12);small('范数',690,237,50,TEAL,12)
    rect(M,381,CW,112,NAVY,16)
    formula('C<sub>d</sub> = ker N<sub>L/K</sub> ,    d=(t+1)(t²+1)',M+24,401,CW-48,31,WHITE)
    text('指数为 t−1 的特殊子群：几何与乘法阶在这里交汇。',M+24,454,CW-48,17,25,'#BBD5DB',align=1)
    card(M,520,464,80,'范数：把共轭相乘','',LT,TEAL,title_size=22)
    card(560,520,464,80,'迹：把共轭相加','',LB,BLUE,title_size=22)


def page08():
    start('为什么误差尺度的改进有意义？', '主项约为 t²。若误差也达到 t²，计数界就可能无法判断真正的密度与存在性。',2,'主稿 §§3-4；图示仅比较 t 的幂次，省略算术因子')
    text('幂次尺度示意',M,181,500,18,27,MUTED,'CNB')
    bars=[(233,'目标主项','t²',BLUE,420),(345,'环境域一般平方根尺度','t²',GOLD,420),(457,'纤维方法累计误差','t<super>3/2</super>',TEAL,315)]
    for y,label,term,color,length in bars:
        text(label,M,y-24,450,17,25,INK)
        rect(M,y+13,length,24,color,5)
        formula(term,M+length+16,y+3,125,26,color,0)
    cards=[('分解','约 t 个范数纤维'),('逐纤维控制','每纤维约t点；特征和≤8√t'),('再组合','t×√t，再乘算术因子')]
    for i,(a,b) in enumerate(cards):
        card(652,180+i*131,372,111,a,b,WHITE,TEAL,16.5,21)
    banner('理论收益：用较小基域上的曲线几何，获得真正能支撑渐近与存在性的误差。',554,h=56,size=18)


def page09():
    start('两类密度：系数不同，含义也不同', '局部素数障碍经过精确平均，形成两个具有不同含义的主项。',2,'主稿 §4：共同生成密度与双满阶计数')
    rect(M,177,CW,111,LT,15)
    text('共同生成',M+22,194,190,22,31,TEAL,'CNB')
    formula('|ℛ<sub>d</sub>| = θ₂(d)(t+1)² + O(t<super>3/2</super>W(d))',M+212,205,734,27)
    rect(M,312,CW,111,LB,15)
    text('二者各自满阶',M+22,329,190,22,31,BLUE,'CNB')
    formula('D<sub>d</sub> ∼ θ(d)²(t+1)²',M+212,340,734,30)
    card(M,451,464,145,'为什么是 1−p⁻²？','共同生成失败，需要二者同时落入相应真子群。<br/>θ₂(d)=∏<sub>p|d</sub>(1−p⁻²)。',WHITE,TEAL,16.5,21)
    card(560,451,464,145,'为什么是 (1−p⁻¹)²？','各自满阶要求二者分别避开真子群。<br/>θ(d)=φ(d)/d；对每个 s≥2，D<sub>d</sub>>0。',WHITE,BLUE,16.5,21)
    small('记号：W(d)=2<super>ω(d)</super>，ω(d) 为 d 的不同素因子个数；∼ 表示实际数量与主项之比趋于1。',M,603,CW,size=11.5)


def page10():
    start('定理5.1：统一控制每一个非零相对迹', '在 C<sub>d</sub> 中先固定 a+a<super>t²</super>=c，再筛出乘法阶恰好为 d 的元素。',2,'主稿 定理5.1；Q_c 的精确中心见 §5.2')
    blocks=[(M,280,'C<sub>d</sub>','范数为1的全部元素',WHITE),(400,280,'Q<sub>c</sub>','固定相对迹 c',LB),(744,280,'M<sub>c</sub>','再加精确阶 d',LT)]
    for x,w,a,b,bg in blocks:
        card(x,182,w,127,a,b,bg,TEAL if a.startswith('M') else BLUE,17,25)
    arrow(345,247,390,247,BLUE);arrow(689,247,734,247,TEAL)
    rect(M,343,CW,112,NAVY,15)
    small('对全部 c∈E*，使用同一组显式常数',M+24,354,CW-48,'#B7D1D8',14)
    formula('|M<sub>c</sub> − θ(d)(t+1)| ≤ θ(d)(4W(d)−2)√t',M+20,392,CW-40,29,WHITE)
    card(M,484,464,119,'未筛选总体的波动','Q<sub>c</sub> 用经典二元 Kloosterman 和精确表达。',WHITE,BLUE,16.5,21)
    card(560,484,464,119,'精确阶筛选的波动','四边界点曲线上的 4√t 特征和界控制筛选误差。',WHITE,TEAL,16.5,21)


def ring(cx,cy,r,n,color_fn,dot_r=5.5):
    C.setStrokeColor(col(LINE));C.setLineWidth(1)
    C.circle(cx,H-cy,r,fill=0,stroke=1)
    for i in range(n):
        a=2*pi*i/n-pi/2
        dot(cx+r*cos(a),cy+r*sin(a),dot_r,color_fn(i))


def page11():
    start('定理5.4：空切片只有两组', '这是全部非零 c∈E* 的分类；其余非零相对迹都有精确阶 d 的元素。',2,'主稿 定理5.4；环形图只画迹范数为1的类 U')
    rect(M,176,464,331,WHITE,17)
    rect(560,176,464,331,WHITE,17)
    text('t=8 / s=3',M+22,195,420,24,34,TEAL,'CNB')
    text('t=32 / s=5',582,195,420,24,34,BLUE,'CNB')
    ring(185,347,77,9,lambda i:RED,7)
    formula('C₉',115,318,140,36,RED)
    text('c⁹=1<br/>恰好9个非零迹',294,294,200,23,37,INK,'CNB')
    small('U=C₉：全部为空',M+23,455,420,RED,16)
    ring(689,347,79,33,lambda i:RED if i%3==0 else TEAL if i in [11,22] else BLUE,5.3)
    formula('C₁₁',619,319,140,33,RED)
    text('c¹¹=1<br/>恰好11个非零迹',800,294,200,23,37,INK,'CNB')
    small('U=C₃₃：红色 C₁₁ 为空',583,455,420,RED,16)
    banner('空的是“满阶切片”：未筛选的 Q<sub>c</sub> 仍非空。零迹 c=0 则始终有 M₀=0。',535,bg=LR,color=RED,h=67,size=18)


def support_grid(x,y,support):
    p,q=5,3
    cell=49
    zeros=[]
    for a in range(p):
        for b in range(q):
            zero=all(z[0]==a or z[1]==b for z in support)
            if zero: zeros.append((a,b))
            xx,yy=x+a*cell,y+(q-1-b)*cell
            rect(xx,yy,cell-4,cell-4,LG if zero else '#F2F5F5',5,
                 stroke=GOLD if zero else None,lw=1.7)
            if (a,b) in support:
                dot(xx+(cell-4)/2,yy+(cell-4)/2,8,TEAL if (a,b)==(0,0) else BLUE)
    for a in range(p): small(str(a),x+a*cell+16,y+q*cell+8,20,size=11)
    for b in range(q): small(str(b),x-23,y+(q-1-b)*cell+12,20,size=11)
    small('C₅ 坐标',x+70,y+q*cell+35,145,size=12)
    small('C₃',x-33,y-27,60,size=12)
    return zeros


def page12():
    start('支持结构：把“空”变成一个覆盖问题', '双素数商群模型：支持取逆稳定，且代表位置非空。零值要求支持被一行与一列共同覆盖。',2,'主稿 §5：取逆支持引理；CRT框架为经典背景')
    rect(M,179,464,328,WHITE,16);rect(560,179,464,328,WHITE,16)
    text('一对互逆生成元',M+22,196,420,22,32,BLUE,'CNB')
    text('加入第三个支持像',582,196,420,22,32,TEAL,'CNB')
    z1=support_grid(158,267,{(1,1),(4,2)})
    z2=support_grid(662,267,{(1,1),(4,2),(0,0)})
    assert set(z1)=={(1,2),(4,1)} and not z2
    small('蓝点：支持；金色格：两个混合角点',M+22,468,420,BLUE,14)
    small('第三个不同支持像排除双素数障碍',582,468,420,TEAL,14)
    card(M,533,464,74,'C₉机制：所需支持缺失','',LR,RED,title_size=20)
    card(560,533,464,74,'C₁₁机制：支持局限于素数坐标核','',LG,GOLD,title_size=18)


def page13():
    start('从“是否存在”走向“如何分布”', '卷积给出同一迹范数类中的精确均值与方差；缩放把范数1的分类转移到任意非零K范数。',2,'主稿 命题5.5、推论5.6-5.7')
    text('t=32：U=C₃₃ 上的精确分布',M,184,470,20,31,INK,'CNB')
    rows=[('C₁₁','11 个迹值','0',RED,LR),('C₃ 去掉单位元','2 个迹值','20',TEAL,LT),('其余位置','20 个迹值','18',BLUE,LB)]
    for i,(a,b,c,ac,bg) in enumerate(rows):
        y=232+i*94
        rect(M,y,464,79,bg,12)
        text(a,M+18,y+12,245,18,27,ac,'CNB')
        small(b,M+18,y+43,230,size=14)
        formula(c,M+302,y+11,143,35,ac)
    small('右侧数字为每个切片的 M<sub>c</sub>，不是迹值个数。',M,529,464,size=13)
    card(560,180,464,165,'任意非零范数 ν','选 λ∈K*，使 λ⁴=ν；令 a=λb。<br/>范数移回1，相对迹按 λ 同步缩放。',WHITE,TEAL,18,23)
    card(560,365,464,177,'纤维内的最大可能阶','最大阶为 ord(ν)d。<br/>若 ν 是 K 的本原元，对应的满阶元素就是 L 的本原元。',WHITE,BLUE,18,23)
    banner('分布信息更细：方差界不含逐点估计中的 W(t+1) 因子。',566,h=42,size=17)


def page14():
    start('四分之一次幂：统一指数的边界', 'k=(q−1)/d。下图定位的是幂指数；精确的普适临界范围仍有对数缺口。',2,'主稿 §6；横轴为位置示意，不按数值比例')
    rect(M,180,CW,101,WHITE,14)
    text('统一充分范围 / n≥16',M+22,197,350,20,30,TEAL,'CNB')
    formula('k ≤ q<super>1/4</super> / √(log₂q)',412,204,580,34,TEAL)
    line(105,378,981,378,LINE,3)
    rect(107,364,270,28,LT,8)
    dot(377,378,8,TEAL);dot(719,378,8,BLUE);dot(836,378,8,GOLD);dot(953,378,8,RED)
    text('统一可证范围',91,308,280,18,28,TEAL,'CNB',1)
    text('四次范数族可实现',600,310,225,17,27,BLUE,'CNB',1)
    formula('q<super>1/4</super>−1',620,409,200,29,BLUE)
    formula('q<super>1/4</super>',778,315,116,29,GOLD)
    formula('q<super>1/4</super>+1',880,409,170,29,RED)
    small('本原但受范数障碍阻止',809,465,230,RED,14)
    line(836,351,836,463,GOLD,1)
    text('对数缺口',428,409,210,18,27,MUTED,align=1)
    arrow(410,420,610,420,MUTED,1.2,6)
    banner('意义：最佳统一幂指数被定位在 1/4；消除或缩小对数损失是有价值的后续问题。',548,h=61,size=18)


def triangle(cx,cy,labels,r=28):
    pts=[(cx+r*cos(-pi/2+2*pi*i/3),cy+r*sin(-pi/2+2*pi*i/3)) for i in range(3)]
    for i in range(3):
        a,b=pts[i],pts[(i+1)%3]
        arrow(*a,*b,TEAL,1.5,5)
    for (x,y),label in zip(pts,labels):
        dot(x,y,12,WHITE,TEAL,1.2)
        text(str(label),x-14,y-9,28,11,17,INK,'ENB',1)


def page15():
    start('补充稿：坐标构造与定向线展', '显式模型让抽象结果可见；几何对应把 F-固定映射的分类变成线展及其定向的分类。',3,'补充稿 S1-S3；四维完整分类与六维标准线展范围见 S3')
    card(M,179,464,335,'Singer型坐标构造','六维二元空间：64个点。<br/>非零向量由一个63循环贯穿。',WHITE,TEAL,17,23)
    ring(184,394,71,63,lambda i:TEAL if i%7==0 else '#B5D6D7',2.5)
    dot(184,394,5,GOLD)
    text('0',174,403,30,12,18,MUTED,'EN',1)
    formula('64×63',287,358,206,31,TEAL)
    formula('=4032',287,408,206,31,TEAL)
    small('并给出任意偶数维的 Singer 型构造。',M+22,483,420,TEAL,13)
    card(560,179,464,335,'F(f)=f ↔ 定向线展','每个三循环是 {x,y,x+y}。<br/>下图给出四维标准线展的5条线。',WHITE,BLUE,17,23)
    for cx,cy,labels in [(650,344,(1,2,3)),(790,344,(4,8,12)),(930,344,(5,10,15)),
                         (720,448,(6,11,13)),(860,448,(7,9,14))]:
        triangle(cx,cy,labels)
    banner('四维：1792个 F-固定映射、3个共轭类。六维标准线展：80类；其他线展类型不在此计数范围。',542,h=66,size=16.5)


def page16():
    start('非线性例子：规定伴随对生成 A₁₆', '一个具体构造展示仿射框架以外的群结构，并给出可以逐步核查的群论证明。',3,'补充稿 S4；显式置换、三循环及证明均已列出')
    rect(M,180,464,362,WHITE,16)
    text('f：一个15循环 + 固定点3',M+22,197,420,20,30,INK,'CNB')
    order=[0,1,5,7,10,9,14,6,15,4,11,13,8,2,12]
    cx,cy,r=288,388,108
    for i,v in enumerate(order):
        a=2*pi*i/15-pi/2;b=2*pi*(i+1)/15-pi/2
        arrow(cx+r*cos(a),cy+r*sin(a),cx+r*cos(b),cy+r*sin(b),LINE,1.4,5)
    for i,v in enumerate(order):
        a=2*pi*i/15-pi/2;x,y=cx+r*cos(a),cy+r*sin(a)
        dot(x,y,12,LT,TEAL,1.2)
        text(str(v),x-15,y-9,30,11.5,17,TEAL,'ENB',1)
    dot(cx,cy,24,LG)
    text('3',cx-18,cy-16,36,23,32,GOLD,'ENB',1)
    steps=[('规定关系','g=F(f)；两置换的固定点不同。'),('找到短循环','令 w=f²g，有 w³⁵=(3 0 14)。'),('完成群论推导','双传递性与三循环共同给出 ⟨f,g⟩=A₁₆。')]
    for i,(a,b) in enumerate(steps):
        card(560,180+i*126,464,109,a,b,WHITE,TEAL if i<2 else BLUE,17,21)
    banner('仿射生成群为亚交换群；这个非线性伴随对达到非交换单群。',566,h=43,size=17)


def page17():
    start('与前驱对标：增量落在“有效与完整”', '相关对象与工具有清晰前驱。本文的主张应由具体参数、误差和分类范围支撑。',0,'详细条件代入：主稿附录D；补充稿 S7；文献见末页')
    rows=[('Cohen / Özbudak 等','规定阶与迹、相关元素的阶','计数对象与框架先有；本文控制特定范数族中的更细尺度。'),
          ('Rani 等，2023 [J1]','规定阶、范数、迹与 k-normal','核查其充分条件的参数代入；本文给出全 E* 统一界及完整例外。'),
          ('Hachenberger，2015 [L2]','四次扩张的本原正规几何','聚合计数不决定某一个指定迹切片；本文刻画个别切片。'),
          ('经典曲线 / CRT 工具','Weil型界、Lang覆盖、循环群分解','新增内容在具体几何检验、局部系数、支持约束与全参数闭合。')]
    for i,(a,b,c) in enumerate(rows):
        y=178+i*91
        rect(M,y,CW,80,WHITE if i%2 else LB,12)
        text(a,M+18,y+15,267,17,25,TEAL,'CNB',maxh=54)
        text(b,M+306,y+15,245,16,24,INK,maxh=54)
        text(c,M+590,y+12,356,15.5,24,INK,maxh=57)
    banner('新性主要体现于有效性、分类完整性与例外结构；经典方法和先有对象均有明确归属。',559,h=49,size=16.5)


def page18():
    start('意向期刊：按研究问题与代表论文对标', '优先讨论领域匹配与数学贡献的表达；下列定位是研究判断，不是接收概率或年度分区认定。',4,'核对日期 2026-10-26；[J1]-[J3] 为出版方一手页面，见末页')
    journals=[
        ('Finite Fields and<br/>Their Applications','最直接的领域目标 [J1]',TEAL,LT,
         '已有规定阶、范数与迹的<br/>相近主题论文，<br/>契合本文的中心问题。',
         '突出基域尺度、统一迹估计与完整例外；让前驱比较可逐项核查。',
         'https://www.sciencedirect.com/science/article/pii/S1071579723000953'),
        ('Designs, Codes<br/>and Cryptography','相关方向对标 [J2]',BLUE,LB,
         '官方范围明确覆盖有限域、有限几何及其代数和几何理论。',
         '强化范数几何、完全映射与线展的联系，保持主结果集中。',
         'https://link.springer.com/journal/10623/aims-and-scope'),
        ('Advances in Mathematics<br/>of Communications','有条件的候选 [J3]',GOLD,LG,
         '范围含有限几何、代数、数论和计算方法，并重视通信相关性。',
         '若选择该刊，需要建立具体、真实的相关性，不能仅以应用名词包装。',
         'https://www.aimsciences.org/AMC')]
    for i,(name,status,ac,bg,match,action,url) in enumerate(journals):
        y=179+i*129
        rect(M,y,CW,114,bg,14)
        text(name,M+20,y+13,320,18,26,INK,'ENB',maxh=55)
        small(status,M+20,y+79,320,ac,13)
        text(match,M+374,y+18,270,16,25,INK,maxh=79)
        text(action,M+682,y+18,266,16,25,INK,maxh=79)
        C.linkURL(url,(M,H-y-114,M+346,H-y),relative=0,thickness=0)
    small('定位判断：FFA 是当前最直接的领域对标；投稿前应完成独立复核并进一步凝练主结果。',M,588,CW,TEAL,14)


def page19():
    start('仍值得深入的三个理论问题', '现有结果留下明确的延伸空间。以下是开放方向，尚未被本文的已证结论覆盖。',4,'主稿 §7 的开放方向与当前支持引理的适用边界')
    tasks=[('A','支持结构的一般化','在明确附加条件下，研究三个及以上素数坐标的障碍；当前无条件推广已有反例。',
            '潜在成果：可被其他参数族直接引用的结构定理。',TEAL,LT),
           ('B','收紧统一有效范围','分析筛法与算术因子，争取缩小 q<super>1/4</super> 范围中的对数损失。',
            '潜在成果：更强的统一定量结论；难度较高。',BLUE,LB),
           ('C','扩展范数纤维几何','考虑其他扩张或更高范数塔；重新处理奇异纤维、边界分歧和常值特征。',
            '潜在成果：适用面更广的几何计数框架。',GOLD,LG)]
    for i,(letter,title,body,result,ac,bg) in enumerate(tasks):
        y=179+i*139
        rect(M,y,CW,124,bg,14)
        text(letter,M+18,y+28,62,35,48,ac,'ENB',1)
        text(title,M+106,y+16,825,22,31,ac,'CNB')
        text(body,M+106,y+56,825,16.5,25,INK,maxh=51)
        text(result,M+106,y+95,825,14,21,MUTED,maxh=22)


def page20():
    start('这套框架的可复用价值在哪里？', '三个接口把具体计算组织成可以继续研究的数学结构。其适用范围仍需逐项验证。',4,'研究特点：局部估计、支持障碍与规定伴随生成之间的联系')
    cols=[('局部估计 → 全局分布','范数纤维上的几何控制，经过局部系数平均，形成密度与统一迹估计。<br/><br/>接口：哪些曲线族允许同类有效平均？',LT,TEAL),
          ('有限例外 → 结构障碍','空切片可以由支持缺失、素数坐标核或极小商群支持解释。<br/><br/>接口：何种附加假设能保证更一般的分类？',LB,BLUE),
          ('元素算术 → 置换群','相邻元素的联合阶条件，决定规定伴随对的标量仿射实现。<br/><br/>接口：哪些算术族能产生新的群实现边界？',LG,GOLD)]
    for i,(a,b,bg,ac) in enumerate(cols):
        card(M+i*329,194,310,296,a,b,bg,ac,18,24)
    rect(M,522,CW,82,NAVY,14)
    text('值得重视的特点',M+22,538,267,22,31,WHITE,'CNB')
    text('结果有精确对象，例外有可解释机制，推广也有可以检验的具体边界。',M+316,538,628,20,31,'#D5E6E9',maxh=63)


def page21():
    start('可信度来自清楚的证明与核验边界', '理论证明、精确计算和选择性形式化相互支持，各自覆盖的范围应明确可查。',4,'主稿附录B-C；补充稿附录 S.B；formalization/InverseSupportGrid.lean')
    cards=[('一般数学证明','几何估计、密度定理与<br/>无限参数范围。<br/><br/>完整例外分类的逻辑链。','已在主稿给出',TEAL,LT),
           ('精确算术与证书','有限小参数、元素阶、多项式恒等式、代表与支持分离见证。','有数据与验证器',BLUE,LB),
           ('Lean选择性形式化','六个支持集组合引理；另有基础模块。完整5.1/5.4及几何估计未整体形式化。','边界明确可查',GOLD,LG)]
    for i,(a,b,status,ac,bg) in enumerate(cards):
        x=M+i*329
        card(x,190,310,280,a,b,bg,ac,17.5,22)
        tag(status,x+22,421,266,ac,WHITE)
    card(M,501,CW,105,'证明、证书与形式化的覆盖范围均可查','文献定位以所列前驱及其条件为范围；有限测试不替代一般证明，完整结果尚未经外部同行评审。',WHITE,TEAL,16.5,20)


def reference(key,title,detail,url,y):
    text(key,M,y,75,14,21,TEAL,'ENB')
    text(title,M+82,y,CW-82,14,21,INK,'CNB',maxh=43)
    small(detail,M+82,y+25,CW-82,size=11.5)
    C.linkURL(url,(M+78,H-y-48,W-M,H-y+2),relative=0,thickness=0)


def page22():
    start('阅读与文献导航', '先判断价值与兴趣，再进入最相关的证明。下列出版方链接可点击；期刊匹配判断为本综述的分析。',4,'依据：当前主稿40页、补充稿36页')
    routes=[('5分钟看价值','本综述 2-3、11、18-19页',2),('30分钟看核心','主稿引言、第5节及第7节',10),('深入查看证明','主稿 §§3-4、附录D；补充稿 S3、S4、S7',8)]
    for i,(a,b,target) in enumerate(routes):
        x=M+i*329
        card(x,174,310,124,a,b,LT if i==0 else WHITE,TEAL,14.5,20)
        C.linkRect('',f'p{target:02d}',(x,H-298,x+310,H-174),relative=0,thickness=0)
    reference('[J1]','Rani et al. / Finite Fields and Their Applications (2023)',
        'On r-primitive k-normal elements with prescribed norm and trace over finite fields · DOI: 10.1016/j.ffa.2023.102253',
        'https://www.sciencedirect.com/science/article/pii/S1071579723000953',307)
    reference('[J2]','Designs, Codes and Cryptography / 官方 Aims and scope',
        'link.springer.com/journal/10623/aims-and-scope',
        'https://link.springer.com/journal/10623/aims-and-scope',359)
    reference('[J3]','Advances in Mathematics of Communications / 官方期刊页',
        'aimsciences.org/AMC', 'https://www.aimsciences.org/AMC',411)
    reference('[L1]','Cohen (2003) / The orders of related elements of a finite field',
        'Ramanujan Journal 7, 169-183 · DOI: 10.1023/A:1026295128600',
        'https://doi.org/10.1023/A:1026295128600',463)
    reference('[L2]','Hachenberger (2015) / Primitive normal bases for quartic and cubic extensions: a geometric approach',
        'Designs, Codes and Cryptography 77, 335-350 · DOI: 10.1007/s10623-015-0051-0',
        'https://doi.org/10.1007/s10623-015-0051-0',515)
    reference('[L3]','Özbudak (2005) / Elements of prescribed order, prescribed traces and systems of rational functions over finite fields',
        'Designs, Codes and Cryptography 34, 35-54 · DOI: 10.1007/s10623-003-4193-0',
        'https://doi.org/10.1007/s10623-003-4193-0',567)


def finish():
    assert PAGE==TOTAL
    C.save()
    reader=PdfReader(OUT)
    assert len(reader.pages)==TOTAL
    text_all='\n'.join(p.extract_text() or '' for p in reader.pages)
    for needle in ['定理5.1','定理5.4','支持结构','意向期刊','理论价值','1792','4032']:
        assert needle in text_all, needle
    for excluded in ['合作','联名','邀请','求助','共同研究','共同推进','共同复核','COLLABORATION','52页','旧稿']:
        assert excluded not in text_all, excluded
    page_sizes=[]
    for p in reader.pages:
        assert float(p.mediabox.width)==W and float(p.mediabox.height)==H
        page_sizes.append([float(p.mediabox.width),float(p.mediabox.height)])
    report=dict(status='GENERATED_AWAITING_VISUAL_REVIEW',pages=TOTAL,
        pdf=str(OUT),sha256=hashlib.sha256(OUT.read_bytes()).hexdigest(),
        page_size_points=[W,H],text_blocks=len(TEXT_BOXES),font_glyph_checks_passed=True,
        bookmarks=len(reader.outline),links=sum(len(p.get('/Annots',[])) for p in reader.pages),
        source_main_sha256=hashlib.sha256((PAPER/'main.pdf').read_bytes()).hexdigest(),
        source_supplement_sha256=hashlib.sha256((PAPER/'supplement.pdf').read_bytes()).hexdigest(),
        old_manuscript_comparison_included=False,
        focus='Research value, calibrated novelty, journal fit and theoretical research perspectives')
    (HERE/'build_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (HERE/'page_map.json').write_text(json.dumps(PAGES,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (HERE/'text_layout.json').write_text(json.dumps(TEXT_BOXES,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (HERE/'extracted_text.txt').write_text(text_all,encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))


def main():
    cover()
    for fn in [page02,page03,page04,page05,page06,page07,page08,page09,page10,page11,
               page12,page13,page14,page15,page16,page17,page18,page19,page20,page21,page22]:
        fn()
    finish()


if __name__=='__main__':
    main()

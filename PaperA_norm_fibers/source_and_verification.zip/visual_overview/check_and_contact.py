"""Check embedded fonts and links, and produce contacts for human visual review."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from pypdf import PdfReader
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
PDF=HERE.parent/'PaperA_中文图解学术综述.pdf'
RENDER=ROOT/'tmp/pdfs/paperA-visual-brief'
reader=PdfReader(PDF)
pages=sorted(RENDER.glob('page-[0-9][0-9].png'))
assert len(pages)==len(reader.pages)==22
font_checks={}
for page in reader.pages:
    for ref in page['/Resources']['/Font'].get_object().values():
        font=ref.get_object()
        desc=font.get('/FontDescriptor')
        if desc:
            desc=desc.get_object()
            font_checks[str(font['/BaseFont'])]=any(k in desc for k in ['/FontFile','/FontFile2','/FontFile3'])
        elif str(font['/BaseFont']) not in ['/Helvetica','/Times-Roman','/Courier']:
            raise RuntimeError('Unexpected unembedded font: '+str(font))
assert font_checks and all(font_checks.values())
text='\n'.join(p.extract_text() or '' for p in reader.pages)
for item in ['合作','联名','邀请','求助','COLLABORATION','旧稿','52页']:
    assert item not in text
all_annots=[]
for i,page in enumerate(reader.pages,1):
    for ref in page.get('/Annots',[]):
        a=ref.get_object()
        all_annots.append(dict(page=i,action=str(a.get('/A','')),destination=str(a.get('/Dest',''))))
fonts=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',21)
contacts=[]
for start in range(0,22,4):
    sheet=Image.new('RGB',(1600,1080),'#d8e0e2')
    draw=ImageDraw.Draw(sheet)
    for j,p in enumerate(pages[start:start+4]):
        img=Image.open(p).convert('RGB')
        img.thumbnail((780,490),Image.Resampling.LANCZOS)
        x=10+(j%2)*800;y=36+(j//2)*540
        draw.text((x,y-29),f'PAGE {start+j+1:02d}',font=fonts,fill='#183447')
        sheet.paste(img,(x,y))
    target=RENDER/f'contact-{start//4+1:02d}.jpg'
    sheet.save(target,quality=92)
    contacts.append(str(target))
report=dict(status='PASS_TECHNICAL_VISUAL_REVIEW_PENDING',pages=22,
    sha256=hashlib.sha256(PDF.read_bytes()).hexdigest(),
    embedded_fonts=font_checks,bookmarks=len(reader.outline),annotation_count=len(all_annots),
    excluded_word_scan_passed=True,contacts=contacts,render_dpi=110,
    page_images=[str(p) for p in pages],pdf_bytes=PDF.stat().st_size)
(HERE/'technical_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))

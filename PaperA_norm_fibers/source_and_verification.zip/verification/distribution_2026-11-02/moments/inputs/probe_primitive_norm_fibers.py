"""Bounded Paper A probe: complete primitive-norm fibers, s=2,...,8.

No manuscript is modified. Polynomial-basis arithmetic is implemented here;
the old file supplies only moduli and factorizations, all checked anew.
The old s=2,...,6 histogram is a comparison, not an input to the counts.
"""
from pathlib import Path
from math import gcd, isqrt, prod
from collections import Counter
import json
import hashlib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
OLD = ROOT / 'output/pdf/PaperA_restructured_2026-10-26/verification/author_runtime/inner_critical_certificates.json'


def factor(n):
    ans = []
    p = 2
    while p*p <= n:
        while n % p == 0:
            ans.append(p)
            n //= p
        p += 1
    if n > 1:
        ans.append(n)
    return ans


def pmul(a, b, mod):
    z = 0
    n = mod.bit_length()-1
    while b:
        if b & 1:
            z ^= a
        b >>= 1
        a <<= 1
        if a >> n:
            a ^= mod
    return z


def pgcd(a, b):
    while b:
        while a and a.bit_length() >= b.bit_length():
            a ^= b << (a.bit_length()-b.bit_length())
        a, b = b, a
    return a


class Field:
    def __init__(self, mod):
        self.mod = mod
        self.n = mod.bit_length()-1
        self.q = 1 << self.n
        # Rabin irreducibility test, no probabilistic tests.
        powers = [2]
        for _ in range(self.n):
            powers.append(pmul(powers[-1], powers[-1], mod))
        assert powers[-1] == 2
        for p in set(factor(self.n)):
            assert pgcd(powers[self.n//p] ^ 2, mod) == 1
        def rawpow(a, k):
            z = 1
            while k:
                if k & 1:
                    z = pmul(z, a, mod)
                a = pmul(a, a, mod)
                k >>= 1
            return z
        primes = set(factor(self.q-1))
        self.generator = next(a for a in range(2, self.q)
                              if all(rawpow(a, (self.q-1)//p) != 1 for p in primes))
        self.exp, self.log = [], [-1]*self.q
        z = 1
        for j in range(self.q-1):
            assert self.log[z] == -1
            self.log[z] = j
            self.exp.append(z)
            z = pmul(z, self.generator, mod)
        assert z == 1

    def mul(self, a, b):
        return self.exp[(self.log[a]+self.log[b]) % (self.q-1)] if a and b else 0

    def power(self, a, k):
        return self.exp[(self.log[a]*k) % (self.q-1)] if a else int(k == 0)

    def trace(self, a):
        z = 0
        for _ in range(self.n):
            z ^= a
            a = self.mul(a, a)
        assert z in (0, 1)
        return z


def tower_power(F, b, c, x, k):
    def mul(z, w):
        m = F.mul
        cross = m(z[0], w[1]) ^ m(z[1], w[0])
        yy = m(z[1], w[1])
        return (m(z[0], w[0]) ^ m(b, yy), cross ^ m(c, yy))
    z = (1, 0)
    while k:
        if k & 1:
            z = mul(z, x)
        x = mul(x, x)
        k >>= 1
    return z


def run(row):
    s = row['s']
    t = 1 << s
    A, B = t+1, t*t+1
    d = A*B
    assert sorted(row['A_factors']) == factor(A)
    assert sorted(row['B_factors']) == factor(B)
    F = Field(int(row['E_modulus_hex'], 16))
    assert F.n == 2*s
    u = F.power(F.generator, t-1)
    assert F.power(u, A) == 1
    assert all(F.power(u, A//p) != 1 for p in set(factor(A)))
    units = {j for j in range(A) if gcd(j, A) == 1}
    pending = set(units)
    orbits = []
    while pending:
        j = min(pending)
        orb, z = [], j
        while z not in orb:
            orb.append(z)
            z = 2*z % A
        assert z == j and set(orb) <= pending
        pending -= set(orb)
        orbits.append(orb)
    records = []
    for orb in orbits:
        j = orb[0]
        b = F.power(u, j)
        good_pairs = []
        trace_pairs = 0
        for k in sorted(units):
            w = F.power(u, k)
            c = 1 ^ b ^ w
            if not c or F.trace(F.mul(b, F.power(c, F.q-3))) != 1:
                continue
            trace_pairs += 1
            # Irreducibility implies both roots are outside E. Norms b,w
            # already force the A-primary parts to have full order.
            tp = lambda x, e: tower_power(F, b, c, x, e)
            assert tp((0, 1), B) == (b, 0)
            assert tp((1, 1), B) == (w, 0)
            assert tp((0, 1), d) == tp((1, 1), d) == (1, 0)
            residues = {str(p): [tp((0, 1), d//p), tp((1, 1), d//p)]
                        for p in set(factor(B))}
            if any(z == (1, 0) for pair in residues.values() for z in pair):
                continue
            good_pairs.append({'w_exponent': k, 'w': hex(w), 'c': hex(c),
                               'B_order_residues': residues})
        assert good_pairs
        special = {}
        if len(factor(A)) == len(factor(B)) == 1:
            population = 0
            for k in range(A):
                w = F.power(u, k)
                c = 1 ^ b ^ w
                if c and F.trace(F.mul(b, F.power(c, F.q-3))) == 1:
                    population += 2
            assert population % 4 == 0
            assert (population-A)**2 <= 4*t
            assert 2*len(good_pairs) == population-2*F.trace(b)
            assert isqrt(t)**2 == t
            assert 2*len(good_pairs) >= t+2-2*isqrt(t)
            special = {'population':population, 'trace_b':F.trace(b),
                       'proved_lower_bound':t+2-2*isqrt(t)}
        records.append({'norm_orbit_exponents': orb, 'b': hex(b),
                        'irreducible_primitive_norm_pairs': trace_pairs,
                        'D_d_b': 2*len(good_pairs), 'witness': good_pairs[0],
                        'prime_case_identity':special})
    hist = Counter()
    for r in records:
        hist[r['D_d_b']] += len(r['norm_orbit_exponents'])
    expected = {2:{2:4}, 3:{4:6}, 4:{14:8, 12:8}, 5:{12:20},
                6:{38:12, 44:24, 40:12}}
    if s in expected:
        assert hist == expected[s]
    ans = {'s':s, 't':t, 'A':A, 'B':B, 'd':d,
           'E_modulus':hex(F.mod), 'E_generator':hex(F.generator),
           'U_generator':hex(u), 'A_factors':factor(A), 'B_factors':factor(B),
           'number_primitive_norms':len(units), 'orbit_count':len(orbits),
           'D_histogram':dict(sorted(hist.items())),
           'D_total':sum(k*v for k,v in hist.items()), 'minimum':min(hist),
           'all_primitive_norms_positive':True, 'orbits':records}
    print(f's={s}: {len(orbits)} norm orbits, min={min(hist)}, histogram={dict(hist)}', flush=True)
    return ans


def main():
    assert __debug__
    rows = json.loads(OLD.read_text(encoding='utf-8'))['certificates']
    results = [run(row) for row in rows if 2 <= row['s'] <= 8]
    out = {'scope':'All primitive inner norms, exact finite range s=2,...,8. No all-s extrapolation.',
           'input_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),
           'arithmetic':'Self-contained polynomial basis; irreducibility and factors checked.',
           'coverage':'All primitive w for one representative of every doubling orbit of primitive b.',
           'results':results}
    (OUT/'primitive_norm_fiber_controls.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')


if __name__ == '__main__':
    main()

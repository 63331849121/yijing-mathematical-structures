"""Finite replay using previous review's polynomial/normalized-AS arithmetic.

No producer arithmetic imports, no logarithm tables, no Dickson order test.
Reconstructs all primitive-w entries of the Frobenius quotient at s=2,...,9.
This is a second arithmetic implementation, not an external expert review.
"""
from pathlib import Path
from fractions import Fraction
from math import gcd,prod,isqrt
import hashlib,json,time
import reference_review_arithmetic as arithmetic

HERE=Path(__file__).resolve().parent
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    started=time.time();src=HERE/'distribution_probe.json';before=sha(src)
    original=json.loads(src.read_text())
    # The stored producer paths may be relative; locate the named certificate input.
    candidates=[HERE/p for p in original['input_sha256'] if p.endswith('inner_critical_certificates.json')]
    require(len(candidates)==1,'certificate input')
    cert={r['s']:r for r in json.loads(candidates[0].read_text())['certificates']}
    checked=[];total_order_tests=0;total_pairs=0
    for row in original['results']:
        s=row['s'];t=1<<s;A=t+1;B=t*t+1;d=A*B
        for key,value in [('A_factors',A),('B_factors',B)]:
            fs=cert[s][key]
            require(prod(fs)==value and all(p>=2 and all(p%j for j in range(2,isqrt(p)+1)) for p in fs),'complete prime factorization')
        F=arithmetic.BinaryField(int(cert[s]['E_modulus_hex'],16),2*s);irr=F.irreducibility()
        # Norm generator is recorded in the original complete-count payload.
        norm_input=next(HERE/p for p in original['input_sha256'] if p.endswith('primitive_norm_fiber_controls.json'))
        oldrows={r['s']:r for r in json.loads(norm_input.read_text())['results']}
        if s in oldrows:
            u=int(oldrows[s]['U_generator'],16);gen=int(oldrows[s]['E_generator'],16)
        else:
            # For the same polynomial model reconstruct the first primitive E generator.
            # E^* has order (t-1)(t+1), unrelated to B. Factor it by trial division.
            n=F.q-1;fs=[];p=2
            while p*p<=n:
                while n%p==0:fs.append(p);n//=p
                p+=1
            if n>1:fs.append(n)
            gen=next(g for g in range(2,F.q) if all(F.power(g,(F.q-1)//p)!=1 for p in set(fs)))
            u=F.power(gen,t-1)
        require(F.power(u,A)==1 and all(F.power(u,A//p)!=1 for p in set(cert[s]['A_factors'])),'norm generator order')
        circle=[1]
        for j in range(1,A):circle.append(F.mul(circle[-1],u))
        require(len(set(circle))==A,'norm circle coverage')
        K=[0]+[F.power(gen,(t+1)*j) for j in range(t-1)]
        require(len(set(K))==t and all(F.power(z,t)==z for z in K),'K field coverage')
        traceK={}
        for z in K:
            value=0;x=z
            for _ in range(s):value^=x;x=F.square(x)
            require(value in (0,1),'absolute K trace');traceK[z]=value
        inverseK={z:F.inverse(z) for z in K if z}
        orbits=[r['exponents'] for r in row['orbit_records']];k=len(orbits)
        flat=[j for o in orbits for j in o]
        require(set(flat)=={j for j in range(A) if gcd(j,A)==1} and len(flat)==len(set(flat)),'orbit coverage')
        for o in orbits:require(len(o)==2*s and all(o[(i+1)%len(o)]==2*j%A for i,j in enumerate(o)),'Frobenius orbit')
        QD=[[0]*k for _ in range(k)];QP=[[0]*k for _ in range(k)];Xs=[];pair_checks=0
        col={j:i for i,o in enumerate(orbits) for j in o}
        for i,o in enumerate(orbits):
            b=circle[o[0]];unfiltered=0
            for j,w in enumerate(circle):
                c=1^b^w;require(c!=0,'primitive-b denominator')
                lam=F.mul(b,F.inverse(F.square(c)))
                if F.trace(lam)!=1:continue
                unfiltered+=2
                if j not in col:continue
                QP[i][col[j]]+=2;pair_checks+=1;total_pairs+=1
                tower=arithmetic.ArtinSchreierTower(F,lam)
                a=(0,c);plus=(1,c);conj=(c,c)
                require(tower.power(a,F.q)==conj,'actual conjugation')
                require(tower.mul(a,conj)==(b,0),'first norm')
                require(tower.mul(plus,(1^c,c))==(w,0),'second norm')
                good=True
                for p in sorted(set(cert[s]['B_factors'])):
                    for element in (a,plus):
                        total_order_tests+=1
                        if tower.power(element,d//p)==(1,0):good=False
                if good:QD[i][col[j]]+=2
            Xs.append(unfiltered)
        require(QD==row['frobenius_quotient']['D_matrix'],'full-order quotient matrix')
        require(QP==row['frobenius_quotient']['P_matrix'],'primitive-w quotient matrix')
        require(Xs==[r['X'] for r in row['orbit_records']],'unfiltered counts')
        for item in row['kloosterman_fiber_checks']:
            b=circle[item['b_exponent']];beta=int(item['beta'],16)
            require(F.mul(beta,1^b^F.inverse(b))==1 and beta in traceK,'Kloosterman parameter')
            kl=sum(1-2*traceK[z^F.mul(beta,inverseK[z])] for z in inverseK)
            require(kl==item['Kl'] and A+kl==item['X_b'],'direct independent Kloosterman count')
        vals=[sum(v) for v in QD];mu=Fraction(sum(vals),k)
        variance=sum((x-mu)**2 for x in vals)/k
        require(mu==Fraction(row['D_mean']) and variance==Fraction(row['D_variance']),'exact moments')
        witness=row['frobenius_quotient']['exact_2sqrt_counterexample']
        if witness:
            v=witness['vector'];kap=Fraction(row['frobenius_quotient']['kappa']);m=2*s
            norm=sum(x*x for x in v)
            numerator=sum(v[i]*v[j]*(QD[i][j]*kap.denominator-m*kap.numerator) for i in range(k) for j in range(k))
            margin=abs(numerator)-witness['threshold']*kap.denominator*norm
            require(numerator==witness['quadratic_form_numerator'] and margin==witness['strict_integer_margin'] and margin>0,'exact spectral obstruction')
        checked.append({'s':s,'norm_orbits':k,'primitive_norms':len(flat),'quadratic_pairs_checked':pair_checks,
                        'mean':str(mu),'variance':str(variance),'kloosterman_fiber_checks':len(row['kloosterman_fiber_checks']),
                        'irreducibility':irr,'status':'PASS'})
        print(f's={s}: normalized-AS quotient replay PASS; variance {variance}',flush=True)
    require(sha(src)==before,'probe report changed during replay')
    require(all(sha(HERE/p)==h for p,h in original['input_sha256'].items()),'original inputs changed')
    result={'status':'PASS','scope':'Complete finite quotient/counted-order replay s=2,...,9; general geometric and spectral bounds are outside this program.',
            'implementation':'Prior review polynomial arithmetic and normalized AS tower; no producer arithmetic or Dickson order test.',
            'source_sha256':before,'primitive_w_quadratic_pairs_checked':total_pairs,'prime_order_power_tests':total_order_tests,
            'rows':checked,'elapsed_seconds':round(time.time()-started,3),'exact_s8_spectral_obstruction':'PASS'}
    (HERE/'independent_distribution_replay.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','primitive_w_quadratic_pairs_checked','prime_order_power_tests','elapsed_seconds')}))

if __name__=='__main__':main()

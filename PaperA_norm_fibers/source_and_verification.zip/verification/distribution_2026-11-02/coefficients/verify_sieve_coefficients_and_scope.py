"""Independent exact cyclic-sieve and finite-scope audit.

Only copied inputs in this review directory are read. This script does not
enumerate B orders, reuse any producer arithmetic module, or certify HOM3.
"""
from fractions import Fraction as Q
from itertools import combinations, product
from math import gcd, prod
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
INPUTS = HERE / "inputs"


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def factor(n):
    result = []
    p = 2
    while p * p <= n:
        if n % p == 0:
            result.append(p)
            while n % p == 0:
                n //= p
        p += 1
    if n > 1:
        result.append(n)
    return result


def squarefree_orders(n):
    primes = factor(n)
    for size in range(len(primes) + 1):
        for chosen in combinations(primes, size):
            yield prod(chosen), (-1) ** size, prod(p - 1 for p in chosen)


def theta(n):
    return prod((Q(p - 1, p) for p in factor(n)), start=Q(1))


def exact_primitive_indicator(n, j):
    # For squarefree m, c_m(j) = product (p-1 if p | j else -1).
    total = Q()
    for m, mu, phi in squarefree_orders(n):
        ramanujan = prod(p - 1 if j % p == 0 else -1 for p in factor(m))
        total += Q(mu, phi) * ramanujan
    return theta(n) * total


def tensor_mass(A, B):
    coefficients = []
    for (m, mu_m, phi_m), (n, mu_n, phi_n), (r, mu_r, phi_r) in product(
        squarefree_orders(A), squarefree_orders(B), squarefree_orders(B)
    ):
        # One coefficient for each character; multiplicity counts exact orders.
        coeff = Q(mu_m * mu_n * mu_r, phi_m * phi_n * phi_r)
        count = phi_m * phi_n * phi_r
        coefficients.append(((m, n, r), coeff, count))
    mass = sum((abs(c) * count for _, c, count in coefficients), Q())
    constant = next((c, count) for orders, c, count in coefficients if orders == (1, 1, 1))
    cubic = next((c, count) for orders, c, count in coefficients if orders == (3, 1, 1))
    remainder = sum((abs(c) * count for orders, c, count in coefficients
                     if orders not in ((1, 1, 1), (3, 1, 1))), Q())
    M = (2 ** len(factor(A))) * (2 ** len(factor(B))) ** 2
    require(mass == M, "full normalized coefficient mass")
    require(constant == (Q(1), 1), "one constant character triple")
    require(cubic == (Q(-1, 2), 2), "two cubic characters each have coefficient -1/2")
    require(remainder == M - 2, "remaining mass M-2")
    require(2 + Q(1, 2) * 4 + 8 * remainder == 8 * M - 12, "pointwise constant")
    require(Q(1, 2) * 4 + 8 * remainder == 8 * M - 14, "Minkowski constant")
    return {"A": A, "B": B, "theta_A": str(theta(A)), "theta_B": str(theta(B)),
            "c": str(theta(A) * theta(B) ** 2), "M": M,
            "normalized_full_mass": str(mass), "cubic_coefficient_per_character": "-1/2",
            "cubic_character_count": 2, "remaining_mass": str(remainder),
            "pointwise_error_factor": 8 * M - 12,
            "Minkowski_factor_outside_sigma_N": 8 * M - 14}


def weighted_average(records, size, fn):
    return sum((len(rec["exponents"]) * Q(fn(rec)) for rec in records), Q()) / size


def main():
    input_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in sorted(INPUTS.iterdir()) if p.is_file()}
    indicator_groups = [3, 9, 15, 27, 33, 45, 65, 105, 129, 175, 513, 1025, 2049]
    for n in indicator_groups:
        for j in range(n):
            require(exact_primitive_indicator(n, j) == int(gcd(n, j) == 1),
                    "exact primitive indicator at n=%d j=%d" % (n, j))
    tensor_cases = [tensor_mass(A, B) for A, B in
                    [(9, 65), (33, 1025), (129, 16385), (513, 262145), (2049, 4194305),
                     (3 ** 4 * 11 * 17, 5 ** 3 * 13 ** 2 * 37)]]
    data = json.loads((INPUTS / "cubic_mixed_moment_probe.json").read_text(encoding="utf-8"))
    genus = {r["s"]: r for r in json.loads((INPUTS / "cubic_genus2_controls.json").read_text())["rows"]}
    old = {r["s"]: r for r in json.loads((INPUTS / "distribution_probe.json").read_text())["results"]}
    raw = json.loads((INPUTS / "raw_arithmetic_replay.json").read_text())
    finite = []
    for row in data["rows"]:
        s, A, t = row["s"], row["A"], row["t"]
        records = row["records"]
        expected = {j for j in range(A) if gcd(j, A) == 1}
        actual = [j for rec in records for j in rec["exponents"]]
        require(len(actual) == len(set(actual)) and set(actual) == expected, "complete primitive coverage")
        require(row["primitive_norms"] == len(expected), "primitive count")
        require(row["orbits"] == len(records), "orbit count")
        traces = {r["representative"]: r for r in genus[s]["controls"]}
        require(len(traces) == len(records) and genus[s]["primitive_norms"] == len(expected),
                "genus-two controls have exactly the same finite coverage")
        prior = ({j: rec for rec in old[s]["orbit_records"] for j in rec["exponents"]}
                 if s in old else {})
        copied_D = 0
        for rec in records:
            orbit = rec["exponents"]
            require(len(orbit) == 2 * s, "full 2s Frobenius orbit")
            require(all(orbit[(i + 1) % len(orbit)] == (2 * j) % A
                        for i, j in enumerate(orbit)), "squaring orbit")
            N, cube, R, P3 = rec["N"], rec["cube_w_population"], rec["R3"], rec["P3"]
            require(R == 3 * cube - N and 3 * P3 == 2 * N - R, "exact cubic filter")
            require((N - A) ** 2 <= 4 * t and R ** 2 <= 16 * t, "pointwise Hasse bounds")
            require(R == -traces[orbit[0]]["genus2_trace"], "archived genus-two trace agreement")
            if prior:
                require(all((rec["N"], rec["P"], rec["D"]) ==
                            (prior[j]["X"], prior[j]["P"], prior[j]["D"]) for j in orbit),
                        "old complete N, P, D values agree across each orbit")
                copied_D += len(orbit)
            else:
                require(s == 11 and rec["D"] is None, "s11 has no B-order count")
                require("full_sieve_diagnostic" not in row, "s11 has no B-order diagnostic")
        size = len(expected)
        mean = lambda fn: weighted_average(records, size, fn)
        N = lambda r: r["N"]
        R = lambda r: r["R3"]
        P3 = lambda r: r["P3"]
        variance = lambda fn: mean(lambda r: fn(r) ** 2) - mean(fn) ** 2
        cov = mean(lambda r: N(r) * R(r)) - mean(N) * mean(R)
        mixed = mean(lambda r: (N(r) - A) * R(r))
        require(str(mixed) == row["mixed_k_R3"] and str(cov) == row["cov_N_R3"], "exact mixed moment")
        require(variance(P3) == Q(4, 9) * variance(N) + Q(1, 9) * variance(R) - Q(4, 9) * cov,
                "variance decomposition")
        require(variance(R) <= 16 * t, "variance R bound")
        D_checks = {}
        if prior:
            B = t * t + 1
            c = theta(A) * theta(B) ** 2
            M = (2 ** len(factor(A))) * (2 ** len(factor(B))) ** 2
            require(all((Q(rec["D"]) - c * A) ** 2 <= c ** 2 * (8 * M - 12) ** 2 * t
                        for rec in records), "improved pointwise D bound on archived values")
            variance_D = variance(lambda r: r["D"])
            require(variance_D <= c ** 2 * (8 * M - 12) ** 2 * t,
                    "improved variance D bound on archived values")
            # Check sigma_D/c <= sqrt(V_N) + (8M-14)sqrt(t) without floats.
            excess = variance_D / c ** 2 - variance(N) - (8 * M - 14) ** 2 * t
            require(excess <= 0 or excess ** 2 <= 4 * (8 * M - 14) ** 2 * t * variance(N),
                    "Minkowski variance bound on archived values")
            D_checks = {"archived_D_pointwise_bound": True,
                        "archived_D_variance_bound": True,
                        "archived_D_Minkowski_bound": True}
        finite.append({"s": s, "primitive_norms": size, "squaring_orbits": len(records),
                       "mixed_k_R3": str(mixed), "cov_N_R3": str(cov),
                       "archived_D_norms": copied_D,
                       "B_order_enumeration_in_this_audit": False, **D_checks})
    total = sum(r["primitive_norms"] for r in finite)
    orbits = sum(r["squaring_orbits"] for r in finite)
    D_total = sum(r["archived_D_norms"] for r in finite)
    require((total, orbits, D_total) == (1798, 89, 434), "coverage totals")
    require(raw["primitive_norms_checked"] == total and raw["archived_full_D_primitive_norms_checked"] == D_total,
            "raw replay summary scope")
    require(input_hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in sorted(INPUTS.iterdir()) if p.is_file()}, "copied inputs unchanged")
    result = {"status": "PASS", "scope": "Exact sieve coefficients and archived finite-data scope only; no HOM3 and no new B-order enumeration.",
              "input_sha256": input_hashes, "primitive_indicator_groups": indicator_groups,
              "primitive_indicator_values_checked": sum(indicator_groups),
              "tensor_cases": tensor_cases, "finite_coverage": finite,
              "totals": {"primitive_norms": total, "squaring_orbits": orbits, "archived_D_norms": D_total}}
    (HERE / "sieve_coefficients_and_scope_checks.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("PASS: exact primitive indicators, tensor sieve masses, 8M-12 / 8M-14, 1798/89, archived D434, s11 D-null boundary.")


if __name__ == "__main__":
    main()

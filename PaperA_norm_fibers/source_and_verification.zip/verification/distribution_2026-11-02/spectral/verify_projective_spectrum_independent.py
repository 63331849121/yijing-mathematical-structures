"""Independent F8/F64 spectrum, Sylvester resultants, and unit-root exclusion.

No producer arithmetic or CAS is imported. All exact arithmetic below uses
Python standard-library integers and fractions. Inputs are review-local copies.
Polynomial coefficient lists use increasing degree internally.
"""
from fractions import Fraction as Q
from math import gcd, factorial
from pathlib import Path
import hashlib
import json
import time

HERE = Path(__file__).resolve().parent
INPUTS = HERE / "spectral_inputs"


def require(ok, label):
    if not ok:
        raise AssertionError(label)


def trim(a):
    a = list(a)
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return a


def add(a, b):
    out = [0] * max(len(a), len(b))
    for i, x in enumerate(a):
        out[i] += x
    for i, x in enumerate(b):
        out[i] += x
    return trim(out)


def scale(a, c):
    return trim([c * x for x in a])


def mul(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return trim(out)


def power(a, n):
    out = [1]
    while n:
        if n & 1:
            out = mul(out, a)
        a = mul(a, a)
        n //= 2
    return out


def evaluate(a, x):
    out = 0
    for c in reversed(a):
        out = out * x + c
    return out


def divide_QQ(a, b):
    a, b = trim([Q(x) for x in a]), trim([Q(x) for x in b])
    require(b != [0], "nonzero polynomial divisor")
    quotient = [Q(0)] * max(1, len(a) - len(b) + 1)
    while a != [0] and len(a) >= len(b):
        shift = len(a) - len(b)
        c = a[-1] / b[-1]
        quotient[shift] = c
        for i in range(len(b)):
            a[i + shift] -= c * b[i]
        a = trim(a)
    return trim(quotient), a


def gcd_QQ(a, b):
    degrees = []
    while trim(b) != [0]:
        _, remainder = divide_QQ(a, b)
        degrees.append(-1 if remainder == [0] else len(remainder) - 1)
        a, b = b, remainder
    return scale(a, Q(1, a[-1])), degrees


def determinant_bareiss(matrix):
    a = [list(row) for row in matrix]
    n, sign, previous = len(a), 1, 1
    if n == 0:
        return 1
    for k in range(n - 1):
        pivot_row = next((i for i in range(k, n) if a[i][k]), None)
        if pivot_row is None:
            return 0
        if pivot_row != k:
            a[k], a[pivot_row] = a[pivot_row], a[k]
            sign = -sign
        pivot = a[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                numerator = pivot * a[i][j] - a[i][k] * a[k][j]
                require(numerator % previous == 0, "Bareiss division is exact")
                a[i][j] = numerator // previous
            a[i][k] = 0
        previous = pivot
    return sign * a[-1][-1]


def sylvester_resultant_fixed_degrees(f, g):
    # Keep prescribed degree even when one numerical leading coefficient is 0.
    m, n = len(f) - 1, len(g) - 1
    fd, gd = list(reversed(f)), list(reversed(g))
    matrix = []
    for shift in range(n):
        matrix.append([0] * shift + fd + [0] * (n - shift - 1))
    for shift in range(m):
        matrix.append([0] * shift + gd + [0] * (m - shift - 1))
    return determinant_bareiss(matrix)


def interpolate_at_nonnegative_integers(values):
    # Exact Newton forward differences: sum Delta^k P(0) (X)_k/k!.
    differences = list(values)
    firsts = []
    while differences:
        firsts.append(differences[0])
        differences = [differences[i + 1] - differences[i] for i in range(len(differences) - 1)]
    falling, result = [1], [Q(0)]
    for k, difference in enumerate(firsts):
        result = add(result, scale(falling, Q(difference, factorial(k))))
        falling = mul(falling, [-k, 1])
    require(all(Q(c).denominator == 1 for c in result), "interpolated coefficients are integers")
    return [int(c) for c in result]


def primitive_part(a):
    content = 0
    for c in a:
        content = gcd(content, c)
    content = abs(content)
    require(content != 0, "nonzero resultant")
    if a[-1] < 0:
        content = -content
    return [c // content for c in a], content


def binary_remainder(a, b):
    while a and a.bit_length() >= b.bit_length():
        a ^= b << (a.bit_length() - b.bit_length())
    return a


def binary_gcd(a, b):
    while b:
        a, b = b, binary_remainder(a, b)
    return a


class F64:
    """Polynomial bits modulo z^6+z+1; no arithmetic tables/imports."""
    modulus = 0x43

    @staticmethod
    def mul(a, b):
        out = 0
        while b:
            if b & 1:
                out ^= a
            b >>= 1
            a <<= 1
            if a & 64:
                a ^= 0x43
        return out

    @classmethod
    def power(cls, a, n):
        out = 1
        while n:
            if n & 1:
                out = cls.mul(out, a)
            a = cls.mul(a, a)
            n >>= 1
        return out

    @classmethod
    def inverse(cls, a):
        require(a != 0, "finite-field inverse is defined")
        v = cls.power(a, 62)
        require(cls.mul(a, v) == 1, "finite-field inverse")
        return v

    @classmethod
    def trace(cls, a, extension_degree):
        result = 0
        for _ in range(extension_degree):
            result ^= a
            a = cls.mul(a, a)
        require(result in (0, 1), "absolute trace lands in F2")
        return result


def field_checks():
    require(F64.power(2, 64) == 2, "Rabin X^64=X modulo modulus")
    for d in (2, 3):
        require(binary_gcd(0x43, F64.power(2, 1 << d) ^ 2) == 1,
                "Rabin irreducibility prime-degree test")
    E = list(range(64))
    K = [x for x in E if F64.power(x, 8) == x]
    require(len(K) == 8, "F8 fixed field")
    b, u = 0x06, 0x0B
    require(F64.mul(u, u) == b, "u squared equals b")
    require(F64.power(u, 9) == 1 and F64.power(u, 3) != 1, "u has exact order 9")
    h = u ^ F64.inverse(u)
    beta = F64.inverse(1 ^ F64.mul(h, h))
    require(h == beta == 0x17 and h in K and h not in (0, 1), "good specialization h=beta=0x17")
    H = 1 ^ F64.mul(h, h)

    def kloosterman(elements, degree):
        return sum(1 - 2 * F64.trace(x ^ F64.mul(beta, F64.inverse(x)), degree)
                   for x in elements if x != 0)

    def count_curve(elements):
        count, poles, affine, infinity = 0, [], 0, 0
        for x in elements:
            D = F64.mul(F64.mul(x, x), x) ^ x
            denominator = H ^ F64.mul(h, D)
            if denominator == 0:
                derivative = F64.mul(h, F64.mul(x, x) ^ 1)
                require(D != 0 and derivative != 0, "every rational pole is simple and not canceled")
                poles.append(x)
                count += 1  # One smooth-model point over each rational simple pole.
            else:
                rhs = F64.mul(D, F64.inverse(denominator))
                solutions = sum((F64.mul(y, y) ^ y) == rhs for y in elements)
                require(solutions in (0, 2), "AS nonpole fiber")
                affine += solutions
                count += solutions
        rhs_inf = F64.inverse(h)
        infinity = sum((F64.mul(y, y) ^ y) == rhs_inf for y in elements)
        count += infinity
        return {"points": count, "rational_poles": [hex(x) for x in poles],
                "nonpole_affine_points": affine, "points_at_infinity": infinity}

    kl8, kl64 = kloosterman(K, 3), kloosterman(E, 6)
    c8, c64 = count_curve(K), count_curve(E)
    require((kl8, kl64, c8["points"], c64["points"]) == (-1, 15, 13, 75),
            "independent finite-field sums and point counts")
    trF, trF2 = -kl8, -kl64
    detF = (trF * trF - trF2) // 2
    require((trF, trF2, detF) == (1, -15, 8), "F characteristic polynomial from two sums")
    trG, trG2 = 9 - c8["points"], 65 - c64["points"]
    e2 = (trG * trG - trG2) // 2
    PF = [detF, -trF, 1]
    # H1 of a genus-2 curve is 8-reciprocal by its polarization.
    PG = [8 * 8, -8 * trG, e2, -trG, 1]
    require(PF == [8, -1, 1] and PG == [64, 32, 13, 4, 1], "F and G characteristic polynomials")
    return PF, PG, {"modulus": "0x43", "Rabin_irreducible": True,
                    "F8_elements": [hex(x) for x in K], "b": hex(b), "u": hex(u),
                    "h": hex(h), "beta": hex(beta), "Kl8": kl8, "Kl64": kl64,
                    "curve_F8": c8, "curve_F64": c64,
                    "F_trace": trF, "F_trace_squared_Frobenius": trF2, "F_determinant": detF,
                    "G_trace": trG, "G_trace_squared_Frobenius": trG2,
                    "G_second_elementary_symmetric_coefficient": e2,
                    "PF_descending": list(reversed(PF)), "PG_descending": list(reversed(PG))}


def cyclotomics_up_to(bound):
    polys = {}
    for n in range(1, bound + 1):
        p = [-1] + [0] * (n - 1) + [1]
        for d in range(1, n):
            if n % d == 0:
                p, remainder = divide_QQ(p, polys[d])
                require(remainder == [0], "exact cyclotomic recursion")
        require(all(Q(x).denominator == 1 for x in p), "integral cyclotomic coefficients")
        polys[n] = [int(x) for x in p]
        phi = sum(gcd(n, j) == 1 for j in range(1, n + 1))
        require(len(p) - 1 == phi, "cyclotomic degree independently matches totient count")
        require(phi * phi >= Q(n, 2), "phi squared bound across enumerated range")
    return polys


def main():
    started = time.time()
    digests = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUTS.iterdir() if p.is_file()}
    PF, PG, field = field_checks()
    RF = [8, 15, 8]
    # General identity: beta1 beta2=8, beta1+beta2=1, so the ratio sum is -15/8.
    require(Q(PF[1] ** 2, PF[0]) - 2 == -Q(RF[1], RF[2]) and RF[0] == RF[2],
            "RF roots are both beta ratios")

    def rg_value(z):
        return sylvester_resultant_fixed_degrees(PG, [c * z ** i for i, c in enumerate(PG)])

    rg_samples = [rg_value(z) for z in range(17)]
    RG = interpolate_at_nonnegative_integers(rg_samples)
    require(len(RG) - 1 == 16, "first resultant degree 16")
    for z in (-3, 17, 19):
        require(evaluate(RG, z) == rg_value(z), "first resultant additional direct determinant")

    def r_value(z):
        return sylvester_resultant_fixed_degrees(RF, [c * z ** i for i, c in enumerate(RG)])

    r_samples = [r_value(z) for z in range(33)]
    R_raw = interpolate_at_nonnegative_integers(r_samples)
    R, content = primitive_part(R_raw)
    require(len(R) - 1 == 32, "second resultant primitive degree 32")
    for z in (-1, 33, 35):
        require(evaluate(R_raw, z) == r_value(z), "second resultant additional direct determinant")

    Q2 = [8, 15, 8]
    Q8 = [4096, -9600, 10377, -11100, 12598, -11100, 10377, -9600, 4096]
    Q8p = [4096, -2880, 5232, -3645, 4394, -3645, 5232, -2880, 4096]
    require(mul(mul(power(Q2, 4), Q8), power(Q8p, 2)) == R,
            "exact full polynomial identity R=Q2^4 Q8 Q8p^2")
    require(gcd(*R) == 1, "R is primitive")
    source = json.loads((INPUTS / "projective_specialization_probe.json").read_text())["rows"][0]
    require(list(reversed(R)) == source["projective_ratio_polynomial_coefficients"],
            "all 33 independent resultant coefficients match source")

    cyclo = cyclotomics_up_to(128)
    orders = [n for n in range(1, 129) if len(cyclo[n]) - 1 <= 8]
    expected = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 15, 16, 18, 20, 24, 30]
    require(orders == expected, "complete 18 possible cyclotomic orders")
    gcd_checks = []
    for n in orders:
        for name, factor in (("Q2", Q2), ("Q8", Q8), ("Q8p", Q8p)):
            result, remainder_degrees = gcd_QQ(factor, cyclo[n])
            require(result == [1], "no unit root at order %d in %s" % (n, name))
            gcd_checks.append({"N": n, "phi_N": len(cyclo[n]) - 1, "factor": name,
                               "Phi_N_descending": list(reversed(cyclo[n])),
                               "gcd_over_QQ": [1], "euclidean_remainder_degrees": remainder_degrees})
    require(len(gcd_checks) == 54, "all 54 rational gcd checks")
    require(digests == {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in INPUTS.iterdir() if p.is_file()}, "copied inputs unchanged")
    out = {"status": "PASS", "scope": "Independent exact finite spectra, full resultant identity, and exclusion of every unit root. The geometric projective criterion is reviewed separately.",
           "implementation": "Own bit-field arithmetic, integer Bareiss Sylvester determinants, exact rational Newton interpolation and Euclidean polynomial gcd; Python standard library only.",
           "input_sha256": digests, "finite_spectrum": field,
           "resultants": {"RF_descending": list(reversed(RF)),
                          "RG_descending": list(reversed(RG)), "RG_degree": 16,
                          "first_interpolation_points": list(range(17)),
                          "first_additional_points": [-3, 17, 19],
                          "R_raw_content": content,
                          "R_primitive_descending": list(reversed(R)), "R_primitive_degree": 32,
                          "second_interpolation_points": list(range(33)),
                          "second_additional_points": [-1, 33, 35],
                          "Q2_descending": list(reversed(Q2)), "Q8_descending": list(reversed(Q8)),
                          "Q8p_descending": list(reversed(Q8p)),
                          "factorization_multiplicities": {"Q2": 4, "Q8": 1, "Q8p": 2},
                          "factorization_identity": True, "source_coefficients_match": True},
           "cyclotomic_orders": orders, "gcd_count": len(gcd_checks), "gcd_checks": gcd_checks,
           "exhaustiveness": "For p^a, phi(p^a)^2/p^a=p^(a-2)(p-1)^2. Odd primes contribute >=1; only 2^1 contributes 1/2. Hence phi(N)^2>=N/2, so phi(N)<=8 implies N<=128.",
           "elapsed_seconds": round(time.time() - started, 3)}
    (HERE / "projective_spectrum_independent_checks.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("PASS: independent F8/F64 points 13/75, Kl8=-1 (Kl64=15), PF/PG, both Sylvester resultants, exact degree-32 factorization, all 18 orders / 54 rational gcds.")
    print("Second-resultant content:", content)
    print("Elapsed seconds:", out["elapsed_seconds"])


if __name__ == "__main__":
    main()

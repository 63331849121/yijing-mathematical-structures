"""Direct genus-two point counts for the same cubic mixed-moment reduction."""
from pathlib import Path
import json,time
import probe_cubic_mixed_moment as probe

HERE=Path(__file__).resolve().parent

def main():
    started=time.time();data=json.loads((HERE/'cubic_mixed_moment_probe.json').read_text())
    rows=[]
    for row in data['rows']:
        s=row['s'];t=row['t'];A=row['A']
        F=probe.arith.BinaryField(int(row['E_modulus'],16),2*s)
        gen=next(g for g in range(2,F.q) if all(F.power(g,(F.q-1)//p)!=1 for p in probe.factors(F.q-1)))
        g=F.power(gen,A);K=[0,1]
        for _ in range(t-2):K.append(F.mul(K[-1],g))
        probe.require(len(set(K))==t and all(F.power(x,t)==x for x in K),'embedded K')
        tr={}
        for x in K:
            y=x;v=0
            for _ in range(s):v^=y;y=F.square(y)
            probe.require(v in (0,1),'trace K');tr[x]=v
        controls=[]
        for rec in row['records']:
            b=int(rec['b_hex'],16);u=F.power(b,(A+1)//2)
            h=u^F.inverse(u);H=F.square(h)^1
            probe.require(h in tr and h not in (0,1),'good h')
            # On y²+y=D3(x)/(H+h D3(x)), each rational pole contributes
            # one point; its deviation from the base P¹ count is zero.
            character_sum=0;poles=[]
            for x in K:
                D=F.mul(F.square(x),x)^x
                den=H^F.mul(h,D)
                if den==0:poles.append(x);continue
                character_sum+=1-2*tr[F.mul(D,F.inverse(den))]
            character_sum+=1-2*tr[F.inverse(h)]
            a=-character_sum
            probe.require(rec['R3']==-a,'cubic sieve equals negative genus-two trace')
            probe.require(a*a<=16*t,'genus-two Hasse bound')
            controls.append({'representative':rec['exponents'][0],'h':hex(h),'genus2_trace':a,
                             'R3':rec['R3'],'rational_poles':len(poles)})
        rows.append({'s':s,'primitive_norms':row['primitive_norms'],'orbit_checks':len(controls),
                     'controls':controls,'status':'PASS'})
        print('s=%d: genus-two identity PASS (%d orbits)' % (s,len(controls)),flush=True)
    (HERE/'cubic_genus2_controls.json').write_text(json.dumps({'status':'PASS',
       'scope':'Exact finite controls only; general identity requires the written cubic root-count proof.',
       'rows':rows,'primitive_norms_covered':sum(r['primitive_norms'] for r in rows),
       'elapsed_seconds':round(time.time()-started,3)},indent=2)+'\n')

if __name__=='__main__':main()

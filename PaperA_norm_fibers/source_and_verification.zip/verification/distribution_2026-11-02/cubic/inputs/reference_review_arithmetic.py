"""Unchanged arithmetic definitions extracted from the earlier independent review.
Only used as a library; not a new independent expert review.
"""
CHECKS=0

def require(condition, label):
    global CHECKS
    CHECKS += 1
    if not condition:
        raise ValueError(label)

def poly_remainder(value, divisor):
    while value and value.bit_length() >= divisor.bit_length():
        value ^= divisor << (value.bit_length() - divisor.bit_length())
    return value

def poly_gcd(a, b):
    while b:
        a, b = b, poly_remainder(a, b)
    return a

def binary_rank(columns):
    basis = {}
    for column in columns:
        while column:
            pivot = column.bit_length() - 1
            if pivot in basis:
                column ^= basis[pivot]
            else:
                basis[pivot] = column
                break
    return len(basis)

class BinaryField:
    def __init__(self, modulus, n):
        self.modulus, self.n, self.q = modulus, n, 1 << n
        require(modulus.bit_length() == n + 1 and modulus & 1, 'modulus degree/constant')
        self.reduce_tables = [[poly_remainder(v << (8 * i), modulus) for v in range(256)]
                              for i in range((2 * n + 7) // 8)]
        self.square_table = [sum(((v >> j) & 1) << (2 * j) for j in range(8)) for v in range(256)]

    def reduce(self, raw):
        value, position = 0, 0
        while raw:
            value ^= self.reduce_tables[position][raw & 255]
            raw >>= 8
            position += 1
        return value

    def mul(self, a, b):
        table = [0, a]
        for i in range(1, 4):
            table += [v ^ (a << i) for v in table]
        raw, shift = 0, 0
        while b:
            raw ^= table[b & 15] << shift
            b >>= 4
            shift += 4
        return self.reduce(raw)

    def square(self, a):
        raw, shift = 0, 0
        while a:
            raw |= self.square_table[a & 255] << shift
            a >>= 8
            shift += 16
        return self.reduce(raw)

    def power(self, a, exponent):
        value = 1
        while exponent:
            if exponent & 1:
                value = self.mul(value, a)
            exponent >>= 1
            if exponent:
                a = self.square(a)
        return value

    def inverse(self, a):
        # Extended polynomial Euclidean algorithm; no exponent inversion.
        require(a != 0, 'inverse zero')
        u, v, r, z = a, self.modulus, 1, 0
        while u != 1:
            degree = u.bit_length() - v.bit_length()
            if degree < 0:
                u, v, r, z = v, u, z, r
                degree = -degree
            u ^= v << degree
            r ^= z << degree
        result = poly_remainder(r, self.modulus)
        require(self.mul(a, result) == 1, 'Euclidean inverse')
        return result

    def trace(self, a):
        value = 0
        for i in range(self.n):
            value ^= a
            a = self.square(a)
        require(value in (0, 1), 'trace in binary field')
        return value

    def irreducibility(self):
        derivative = sum(((self.modulus >> i) & 1) << (i - 1) for i in range(1, self.n + 1, 2))
        squarefree = poly_gcd(self.modulus, derivative) == 1
        # Columns of Frobenius minus identity on the quotient vector space.
        columns = [poly_remainder(1 << (2 * j), self.modulus) ^ (1 << j) for j in range(self.n)]
        fixed_dimension = self.n - binary_rank(columns)
        require(squarefree and fixed_dimension == 1, 'Berlekamp irreducibility')
        require(self.power(2, self.q) == 2, 'field Frobenius')
        # Separate bit-convolution/long-division spot check of this audit's arithmetic.
        state = 0x12345678
        for i in range(128):
            state = (1103515245 * state + 12345) & 0x7fffffff
            a = state % self.q
            state = (1103515245 * state + 12345) & 0x7fffffff
            b = state % self.q
            raw = 0
            for j in range(self.n):
                if (b >> j) & 1:
                    raw ^= a << j
            require(self.mul(a, b) == poly_remainder(raw, self.modulus), 'arithmetic spot check')
            require(self.square(a) == self.mul(a, a), 'square spot check')
        return {'squarefree': squarefree, 'Berlekamp_fixed_space_dimension': fixed_dimension,
                'arithmetic_spot_checks': 128}

class ArtinSchreierTower:
    """T^2 = T + lam; original Z = c*T, not the author's Z-basis."""
    def __init__(self, field, lam):
        self.f, self.lam = field, lam

    def mul(self, a, b):
        m = self.f.mul
        ac = m(a[0], b[0])
        bd = m(a[1], b[1])
        return ac ^ m(self.lam, bd), m(a[0], b[1]) ^ m(a[1], b[0]) ^ bd

    def square(self, a):
        x, y = self.f.square(a[0]), self.f.square(a[1])
        return x ^ self.f.mul(self.lam, y), y

    def power(self, a, exponent):
        answer = (1, 0)
        while exponent:
            if exponent & 1:
                answer = self.mul(answer, a)
            exponent >>= 1
            if exponent:
                a = self.square(a)
        return answer

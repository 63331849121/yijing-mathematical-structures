"""Second arithmetic replay: raw polynomial multiplication and batch inversion.

No imports from the producer or earlier review arithmetic. Only one cubic
coordinate is checked; general mixed cancellation and B-order tests are outside scope.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import gcd,prod,isqrt
import hashlib,json,time

HERE=Path(__file__).resolve().parent


def require(ok,label):
    if not ok:raise ValueError(label)


class RawField:
    def __init__(self,m,n):self.m,self.n,self.q=m,n,1<<n
    def mul(self,a,b):
        out=0
        while b:
            if b&1:out^=a
            b>>=1;a<<=1
            if a&self.q:a^=self.m
        return out
    def power(self,a,n):
        out=1
        while n:
            if n&1:out=self.mul(out,a)
            a=self.mul(a,a);n>>=1
        return out
    def trace(self,a,n=None):
        out=0
        for _ in range(self.n if n is None else n):out^=a;a=self.mul(a,a)
        require(out in (0,1),'binary trace');return out
    def batch_inverse(self,values):
        prefixes=[1]
        for v in values:
            require(v!=0,'batch inversion nonzero')
            prefixes.append(self.mul(prefixes[-1],v))
        inv=self.power(prefixes[-1],self.q-2)
        require(self.mul(inv,prefixes[-1])==1,'inverse power')
        result=[0]*len(values)
        for i in range(len(values)-1,-1,-1):
            result[i]=self.mul(inv,prefixes[i]);inv=self.mul(inv,values[i])
        return result


def factor(n):
    fs=[];p=2
    while p*p<=n:
        while n%p==0:fs.append(p);n//=p
        p+=1
    if n>1:fs.append(n)
    return fs


def main():
    started=time.time();src=HERE/'cubic_mixed_moment_probe.json'
    digest=hashlib.sha256(src.read_bytes()).hexdigest()
    data=json.loads(src.read_text());cert={r['s']:r for r in json.loads((HERE/'inputs/inner_critical_certificates.json').read_text())['certificates']}
    genus={r['s']:r for r in json.loads((HERE/'cubic_genus2_controls.json').read_text())['rows']}
    checks=[];full_D_fibers=0
    for row in data['rows']:
        s=row['s'];t=1<<s;A=t+1;B=t*t+1
        F=RawField(int(row['E_modulus'],16),2*s)
        # Rabin irreducibility: X^(2^n)=X and gcd tests for prime divisors of n.
        def remainder(a,b):
            while a.bit_length()>=b.bit_length():a^=b<<(a.bit_length()-b.bit_length())
            return a
        def pgcd(a,b):
            while b:a,b=b,remainder(a,b)
            return a
        require(F.power(2,F.q)==2,'field Frobenius')
        for p in set(factor(2*s)):
            require(pgcd(F.m,F.power(2,1<<((2*s)//p))^2)==1,'Rabin irreducibility')
        u=int(row['U_generator'],16)
        require(F.power(u,A)==1 and all(F.power(u,A//p)!=1 for p in set(factor(A))),'generator order')
        circle=[1]
        for _ in range(A-1):circle.append(F.mul(circle[-1],u))
        require(len(set(circle))==A,'circle coverage')
        trace_mask=sum(F.trace(1<<i)<<i for i in range(2*s))
        k_order=t-1
        candidate=next(F.power(a,A) for a in range(2,F.q)
            if F.power(a,A)!=0 and all(F.power(F.power(a,A),k_order//p)!=1 for p in set(factor(k_order))))
        K=[0,1]
        for _ in range(t-2):K.append(F.mul(K[-1],candidate))
        require(len(set(K))==t and all(F.power(x,t)==x for x in K),'K field coverage')
        traceK={x:F.trace(x,s) for x in K}
        all_exponents=[j for r in row['records'] for j in r['exponents']]
        require(len(all_exponents)==len(set(all_exponents)) and set(all_exponents)=={j for j in range(A) if gcd(j,A)==1},'primitive coverage')
        values=[];genus_controls={r['representative']:r for r in genus[s]['controls']}
        for r in row['records']:
            orbit=r['exponents'];j=orbit[0]
            require(len(orbit)==2*s and all(orbit[(i+1)%len(orbit)]==2*v%A for i,v in enumerate(orbit)),'Frobenius orbit')
            b=circle[j];require(b==int(r['b_hex'],16),'basis alignment')
            root=F.power(b,(A+1)//2)
            cs=[1^b^w for w in circle];invs=F.batch_inverse(cs)
            N=C=P=0
            for l,inv in enumerate(invs):
                point_count=2*((F.mul(root,inv)&trace_mask).bit_count()&1)
                N+=point_count
                if l%3==0:C+=point_count
                if gcd(l,A)==1:P+=point_count
            R=3*C-N
            require((N,C,R,P)==(r['N'],r['cube_w_population'],r['R3'],r['P']),'complete w populations')
            h=root^F.power(root,F.q-2);H=F.mul(h,h)^1
            require(h in traceK and h not in (0,1),'good h')
            D=[F.mul(F.mul(x,x),x)^x for x in K]
            den=[H^F.mul(h,d) for d in D]
            active=[i for i,v in enumerate(den) if v]
            invden=F.batch_inverse([den[i] for i in active])
            charsum=sum(1-2*traceK[F.mul(D[i],iv)] for i,iv in zip(active,invden))
            charsum+=1-2*traceK[F.power(h,F.q-2)]
            require(charsum==R==-genus_controls[j]['genus2_trace'],'genus-two trace identity')
            require(R*R<=16*t,'new pointwise bound')
            values.append((len(orbit),N-A,R,N-C))
        n=sum(w for w,k,r,p in values)
        avg=lambda fn:sum((Q(fn(k,r,p))*w for w,k,r,p in values),Q())/n
        mixed=avg(lambda k,r,p:k*r)
        cov= mixed-avg(lambda k,r,p:k)*avg(lambda k,r,p:r)
        require(str(mixed)==row['mixed_k_R3'] and str(cov)==row['cov_N_R3'],'mixed moments')
        variance_R=avg(lambda k,r,p:r*r)-avg(lambda k,r,p:r)**2
        require(variance_R<=16*t,'variance of cubic coordinate')
        AF=cert[s]['A_factors'];BF=cert[s]['B_factors']
        require(prod(AF)==A and prod(BF)==B,'factor products')
        require(all(p>=2 and all(p%j for j in range(2,isqrt(p)+1)) for p in AF+BF),'factor primality')
        theta=lambda fs:prod((Q(p-1,p) for p in set(fs)),start=Q(1))
        c=theta(AF)*theta(BF)**2;M=(1<<len(set(AF)))*(1<<len(set(BF)))**2
        finite_D=[r for r in row['records'] if r['D'] is not None]
        for r in finite_D:require((r['D']-c*A)**2<=c*c*(8*M-12)**2*t,'improved D bound on archived full-order counts')
        full_D_fibers+=sum(len(r['exponents']) for r in finite_D)
        checks.append({'s':s,'primitive_norms':n,'orbit_checks':len(values),'mixed':str(mixed),
           'cov_N_R3':str(cov),'new_D_error_coefficient':str(c*(8*M-12)),
           'old_D_error_coefficient':str(c*(8*M-6)),
           'variance_bound_ratio_new_over_old':str(Q((8*M-12)**2,(8*M-6)**2)),
           'full_D_finite_checks':len(finite_D),'status':'PASS'})
        print('s=%d: raw arithmetic replay PASS (%d primitive norms)'%(s,n),flush=True)
    require(hashlib.sha256(src.read_bytes()).hexdigest()==digest,'probe unchanged')
    out={'status':'PASS','source_sha256':digest,'implementation':'Raw shift/XOR arithmetic; batch inverse by one exponentiation; no imported producer/review arithmetic.',
         'scope':'One cubic w coordinate; complete w and genus-two counts. No new B-order enumeration and no general mixed-cancellation certification.',
         'primitive_norms_checked':sum(r['primitive_norms'] for r in checks),'archived_full_D_primitive_norms_checked':full_D_fibers,
         'rows':checks,'elapsed_seconds':round(time.time()-started,3)}
    (HERE/'raw_arithmetic_replay.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':main()

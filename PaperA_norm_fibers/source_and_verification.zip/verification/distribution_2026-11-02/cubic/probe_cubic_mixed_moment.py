"""One finite probe: the cubic-coordinate mixed moment for primitive norms."""
from pathlib import Path
from fractions import Fraction as Q
from math import gcd
import hashlib
import importlib.util
import json
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('review_field', HERE/'inputs/reference_review_arithmetic.py')
arith = importlib.util.module_from_spec(spec)
spec.loader.exec_module(arith)


def factors(n):
    result = []
    p = 2
    while p*p <= n:
        if n % p == 0:
            result.append(p)
            while n % p == 0:
                n //= p
        p += 1
    if n > 1:
        result.append(n)
    return result


def require(ok, why):
    if not ok:
        raise ValueError(why)


def main():
    started = time.time()
    ins = sorted((HERE/'inputs').glob('*'))
    hashes = {p.relative_to(HERE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in ins}
    cert = {r['s']: r for r in json.loads((HERE/'inputs/inner_critical_certificates.json').read_text())['certificates']}
    coordinates = {r['s']:r for r in json.loads((HERE/'inputs/primitive_norm_fiber_controls.json').read_text())['results']}
    prior = {r['s']:r for r in json.loads((HERE/'inputs/distribution_probe.json').read_text())['results']}
    rows = []
    for s in (3,5,7,9,11):
        begin = time.time()
        t = 1 << s
        A = t+1
        B = t*t+1
        W = 1 << len(factors(A))
        require(A%3 == 0 and B%5 == 0 and B>5, 'chosen composite-B family')
        F = arith.BinaryField(int(cert[s]['E_modulus_hex'],16),2*s)
        irr = F.irreducibility()
        full_factors = factors(F.q-1)
        if s in coordinates:
            u = int(coordinates[s]['U_generator'],16)
        else:
            gen = next(g for g in range(2,F.q) if all(F.power(g,(F.q-1)//p)!=1 for p in full_factors))
            u = F.power(gen,t-1)
        require(F.power(u,A)==1 and all(F.power(u,A//p)!=1 for p in factors(A)), 'U generator')
        circle = [1]
        for j in range(1,A):
            circle.append(F.mul(circle[-1],u))
        require(len(set(circle))==A, 'U coverage')
        trace_mask = sum(F.trace(1<<i)<<i for i in range(2*s))
        seen = set()
        orbits = []
        for j in range(1,A):
            if gcd(j,A)!=1 or j in seen:
                continue
            orbit = []
            v = j
            while v not in seen:
                orbit.append(v)
                seen.add(v)
                v = 2*v%A
            require(v==j and len(orbit)==2*s, 'full Frobenius orbit')
            orbits.append(orbit)
        require(seen=={j for j in range(A) if gcd(j,A)==1}, 'primitive coverage')
        records = []
        prior_map = ({j:r for r in prior[s]['orbit_records'] for j in r['exponents']}
                     if s in prior else {})
        for orbit in orbits:
            j = orbit[0]
            b = circle[j]
            root_b = F.power(b,(A+1)//2)
            N = 0
            cube = 0
            P = 0
            for l,w in enumerate(circle):
                c = 1^b^w
                require(c!=0, 'no degenerate primitive-b branch')
                trace_value = F.mul(root_b,F.inverse(c))
                h = 2*((trace_value & trace_mask).bit_count() & 1)
                N += h
                if l%3==0:
                    cube += h
                if gcd(l,A)==1:
                    P += h
            R = 3*cube-N
            P3 = N-cube
            require(3*P3==2*N-R, 'exact cubic-coordinate filter')
            if prior_map:
                require(N==prior_map[j]['X'] and P==prior_map[j]['P'], 'old complete counts')
            records.append({'exponents':orbit,'b_hex':hex(b),'N':N,'cube_w_population':cube,
                            'R3':R,'P3':P3,'P':P, 'D':prior_map[j]['D'] if prior_map else None})
        n = len(seen)
        def avg(fn):
            return sum((Q(fn(r))*len(r['exponents']) for r in records),Q())/n
        def cov(f,g):
            return avg(lambda r:f(r)*g(r))-avg(f)*avg(g)
        k = lambda r:r['N']-A
        R = lambda r:r['R3']
        N = lambda r:r['N']
        P3 = lambda r:r['P3']
        mixed = avg(lambda r:k(r)*R(r))
        C = cov(N,R)
        VN = cov(N,N)
        VR = cov(R,R)
        VP3 = cov(P3,P3)
        require(VP3==Q(4,9)*VN+Q(1,9)*VR-Q(4,9)*C, 'variance decomposition of one sieve coordinate')
        result = {'s':s,'t':t,'A':A,'B':B,'A_distinct_factors':factors(A),'W_A':W,
                  'primitive_norms':n,'orbits':len(orbits),'E_modulus':hex(F.modulus),'U_generator':hex(u),
                  'irreducibility':irr,'mean_k':str(avg(k)),'mean_R3':str(avg(R)),
                  'mixed_k_R3':str(mixed),'mixed_over_t':str(mixed/t),
                  'mixed_squared_over_W2_t':str(mixed*mixed/(W*W*t)),
                  'cov_N_R3':str(C),'var_N':str(VN),'var_R3':str(VR),'var_P3':str(VP3),
                  'cov_N_P3':str(cov(N,P3)),'records':records,
                  'elapsed_seconds':round(time.time()-begin,3)}
        if prior_map:
            Pop = lambda r:r['P']
            Loss = lambda r:r['P']-r['D']
            result['full_sieve_diagnostic'] = {
                'cov_N_P':str(cov(N,Pop)), 'cov_N_B_loss':str(cov(N,Loss)),
                'cov_R3_B_loss':str(cov(R,Loss)),
                'var_B_loss':str(cov(Loss,Loss)),
                'var_D':str(cov(lambda r:r['D'],lambda r:r['D']))}
        rows.append(result)
        print('s=%d: mixed=%s, mixed/t=%s, Cov(N,R3)=%s' % (s,mixed,mixed/t,C),flush=True)
    require(hashes=={p.relative_to(HERE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in ins}, 'inputs unchanged')
    out={'status':'PASS','scope':'One cubic-coordinate mixed moment; no generic-B variance theorem.',
         'input_sha256':hashes,'rows':rows,'elapsed_seconds':round(time.time()-started,3)}
    (HERE/'cubic_mixed_moment_probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()

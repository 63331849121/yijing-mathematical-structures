"""Independent exact replay: no producer/helper imports.
Rebuilds primes by Eratosthenes, verifies selected sieve rows, and checks
every root witness with bit convolution/long division and tower arithmetic.
"""
from pathlib import Path
from fractions import Fraction
from math import gcd,isqrt,prod
import hashlib,json

OUT=Path(__file__).resolve().parent


def primes(n):
    sieve=bytearray(b'\x01')*(n+1);sieve[:2]=b'\x00\x00'
    for i in range(2,isqrt(n)+1):
        if sieve[i]:sieve[i*i:n+1:i]=b'\x00'*((n-i*i)//i+1)
    return [i for i in range(2,n+1) if sieve[i]]


def factor(n):
    ans=[]
    for p in primes(isqrt(n)+1):
        while n%p==0:ans.append(p);n//=p
        if n==1:break
    if n>1:ans.append(n)
    return ans


def remainder(a,b):
    while a.bit_length()>=b.bit_length():a^=b<<(a.bit_length()-b.bit_length())
    return a


def polynomial_gcd(a,b):
    while b:a,b=b,remainder(a,b)
    return a


def field_mul(a,b,mod):
    p=0
    for i in range(b.bit_length()):
        if b>>i&1:p^=a<<i
    return remainder(p,mod)


def power(x,k,one,mul):
    z=one
    for bit in bin(k)[2:]:
        z=mul(z,z)
        if bit=='1':z=mul(z,x)
    return z


def verify_sieve():
    data=json.loads((OUT/'global_sieve_controls.json').read_text())
    ps=primes(4096)
    odd=[p for p in ps if p>2];one4=[p for p in ps if p%4==1]
    assert len(odd)==563 and len(one4)==276
    assert 4096**563<(1<<(12*79))*prod(odd)
    assert 4096**276<(1<<(12*39))*prod(one4)
    failed=[]
    assert [r['s'] for r in data['rows']]==list(range(2,1924))
    for row in data['rows']:
        s=row['s'];t=1<<s
        sets=[];ks=[]
        for key,n in [('A',t+1),('B',t*t+1)]:
            fs=row[key+'_small_factors'];res=int(row[key+'_residual']);k=row[key+'_residual_omega_upper']
            assert all(p in ps and e>=1 for p,e in fs)
            assert len({p for p,e in fs})==len(fs)
            assert prod(p**e for p,e in fs)*res==n
            assert all(res%p for p in ps)
            assert 4097**k<=res<4097**(k+1)
            if key=='B':assert all(p%4==1 for p,e in fs)
            sets.append({p for p,e in fs});ks.append(k)
        ca=set(row['core_A']);cb=set(row['core_B'])
        assert ca<=sets[0] and cb<=sets[1]
        oa=sets[0]-ca;ob=sets[1]-cb
        delta=1-sum((Fraction(1,p) for p in oa),Fraction())-2*sum((Fraction(1,p) for p in ob),Fraction())-Fraction(ks[0]+2*ks[1],4097)
        N=len(oa)+2*len(ob)+ks[0]+2*ks[1]
        assert delta>0 and delta==Fraction(row['delta_lower'])
        assert N==row['omitted_position_upper']
        C=8*(1<<(len(ca)+2*len(cb)))*(2+Fraction(N-1,1)/delta)-6
        assert C==Fraction(row['C'])
        positive=(t+1)**2*C.denominator**2>t*C.numerator**2
        assert positive==row['positive']
        if not positive:failed.append(s)
    assert failed==data['unresolved_parameters']
    print('integer sieve: 1922 rows and uniform-tail products PASS',flush=True)
    return failed


def verify_witnesses(expected):
    data=json.loads((OUT/'remaining_fiber_witnesses.json').read_text())
    assert data['parameters']==expected
    assert [r['s'] for r in data['rows']]==expected
    summaries=[];total_orders=0
    for row in data['rows']:
        s=row['s'];t=1<<s;A=t+1;B=t*t+1;d=A*B
        mod=int(row['E_modulus'],16);n=2*s;q=1<<n
        assert mod.bit_length()==n+1
        m=lambda a,b:field_mul(a,b,mod)
        pw=lambda a,k:power(a,k,1,m)
        sq=[2]
        for _ in range(n):sq.append(m(sq[-1],sq[-1]))
        assert sq[-1]==2
        assert all(polynomial_gcd(mod,sq[n//p]^2)==1 for p in set(factor(n)))
        pa,pb=factor(A),factor(B)
        assert pa==row['A_factors'] and pb==row['B_factors']
        u=int(row['U_generator'],16)
        assert pw(u,A)==1 and all(pw(u,A//p)!=1 for p in set(pa))
        def trace(a):
            z=0
            for _ in range(n):z^=a;a=m(a,a)
            assert z in (0,1)
            return z
        covered=set()
        for rec in row['witnesses']:
            j=rec['norm_exponent'];k=rec['w_exponent'];orb=rec['norm_orbit']
            assert orb[0]==j and gcd(j,A)==gcd(k,A)==1
            assert len(orb)==len(set(orb)) and not covered.intersection(orb)
            assert all(orb[(i+1)%len(orb)]==2*z%A for i,z in enumerate(orb))
            covered.update(orb)
            b,w,c=(int(rec[z],16) for z in ('b','w','c'))
            assert b==pw(u,j) and w==pw(u,k) and c==1^b^w and c
            assert trace(m(b,pw(c,q-3)))==1
            def tm(z,v):
                p0=m(z[0],v[0]);p2=m(z[1],v[1])
                cross=m(z[0]^z[1],v[0]^v[1])^p0^p2
                return (p0^m(b,p2),cross^m(c,p2))
            tp=lambda a,e:power(a,e,(1,0),tm)
            assert tp((0,1),B)==(b,0) and tp((1,1),B)==(w,0)
            for a in ((0,1),(1,1)):
                assert tp(a,d)==(1,0)
                for p in set(pa+pb):
                    assert tp(a,d//p)!=(1,0)
                    total_orders+=1
        assert covered=={j for j in range(A) if gcd(j,A)==1}
        assert len(covered)==row['primitive_norms']
        summaries.append({'s':s,'norm_orbits':len(row['witnesses']),'primitive_norms_covered':len(covered)})
        print('witness s',s,'PASS, orbits',len(row['witnesses']),flush=True)
    return summaries,total_orders


def main():
    assert __debug__
    unresolved=verify_sieve()
    rows,checks=verify_witnesses(unresolved)
    result={'status':'PASS','integer_sieve_rows':1922,'uniform_tail_from':1924,
            'finite_parameters':unresolved,'rows':rows,
            'witness_count':sum(r['norm_orbits'] for r in rows),
            'primitive_norm_count':sum(r['primitive_norms_covered'] for r in rows),
            'exact_prime_order_tests':checks,
            'scope':'Independent arithmetic implementation; not an independent expert or formal certification of the inherited character estimate.',
            'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'global_sieve_controls.json',OUT/'remaining_fiber_witnesses.json']}}
    (OUT/'independent_closure_controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print('ALL PASS',result['witness_count'],'witnesses;',result['primitive_norm_count'],'primitive norms;',checks,'prime order tests',flush=True)


if __name__=='__main__':main()

"""Independent exact arithmetic audit of the selected sieve certificates.

This file imports no producer/checker module and writes only beside itself.
Run from any directory with Python 3.10+.
"""
from __future__ import annotations

from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE


def eratosthenes(limit: int) -> list[int]:
    flags = bytearray(b"\x01") * (limit + 1)
    flags[0:2] = b"\x00\x00"
    candidate = 2
    while candidate * candidate <= limit:
        if flags[candidate]:
            for composite in range(candidate * candidate, limit + 1, candidate):
                flags[composite] = 0
        candidate += 1
    return [p for p, yes in enumerate(flags) if yes]


def divide_and_budget(n: int, primes: list[int]):
    remaining, found = n, {}
    for p in primes:
        if remaining % p == 0:
            exponent = 0
            while remaining % p == 0:
                remaining //= p
                exponent += 1
            found[p] = exponent
    # bit_length gives an upper estimate because 4097 > 2**12.
    budget = (remaining.bit_length() - 1) // 12
    while 4097**budget > remaining:
        budget -= 1
    while 4097 ** (budget + 1) <= remaining:
        budget += 1
    assert 4097**budget <= remaining < 4097 ** (budget + 1)
    assert prod(p**e for p, e in found.items()) * remaining == n
    assert all(remaining % p != 0 for p in primes)
    return found, remaining, budget


def main():
    source_path = SOURCE / "global_sieve_controls.json"
    raw = source_path.read_bytes()
    evidence = json.loads(raw)
    ps = eratosthenes(4096)
    odd = [p for p in ps if p & 1]
    one4 = [p for p in ps if p % 4 == 1]
    tail = []
    for label, pp, exponent in (("A", odd, 79), ("B", one4, 39)):
        left = 4096 ** len(pp)
        prime_product = prod(pp)
        right = 2 ** (12 * exponent) * prime_product
        assert left < right
        # Also record that reducing either stated integer constant by 1 fails.
        assert left >= 2 ** (12 * (exponent - 1)) * prime_product
        tail.append({"component": label, "prime_count": len(pp),
                     "first_prime": pp[0], "last_prime": pp[-1],
                     "log2_constant": exponent,
                     "left_bit_length": left.bit_length(),
                     "right_bit_length": right.bit_length(),
                     "exact_product_inequality": True,
                     "smaller_integer_exponent_fails": True})
    assert (len(odd), len(one4)) == (563, 276)
    assert 12 * 160 + 3 == 1923
    assert 2**1923 < 2**1924

    rows = evidence["rows"]
    assert [r["s"] for r in rows] == list(range(2, 1924))
    passed, failed, recomputed = [], [], []
    minimum = None
    n0_zero, n0_one, nonpositive_c = [], [], []
    for row in rows:
        s = row["s"]
        t = 1 << s
        aa, ra, ka = divide_and_budget(t + 1, ps)
        bb, rb, kb = divide_and_budget(t * t + 1, ps)
        assert dict(row["A_small_factors"]) == aa
        assert dict(row["B_small_factors"]) == bb
        assert len(row["A_small_factors"]) == len(aa)
        assert len(row["B_small_factors"]) == len(bb)
        assert int(row["A_residual"]) == ra
        assert int(row["B_residual"]) == rb
        assert row["A_residual_omega_upper"] == ka
        assert row["B_residual_omega_upper"] == kb
        ca, cb = set(row["core_A"]), set(row["core_B"])
        assert len(ca) == len(row["core_A"]) and ca <= aa.keys()
        assert len(cb) == len(row["core_B"]) and cb <= bb.keys()
        assert all(p % 4 == 1 for p in bb)
        omit_a, omit_b = set(aa) - ca, set(bb) - cb
        delta = (1 - sum((Fraction(1, p) for p in omit_a), Fraction())
                 - 2 * sum((Fraction(1, p) for p in omit_b), Fraction())
                 - Fraction(ka + 2 * kb, 4097))
        count = len(omit_a) + 2 * len(omit_b) + ka + 2 * kb
        weight = 2 ** (len(ca) + 2 * len(cb))
        assert 0 < delta <= 1
        coefficient = 8 * weight * (2 + Fraction(count - 1) / delta) - 6
        assert coefficient > 0
        assert Fraction(row["delta_lower"]) == delta
        assert row["omitted_position_upper"] == count
        assert Fraction(row["C"]) == coefficient
        lhs = (t + 1) ** 2 * coefficient.denominator**2
        rhs = t * coefficient.numerator**2
        positive = lhs > rhs
        assert row["positive"] is positive
        (passed if positive else failed).append(s)
        if positive:
            ratio = Fraction(lhs, rhs)
            if minimum is None or ratio < minimum[0]:
                minimum = (ratio, s, str(coefficient), str(delta), count, weight)
        if count == 0:
            n0_zero.append(s)
            assert delta == 1 and coefficient == 8 * weight - 6
        if count == 1:
            n0_one.append(s)
            assert coefficient == 16 * weight - 6
        recomputed.append({"s": s, "delta0": str(delta), "N0": count,
                           "W0": weight, "C0": str(coefficient),
                           "squared_integer_comparison": positive})
    assert failed == [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15]
    assert len(passed) == 1909
    assert evidence["unresolved_parameters"] == failed

    # All abstract truth patterns, including distinct conditions on the same
    # B-prime, obey the union-sieve score. No independence is assumed.
    pattern_count = 0
    for n in range(13):
        for truths in product((False, True), repeat=n):
            score = sum(truths) - (n - 1)
            indicator = int(all(truths))
            failures = n - sum(truths)
            assert score == 1 - failures and score <= indicator
            pattern_count += 1
    # Exact sample check of the replacement inequality, including N=0/1.
    # The general proof is supplied in 01_math_review.txt.
    monotonicity_checks = 0
    for n0 in range(13):
        for delta0 in [Fraction(1, 7), Fraction(1, 2), Fraction(9, 10), Fraction(1)]:
            if n0 == 0 and delta0 != 1:
                continue
            upper_lambda = 2 + Fraction(n0 - 1) / delta0
            for n in range(n0 + 1):
                for delta in [delta0, (delta0 + 1) / 2, Fraction(1)]:
                    if n == 0 and delta != 1:
                        continue
                    real_lambda = 2 + Fraction(n - 1) / delta
                    assert real_lambda <= upper_lambda
                    monotonicity_checks += 1

    result = {
        "status": "PASS_WITH_STATED_INPUTS",
        "scope": "independent selected-certificate arithmetic, not witness field arithmetic or a complete reproof of Paper A geometry",
        "imports_author_code": False,
        "source_sha256": sha256(raw).hexdigest(),
        "tail_checks": tail,
        "tail_exponent_threshold": {"strict_condition": "s > 1923", "first_integer": 1924},
        "finite_row_count": len(rows), "positive_rows": len(passed),
        "inequality_failure_parameters": failed,
        "C0_nonpositive_rows": nonpositive_c,
        "N0_zero_selected_rows": n0_zero,
        "N0_one_selected_rows": n0_one,
        "minimum_positive_squared_ratio": {
            "s": minimum[1], "ratio_exact": str(minimum[0]),
            "ratio_approximate": float(minimum[0]),
            "C0": minimum[2], "delta0": minimum[3],
            "N0": minimum[4], "W0": minimum[5]},
        "abstract_pointwise_truth_patterns_checked": pattern_count,
        "sample_replacement_checks": monotonicity_checks,
        "rows": recomputed,
    }
    (HERE / "03_sieve_integer_results.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    compact = {k: v for k, v in result.items() if k != "rows"}
    print(json.dumps(compact, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

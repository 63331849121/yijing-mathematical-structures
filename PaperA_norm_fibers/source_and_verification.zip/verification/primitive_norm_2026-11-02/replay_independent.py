"""Independent certificate audit, stdlib only, no author arithmetic imports.

Run: python -B replay_independent.py
Only creates reports alongside this script. Input files are opened read-only.
Polynomial irreducibility: squarefree + Berlekamp fixed-space dimension one.
Field arithmetic: nibble carryless product and byte-table polynomial reduction.
Quadratic arithmetic: normalized Artin--Schreier tower T^2+T+lambda.
"""
from pathlib import Path
from fractions import Fraction
from math import gcd, isqrt, prod
import hashlib
import json
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE
EXPECTED = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15]
CHECKS = 0


def require(condition, label):
    global CHECKS
    CHECKS += 1
    if not condition:
        raise ValueError(label)


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def input_hashes():
    return {name: digest(SOURCE / name) for name in ('global_sieve_controls.json', 'remaining_fiber_witnesses.json')}


def prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    return all(n % k for k in range(3, isqrt(n) + 1, 2))


def factor_integer(n):
    answer = []
    while n % 2 == 0:
        answer.append(2)
        n //= 2
    candidate = 3
    while candidate * candidate <= n:
        while n % candidate == 0:
            answer.append(candidate)
            n //= candidate
        candidate += 2
    if n > 1:
        answer.append(n)
    return answer


def partial_from_integer(n, primes):
    residual = n
    result = []
    for p in primes:
        exponent = 0
        while residual % p == 0:
            residual //= p
            exponent += 1
        if exponent:
            result.append([p, exponent])
    # Binary search, without treating the residual as a prime.
    lo, hi = 0, residual.bit_length() + 1
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if 4097 ** mid <= residual:
            lo = mid
        else:
            hi = mid
    require(4097 ** lo <= residual < 4097 ** (lo + 1), 'residual budget')
    require(prod(p ** e for p, e in result) * residual == n, 'partial product')
    require(all(residual % p for p in primes), 'residual small divisor')
    return result, residual, lo


def verify_integer_certificates():
    data = json.loads((SOURCE / 'global_sieve_controls.json').read_text(encoding='utf-8'))
    primes = [k for k in range(2, 4097) if prime(k)]
    odd = [p for p in primes if p != 2]
    one4 = [p for p in primes if p % 4 == 1]
    require(len(odd) == 563 and len(one4) == 276, 'tail prime counts')
    require(4096 ** len(odd) < 2 ** (12 * 79) * prod(odd), 'tail A product')
    require(4096 ** len(one4) < 2 ** (12 * 39) * prod(one4), 'tail B product')
    require(12 * (3 + 79 + 2 * 39) + 3 == 1923, 'tail threshold exponent')
    require([r['s'] for r in data['rows']] == list(range(2, 1924)), 'sieve exact parameter range')
    require(data['trial_bound'] == 4096 and data['uniform_tail_from'] == 1924, 'sieve metadata')
    require(data['uniform_constants_log2'] == [79, 39], 'tail constants')
    summaries = []
    failed = []
    for row in data['rows']:
        s = row['s']
        t = 2 ** s
        actual = []
        for name, n in [('A', t + 1), ('B', t * t + 1)]:
            factors, residual, budget = partial_from_integer(n, primes)
            require(factors == row[name + '_small_factors'], f's={s} {name} factors')
            require(residual == int(row[name + '_residual']), f's={s} {name} residual')
            require(budget == row[name + '_residual_omega_upper'], f's={s} {name} budget')
            if name == 'B':
                require(all(p % 4 == 1 for p, _ in factors), f's={s} B prime congruence')
            actual.append((factors, residual, budget))
        sa, sb = ({p for p, e in v[0]} for v in actual)
        ca, cb = row['core_A'], row['core_B']
        require(len(ca) == len(set(ca)) and set(ca) <= sa, f's={s} A core')
        require(len(cb) == len(set(cb)) and set(cb) <= sb, f's={s} B core')
        oa, ob = sa - set(ca), sb - set(cb)
        k = actual[0][2] + 2 * actual[1][2]
        delta = Fraction(1) - sum((Fraction(1, p) for p in oa), Fraction()) - 2 * sum((Fraction(1, p) for p in ob), Fraction()) - Fraction(k, 4097)
        count = len(oa) + 2 * len(ob) + k
        W = 2 ** (len(ca) + 2 * len(cb))
        C = 8 * W * (2 + Fraction(count - 1, 1) / delta) - 6
        require(delta > 0 and C > 0, f's={s} signs')
        require(delta == Fraction(row['delta_lower']), f's={s} delta')
        require(count == row['omitted_position_upper'], f's={s} count')
        require(C == Fraction(row['C']), f's={s} coefficient')
        difference = (t + 1) ** 2 * C.denominator ** 2 - t * C.numerator ** 2
        positive = difference > 0
        require(positive == row['positive'], f's={s} positive')
        if not positive:
            failed.append(s)
        summaries.append({'s': s, 'passed': positive, 'delta': str(delta), 'C': str(C), 'N_upper': count,
                          'core_A': ca, 'core_B': cb, 'A_residual_omega_upper': actual[0][2],
                          'B_residual_omega_upper': actual[1][2], 'exact_inequality_difference_sign': (difference > 0) - (difference < 0)})
    require(failed == data['unresolved_parameters'] == EXPECTED, 'unresolved set')
    special14 = next(r for r in summaries if r['s'] == 14)
    r14 = next(r for r in data['rows'] if r['s'] == 14)
    C14 = Fraction(special14['C'])
    special14 = dict(special14, A=16385, B=268435457, B_small_factors=r14['B_small_factors'],
                     B_residual=r14['B_residual'],
                     exact_inequality_difference=str(16385 ** 2 * C14.denominator ** 2 - 16384 * C14.numerator ** 2))
    print('Independent integer replay: all 1922 rows checked; unresolved', failed, flush=True)
    return {'status': 'PASS', 'rows_checked': len(summaries), 'rows': summaries,
            'successful_rows': len(summaries) - len(failed), 'unresolved_parameters': failed,
            's14': special14, 'tail': {'from': 1924, 'odd_primes_below4096': len(odd),
            'one_mod4_primes_below4096': len(one4), 'integer_product_checks': True,
            'strict_threshold': 's > 1923', 'residuals_assumed_prime': False}}


def poly_remainder(value, divisor):
    while value and value.bit_length() >= divisor.bit_length():
        value ^= divisor << (value.bit_length() - divisor.bit_length())
    return value


def poly_gcd(a, b):
    while b:
        a, b = b, poly_remainder(a, b)
    return a


def binary_rank(columns):
    basis = {}
    for column in columns:
        while column:
            pivot = column.bit_length() - 1
            if pivot in basis:
                column ^= basis[pivot]
            else:
                basis[pivot] = column
                break
    return len(basis)


class BinaryField:
    def __init__(self, modulus, n):
        self.modulus, self.n, self.q = modulus, n, 1 << n
        require(modulus.bit_length() == n + 1 and modulus & 1, 'modulus degree/constant')
        self.reduce_tables = [[poly_remainder(v << (8 * i), modulus) for v in range(256)]
                              for i in range((2 * n + 7) // 8)]
        self.square_table = [sum(((v >> j) & 1) << (2 * j) for j in range(8)) for v in range(256)]

    def reduce(self, raw):
        value, position = 0, 0
        while raw:
            value ^= self.reduce_tables[position][raw & 255]
            raw >>= 8
            position += 1
        return value

    def mul(self, a, b):
        table = [0, a]
        for i in range(1, 4):
            table += [v ^ (a << i) for v in table]
        raw, shift = 0, 0
        while b:
            raw ^= table[b & 15] << shift
            b >>= 4
            shift += 4
        return self.reduce(raw)

    def square(self, a):
        raw, shift = 0, 0
        while a:
            raw |= self.square_table[a & 255] << shift
            a >>= 8
            shift += 16
        return self.reduce(raw)

    def power(self, a, exponent):
        value = 1
        while exponent:
            if exponent & 1:
                value = self.mul(value, a)
            exponent >>= 1
            if exponent:
                a = self.square(a)
        return value

    def inverse(self, a):
        # Extended polynomial Euclidean algorithm; no exponent inversion.
        require(a != 0, 'inverse zero')
        u, v, r, z = a, self.modulus, 1, 0
        while u != 1:
            degree = u.bit_length() - v.bit_length()
            if degree < 0:
                u, v, r, z = v, u, z, r
                degree = -degree
            u ^= v << degree
            r ^= z << degree
        result = poly_remainder(r, self.modulus)
        require(self.mul(a, result) == 1, 'Euclidean inverse')
        return result

    def trace(self, a):
        value = 0
        for i in range(self.n):
            value ^= a
            a = self.square(a)
        require(value in (0, 1), 'trace in binary field')
        return value

    def irreducibility(self):
        derivative = sum(((self.modulus >> i) & 1) << (i - 1) for i in range(1, self.n + 1, 2))
        squarefree = poly_gcd(self.modulus, derivative) == 1
        # Columns of Frobenius minus identity on the quotient vector space.
        columns = [poly_remainder(1 << (2 * j), self.modulus) ^ (1 << j) for j in range(self.n)]
        fixed_dimension = self.n - binary_rank(columns)
        require(squarefree and fixed_dimension == 1, 'Berlekamp irreducibility')
        require(self.power(2, self.q) == 2, 'field Frobenius')
        # Separate bit-convolution/long-division spot check of this audit's arithmetic.
        state = 0x12345678
        for i in range(128):
            state = (1103515245 * state + 12345) & 0x7fffffff
            a = state % self.q
            state = (1103515245 * state + 12345) & 0x7fffffff
            b = state % self.q
            raw = 0
            for j in range(self.n):
                if (b >> j) & 1:
                    raw ^= a << j
            require(self.mul(a, b) == poly_remainder(raw, self.modulus), 'arithmetic spot check')
            require(self.square(a) == self.mul(a, a), 'square spot check')
        return {'squarefree': squarefree, 'Berlekamp_fixed_space_dimension': fixed_dimension,
                'arithmetic_spot_checks': 128}


class ArtinSchreierTower:
    """T^2 = T + lam; original Z = c*T, not the author's Z-basis."""
    def __init__(self, field, lam):
        self.f, self.lam = field, lam

    def mul(self, a, b):
        m = self.f.mul
        ac = m(a[0], b[0])
        bd = m(a[1], b[1])
        return ac ^ m(self.lam, bd), m(a[0], b[1]) ^ m(a[1], b[0]) ^ bd

    def square(self, a):
        x, y = self.f.square(a[0]), self.f.square(a[1])
        return x ^ self.f.mul(self.lam, y), y

    def power(self, a, exponent):
        answer = (1, 0)
        while exponent:
            if exponent & 1:
                answer = self.mul(answer, a)
            exponent >>= 1
            if exponent:
                a = self.square(a)
        return answer


def verify_witness_certificates(expected):
    data = json.loads((SOURCE / 'remaining_fiber_witnesses.json').read_text(encoding='utf-8'))
    require(data['parameters'] == expected and [r['s'] for r in data['rows']] == expected, 'witness exact parameter set')
    summaries = []
    total_prime_tests, total_d_tests, conjugate_prime_tests, conjugate_d_tests = 0, 0, 0, 0
    norm_checks, orbit_points, transported_norm_checks, checked_records = 0, 0, 0, []
    for row in data['rows']:
        s = row['s']
        t, n = 1 << s, 2 * s
        A, B = t + 1, t * t + 1
        d = A * B
        q = t * t
        require((row['A'], row['B'], row['d']) == (A, B, d), f's={s} integer parameters')
        fa, fb = factor_integer(A), factor_integer(B)
        require(fa == row['A_factors'] and fb == row['B_factors'], f's={s} factorization')
        require(prod(fa) == A and prod(fb) == B and all(prime(p) for p in set(fa + fb)), f's={s} factors prime/product')
        require(gcd(A, B) == 1, f's={s} coprime A/B')
        field = BinaryField(int(row['E_modulus'], 16), n)
        irreducibility = field.irreducibility()
        u = int(row['U_generator'], 16)
        require(0 < u < q, f's={s} generator encoding')
        require(field.power(u, A) == 1 and all(field.power(u, A // p) != 1 for p in set(fa)), f's={s} U generator exact order')
        values = [1]
        for i in range(1, A):
            values.append(field.mul(values[-1], u))
        require(len(set(values)) == A and field.mul(values[-1], u) == 1, f's={s} full U table')
        units = {j for j in range(A) if gcd(j, A) == 1}
        covered = set()
        row_prime_tests = 0
        for index, rec in enumerate(row['witnesses']):
            label = f's={s}, witness={index}'
            j, k, orbit = rec['norm_exponent'], rec['w_exponent'], rec['norm_orbit']
            require(0 < j < A and 0 < k < A and j in units and k in units, label + ' exponents')
            require(orbit and orbit[0] == j == min(orbit), label + ' canonical representative')
            own_orbit, v = [], j
            while v not in own_orbit:
                own_orbit.append(v)
                v = 2 * v % A
            require(v == j and own_orbit == orbit and len(orbit) == 2 * s, label + ' exact square orbit')
            require(not covered.intersection(orbit), label + ' orbit disjoint')
            covered.update(orbit)
            # Check the exponent orbit in the actual binary field as well.
            for v in orbit:
                require(field.square(values[v]) == values[2 * v % A], label + ' actual field Frobenius')
                orbit_points += 1
            b, w, c = [int(rec[key], 16) for key in ('b', 'w', 'c')]
            require(all(0 <= x < q for x in (b, w, c)), label + ' canonical field encodings')
            require(b == values[j] and w == values[k] and c == (1 ^ b ^ w) and c != 0, label + ' b/w/c values')
            require(field.power(b, A) == field.power(w, A) == 1, label + ' norm U membership')
            invc = field.inverse(c)
            lam = field.mul(b, field.square(invc))
            require(field.trace(lam) == 1, label + ' quadratic irreducibility trace')
            tower = ArtinSchreierTower(field, lam)
            a, plus = (0, c), (1, c)
            conjugate, plus_conjugate = (c, c), (1 ^ c, c)
            for root in (a, conjugate):
                root_square = tower.square(root)
                c_times_root = (field.mul(c, root[0]), field.mul(c, root[1]))
                require((root_square[0] ^ c_times_root[0] ^ b, root_square[1] ^ c_times_root[1]) == (0, 0), label + ' original quadratic roots')
            require(tower.power(a, q) == conjugate and tower.power(plus, q) == plus_conjugate, label + ' actual q-Frobenius conjugation')
            require(tower.mul(a, conjugate) == (b, 0) and tower.mul(plus, plus_conjugate) == (w, 0), label + ' conjugate product norms')
            require(tower.power(a, B) == (b, 0) and tower.power(plus, B) == (w, 0), label + ' actual L/E norms')
            require(field.power(w, A) == 1 and tower.power(plus, B * A) == (1, 0), label + ' actual L/K norm')
            norm_checks += 5
            # Literal squaring transport through every norm in this orbit.
            # Order transport then follows from squaring being an automorphism.
            moved_a, moved_w = a, w
            for v in orbit:
                moved_plus = (moved_a[0] ^ 1, moved_a[1])
                moved_conjugate = (moved_a[0] ^ moved_a[1], moved_a[1])
                moved_plus_conjugate = (moved_plus[0] ^ moved_plus[1], moved_plus[1])
                require(tower.mul(moved_a, moved_conjugate) == (values[v], 0), label + ' transported first norm')
                require(tower.mul(moved_plus, moved_plus_conjugate) == (moved_w, 0), label + ' transported second norm')
                require(field.power(moved_w, A) == 1, label + ' transported L/K norm')
                transported_norm_checks += 3
                moved_a, moved_w = tower.square(moved_a), field.square(moved_w)
            for element in (a, plus):
                require(tower.power(element, d) == (1, 0), label + ' d power')
                total_d_tests += 1
                for p in sorted(set(fa + fb)):
                    require(tower.power(element, d // p) != (1, 0), label + f' exact order at p={p}')
                    total_prime_tests += 1
                    row_prime_tests += 1
            # Extra literal checks of the other root and its linked translate.
            # These are additional to the claimed 16026 checks.
            for element in (conjugate, plus_conjugate):
                require(tower.power(element, d) == (1, 0), label + ' conjugate d power')
                conjugate_d_tests += 1
                for p in sorted(set(fa + fb)):
                    require(tower.power(element, d // p) != (1, 0), label + f' conjugate exact order p={p}')
                    conjugate_prime_tests += 1
            checked_records.append({'s': s, 'index': index, 'j': j, 'k': k, 'orbit_size': len(orbit),
                                    'distinct_d_primes': len(set(fa + fb)), 'status': 'PASS'})
        require(covered == units, f's={s} primitive norm coverage')
        require(len(covered) == row['primitive_norms'], f's={s} primitive norm count')
        summaries.append({'s': s, 'A': A, 'B': B, 'A_factors': fa, 'B_factors': fb,
                          'E_modulus': row['E_modulus'], 'irreducibility': irreducibility,
                          'primitive_norms': len(covered), 'witnesses': len(row['witnesses']),
                          'Frobenius_orbit_size': 2 * s, 'prime_order_tests': row_prime_tests,
                          'status': 'PASS'})
        print(f'Independent tower replay s={s}: {len(row["witnesses"])} witnesses, {len(covered)} norms, PASS', flush=True)
    count = len(checked_records)
    require(count == 1182, 'total witness count')
    require(sum(r['primitive_norms'] for r in summaries) == orbit_points == 32022, 'total norm coverage count')
    require(total_prime_tests == 16026, 'claimed prime test count')
    require(total_d_tests == 2364, 'd power count')
    require(conjugate_prime_tests == total_prime_tests and conjugate_d_tests == total_d_tests, 'extra conjugate count')
    return {'status': 'PASS', 'parameters': expected, 'rows': summaries, 'witness_count': count,
            'primitive_norms_covered': orbit_points, 'linked_element_d_power_tests': total_d_tests,
            'linked_element_prime_order_tests': total_prime_tests,
            'extra_conjugate_d_power_tests': conjugate_d_tests,
            'extra_conjugate_prime_order_tests': conjugate_prime_tests,
            'norm_identity_checks': norm_checks, 'transported_orbit_norm_checks': transported_norm_checks,
            'witness_records': checked_records}


def main():
    start = time.time()
    before = input_hashes()
    integer = verify_integer_certificates()
    witnesses = verify_witness_certificates(integer['unresolved_parameters'])
    after = input_hashes()
    require(before == after, 'input directory unchanged')
    result = {'status': 'PASS', 'scope': 'Independent finite arithmetic and certificate replay; inherited geometric estimate is outside this script.',
              'implementation': 'stdlib only; imports no author code; Berlekamp field check; normalized Artin-Schreier tower; exact integer arithmetic',
              'input_directory': str(SOURCE), 'input_sha256_before': before, 'input_sha256_after': after,
              'input_unchanged': True, 'integer_sieve': integer, 'finite_witnesses': witnesses,
              'script_sha256': digest(Path(__file__)), 'require_checks': CHECKS,
              'python': sys.version, 'elapsed_seconds': round(time.time() - start, 3)}
    destination = HERE / 'independent_replay_results.json'
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('ALL PASS:', count_summary(witnesses), 'checks', CHECKS, 'seconds', result['elapsed_seconds'], flush=True)


def count_summary(w):
    return f'{w["witness_count"]} witnesses, {w["primitive_norms_covered"]} covered norms, {w["linked_element_prime_order_tests"]} claimed prime tests + same number extra conjugate tests'


if __name__ == '__main__':
    main()

Complete primitive inner-norm support: portable verification attachment
2026-11-02. Run from the project directory with Python 3.10+ (stdlib only).

python -B verification/primitive_norm_2026-11-02/verify_closure_independent.py
python -B verification/primitive_norm_2026-11-02/replay_independent.py
python -B verification/primitive_norm_2026-11-02/check_sieve_integer.py

Do not use -O: two checkers use assertions. No witness finder is called.
Each command writes its report beside the script, leaving both data files unchanged.

Inputs (copied byte for byte from the reviewed research archive):
global_sieve_controls.json: all 1922 rows for s=2,...,1923; 1909 positive.
remaining_fiber_witnesses.json: 1182 witnesses for 13 remaining parameters,
covering every one of the 32022 primitive norms by doubling orbits.
Both prime products for the uniform s>=1924 tail are reconstructed exactly.

verify_closure_independent.py: Rabin irreducibility, bit convolution/long division,
literal Z^2+cZ+b quadratic tower powers; 16026 prime-order tests.
replay_independent.py: independently authored review implementation using
Berlekamp irreducibility, nibble products, normalized T^2+T+b/c^2 tower;
also checks the conjugate root and transports all 32022 norm positions.
check_sieve_integer.py: separate exact integer/rational implementation,
including selected core budgets, pointwise sieve scores and edge cases.

input_provenance.json records original paths, hashes and portability adaptations.
Only review checker input paths and its immutable-input hash list were adapted.
No arithmetic logic or certificate values were changed.

The general sieve, tail bound and Frobenius propagation are mathematical proofs
in the manuscript. These programs certify their finite arithmetic inputs.
The inherited geometric character estimate is not re-proved by these programs.

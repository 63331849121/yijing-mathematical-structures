Current selective Lean formalization, 2026-10-26

InverseSupportGrid.lean formalizes the two-coordinate combinatorial core used
in the inverse-support lemma preceding Theorem 5.4. It imports only Lean Init.
The toolchain is pinned to leanprover/lean4:v4.31.0.

With this toolchain already installed, run:
  python verify_lean.py
or:
  elan run leanprover/lean4:v4.31.0 lean InverseSupportGrid.lean

The checker records a fresh successful Lean run and prints the axiom dependency
audit for six declarations. No proof placeholders or added axioms are used.

The exact formal scope consists of cover inversion, the two possible mixed
corners, the intersection of two covers, inverse-pair support rigidity,
exclusion by a third support point, and the converse inverse-pair cover test.
Involutions, inverse closure and nonfixed distinguished coordinates are explicit
hypotheses. These are mathematical hypotheses, not proofs of the finite-field
interfaces where they are used in the paper.

Not formalized here: cyclic-group CRT and generator/coordinate equivalence;
the specific Frobenius and reciprocal-trace interface; the finite-field witness
checker; the one-prime or prime-kernel counting branches; the four/eight-point
geometric character bounds; and the complete statement of Theorem 5.4.

The original three mathlib files remain unchanged under:
  provenance/original_repository/PaperA_scalar_realizations/lean/
Their earlier pinned-environment checks are historical records. Two historical
hashes (AGL.lean and CohenEvenConditional.lean) do not match the distributed
files; the old JSON is preserved as a historical record, not silently replaced.
This revision's three successful reruns are separately recorded in:
  verification/supplement_sync_2026-10-26/original_lean_fresh_checks.json
The checker verifies that each rerun record refers to the distributed bytes.
It does not rerun the three mathlib files in every invocation. All three
distributed files passed the separate rerun. Their exact
toolchain and nine dependency commits are recorded separately.

Lean checking of a selected lemma, exact finite arithmetic and an external
mathematical peer review are separate forms of evidence. No full Lean build of
the paper or external human peer review is claimed.

"""Finite corroboration of our structural norm/trace comparison.

This does not verify any unavailable theorem from Rani et al. (2023).
Run with Python's standard library, without -O.
"""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def mul(a, b, modulus):
    raw = 0
    while b:
        low = b & -b
        raw ^= a << (low.bit_length()-1)
        b ^= low
    while raw.bit_length() >= modulus.bit_length():
        raw ^= modulus << (raw.bit_length()-modulus.bit_length())
    return raw


def power(a, exponent, modulus):
    value = 1
    for bit in bin(exponent)[2:]:
        value = mul(value, value, modulus)
        if bit == '1':
            value = mul(value, a, modulus)
    return value


def absolute_trace(a, n, modulus):
    value = 0
    for _ in range(n):
        value ^= a
        a = mul(a, a, modulus)
    assert value in (0, 1)
    return value


def artin_schreier_solver(n, modulus):
    pivots = {}
    for i in range(n):
        column = mul(1 << i, 1 << i, modulus) ^ (1 << i)
        mask = 1 << i
        while column:
            k = column.bit_length()-1
            if k not in pivots:
                pivots[k] = (column, mask)
                break
            v, u = pivots[k]
            column ^= v
            mask ^= u
    assert len(pivots) == n-1

    def solve(value):
        target, out = value, 0
        while value:
            k = value.bit_length()-1
            v, u = pivots[k]
            value ^= v
            out ^= u
        assert mul(out, out, modulus) ^ out == target
        return out
    return solve


def main():
    source = ROOT/'verification/uniform_trace/uniform_trace_checks.json'
    data = json.loads(source.read_text(encoding='utf-8'))
    rows = []
    for row in data['complete_finite_slice_certificates']:
        s, t = row['s'], row['t']
        n = 2*s
        modulus = int(row['E_modulus_hex'], 16)
        b = int(row['quadratic_b_hex'], 16)
        A = t+1
        assert power(b, A, modulus) == 1
        assert all(power(b, A//p, modulus) != 1 for p in row['A_prime_divisors'])
        h = b ^ power(b, t, modulus)
        assert h and power(h, t, modulus) == h
        solve = artin_schreier_solver(n, modulus)
        bad, all_c, good = [], set(), 0
        for item in row['slices']:
            c = int(item['c_hex'], 16)
            assert c and c not in all_c and power(c, t, modulus) == c
            all_c.add(c)
            ci = power(c, (1 << n)-2, modulus)
            inverse_square = mul(ci, ci, modulus)
            term = mul(b, inverse_square, modulus)
            trace = absolute_trace(term, n, modulus)
            assert trace == absolute_trace(mul(h, inverse_square, modulus), s, modulus)
            if trace:
                good += 1
                continue
            root = mul(c, solve(term), modulus)
            other = root ^ c
            assert mul(root, root, modulus) ^ mul(c, root, modulus) ^ b == 0
            assert mul(root, other, modulus) == b and root ^ other == c
            assert root != other and power(root, 1 << n, modulus) == root
            assert power(other, 1 << n, modulus) == other
            bad.append(dict(c_hex=hex(c), root_hex=hex(root), other_root_hex=hex(other)))
        assert len(all_c) == t-1 and len(bad) == t//2-1 and good == t//2
        rows.append(dict(s=s, t=t, q=t*t, n=2, r=t-1, k=0, omega=t-1,
                         E_modulus_hex=hex(modulus), norm_b_hex=hex(b),
                         norm_b_exact_order=A, bad_nonzero_K_traces=len(bad),
                         expected_bad_count=t//2-1, good_irreducible_traces=good,
                         one_explicit_counterexample=bad[0]))
        print('UNIFORM_NORM_TRACE_OBSTRUCTION', s, 'bad c', len(bad), 'PASS')

    # E=F2[z]/(z^4+z+1), b=z^3 of order 5, c=z+z^2 in F4*.
    modulus, z, b, c = 0x13, 2, 8, 6
    assert power(b, 5, modulus) == 1 and b != 1 and power(c, 4, modulus) == c
    assert z ^ mul(z, z, modulus) == c and mul(z, mul(z, z, modulus), modulus) == b
    explicit = dict(t=4, q=16, n=2, r=3, k=0, omega=3,
                    E_modulus_hex='0x13', norm_b_hex='0x8', trace_c_hex='0x6',
                    factorization='(X+z)(X+z^2)=X^2+(z+z^2)X+z^3',
                    norm_b_exact_order=5,
                    conclusion='Both roots lie in E and have zero trace from L/E; no L element can have this prescribed norm b and nonzero relative trace c.')
    output = dict(status='PASS',
                  scope='Our structural obstructions, not verification of unavailable Rani23 sufficient conditions.',
                  source_certificate_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  quadratic_obstructions=rows, explicit_t4_counterexample=explicit,
                  aggregate_counts_from_previously_verified_data=[
                      dict(s=row['s'], sum_M_c=sum(x['M'] for x in row['slices']),
                           M1=next(x['M'] for x in row['slices'] if x['c_hex'] == '0x1'))
                      for row in data['complete_finite_slice_certificates'] if row['s'] in (3, 5)])
    (HERE/'structural_parameter_checks.json').write_text(json.dumps(output, indent=2), encoding='utf-8')
    print('STRUCTURAL_CHECKS_PASS')


if __name__ == '__main__':
    main()

"""Build both current PDFs to a stable mutual-reference state and audit preservation."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import re
import subprocess
from pypdf import PdfReader

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BEFORE=HERE/'before_supplement_sync'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,o):(HERE/name).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    desktop=json.loads((HERE/'desktop_compiler.json').read_text(encoding='utf-8'))
    if desktop['status']!='PASS':raise RuntimeError('Built-in compilation checks incomplete')
    previous=None;stable=False
    for cycle in range(1,5):
        for name in ['main','supplement']:
            p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],
                cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            if p.returncode:raise RuntimeError(p.stdout.decode(errors='replace')[-6000:])
        state=hashlib.sha256(b''.join((ROOT/f).read_bytes() for f in
            ['main.aux','supplement.aux','main.out','supplement.out','supplement.toc'])).hexdigest()
        if state==previous:stable=True;break
        previous=state
    if not stable:raise RuntimeError('Mutual references did not stabilize')
    compilations=[]
    for name in ['main','supplement']:
        text=(ROOT/(name+'.log')).read_text(encoding='utf-8',errors='replace')
        bad=[line for line in text.splitlines() if any(s in line for s in
            ['Undefined control sequence','LaTeX Error:','Overfull \\hbox','Overfull \\vbox',
             'undefined references','multiply defined','has been referenced but does not exist',
             'Rerun to get cross-references right']) or re.search(r'LaTeX Warning: (?:Reference|Citation).*undefined',line)]
        if bad:raise RuntimeError(json.dumps({'document':name,'issues':bad}))
        compilations.append({'document':name,'pages':len(PdfReader(ROOT/(name+'.pdf')).pages),
            'pdf_sha256':sha(ROOT/(name+'.pdf')),'issues':[],
            'built_in_compiler_success':desktop['documents'][name]=='success','compilation_cycles':cycle})
    write('compilation.json',{'status':'PASS','mutual_reference_state_stable':True,'documents':compilations})
    aux='\n'.join((ROOT/f).read_text(encoding='utf-8') for f in ['main.aux','supplement.aux'])
    labels=dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}',aux))
    mapped=list(csv.DictReader((ROOT/'provenance/label_mapping.csv').open(encoding='utf-8-sig')))
    for row in mapped:
        if labels.get(row['Original label'])!=row['New printed number']:
            raise RuntimeError('Original printed number changed: '+row['Original label'])
    old=json.loads((BEFORE/'delivery_manifest.json.snapshot').read_text(encoding='utf-8'))
    oldsha={x['path']:x['sha256'] for x in old['files']}
    math=json.loads((ROOT/'provenance/mathematical_preservation_audit.json').read_text(encoding='utf-8'))
    core=sorted({x['destination'] for x in math['results']})
    for p in core:
        if sha(ROOT/p)!=oldsha[p]:raise RuntimeError('Core mathematical source changed: '+p)
    if sha(ROOT/'main/trace_slices.tex')!=oldsha['main/trace_slices.tex']:
        raise RuntimeError('Current trace theorems or support proof changed')
    original_lean=ROOT/'provenance/original_repository/PaperA_scalar_realizations/lean'
    for name in ['AGL.lean','CohenEvenConditional.lean','CompleteMappingTriality.lean','checked_environment.json']:
        p=original_lean/name;rel=p.relative_to(ROOT).as_posix()
        if sha(p)!=oldsha[rel]:raise RuntimeError('Historical Lean file changed: '+name)
    write('preservation_checks.json',{'status':'PASS','original_labels_preserved':len(mapped),
        'original_statement_proof_count':len(math['results']),'original_core_files_unchanged':core,
        'trace_section_including_51_54_and_support_proof_unchanged':True,
        'original_52_page_pdf_unchanged':sha(ROOT/'provenance/PaperA_original_52pages.pdf')==oldsha['provenance/PaperA_original_52pages.pdf'],
        'historical_Lean_sources_and_records_unchanged':True})
    spec=importlib.util.spec_from_file_location('pdf_links_only',ROOT/'verification/fulltext_structure_2026-10-26/finalize_structure.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    write('pdf_links.json',module.check_links())
    print(json.dumps({'status':'PASS','cycles':cycle,'documents':compilations,'original_labels':len(mapped)},ensure_ascii=False))


if __name__=='__main__':main()

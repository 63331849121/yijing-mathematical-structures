"""Synchronize the supplement and distinguish current Lean checks from history."""
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def one(text,old,new):
    if text.count(old)!=1:raise RuntimeError('Replacement not unique: '+old[:90])
    return text.replace(old,new,1)


def main():
    legacy=json.loads((HERE/'original_lean_fresh_checks.json').read_text(encoding='utf-8'))
    new=json.loads((ROOT/'formalization/lean_check.json').read_text(encoding='utf-8'))
    if legacy['status']!='PASS' or new['status']!='PASS':raise RuntimeError('Lean checks incomplete')
    p=ROOT/'supplement/comparison.tex'
    text=p.read_text(encoding='utf-8')
    old=r'''Theorem~\ref{thm:uniform-relative-trace} extends the trace-one
calculation to every nonzero $c\in K$, with the same four-point
bound. The prime sieve is classical; the uniform application
gives $M_c>0$ for $s\ge10$, and the polynomial calculation
identifies the two empty trace-one parameters. Exact full-order
witnesses in the remaining small fields show that these are
the only empty nonzero slices.'''
    updated=r'''Theorem~\ref{thm:uniform-relative-trace} extends the trace-one
calculation to every $c\in E^*$, with the uniform four-point
bound. Theorem~\ref{thm:trace-positivity-classification} classifies
the complete empty groups $C_9$ at $s=3$ and $C_{11}$ at $s=5$.
The current finite proof uses the inverse-support reduction,
$755$ representative witnesses and $731$ separating witnesses;
the older all-trace coverage families remain a separate check.
Proposition~\ref{prop:trace-norm-distribution} and
Corollaries~\ref{cor:exceptional-trace-profiles}--\ref{cor:arbitrary-norm-trace}
give the within-class distribution and arbitrary-norm transfer.
Main Appendix~\ref{app:trace-certificates} states the current
certificate dependencies.'''
    text=one(text,old,updated)
    start=text.index('Rani--Sharma--Tiwari--Panigrahi')
    replacement=r'''Rani--Sharma--Tiwari--Panigrahi \cite{Rani23} provide a
prescribed-order, norm and trace framework containing these
counts after specialization and summation. Their complete
Section~4 has now been checked. The relevant sufficient
conditions become $t^{-1}>(t-1)W(d)$ over $K$, or
$t^{-2}>(t-1)W(B)$ over $E$, and fail for $t\ge4$.
For $c\in K^*$ the relative-trace population is $1$-normal
over $K$; for $c\in E\setminus K$ it is normal. A condition
on absolute trace alone therefore does not prescribe the
individual $E$-valued relative trace.

The earlier function-field count \cite{Oz05} and quartic
primitive-normal geometry \cite{Ha15} are also predecessors.
Main Appendix~\ref{app:prior-trace-comparisons} records their
fulltext comparisons, including exact-genus refinements and
the aggregate-to-slice identity. It also records the completed
comparisons with the recent product, hypersurface and
rational-image criteria. The five priority original-fulltext
gaps have been closed; this is not an exhaustive global
priority certification. MathSciNet topic retrieval remains
incomplete, and no failure of a displayed criterion is taken
to exclude every refinement of its methods.
'''
    text=text[:start]+replacement
    p.write_text(text,encoding='utf-8')

    p=ROOT/'supplement/verification.tex'
    text=p.read_text(encoding='utf-8')
    end=text.index('All numerical claims')
    current=r'''\section{Verification scope and original coordinate certificates}\label{app:code}
This appendix separates current checks from the archived
verification record of the original $52$-page manuscript.
Current project paths refer to the accompanying restructured
project; paths in the archived subsection refer to the original
paper directory under \path{provenance/original_repository/}.

\subsection*{Current trace certificates and Lean scope}
The uniform relative-trace estimate, complete $C_9/C_{11}$
classification, variance formula and norm transfer are in main
Section~\ref{sec:existence}. Main
Appendices~\ref{app:trace-certificates}--\ref{app:reproducibility}
specify their exact-arithmetic checks. The current finite
classification proof uses $755$ representative witnesses and
$731$ support-separation witnesses; $255$ further representatives
at the analytic case $s=8$ and the old $3319$ all-trace families
are retained as checks. These computations and the ordinary
geometric proof have separate roles.

The new module \path{formalization/InverseSupportGrid.lean}
has been checked with Lean~4.31.0. It imports only \path{Init}
and checks six lemmas: inversion of a row--column cover,
the two mixed corners, the intersection of two covers,
inverse-pair support rigidity, exclusion by a third support
point, and the converse test for an inverse-pair support.
The compiler's axiom audit reports no axiom dependencies for
these six declarations. Involutions, inverse closure and the
nonfixed distinguished coordinates are explicit hypotheses.

This is selective formalization of the two-coordinate
combinatorial core. It does not formalize the cyclic-group
CRT interface, the finite-field Frobenius and order interfaces,
the field-witness checker, the one-prime counting branches,
the geometric character estimates, or the complete
Theorem~\ref{thm:trace-positivity-classification}.
The fresh source hash, compiler output and precise scope are
in \path{formalization/lean_check.json} and
\path{formalization/lean_check.log}.

The three original Lean files have also been rerun on the
distributed sources in an isolated environment using the
original Lean version and all nine pinned dependency commits.
All three checks exit successfully. The mathlib archive cache
was reused; a cache-free cloud build is not claimed.
The historical \path{checked_environment.json} contains
different hashes for \path{AGL.lean} and
\path{CohenEvenConditional.lean}; it is preserved as history.
The new results and the actual distributed hashes are recorded
separately in
\path{verification/supplement_sync_2026-10-26/original_lean_fresh_checks.json}.
The old hash record is not used as proof that the current bytes
were checked. No source file in the original Lean archive was
modified to obtain the new checks.

\subsection*{Archived verification record of the original manuscript}
The following record is retained from the $52$-page source
at the pinned revision in main
Appendix~\ref{app:reproducibility}. Its original run counts and
formalization claims describe that source record; current
scope is given above.

'''
    text=current+text[end:]
    text=one(text,r'\subsection*{Explicit $\tau$-collapse data}',
             r'\subsection*{Explicit tau-collapse data}')
    p.write_text(text,encoding='utf-8')

    p=ROOT/'main/reproducibility.tex'
    text=p.read_text(encoding='utf-8')
    old=r'''revision includes no fresh complete Lean build.'''
    updated=r'''revision includes no complete Lean formalization of the paper.
The three original Lean files were separately rerun in an
isolated environment with the pinned toolchain and dependency
commits; all passed, using the existing mathlib archive cache.
Two hashes in the historical check record differ from the
distributed sources, so the new actual hashes and successful
runs are recorded separately in
\path{verification/supplement_sync_2026-10-26/}.

The new dependency-free module
\path{formalization/InverseSupportGrid.lean} freshly checks
six lemmas forming the two-coordinate combinatorial core of
the inverse-support reduction. Their axiom audit is empty.
The cyclic-group CRT and finite-field interfaces, field
certificates and geometric estimates remain paper proofs
or external exact-arithmetic checks. In particular this
module does not formalize the complete trace classification.
Supplementary Appendix~\ref{app:code} gives the precise
current and historical formalization scopes.'''
    text=one(text,old,updated)
    p.write_text(text,encoding='utf-8')

    p=ROOT/'supplement/bibliography.tex'
    text=p.read_text(encoding='utf-8')
    entries=r'''\bibitem{Oz05} F.~\"Ozbudak,
\emph{Elements of prescribed order, prescribed traces and systems
of rational functions over finite fields},
Des.~Codes Cryptogr.~34 (2005) 35--54,
\href{https://doi.org/10.1007/s10623-003-4193-0}{doi:10.1007/s10623-003-4193-0}.
\bibitem{Ha15} D.~Hachenberger,
\emph{Primitive normal bases for quartic and cubic extensions:
a geometric approach}, Des.~Codes Cryptogr.~77 (2015) 335--350,
\href{https://doi.org/10.1007/s10623-015-0051-0}{doi:10.1007/s10623-015-0051-0}.
'''
    text=one(text,'\\end{thebibliography}',entries+'\\end{thebibliography}')
    p.write_text(text,encoding='utf-8')
    p=ROOT/'supplement.tex'
    text=p.read_text(encoding='utf-8')
    text=one(text,'\\input{preamble}',r'''\input{preamble}
% Use the standard ten-point mono metrics at all sizes for portable previews.
\AtBeginDocument{%
  \begingroup\normalfont\ttfamily\endgroup
  \DeclareFontShape{T1}{lmtt}{m}{n}{<->ec-lmtt10}{}%
  \renewcommand{\labelitemi}{\(\bullet\)}%
}''')
    p.write_text(text,encoding='utf-8')
    print('Supplement comparisons, current formalization scope and main verification record synchronized.')


if __name__=='__main__':main()

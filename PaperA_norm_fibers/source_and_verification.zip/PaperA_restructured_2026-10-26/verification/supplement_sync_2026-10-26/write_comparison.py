"""Compare the archived 52-page source with the synchronized current manuscript."""
from pathlib import Path
from pypdf import PdfReader
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def main():
    pages={name:len(PdfReader(ROOT/name).pages) for name in
        ['provenance/PaperA_original_52pages.pdf','main.pdf','supplement.pdf','PaperA_贡献与重构审计.pdf']}
    old=pages['provenance/PaperA_original_52pages.pdf'];main=pages['main.pdf'];supp=pages['supplement.pdf']
    lean=json.loads((ROOT/'formalization/lean_check.json').read_text(encoding='utf-8'))
    legacy=json.loads((HERE/'original_lean_fresh_checks.json').read_text(encoding='utf-8'))
    if old!=52 or lean['status']!='PASS' or legacy['status']!='PASS':raise RuntimeError('Comparison prerequisites failed')
    text=f'''原52页稿与当前版本：内容、结构及形式化范围对照
2026年10月26日；v12-supplement-sync-and-selective-Lean

一、比较对象和页数口径

原稿为provenance/PaperA_original_52pages.pdf，实测{old}页，题为
Affine companion groups in characteristic two: scalar realizations and density，日期2026年10月12日。
当前研究稿为main.pdf {main}页，加supplement.pdf {supp}页，合计{main+supp}页。
主稿比原单卷集中，但整体材料比原52页增加了{main+supp-old}页，不能表述成把整篇52页缩减成{main}页。
分卷带来独立引言、目录与参考文献，新增理论、证书及归属说明也增加篇幅；页数差不能直接当作数学增量。
根目录13页的PaperA_贡献与重构审计.pdf为早期历史快照，不是当前版本总评；当前状态以本报告及最新核验记录为准。

二、原稿已经具备的内容：本轮没有重新“发明”

原52页已有46条编号数学陈述及100个原标签。其陈述、证明及重构后编号已持续保留。
以下核心内容原稿已经存在，当前主要是重组、归属澄清和论证依赖的优化：

内容                              原编号       当前编号/位置
仿射伴随群的一般矩阵公式            5.1          主稿2.3
范数纤维8√t混合特征和估计           5.21         主稿3.4
联合生成密度及范数系数的精确平均     5.23         主稿4.3
双满阶密度及D_d全参数正性           5.24         主稿4.4
统一指标1/4障碍                    5.12         主稿6.7
迹一双满阶子族及四点覆盖            5.25         补充稿S8.1

因此原稿的“5.1”与现稿的“5.1”不是同一条定理，不能仅按同号比较。
原稿已经证明D_d>0对所有s>=2成立，当前不能把这一全族存在性重新算成后续新增结论。
原稿也已经有c=1的四点估计、Frobenius耦合和明确经典工具归属；常数4本身不是后续才出现。

三、相对原稿的主要实质扩展

1. 相对迹范围与统一估计。
   原稿着重迹一子族及其大参数存在性；现5.1将相应计数统一扩展到所有c∈E*，保留相位约化、几何覆盖与精确中心。
   这是真正的参数范围与分布结论扩展，不能仅视为章节搬迁。

2. 完整异常分类。
   原稿记录迹一在s=3、5为空，且用完整邻接族的有限证书处理小参数。
   现5.4刻画整个E*上的全部空切片：s=3的C9及s=5的C11，并完整刻画迹一子族何时为正。
   它与原稿D_d全族正性是不同问题：D_d在这两个参数仍然为正。

3. 分布细化。
   增加精确Kloosterman中心、固定迹范数类的卷积、均值与方差（方差去掉W(A)因子），
   并给出t=32上的0/20/18完整分布，以及任意非零范数纤维的缩放分类。
   其中傅里叶工具和缩放本身为经典步骤；不把所有短推论并列计算为重大独立创新。

4. 新证明结构。
   取逆支持集归结把有限部分改为755个代表迹见证与731个支持分离见证，合计1486。
   同口径排除分析已解决的s=8，旧全迹证明为2809个压缩覆盖族；旧方法本来就不是逐点穷举。
   C9由支持缺失解释，C11由支持集中于素数坐标核解释。双素数条件、取逆对称及支持分离都有反例说明边界。

5. 文献归属与查新。
   现已完成五项优先原始全文的逐条件比较，并区分计数对象前驱、经典方法与本族的有效结论。
   这提高了新颖性判断的依据，不等于完成全球所有文献排除；MathSciNet主题检索仍未完成。

四、补充稿本轮同步了什么

S7原来仍写“Rani等仅核对摘要”，且把相对迹范围写成K*，已修正为实际完成的全文核查及E*范围。
同时区分K*相对迹的1-normal类型和E\\K相对迹的normal类型，并指向主稿附录D的完整条件比较。
S.B现在先说明当前验证及形式化范围，再保留原52页验证记录，避免把历史运行记录当作本次结果。
主稿附录C同步说明新Lean模块及原三文件重跑结果；两份PDF互引重新编译并检查。
没有因此重写坐标Singer、铺展、非线性例子等原有数学证明。
补充稿预览所缺的一个Latin Modern实体字体以未修改资源及许可证提供，避免依赖下载失败的字体缓存。

五、Lean：原有内容、实际新增与尚未覆盖

原有三份：
- CompleteMappingTriality.lean：函数层面的轮换、F³=id和唯一不动点。
- AGL.lean：域标量情形的交换子、平移共轭及Singer型群生成推导。
- CohenEvenConditional.lean：显式阶与Frobenius接口下的恒等式及阶推导。
  其中CohenEvenData是数据接口声明，不是已经构造出这些数据的存在性证明。

本轮发现历史checked_environment.json有两项哈希与分发文件不一致：AGL及CohenEvenConditional。
没有改写历史记录，也没有修改原有Lean文件；在隔离目录重新取得全部9个固定依赖源码，复用本机mathlib缓存，按Lean4.31.0重跑三份实际源码，全部通过。
本次源码哈希、9个提交、编译结果与日志另存original_lean_fresh_checks.json及各文件check.log。
这补齐的是“分发源码对应哪一次成功检查”的证据，不能仅凭旧JSON宣称当前文件已通过。
没有声称进行了完全无缓存的云端CI。

实际新增formalization/InverseSupportGrid.lean，只依赖Lean Init。
其中6条引理已新鲜编译通过，公理依赖检查均为空：
覆盖取逆、两个混合角点、两覆盖之交、互逆点对刚性、第三点排除覆盖，以及互逆点对覆盖的反向判据。
这些是已有组合证明的机器验证，不作为新增的六项数学创新来计数。

仍未形式化：
- 循环群CRT商与满阶条件的完整接口；
- 具体有限域Frobenius如何产生T_h取逆闭合及与M_c计数的连接；
- 单素数/素数坐标核分支和2n/(pq)的精确计数接口；
- 有限域见证与多项式证书在Lean内的可靠检验器；
- 四点、八点几何特征和估计，以及5.1、5.4的完整Lean证明。
因此“已有部分Lean核验”成立，“整篇或定理5.4已完全形式化”不成立。

六、是否需要继续形式化

建议有选择地继续，而不把整篇Lean化设为当前投稿前置任务。
优先次序：
1. 对关键几何证明作外部独立同行复核，尤其下降、字符迹、几何非平凡性与分歧步骤；本轮尚未完成这项外部复核。
2. 如继续Lean，先补循环群CRT/阶接口，把已核验的二维组合核心连接到实际支持引理。
3. 再考虑一个经过证明正确的有限证书检验器，使字段运算及有限覆盖不只停留在外部Python检查。
4. 完整几何特征和理论的Lean形式化需扩展更大范围，现阶段不宜替代论文的理论价值提升和同行审核。

七、总体评价

当前版本在原有核心成果之上，形成了更完整的相对迹分布与异常分类主线，并更清楚地区分经典工具、专门族新结论和直接推论。
叙述更集中，证书依赖更清晰，形式化说明与实际源码检查重新对齐。
整篇数学正确性和学术重要性仍应分别评价：选择性Lean提高可靠性，不能替代几何同行复核，也不能单凭它判定期刊分区。
后续最有价值的理论提升仍是更强的结构机制、可迁移结论或边界问题突破，而非单纯增加页数、定理数量或形式化声明。
'''
    (HERE/'原52页与当前版本_对照及形式化范围.txt').write_text(text,encoding='utf-8')
    record={'date':'2026-10-26','revision':'v12-supplement-sync-and-selective-Lean',
        'pages':pages,'current_research_pages':main+supp,'original_labels':100,'original_named_statements':46,
        'original_core_results_retained_not_claimed_as_new':True,
        'numbering_warning':'Original Theorem 5.1 is current Theorem 2.3, not current Theorem 5.1',
        'new_Lean_core_declarations':len(lean['new_declarations_checked']),
        'new_core_axiom_dependencies_empty':True,'original_Lean_sources_freshly_checked':3,
        'historical_hash_mismatches_resolved_by_separate_fresh_check':True,
        'original_historical_records_modified':False,'full_paper_Lean_formalization_completed':False,
        'original_pdf_sha256':hashlib.sha256((ROOT/'provenance/PaperA_original_52pages.pdf').read_bytes()).hexdigest()}
    (HERE/'comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'WRITTEN','original_pages':old,'main_pages':main,'supplement_pages':supp,'total':main+supp}))


if __name__=='__main__':main()

"""Finalize synchronized manuscripts, selective formalization and the public overview."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ZIP = ROOT.parent / 'PaperA_restructured_editable.zip'
BACKUP = ROOT.parent / 'PaperA_restructured_editable_v11_before_supplement_sync.zip'
BACKUP_SHA = 'ab4a48ace2cc3e57c764c8736f01a778b2ee109b63f021b73c65e9eeb768f016'
OVERVIEW = '中文综述_范数纤维与相对迹.txt'
REPORT = 'verification/supplement_sync_2026-10-26/本轮同步与形式化说明.txt'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    previous = read(HERE / 'before_supplement_sync/delivery_manifest.json.snapshot')
    compilation = read(HERE / 'compilation.json')
    preservation = read(HERE / 'preservation_checks.json')
    rendered = read(HERE / 'rendered_inputs.json')
    lean = read(ROOT / 'formalization/lean_check.json')
    legacy = read(HERE / 'original_lean_fresh_checks.json')
    if compilation['status'] != 'PASS' or preservation['status'] != 'PASS':
        raise RuntimeError('Compilation or preservation failed')
    if not compilation['mutual_reference_state_stable']:
        raise RuntimeError('References not stable')
    for item in compilation['documents']:
        name = item['document']
        if item['issues'] or not item['built_in_compiler_success']:
            raise RuntimeError('Unclean compilation: ' + name)
        if digest(ROOT / (name + '.pdf')) != item['pdf_sha256']:
            raise RuntimeError('PDF changed after compilation: ' + name)
        render = next(x for x in rendered['documents'] if x['document'] == name)
        if render['pdf_sha256'] != item['pdf_sha256'] or render['pages'] != item['pages']:
            raise RuntimeError('Rendered PDF is stale: ' + name)
    if lean['status'] != 'PASS' or legacy['status'] != 'PASS':
        raise RuntimeError('Lean check failed')
    if digest(ROOT / lean['module']) != lean['source_sha256']:
        raise RuntimeError('Current formalization source changed')
    if len(lean['new_declarations_checked']) != 6 or not lean['all_six_declarations_have_no_axiom_dependencies']:
        raise RuntimeError('Formalization scope mismatch')
    for item in legacy['files']:
        source = ROOT / 'provenance/original_repository/PaperA_scalar_realizations/lean' / item['file']
        if item['exit_code'] or digest(source) != item['source_sha256']:
            raise RuntimeError('Legacy rerun does not refer to distributed source')
    if not legacy['all_nine_dependency_commits_rechecked_after_runs']:
        raise RuntimeError('Pinned dependencies not verified')

    visual = {
        'status': 'PASS',
        'review_basis': 'All six contact sheets inspected before interruption; four changed detail pages inspected on resumption.',
        'documents': [dict(document=x['document'], pages=x['pages'], pdf_sha256=x['pdf_sha256'],
                           all_pages_rendered_and_contact_reviewed=True) for x in compilation['documents']],
        'total_pages_reviewed': 76,
        'detail_pages': {'main': [36], 'supplement': [25, 31, 32]},
        'checks': ['No clipped text or equations', 'No replacement glyphs in changed passages',
                   'Readable monospaced paths and hashes', 'Consistent page layout and headings'],
        'issues': []}
    write(HERE / 'visual_review.json', visual)
    spec = importlib.util.spec_from_file_location('retained_link_inspector',
        ROOT / 'verification/fulltext_structure_2026-10-26/finalize_structure.py')
    util = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(util)
    links = util.check_links()
    write(HERE / 'pdf_links.json', links)

    overview = (ROOT / OVERVIEW).read_text(encoding='utf-8')
    if '旧稿' in overview or '52页' in overview or '全球首创' in overview:
        raise RuntimeError('Public overview contains excluded historical/priority framing')
    write(HERE / 'overview_review.json', {
        'status': 'PASS', 'file': OVERVIEW, 'sha256': digest(ROOT / OVERVIEW),
        'characters': len(overview), 'source_documents': ['main.pdf', 'supplement.pdf'],
        'checked_topics': ['Joint generation vs individual exact order', 'Base-field error scale',
            'Uniform E-valued traces', 'Complete nonzero C9/C11 exception classification',
            'Inverse-support hypotheses', 'Norm transfer and maximum orders',
            'Quarter exponent with logarithmic gap', 'Three GL(4,2) fixed-map classes',
            'Explicit nonlinear A16 example', 'Selective Lean scope'],
        'old_manuscript_discussion': False, 'absolute_priority_or_journal_guarantee': False})

    report = '''主稿、补充稿同步与选择性形式化：最终说明
2026年10月26日

当前主稿40页，补充稿36页，共76页。二者的桌面编译和稳定本地编译均通过；
全部页面已渲染检查，改动页另作放大核对，双向PDF目标链接检查通过。

补充稿S7已同步为整个E*的相对迹估计、完整C9/C11例外分类及支持集证明。
Rani等（2023）第四节全文条件的核查状态和Ozbudak、Hachenberger前驱比较已同步。
主稿附录C、补充稿附录S.B均明确列出当前精确计算及Lean的覆盖范围。
为桌面预览补充的字体文件为未修改的已安装字体，并附原许可。

新模块InverseSupportGrid.lean在固定Lean 4.31.0下检查六个组合引理，
六个声明的公理依赖审计均为空。三个原有Lean文件也在固定版本和九项依赖提交下
重新检查通过；复用了mathlib归档缓存，不声称无缓存云端构建。
历史记录中两个源文件哈希与分发内容不符；保留原记录，另附实际哈希与本次成功检查。
一般循环群CRT接口、有限域接口、证书检查器、几何估计及完整定理5.1/5.4
尚未全部形式化。选择性形式化不能表述为整篇论文已获Lean证明。

定理5.1、5.4及取逆支持集归结所在数学核心文件本轮未改变。
原100个标签编号、46条数学陈述和证明所在核心文件均保留。
旧版材料和历轮审计作为历史记录完整保留；当前状态以本说明和findings.json为准。

详细内部对照：原52页与当前版本_对照及形式化范围.txt。
面向首次对外介绍的中文综述：项目根目录/中文综述_范数纤维与相对迹.txt。
中文综述独立介绍当前论文及补充稿，不讨论旧稿及重构过程。

优先文献全文缺口已按既定清单补齐；全球绝对首创性未作确认，
MathSciNet实际主题检索仍未完成，也不保证期刊分区。
所有有限检查均与一般数学证明区分，无外部专家同行复核完成之声明。

可编辑交付包：PaperA_restructured_editable.zip。
本轮前完整备份：PaperA_restructured_editable_v11_before_supplement_sync.zip。
本轮未推送GitHub、未投稿、未向第三方发送消息。
'''
    (ROOT / REPORT).write_text(report, encoding='utf-8')
    facts = {
        'status': 'PASS', 'date': '2026-10-26', 'revision': 'v12-supplement-sync-and-selective-Lean',
        'main_pages': 40, 'supplement_pages': 36, 'total_pages': 76,
        'mathematical_result_revision': 'v11-support-lemma-and-classification-proof',
        'mathematical_core_changed_this_stage': False,
        'supplement_synchronized': True, 'current_public_overview': OVERVIEW,
        'six_new_combinatorial_lemmas_formally_checked': True,
        'six_axiom_dependency_audits_empty': True, 'three_legacy_Lean_files_freshly_rerun': True,
        'full_paper_Lean_formalization': False, 'historical_hash_discrepancies_preserved_and_resolved_by_fresh_checks': 2,
        'all_76_pages_rendered_and_reviewed': True, 'pdf_links': links,
        'original_labels_preserved': 100, 'original_statement_proof_count': 46,
        'remaining_priority_fulltext_gap_ids': [], 'global_priority_confirmed': False,
        'proof_level_literature_exclusion_complete': False,
        'database_actual_topic_search_completed': {'MathSciNet': False, 'zbMATH_Open': True},
        'report': REPORT}
    write(HERE / 'findings.json', facts)
    (ROOT / '重构说明.txt').write_text(
        'PaperA 当前交付说明（v12，2026年10月26日）\n\n' + report +
        '\n数学内容的具体贡献及边界另见主稿引言、第7节与附录D。\n', encoding='utf-8')

    allowed = {'main/reproducibility.tex', 'supplement.tex', 'supplement/comparison.tex',
        'supplement/verification.tex', 'supplement/bibliography.tex',
        'main.pdf', 'main.aux', 'main.log', 'main.out',
        'supplement.pdf', 'supplement.aux', 'supplement.log', 'supplement.out', 'supplement.toc', '重构说明.txt'}
    changed = []
    for item in previous['files']:
        path = ROOT / item['path']
        if not path.is_file():
            raise RuntimeError('Previous payload missing: ' + item['path'])
        if digest(path) != item['sha256']:
            if item['path'] not in allowed:
                raise RuntimeError('Unexpected previous payload change: ' + item['path'])
            changed.append(item['path'])
    write(HERE / 'previous_payload_preservation.json', {
        'status': 'PASS', 'previous_payload_files_retained': len(previous['files']),
        'intentional_changes': changed, 'unexpected_changes': []})

    excluded = {ROOT / 'verification/systematic_novelty_2026-10-26': {
        'zbmath_queries_working.json', 'citation_tracking_working.json', 'seed_control_results.json',
        'query_syntax_controls.json', 'primary_acquisition_log.json', 'missing_title_resolution.json'},
        ROOT / 'verification/fulltext_structure_2026-10-26': {
        'user_provided_inventory.json', 'public_fulltext_discovery.json'}}
    paths = [p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
        and p != ROOT / 'delivery_manifest.json' and p.name not in excluded.get(p.parent, set())]
    for path in paths:
        if path.suffix in {'.txt', '.py', '.json', '.tex', '.csv'} or path.name.endswith('.snapshot'):
            if re.search(rb'\d{10}@m\.scnu\.edu\.cn', path.read_bytes()):
                raise RuntimeError('Private institutional identifier found')
    manifest = {k: v for k, v in previous.items() if k != 'files'}
    manifest.update(revision=facts['revision'], main_manuscript_revision='v12',
        mathematical_result_revision=facts['mathematical_result_revision'],
        supplement_synchronized=True, main_pdf_pages=40, supplement_pdf_pages=36,
        current_report=REPORT, public_overview=OVERVIEW,
        internal_comparison='verification/supplement_sync_2026-10-26/原52页与当前版本_对照及形式化范围.txt',
        six_new_combinatorial_lemmas_formally_checked=True, three_legacy_Lean_files_freshly_rerun=True,
        full_paper_Lean_formalization=False, previous_reports_are_historical=True,
        manuscript_pdf_unchanged=False, global_priority_confirmed=False,
        proof_level_literature_exclusion_complete=False)
    manifest['files'] = [dict(path=p.relative_to(ROOT).as_posix(), bytes=p.stat().st_size, sha256=digest(p))
                         for p in sorted(paths)]
    write(ROOT / 'delivery_manifest.json', manifest)
    if digest(BACKUP) != BACKUP_SHA:
        raise RuntimeError('Previous archive backup mismatch')
    with zipfile.ZipFile(BACKUP) as old:
        old_names = set(old.namelist())
    temporary = ZIP.with_name(ZIP.stem + '.building.zip')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=7) as out:
        for path in paths + [ROOT / 'delivery_manifest.json']:
            out.write(path, ROOT.name + '/' + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(temporary) as out:
        if out.testzip() is not None:
            raise RuntimeError('Archive CRC failure')
        if old_names - set(out.namelist()):
            raise RuntimeError('Previous archive entry lost')
        for item in manifest['files']:
            data = out.read(ROOT.name + '/' + item['path'])
            if hashlib.sha256(data).hexdigest() != item['sha256']:
                raise RuntimeError('Archive hash mismatch: ' + item['path'])
        entries = len(out.infolist())
    temporary.replace(ZIP)
    result = dict(status='PASS', revision=facts['revision'], main_pdf_pages=40, supplement_pdf_pages=36,
        main_pdf_sha256=digest(ROOT / 'main.pdf'), supplement_pdf_sha256=digest(ROOT / 'supplement.pdf'),
        archive=str(ZIP), archive_sha256=digest(ZIP), entries=entries,
        previous_archive=str(BACKUP), previous_archive_entries=len(old_names),
        all_previous_archive_entries_retained=True, crc_and_manifest_verified=True,
        overview=str(ROOT / OVERVIEW), report=str(ROOT / REPORT))
    write(ROOT.parent / 'PaperA_supplement_sync_delivery.json', result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()

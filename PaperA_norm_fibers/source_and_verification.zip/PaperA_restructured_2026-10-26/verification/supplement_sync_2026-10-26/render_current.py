"""Render both current PDFs, recording input hashes before and after rendering."""
from pathlib import Path
from PIL import Image,ImageDraw
from pypdf import PdfReader
import hashlib
import json
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OUT=ROOT.parents[2]/'tmp/pdfs/paperA-supplement-sync-2026-10-26'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    results=[]
    for name in ['main','supplement']:
        p=ROOT/(name+'.pdf');before=sha(p);count=len(PdfReader(p).pages)
        subprocess.run(['pdftoppm','-scale-to','1450','-png',str(p),str(OUT/name)],
            check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        images=sorted(p for p in OUT.glob(name+'-*.png')
                      if p.stem[len(name)+1:].isdigit())
        if len(images)!=count:raise RuntimeError('Rendered page count mismatch')
        contacts=[]
        for start in range(0,count,16):
            sheet=Image.new('RGB',(1100,1600),'#c0c0c0')
            for j,path in enumerate(images[start:start+16]):
                im=Image.open(path).convert('RGB');im.thumbnail((260,370))
                x=(j%4)*275;y=(j//4)*400
                sheet.paste(im,(x+(275-im.width)//2,y+24))
                ImageDraw.Draw(sheet).text((x+10,y+5),name+' '+str(start+j+1),fill='black')
            dest=OUT/(name+f'-contact-{start//16+1}.png');sheet.save(dest);contacts.append(str(dest))
        if sha(p)!=before:raise RuntimeError('PDF changed during rendering')
        results.append({'document':name,'pages':count,'pdf_sha256':before,'contacts':contacts})
    (HERE/'rendered_inputs.json').write_text(json.dumps({'status':'RENDERED','documents':results},indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'RENDERED','pages':sum(x['pages'] for x in results),'documents':results}))


if __name__=='__main__':main()

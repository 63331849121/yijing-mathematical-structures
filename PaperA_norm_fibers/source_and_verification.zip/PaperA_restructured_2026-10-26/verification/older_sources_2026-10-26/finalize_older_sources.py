"""Finalize v10 without modifying historical audits or losing prior payload files."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ZIP = ROOT.parent/'PaperA_restructured_editable.zip'
BACKUP = ROOT.parent/'PaperA_restructured_editable_v9_before_older_sources.zip'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    previous = read(HERE/'before_older_sources/delivery_manifest.json.snapshot')
    compilation = read(HERE/'compilation.json')
    visual = read(HERE/'visual_review.json')
    preservation = read(HERE/'preservation_checks.json')
    exact = read(HERE/'independent_checks.json')
    if compilation['issues'] or not compilation['aux_stable']:
        raise RuntimeError('Compilation not clean and stable')
    if digest(ROOT/'main.pdf') != compilation['pdf_sha256']:
        raise RuntimeError('Main PDF changed after compilation checks')
    if visual['status'] != 'PASS' or visual['pdf_sha256'] != digest(ROOT/'main.pdf'):
        raise RuntimeError('Current PDF has not received visual review')
    if preservation['status'] != 'PASS':
        raise RuntimeError('Preservation checks failed')
    # Import only the existing link inspector, never invoke an old finalizer.
    spec = importlib.util.spec_from_file_location('prior_pdf_links',
        ROOT/'verification/fulltext_structure_2026-10-26/finalize_structure.py')
    utility = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(utility)
    write(HERE/'pdf_links.json', utility.check_links())
    prior_findings = read(ROOT/'verification/cstc26_fulltext_2026-10-26/findings.json')
    remaining = [x for x in prior_findings['remaining_fulltext_gaps']
                 if x['id'] not in {'Ozbudak05','Hachenberger15'}]
    if remaining:
        raise RuntimeError('Unresolved prior priority item: '+str(remaining))
    report = 'verification/older_sources_2026-10-26/两篇早期全文_条件与归属核查.txt'
    facts = {
        'date':'2026-10-26','revision':'v10-older-originals',
        'sources':read(HERE/'source_inventory.json'),
        'all_new_original_pages_read':36,
        'priority_fulltext_gaps_closed_this_stage':['Ozbudak05','Hachenberger15'],
        'remaining_fulltext_gaps':remaining,
        'remaining_priority_fulltext_gaps':remaining,
        'gap_scope':'The five-item priority list only; not all worldwide literature or all screened records',
        'five_priority_originals_read':{'ST26':22,'OV27':24,'CSTC26':17,'Ozbudak05':20,'Hachenberger15':16},
        'five_priority_original_pages':99,
        'Oz05':{
            'framework_contains_M_c':True,
            'direct_parameters':{'q':'t^2','k':1,'m':2,'r':1,'f1':'X','a':'t-1'},
            'strong_linear_independence_checked':True,
            'all_direct_squarefree_cores_fail':True,
            'exact_genus_refinement_checked':True,
            'exact_cover_genus':'(t^2-1)*(u*(t-1)-1)/2',
            'exact_threshold':'1-1/Q+(u*(t-1)-1)/(Q+1)+(Q*(2+u*(t-1))-2)/(Q*(Q^2-1))>1',
            'primitive_lift_with_X_power_R_checked':True,
            'primitive_lift_multiplicity':'phi(t-1)',
            'two_K_trace_coordinate_encoding_checked':True,
            'growing_index_Theorem_4_6_not_overlooked':True,
            'fixed_trace_data_quantifiers_do_not_fix_growing_E_trace':True,
            'Theorem_4_6_printed_hypothesis_ambiguity_recorded':True,
            'comparison_does_not_depend_on_correcting_that_ambiguity':True,
            'example_5_1_shared_exception_numbers_3_5_investigated':True,
            'example_5_1_not_identical_counting_or_existence_problem':True,
            'future_one_way_construction_impossibility_claimed':False},
        'Ha15':{
            'quartic_projective_geometry_prior':True,
            'normality_criterion_and_cyclic_coset_count_prior':True,
            'aggregate_identity':'PN_4(t)=phi(t-1)*sum_{c in E\\K} M_c',
            'Theorem_1_equivalent_bound':'sum_{c in K*} M_c<=phi(t^2+1)',
            'aggregate_positivity_can_coexist_with_M_1_zero':True,
            'published_table_rows_matched':4,
            'fresh_full_quartic_enumeration_this_stage':False},
        'independent_finite_checks':{
            'range_s':[2,9],
            'direct_core_splits':sum(x['direct_core_splits_checked'] for x in exact['Oz05']),
            'primitive_lift_core_splits':sum(x['primitive_lift_core_splits_checked'] for x in exact['Oz05']),
            'binary_rational_example_fields':len(exact['shared_exception_labels_checked']['rows']),
            'all_parameter_core_exclusion_is_a_symbolic_inequality_proof':True},
        'theorem_51':'No direct implication of its effective uniform four-point estimate found in the checked stated results and specializations',
        'theorem_54':'No direct implication of its complete C9/C11 empty-slice classification found in the checked stated results and specializations',
        'all_possible_refinements_of_methods_excluded':False,
        'global_priority_confirmed':False,
        'proof_level_literature_exclusion_complete':False,
        'database_actual_topic_search_completed':{'MathSciNet':False,'zbMATH_Open':True},
        'new_database_queries_in_this_stage':0,
        'mathematical_result_revision':'v8; statements and proofs unchanged',
        'preservation':preservation,
        'main_pages':compilation['pages'],
        'new_mathematical_theorems_claimed_this_stage':False,
        'report':report,
        'external_messages_or_GitHub_push_performed':False}
    write(HERE/'findings.json',facts)
    desc = f'''PaperA 第十轮：两篇早期原始全文核查与归属整合
2026年10月26日

当前主稿 main.pdf：{compilation['pages']}页，原 main.tex 项目原位维护。
桌面编译通过，稳定本地编译通过，无未解析引用和版面溢出；全部页面已渲染复核。
定理5.1、5.4以及5.5–5.7的陈述、证明、编号保持不变。
100个原标签的重构后编号及原46条数学陈述与证明所在核心文件保持不变。
补充稿及历史审计PDF保持；本轮没有新增数学主定理。

两篇全文已补齐
Özbudak（2005），DCC34:35–54，DOI 10.1007/s10623-003-4193-0，20页。
Hachenberger（2015），DCC77:335–350，DOI 10.1007/s10623-015-0051-0，16页。
两篇均阅读全文，关键公式作图像核对。源PDF和整篇提取文本不进入公开可编辑包。

主要判断
Özbudak的一般指定阶、指定迹及函数域方法是前驱。所有直接筛核心、原始提升和两条K迹编码的条件均失败；精确亏格细化也仍失败。
其例5.1亦出现3、5，但域、阶、迹函数不同；已实际检查小域计数，不把数字重合当作本文分类的前驱证明。
Hachenberger的射影几何、正规性标准和循环陪集工具是前驱；其本原正规总量可以为正，同时本文指定迹切片为空。
这些已核查的显示结果不直接推出5.1的有效估计或5.4的完整异常迹分类；不据此断言绝对全球首创。

论文调整
正文保留关键前驱和贡献说明；详细逐式比较移入新附录D，加入两篇条件核对及精确总量桥接。
引言、文献表、经典陪集工具及正规性出处相应补齐；附录C给出核验程序范围。
最新报告：{report}
当前结论和范围以该报告及本轮findings.json为准；先前报告的“剩余全文缺口”是历史状态。

范围
当前五项优先清单ST26、OV27、CSTC26、Özbudak05、Hachenberger15全文均已核对，共99页，该清单剩余缺口为零。
这不等于全球文献全读完。既有zbMATH公开检索记录保留；MathSciNet仍未获得机构认证后的主题检索结果。
本轮没有新增数据库查询，不把原有记录筛选误算为全文阅读。
有限核验覆盖148个直接核心、488个原始提升核心、8个独立二元域实例和4条原表数据；通参数排除由数学不等式证明。

交付
可编辑包：PaperA_restructured_editable.zip。
本轮前备份：PaperA_restructured_editable_v9_before_older_sources.zip。
未推送GitHub，未联系作者，没有完整Lean形式化或期刊档次保证。
'''
    (ROOT/'重构说明.txt').write_text(desc,encoding='utf-8')
    permitted = {'main.tex','main/trace_slices.tex','main/introduction.tex','main/bibliography.tex',
                 'main/reproducibility.tex','main.pdf','main.aux','main.log','main.out','重构说明.txt'}
    changed=[]
    for x in previous['files']:
        path=ROOT/x['path']
        if not path.is_file():
            raise RuntimeError('Previous payload lost: '+x['path'])
        if digest(path)!=x['sha256']:
            if x['path'] not in permitted:
                raise RuntimeError('Unexpected previous-file change: '+x['path'])
            changed.append(x['path'])
    write(HERE/'previous_payload_preservation.json',{
        'status':'PASS','previous_payload_files_retained':len(previous['files']),
        'intentional_changes':changed,'unexpected_changes':[]})
    excluded = {
        ROOT/'verification/systematic_novelty_2026-10-26':{
            'zbmath_queries_working.json','citation_tracking_working.json','seed_control_results.json',
            'query_syntax_controls.json','primary_acquisition_log.json','missing_title_resolution.json'},
        ROOT/'verification/fulltext_structure_2026-10-26':{
            'user_provided_inventory.json','public_fulltext_discovery.json'}}
    paths=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and p!=ROOT/'delivery_manifest.json' and p.name not in excluded.get(p.parent,set())]
    # Avoid including the institution identifier from earlier private access discussion.
    for p in paths:
        if p.suffix in {'.txt','.py','.json','.tex','.csv'} or p.name.endswith('.snapshot'):
            if re.search(rb'\d{10}@m\.scnu\.edu\.cn',p.read_bytes()):
                raise RuntimeError('Private institutional identifier found')
    manifest={k:v for k,v in previous.items() if k!='files'}
    manifest.update(revision='v10-older-originals',main_manuscript_revision='v10',
        mathematical_result_revision='v8',
        fulltext_gaps_closed_this_stage=['Ozbudak05','Hachenberger15'],
        remaining_fulltext_gap_ids=[],remaining_priority_fulltext_gap_ids=[],
        priority_list_scope='The five named priority originals; 99 pages read across successive stages',
        five_priority_fulltext_gaps_closed=True,
        current_report=report,global_priority_confirmed=False,
        main_pdf_pages=compilation['pages'],manuscript_pdf_unchanged=False,
        previous_reports_are_historical=True,proof_level_literature_exclusion_complete=False)
    manifest['files']=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,
                        'sha256':digest(p)} for p in sorted(paths)]
    write(ROOT/'delivery_manifest.json',manifest)
    if not BACKUP.is_file():raise RuntimeError('Prior archive backup missing')
    if digest(BACKUP)!='2fd9aeba5e0c2fe0971f245a87904a68ced21b3566af6b53eca7cafc32674897':
        raise RuntimeError('Unexpected v9 backup hash')
    with zipfile.ZipFile(BACKUP) as z: old_names=set(z.namelist())
    with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for p in paths+[ROOT/'delivery_manifest.json']:
            z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(ZIP) as z:
        if z.testzip() is not None:raise RuntimeError('Archive CRC failure')
        if old_names-set(z.namelist()):raise RuntimeError('Older archive entry lost')
        for row in manifest['files']:
            if hashlib.sha256(z.read(ROOT.name+'/'+row['path'])).hexdigest()!=row['sha256']:
                raise RuntimeError('Manifest archive mismatch: '+row['path'])
        entries=len(z.infolist())
    result={'status':'PASS','revision':manifest['revision'],'archive':str(ZIP),
        'archive_sha256':digest(ZIP),'entries':entries,'previous_archive':str(BACKUP),
        'previous_archive_sha256':digest(BACKUP),'all_previous_archive_entries_retained':True,
        'crc_and_manifest_verified':True,'main_pdf_pages':compilation['pages'],
        'main_pdf_sha256':digest(ROOT/'main.pdf'),'remaining_priority_fulltext_gap_ids':[],
        'global_priority_confirmed':False}
    write(ROOT.parent/'PaperA_older_sources_delivery.json',result)
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()

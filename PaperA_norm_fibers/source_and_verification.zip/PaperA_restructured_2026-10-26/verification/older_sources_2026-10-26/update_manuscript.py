"""Reconcile the two older original fulltexts in the existing manuscript."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise RuntimeError('Expected exactly one occurrence: '+old[:90])
    return text.replace(old, new, 1)


def main():
    path = ROOT/'main/trace_slices.tex'
    original = path.read_text(encoding='utf-8')
    before = (HERE/'before_older_sources/main/trace_slices.tex.snapshot').read_text(encoding='utf-8')
    if original != before:
        raise RuntimeError('Trace source changed since the preserved v9 snapshot')
    start = original.index('The counting problem itself has direct predecessors.')
    end = original.index('\\subsection{The exact unfiltered center}', start)
    comparison = original[start:end]
    compact = r'''The counting object is classical: it occurs in the prescribed-order
and prescribed-trace frameworks of \cite{Coh05,TW15,Oz05}, and
in the line framework of \cite{CK21}. Appendix~\ref{app:prior-trace-comparisons}
gives exact specializations of these results and of
\cite{ST26,OV27,CSTC26,Rani23}. Their displayed sufficient
conditions do not establish the present uniform estimate or
complete classification; the $s=2$ positivity case is already
covered by \cite[Theorem~1.6]{ST26}. The appendix also distinguishes
the primitive-normal aggregate in \cite{Ha15} from a fixed
relative-trace population.

'''
    result = original[:start]+compact+original[end:]
    result = replace_once(result,
        r'''$L^*=K^*\times C_d$; it is a consequence of the preceding
theorems, rather than a separate character-sum method.''',
        r'''$L^*=K^*\times C_d$. Generator counts in cyclic cosets are
classical; see, for example, \cite[Lemma~1]{Ha15}. The transfer
below is a consequence of the preceding theorems, rather than
a separate character-sum method.''')
    result = replace_once(result,
        r'''$(X+1)^4$, so the elements are normal over $K$, in the standard
terminology of \cite{Rani23}.''',
        r'''$(X+1)^4$, so the elements are normal over $K$; the latter
criterion is classical for binary quartic extensions
\cite[\S3]{Ha15}. The $1$-normal terminology follows \cite{Rani23}.''')

    oz = r'''The earlier function-field framework of \cite{Oz05} includes
the same count. In its Theorem~4.3 take $q=Q=t^2$, $k=1$,
$m=2$, $r=1$, $f_1(X)=X$ and index $a=R=t-1$.
Strong linear independence holds because each nonzero linear
combination has a simple pole. Write $u,v$ for its two coprime
squarefree sieve factors, so $uv=\operatorname{rad}(d)$, and put
$z=uR\ge3$. Each linear Artin--Schreier subcover has genus zero.
Its displayed sufficient condition therefore requires
\[
 \theta(v)>1-\frac1Q+
 \frac{2(Q-1)(z-1)Q+Q(2+z)-2}{Q(Q^2-1)}>1,
\]
which is impossible for every allowed core.

The rough genus bound is not essential to this failure.
Following \cite[Remark~4.4 and proof of Theorem~4.3]{Oz05},
retain the exact genus of
$y^Q-y=\alpha^{vR}x^{uR}+\delta$. Since $z$ is odd, it is
$(Q-1)(z-1)/2$. The improved threshold becomes
\[
 1-\frac1Q+\frac{z-1}{Q+1}
       +\frac{Q(2+z)-2}{Q(Q^2-1)}>1.
\]
Indeed $z\ge3$ and $2/(Q+1)>1/Q$. This also rules out the
primitive lift: use index $1$ and $f_1(X)=X^R$, and divide
its count by $\varphi(R)$. Its exact composed-cover genus is
the same. Encoding the $E$-valued trace by two $K$-valued
traces also gives no improvement: take $q=t$, $k=m=2$,
$r=2$ and functions $X,\xi X$, with $\xi\in E\setminus K$.
The trace pairing makes these two coordinates equivalent to
the prescribed relative trace. The cover still has degree
$q^r=Q$ and the same exact genus, while the pole-degree
correction increases. Thus neither the choice of sieve core
nor this change of trace coordinates repairs the criterion.

The asymptotic statements \cite[Theorems~4.5--4.6]{Oz05}
do not supply the missing uniform conclusion. Theorem~4.6
does allow a growing order index, but fixes the coefficient
field and the trace functions, including their number. Its
large-extension assertion does not specify a relative trace
in a growing quadratic subfield. Re-encoding that value by
binary traces requires a growing number of functions, outside
those fixed-data quantifiers.

There is also a superficial coincidence of exceptional exponents.
In \cite[Example~5.1 and Theorem~5.2]{Oz05}, the primitive
element lies in $\mathbb F_{2^m}$ and satisfies two absolute-trace
conditions for fixed rational functions; the exceptional
exponents include $3,5$. Taking $m=s$ gives order $t-1$
in $K$, whereas the present problem has order $d$ in $L$.
Taking $m=4s$ gives the ambient field $L$ but a different
order and different trace constraints. At $s=2$ that example
has no admissible primitive element, whereas $M_1=8$ here.
The two existence statements are therefore different; no
conversion to the relative-trace classification is supplied
by those results.

'''
    comparison = replace_once(comparison,
        'The line framework of', oz+'The line framework of')
    comparison = replace_once(comparison,
        'The product criterion in',
        '\\subsection{Product, hypersurface and rational-image criteria}\nThe product criterion in')
    comparison = replace_once(comparison,
        'bounds, rather than the exceptional slices classified below.',
        'bounds, rather than the exceptional slices classified in\n'
        'Theorem~\\ref{thm:trace-positivity-classification}.')
    ha = r'''\subsection{Primitive-normal aggregates and projective geometry}
Hachenberger's earlier quartic theorem is a geometric predecessor
\cite[Theorem~1 and \S3]{Ha15}. For even $t$ it gives
\[
 PN_4(t)\ge\varphi(t^4-1)-\varphi(t-1)\varphi(t^2+1).
\]
Its projective spread counts primitive points on primitive
lines, excluding their trace-zero hyperplane intersections.
In our notation the exact bridge to that aggregate is
\[
 PN_4(t)=\varphi(t-1)\sum_{c\in E\setminus K} M_c.
\]
Indeed $L^*=K^*\times C_d$, and every generator of $C_d$
has exactly $\varphi(t-1)$ primitive ambient-field lifts.
Scaling by $K^*$ preserves normality. In characteristic two
and degree four, normality over $K$ is equivalent to
$\operatorname{Tr}_{L/K}(a)\ne0$, or $c+c^t\ne0$.
Consequently its lower bound is equivalent to
\[
 \sum_{c\in K^*}M_c\le\varphi(B).
\]
It bounds an aggregate rather than every prescribed trace.
For example its Table~1 gives $PN_4(8)=1512$ and
$PN_4(32)=465000$, while $M_1=0$ at both parameters.
These aggregate counts are consistent with the two empty
trace-one slices and do not classify the exceptional groups.
The later norm-one and ovoid model \cite{Ha21} provides
further geometric context; Supplementary
Section~\ref{supp:comparison} compares its trace sections with
the additional norm-to-trace ratio fixed here.

The comparisons in this appendix concern stated results and
the explicit specializations above. They credit the established
counting frameworks, geometric methods and cyclic-group tools;
they do not rule out every possible further refinement of
those methods or assert absolute global priority.
'''
    appendix = r'''\section{Comparison with earlier prescribed-order results}
\label{app:prior-trace-comparisons}
We compare the relative-trace theorems with the closest
prescribed-order, trace and primitive-normal frameworks.
Throughout, $R=t-1$, $A=t+1$, $B=t^2+1$ and $d=AB$.
The issue is the effective error and the complete classification
of individual traces, since the counting object itself is prior.

\subsection{Prescribed order and trace}
'''+comparison+ha
    (ROOT/'main/literature_comparison.tex').write_text(appendix, encoding='utf-8')
    path.write_text(result, encoding='utf-8')

    path = ROOT/'main.tex'
    text = path.read_text(encoding='utf-8')
    text = replace_once(text, '\\input{main/reproducibility}',
                        '\\input{main/reproducibility}\n\\input{main/literature_comparison}')
    path.write_text(text, encoding='utf-8')

    path = ROOT/'main/introduction.tex'
    text = path.read_text(encoding='utf-8')
    text = replace_once(text, r'\cite{Coh05,TW15};', r'\cite{Coh05,TW15,Oz05};')
    text = replace_once(text,
        r'Section~\ref{sec:existence} gives a uniform proof of this fact',
        r'Appendix~\ref{app:prior-trace-comparisons} gives a uniform proof of this fact')
    text = replace_once(text,
        r'''two or four. Section~\ref{sec:existence} gives the exact
comparison, including the repeated-factor and inverse-trace
conditions.''',
        r'''two or four. Appendix~\ref{app:prior-trace-comparisons} gives
the exact comparison, including the repeated-factor and inverse-trace
conditions. It also checks the earlier function-field criterion
of \cite{Oz05}, retaining the exact Artin--Schreier genus and
allowing every squarefree sieve core.''')
    text = replace_once(text,
        r'''There are also close geometric predecessors. Hachenberger's quartic model
\cite[pp.~94, 97, 107]{Ha21} identifies the norm-one representatives''',
        r'''There are also close geometric predecessors. Hachenberger's
quartic primitive-normal bound \cite[Theorem~1]{Ha15} is an
aggregate of the relative-trace populations; it can be positive
when a specified trace slice is empty
(Appendix~\ref{app:prior-trace-comparisons}). His later model
\cite[pp.~94, 97, 107]{Ha21} identifies the norm-one representatives''')
    text = replace_once(text,
        'The appendices record finite certificates and verification scope.',
        'The appendices record finite certificates, verification scope\nand explicit comparisons with earlier results.')
    path.write_text(text, encoding='utf-8')

    path = ROOT/'main/bibliography.tex'
    text = path.read_text(encoding='utf-8')
    entries = r'''\bibitem{Oz05} F.~\"Ozbudak,
\emph{Elements of prescribed order, prescribed traces and systems
of rational functions over finite fields},
Des.~Codes Cryptogr.~34 (2005) 35--54,
\href{https://doi.org/10.1007/s10623-003-4193-0}{doi:10.1007/s10623-003-4193-0}.
\bibitem{Ha15} D.~Hachenberger,
\emph{Primitive normal bases for quartic and cubic extensions:
a geometric approach}, Des.~Codes Cryptogr.~77 (2015) 335--350,
\href{https://doi.org/10.1007/s10623-015-0051-0}{doi:10.1007/s10623-015-0051-0}.
'''
    text = replace_once(text, '\\bibitem{Ha21}', entries+'\\bibitem{Ha21}')
    path.write_text(text, encoding='utf-8')

    path = ROOT/'main/reproducibility.tex'
    text = path.read_text(encoding='utf-8')
    extra = r'''The comparisons with \cite{Oz05,Ha15} have exact checks in
\path{verification/older_sources_2026-10-26/verify_older_sources.py}.
For $s=2,\ldots,9$ they evaluate every squarefree-core
partition for the direct prescribed-order count and its
primitive lift. The all-parameter obstruction follows from
the inequalities in Appendix~\ref{app:prior-trace-comparisons}.
The script also matches the four published binary rows
$t=4,8,16,32$ of \cite[Table~1]{Ha15} against the preceding
independent norm-kernel enumeration, and separately checks
the distinct binary rational-function example in \cite{Oz05}.
These are finite consistency checks, not a new full enumeration
of the quartic fields or a proof of global priority.

'''
    text = replace_once(text, 'The archived Lean files cover', extra+'The archived Lean files cover')
    path.write_text(text, encoding='utf-8')
    print('Updated existing main project; detailed comparisons moved to new Appendix D.')


if __name__ == '__main__':
    main()

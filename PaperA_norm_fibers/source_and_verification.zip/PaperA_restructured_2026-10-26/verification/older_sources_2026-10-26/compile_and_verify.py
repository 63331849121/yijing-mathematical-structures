"""Build the existing main document and verify numbering/proof preservation."""
from pathlib import Path
import csv
import hashlib
import json
import re
import subprocess
from pypdf import PdfReader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BEFORE = HERE/'before_older_sources'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(name, obj):
    (HERE/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def statement_and_proof(text, label):
    at = text.index('\\label{'+label+'}')
    starts = list(re.finditer(r'\\begin\{(?:theorem|proposition|corollary)\}', text[:at]))
    start = starts[-1].start()
    end = text.index('\\end{proof}', at)+len('\\end{proof}')
    return text[start:end]


def main():
    passes, stable = 0, False
    for _ in range(3):
        previous = (ROOT/'main.aux').read_bytes()
        r = subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],
                           cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        passes += 1
        if r.returncode:
            raise RuntimeError(r.stdout.decode('utf-8', errors='replace')[-7000:])
        if passes >= 2 and previous == (ROOT/'main.aux').read_bytes():
            stable = True
            break
    log = (ROOT/'main.log').read_text(encoding='utf-8', errors='replace')
    issues = [line for line in log.splitlines() if any(x in line for x in
        ['Undefined control sequence', 'LaTeX Error:', 'Overfull \\hbox',
         'Overfull \\vbox', 'undefined references', 'multiply defined',
         'has been referenced but does not exist', 'Rerun to get cross-references right'])
         or re.search(r'LaTeX Warning: (?:Reference|Citation).*undefined', line)]
    if issues or not stable:
        raise RuntimeError(json.dumps({'issues':issues,'aux_stable':stable}))
    aux = '\n'.join((ROOT/p).read_text(encoding='utf-8') for p in ['main.aux','supplement.aux'])
    labels = dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}', aux))
    rows = list(csv.DictReader((ROOT/'provenance/label_mapping.csv').open(encoding='utf-8-sig',newline='')))
    for row in rows:
        if labels.get(row['Original label']) != row['New printed number']:
            raise RuntimeError('Original label number changed: '+row['Original label'])
    previous_manifest = json.loads((BEFORE/'delivery_manifest.json.snapshot').read_text(encoding='utf-8'))
    prior = {x['path']:x['sha256'] for x in previous_manifest['files']}
    original = json.loads((ROOT/'provenance/mathematical_preservation_audit.json').read_text(encoding='utf-8'))
    core = sorted(set(x['destination'] for x in original['results']))
    for p in core:
        if sha(ROOT/p) != prior[p]:
            raise RuntimeError('Original mathematical source changed: '+p)
    old = (BEFORE/'main/trace_slices.tex.snapshot').read_text(encoding='utf-8')
    current = (ROOT/'main/trace_slices.tex').read_text(encoding='utf-8')
    targets = {'thm:uniform-relative-trace':'5.1',
               'thm:trace-positivity-classification':'5.4',
               'prop:trace-norm-distribution':'5.5',
               'cor:exceptional-trace-profiles':'5.6',
               'cor:arbitrary-norm-trace':'5.7'}
    proofs = {}
    for label, number in targets.items():
        same = statement_and_proof(old,label) == statement_and_proof(current,label)
        if not same or labels[label] != number:
            raise RuntimeError('Statement, proof or number changed: '+label)
        proofs[label] = {'number':number,'statement_and_proof_unchanged':True,
                         'text_sha256':hashlib.sha256(statement_and_proof(current,label).encode()).hexdigest()}
    assert sha(ROOT/'supplement.aux') == sha(BEFORE/'supplement.aux.snapshot')
    assert sha(ROOT/'supplement.pdf') == prior['supplement.pdf']
    dump('preservation_checks.json', {'status':'PASS','original_labels_resolved':len(rows),
        'original_restructured_printed_numbers_unchanged':True,
        'original_statement_proof_count':len(original['results']),
        'original_statement_proof_source_files_unchanged':core,
        'results_51_54_55_56_57':proofs,'supplement_pdf_and_aux_unchanged':True,
        'comparison_material_moved_to_appendix_D':True})
    dump('compilation.json', {'document':'main','built_in_compiler_success':True,
        'built_in_message':'The current source compiled successfully with the desktop editor\'s compiler.',
        'local_passes':passes,'aux_stable':stable,'issues':issues,
        'pages':len(PdfReader(ROOT/'main.pdf').pages),'pdf_sha256':sha(ROOT/'main.pdf')})
    print(json.dumps({'status':'PASS','pages':len(PdfReader(ROOT/'main.pdf').pages),
                     'original_labels':len(rows),'original_mathematical_statements':len(original['results']),
                     'preserved_result_numbers':list(targets.values()),'passes':passes}))


if __name__ == '__main__':
    main()

"""Record the supplied original PDFs without copying licensed fulltexts into delivery."""
from pathlib import Path
import hashlib
import json
from pypdf import PdfReader

HERE = Path(__file__).resolve().parent
SOURCES = [
    {'id':'Oz05','path':'G:/下载/s10623-003-4193-0.pdf','pages':20,
     'author':'Ferruh Özbudak',
     'title':'Elements of Prescribed Order, Prescribed Traces and Systems of Rational Functions Over Finite Fields',
     'journal':'Designs, Codes and Cryptography','volume':34,'year':2005,'page_range':'35–54',
     'doi':'10.1007/s10623-003-4193-0',
     'expected_sha256':'9aaaf8c668d9fa190bdd5ac5b2e081bc3203dfab8f32682193e13485136a55c4',
     'key_pdf_pages_visually_checked':[13,14,15,16]},
    {'id':'Ha15','path':'G:/下载/s10623-015-0051-0.pdf','pages':16,
     'author':'Dirk Hachenberger',
     'title':'Primitive normal bases for quartic and cubic extensions: a geometric approach',
     'journal':'Designs, Codes and Cryptography','volume':77,'year':2015,'page_range':'335–350',
     'online_publication_from_original_first_page':'2015-03-14',
     'doi':'10.1007/s10623-015-0051-0',
     'expected_sha256':'c598ebe7ce2577c220f68cb854c308058211ea4e29cb5f0975771d8cd1a4bf59',
     'key_pdf_pages_visually_checked':[3,7,8,12]}]
for row in SOURCES:
    path = Path(row['path'])
    row['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    assert row['sha256'] == row.pop('expected_sha256')
    assert len(PdfReader(path).pages) == row['pages']
    row.update(bytes=path.stat().st_size, supplied_by_user=True,
               all_pages_text_read=True, document_instructions_treated_as_data=True,
               source_pdf_in_public_delivery=False, extracted_fulltext_in_public_delivery=False)
(HERE/'source_inventory.json').write_text(json.dumps(SOURCES,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'sources':len(SOURCES),'all_original_pages_read':sum(x['pages'] for x in SOURCES)}))

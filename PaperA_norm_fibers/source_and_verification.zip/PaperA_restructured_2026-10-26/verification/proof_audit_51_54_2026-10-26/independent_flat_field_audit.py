"""Independent finite checks for Theorems 5.1 and 5.4 (standard library).

Reads archived certificates, but imports none of the earlier arithmetic code.
Witnesses originally in a quadratic tower are transported to a single binary
polynomial field of degree 4s. The field isomorphism and irreducibility are
checked. This is computational corroboration, not a formal proof of the
geometric estimate or a certificate of global priority. Run without -O.
"""
from pathlib import Path
from fractions import Fraction
from functools import lru_cache
from collections import Counter
from itertools import combinations
import hashlib
import json
import math
import re
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def raw_product(a, b):
    """Carryless multiplication, then reduction is a separate operation."""
    out = 0
    while b:
        bit = b & -b
        out ^= a << (bit.bit_length()-1)
        b ^= bit
    return out


def division(a, b):
    assert b
    quotient = 0
    while a.bit_length() >= b.bit_length():
        shift = a.bit_length()-b.bit_length()
        quotient ^= 1 << shift
        a ^= b << shift
    return quotient, a


def product(a, b, modulus):
    return division(raw_product(a, b), modulus)[1]


def power(a, exponent, modulus):
    out = 1
    for bit in bin(exponent)[2:]:
        out = product(out, out, modulus)
        if bit == '1':
            out = product(out, a, modulus)
    return out


def gcd(a, b):
    while b:
        a, b = b, division(a, b)[1]
    return a


def trial_factors(value):
    out = []
    p = 2
    while p*p <= value:
        if value % p == 0:
            out.append(p)
            while value % p == 0:
                value //= p
        p = 3 if p == 2 else p+2
    if value > 1:
        out.append(value)
    return out


def irreducible(modulus):
    degree = modulus.bit_length()-1
    assert degree > 0 and modulus & 1
    assert power(2, 1 << degree, modulus) == 2
    for p in trial_factors(degree):
        assert gcd(power(2, 1 << (degree//p), modulus) ^ 2, modulus) == 1


def evaluate(poly, a, modulus):
    out = 0
    for bit in bin(poly)[2:]:
        out = product(out, a, modulus) ^ int(bit)
    return out


def orbit_polynomial(b, c, modulus, n):
    # Product_i (X^2 + c^(2^i) X + b^(2^i)), coefficients in E.
    coefficients = [1]
    bb, cc = b, c
    for _ in range(n):
        next_coefficients = [0]*(len(coefficients)+2)
        for i, value in enumerate(coefficients):
            next_coefficients[i] ^= product(value, bb, modulus)
            next_coefficients[i+1] ^= product(value, cc, modulus)
            next_coefficients[i+2] ^= value
        coefficients = next_coefficients
        bb = product(bb, bb, modulus)
        cc = product(cc, cc, modulus)
    assert (bb, cc) == (b, c)
    assert set(coefficients) <= {0, 1}
    return sum(x << j for j, x in enumerate(coefficients))


def field_isomorphism(b, b_flat, old_modulus, flat_modulus, n):
    # Invert the binary change-of-basis matrix for 1,b,...,b^(n-1).
    pivots = {}
    old, new = 1, 1
    for j in range(n):
        column, image = old, new
        while column:
            pivot = column.bit_length()-1
            if pivot not in pivots:
                pivots[pivot] = (column, image)
                break
            other, other_image = pivots[pivot]
            column ^= other
            image ^= other_image
        assert column, 'b must have full degree in E'
        old = product(old, b, old_modulus)
        new = product(new, b_flat, flat_modulus)
    assert len(pivots) == n

    def transport(value):
        image = 0
        while value:
            pivot = value.bit_length()-1
            column, column_image = pivots[pivot]
            value ^= column
            image ^= column_image
        return image

    # Check that this binary linear map is the field homomorphism, rather
    # than merely an invertible linear map matching the chosen generator.
    alpha_flat = transport(2)
    assert evaluate(old_modulus, alpha_flat, flat_modulus) == 0
    for j in range(n):
        assert transport(1 << j) == power(alpha_flat, j, flat_modulus)
    assert transport(b) == b_flat and transport(1) == 1
    return transport


def witnesses(data):
    rows = []
    total = 0
    for row in data['complete_finite_slice_certificates']:
        s, t = row['s'], row['t']
        n, degree = 2*s, 4*s
        A, B = t+1, t*t+1
        d = A*B
        old_modulus = int(row['E_modulus_hex'], 16)
        b, cquad = int(row['quadratic_b_hex'], 16), int(row['quadratic_c_hex'], 16)
        irreducible(old_modulus)
        flat = orbit_polynomial(b, cquad, old_modulus, n)
        assert flat.bit_length()-1 == degree
        irreducible(flat)
        primes = trial_factors(d)
        assert primes == sorted(set(row['A_prime_divisors']+row['B_prime_divisors']))
        assert power(2, d, flat) == 1
        assert all(power(2, d//p, flat) != 1 for p in primes)
        b_flat = power(2, B, flat)
        transport = field_isomorphism(b, b_flat, old_modulus, flat, n)
        assert product(2, 2, flat) ^ product(transport(cquad), 2, flat) ^ b_flat == 0

        all_c, mapped, checked = set(), [], 0
        for item in row['slices']:
            c_old = int(item['c_hex'], 16)
            c = transport(c_old)
            assert c and c not in all_c and power(c, t, flat) == c
            all_c.add(c)
            mapped.append((c, item))
            if 'full_order_witness_a_hex' not in item:
                assert (s, c) in ((3, 1), (5, 1))
                continue
            a0, a1 = [transport(int(x, 16)) for x in item['full_order_witness_a_hex']]
            a = a0 ^ product(a1, 2, flat)
            assert a ^ power(a, t*t, flat) == c
            assert power(a, d, flat) == 1
            assert all(power(a, d//p, flat) != 1 for p in primes)
            assert power(a, (t**4-1)//(t-1), flat) == 1
            checked += 1
        assert len(all_c) == t-1 and checked == row['full_order_witnesses']

        # Independent direct enumeration, in the flat field, for s <= 6.
        enumeration = None
        if s <= 6:
            values, a = [], 1
            for _ in range(d):
                values.append(a)
                a <<= 1
                if a >> degree:
                    a ^= flat
            assert a == 1
            Q, M = Counter(), Counter()
            for j, a in enumerate(values):
                c = a ^ values[j*t*t % d]
                if c in all_c:
                    Q[c] += 1
                    M[c] += math.gcd(j, d) == 1
            for c, item in mapped:
                assert (Q[c], M[c]) == (item['Q'], item['M'])
            enumeration = 'All Q_c and M_c agree with independent flat-field subgroup enumeration'
        total += checked
        rows.append(dict(s=s, binary_modulus_hex=hex(flat), degree=degree,
                         checked_full_order_witnesses=checked, trace_values=t-1,
                         isomorphism_checked=True, irreducibility_checked=True,
                         independent_counts=enumeration))
        print('FLAT_FIELD', s, 'degree', degree, 'witnesses', checked, 'PASS', flush=True)
    assert total == 1010
    return rows


@lru_cache(None)
def cyclotomic(n):
    value = (1 << n) ^ 1
    for d in range(1, n):
        if n % d == 0:
            value, remainder = division(value, cyclotomic(d))
            assert remainder == 0
    return value


def finite_polynomials(data):
    output = []
    for row in data['exact_trace_one']:
        phi = cyclotomic(row['A'])
        phi_degree = phi.bit_length()-1
        H = 0
        # Expand X^deg(phi) phi(X+X^-1) by binomial parity,
        # independently of the earlier repeated-product implementation.
        for j in range(phi_degree+1):
            if not (phi >> j) & 1:
                continue
            for k in range(j+1):
                if k & ~j == 0:
                    H ^= 1 << (phi_degree+j-2*k)
        assert H == int(row['H_hex'], 16)
        delta = 0
        for term in row['mobius_terms']:
            e = term['e']
            mu = (-1)**len(trial_factors(e))
            assert mu == term['mu']
            g = gcd(H, power(2, row['B']//e, H) ^ 1)
            assert g == int(term['gcd_hex'], 16)
            delta += mu*(g.bit_length()-1)
        assert delta == row['Delta']
        assert gcd(H, cyclotomic(row['B'])).bit_length()-1 == delta
        certificate = row.get('primitive_coprimality_certificate')
        if certificate:
            u, v = int(certificate['u_hex'], 16), int(certificate['v_hex'], 16)
            phiB = int(certificate['phiB_hex'], 16)
            assert phiB == cyclotomic(row['B'])
            assert raw_product(u, H) ^ raw_product(v, phiB) == 1
        if row['s'] == 3:
            assert gcd(H, power(2, 65, H) ^ 1) == 1
        if row['s'] == 5:
            g = gcd(H, power(2, 1025, H) ^ 1)
            assert g == gcd(H, power(2, 205, H) ^ 1)
            assert g.bit_length()-1 == 20
            assert gcd(H, power(2, 41, H) ^ 1) == gcd(H, power(2, 5, H) ^ 1) == 1
        output.append(dict(s=row['s'], Delta=delta, polynomial_and_Bezout='PASS'))
    return output


def sieve_and_infinite_ranges(data):
    author = json.loads((ROOT/'verification/author_runtime/inner_critical_certificates.json').read_text(encoding='utf-8'))
    prime_certificates = author['prime_certificates']

    @lru_cache(None)
    def lucas(p):
        assert p >= 2
        record = prime_certificates[str(p)]
        if p == 2:
            assert record['factors'] == []
            return True
        factors, v = record['factors'], record['witness']
        assert math.prod(factors) == p-1 and all(2 <= q < p and lucas(q) for q in factors)
        assert pow(v, p-1, p) == 1
        assert all(math.gcd(pow(v, (p-1)//q, p)-1, p) == 1 for q in set(factors))
        return True

    sieve = []
    for row in data['prime_sieve_certificates']:
        t = 1 << row['s']
        primes = []
        for name, expected in [('A_factorization', t+1), ('B_factorization', t*t+1)]:
            assert math.prod(p**exponent for p, exponent in row[name]) == expected
            assert all(exponent > 0 and lucas(p) for p, exponent in row[name])
            primes.extend(p for p, _ in row[name])
        assert len(primes) == len(set(primes))
        core_primes = trial_factors(row['core'])
        assert set(core_primes) <= set(primes) and math.prod(core_primes) == row['core']
        omitted = sorted(set(primes)-set(core_primes))
        assert omitted == row['omitted_primes']
        delta = 1-sum((Fraction(1, p) for p in omitted), Fraction(0))
        assert delta > 0
        Lambda = 2+Fraction(len(omitted)-1)/delta
        C = 4*(1 << len(core_primes))*Lambda-2
        assert str(delta) == row['delta'] and str(Lambda) == row['Lambda'] and str(C) == row['C']
        assert C <= row['C_integer_upper']
        assert (t+1)**2 > t*row['C_integer_upper']**2
        sieve.append(dict(s=row['s'], core=row['core'], positivity='PASS'))
    assert len(sieve) == 24

    text = (ROOT/'main/certificates.tex').read_text(encoding='utf-8')
    listed = {}
    for line in text.splitlines():
        tokens = re.split(r'\s*&\s*', line.split(r'\\')[0].strip())
        if len(tokens) == 6 and all(z.isdecimal() for z in tokens):
            for j in (0, 2, 4):
                s, bound = map(int, tokens[j:j+2])
                if 33 <= s <= 113:
                    listed[s] = bound
    assert len(listed) == 81
    primes = [p for p in range(2, 4097) if all(p % d for d in range(2, math.isqrt(p)+1))]
    for s, listed_bound in sorted(listed.items()):
        bound = 0
        for value in ((1 << s)+1, (1 << (2*s))+1):
            for p in primes:
                if value % p == 0:
                    bound += 1
                    while value % p == 0:
                        value //= p
            k = 0
            while 4097**(k+1) <= value:
                k += 1
            bound += k
        assert bound == listed_bound and s >= 4+2*bound
    odd_small = [p for p in primes if 2 < p < 256]
    assert len(odd_small) == 53 and 256**53 < 4096**8*math.prod(odd_small)
    return dict(prime_sieve=sieve, intermediate_integer_bounds=81,
                odd_integer_constant='W(n)<4096*n^(1/8)', uniform_tail_from_s=114,
                primality_method='Recursive Lucas certificates, fully factored p-1')


def main():
    started = time.monotonic()
    source = ROOT/'verification/uniform_trace/uniform_trace_checks.json'
    data = json.loads(source.read_text(encoding='utf-8'))
    assert data['status'] == 'PASS'
    output = dict(status='PASS', source_certificate_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  scope='Finite certificates and integer ranges only; no replacement for the geometric proof.',
                  arithmetic='Standalone single binary polynomial fields; no imports of earlier arithmetic modules',
                  flat_fields=witnesses(data), polynomial_counts=finite_polynomials(data),
                  analytic_certificates=sieve_and_infinite_ranges(data))
    output['elapsed_seconds'] = round(time.monotonic()-started, 3)
    (HERE/'independent_flat_field_results.json').write_text(json.dumps(output, indent=2), encoding='utf-8')
    print('INDEPENDENT_AUDIT_PASS', output['elapsed_seconds'], flush=True)


if __name__ == '__main__':
    main()

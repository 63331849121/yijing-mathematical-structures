from pathlib import Path
import re, csv, json, hashlib, zipfile, shutil
from pypdf import PdfReader

BASE=Path(r'C:\Users\master\Documents\Codex\mywebsite')
ROOT=BASE/'output/pdf/PaperA_restructured_2026-10-26'
WORK=BASE/'tmp/pdfs/paperA-restructure'
V=ROOT/'verification'
old=(ROOT/'provenance/PaperA_original_52pages.tex').read_text(encoding='utf-8')
files={str(p.relative_to(ROOT)).replace('\\','/'):p.read_text(encoding='utf-8') for folder in ('main','supplement') for p in (ROOT/folder).glob('*.tex')}
where={}
for path,txt in files.items():
    for label in re.findall(r'\\label\{([^}]+)\}',txt):
        assert label not in where,('Duplicate label',label)
        where[label]=path
oldlabels=re.findall(r'\\label\{([^}]+)\}',old)
assert set(oldlabels)<=set(where)
def canonical(txt):return re.sub(r'\s+','',re.sub(r'%[^\n]*','',txt))
pattern=re.compile(r'\\begin\{(theorem|lemma|proposition|corollary)\}(.*?)\\end\{\1\}',re.S)
proofs=[]
for m in pattern.finditer(old):
    labels=re.findall(r'\\label\{([^}]+)\}',m[2])
    if not labels:continue
    label=labels[0];txt=files[where[label]]
    n=[x for x in pattern.finditer(txt) if r'\label{'+label+'}' in x[2]]
    assert len(n)==1; n=n[0]
    assert canonical(m[0])==canonical(n[0]),label
    a=re.match(r'\s*(\\begin\{proof\}.*?\\end\{proof\})',old[m.end():],re.S)
    b=re.match(r'\s*(\\begin\{proof\}.*?\\end\{proof\})',txt[n.end():],re.S)
    if a:
        assert b,label
        expected=a[1]
        if label=='thm:inner-double-count':
            expected=expected.replace('Apply the primitive-character indicator proved in\nTheorem~\\ref{thm:inner-primitive-count} separately to these three\nvariables.','Apply Lemma~\\ref{lem:primitive-indicator} separately to these three\nvariables.')
        assert canonical(expected)==canonical(b[1]),label
    else:assert b is None,label
    proofs.append(dict(label=label,destination=where[label],statement_preserved=True,proof_preserved=True,has_immediate_proof=bool(a)))
assert len(proofs)==46

def aux_labels(path):
    def group(s,i):
        assert s[i]=='{';start=i+1;depth=1;i+=1
        while depth:
            depth+=(s[i]=='{')-(s[i]=='}');i+=1
        return s[start:i-1],i
    out={}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith(r'\newlabel{'):continue
        key,i=group(line,len(r'\newlabel'));payload,_=group(line,i)
        num,i=group(payload,0);page,i=group(payload,i)
        while num.startswith('{') and num.endswith('}'):num=num[1:-1]
        out[key]=(num,page)
    return out
orig=aux_labels(WORK/'source_original.aux')
current={x:aux_labels(ROOT/(x+'.aux')) for x in ('main','supplement')}
with (ROOT/'provenance/label_mapping.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['Original label','Original printed number','New printed number','New PDF','New PDF page','New source file'])
    for key in oldlabels:
        path=where[key];doc=path.split('/')[0];num,page=current[doc][key]
        w.writerow([key,orig[key][0],num,doc+'.pdf',page,path])

aux=[]
for label,title in [('lem:character-decomposition','Character decomposition'),('lem:local-averaging','Local averaging in a cyclic group')]:
    a=re.search(r'\\begin\{auxlemma\}\['+re.escape(title)+r'\](.*?)\\end\{auxlemma\}\s*(\\begin\{proof\}.*?\\end\{proof\})',old,re.S)
    txt=files[where[label]]
    b=re.search(r'\\begin\{lemma\}\['+re.escape(title)+r'\]\\label\{'+re.escape(label)+r'\}(.*?)\\end\{lemma\}\s*(\\begin\{proof\}.*?\\end\{proof\})',txt,re.S)
    assert a and b and canonical(a[1])==canonical(b[1]) and canonical(a[2])==canonical(b[2])
    aux.append(dict(original_heading=title,new_label=label,new_number=current[where[label].split('/')[0]][label][0],statement_body_preserved=True,proof_preserved=True,edit='Originally unnumbered auxiliary lemma promoted to a numbered lemma.'))
audit=dict(original_label_count=100,preserved_label_count=100,statement_count=46,
    explained_proof_edit={'thm:inner-double-count':'Only the primitive-indicator citation is redirected to the standalone classical lemma; the expected replacement has been checked exactly.'},
    results=proofs,promoted_auxiliary_lemmas=aux,all_100_original_labels_resolved=True,
    revision='v2: no further mathematical statement or proof changes')
(ROOT/'provenance/mathematical_preservation_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')

pdfs={}
for p in sorted(ROOT.glob('*.pdf')):
    doc=PdfReader(p);remote=[];web=0
    for page in doc.pages:
        for ref in page.get('/Annots',[]):
            obj=ref.get_object();a=obj.get('/A')
            if not a:continue
            a=a.get_object()
            if str(a.get('/S'))=='/URI':web+=1
            if str(a.get('/S'))=='/GoToR':
                target=a.get('/F');target=target.get_object() if hasattr(target,'get_object') else target
                if isinstance(target,dict):target=target.get('/F')
                remote.append(str(target))
    if p.stem in ('main','supplement'):
        assert all(x==('supplement.pdf' if p.stem=='main' else 'main.pdf') for x in remote)
    pdfs[p.stem]=dict(pages=len(doc.pages),external_document_links=len(remote),external_document_targets=sorted(set(remote)),web_links=web,pdf_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(V/'pdf_links_and_hashes.json').write_text(json.dumps(pdfs,indent=2,ensure_ascii=False),encoding='utf-8')

readme=f'''PaperA 第二轮重构与文献审计
2026年10月26日

交付
main.pdf：修订主稿，{pdfs['main']['pages']}页。
supplement.pdf：补充稿，{pdfs['supplement']['pages']}页。
PaperA_贡献与重构审计.pdf：9页中文报告，说明贡献定位、文献对应、重构理由和质量标准。
main.tex / supplement.tex：两份稿件的编译入口，章节源码可继续编辑。
verification/literature_audit_2026-10-26/：11项文献对照、参数比较、独立数值核查与报告生成记录。
provenance/label_mapping.csv：原100个标签的新旧编号与页码。

第二轮实质修订
1. 摘要、引言与补充稿S7重新按最近文献定位贡献。
2. 明确D_d是既有相邻r-primitive统计；SSL24中心与本稿中心相差O(1)，不再让领先密度本身承担主要创新。
3. 明确Delta_t=N_(t^4)(B,A)已在Cohen 2003通用计数中出现；比较范数几何带来的中心与误差变化。
4. 检查SSL24的基本条件与更强素数筛，检查CSh26的三组充分条件及改变基域的可能；仅对列明条件作判断。
5. 将CSh文献更新为2026正式卷页，并加入ALNR预印本作为更近的进展背景。
6. 二次根计数归于辅助化简；经典Lang构造、曲线界、分式代换与已有射影几何明确归属。
7. 压缩正文中的编辑流程说明；补充稿的四维仿射群统计移到更相邻的位置。

保留与验证
原52页稿取自公开仓库固定版本d33c51696f81492de67b8df2166d0c887666176c；其PDF与附件G:/下载/PaperA.pdf逐字节一致。
原论文目录83个文件已保存并按Git blob校验。原始来源与第一轮重构源码分别存档。
原100标签全部保留。46条带标签定理类陈述逐项一致，证明逐项保留；唯一已记录的引用替换为独立经典原始元指标引理。
两条原先无编号的辅助引理保留陈述与证明并编号。
此前31组双满阶有限域证书、81个中间整数界、s=2..6完整族计数、作者递归素性核验的已执行记录保留。
本轮参数恒等式及筛条件比较另以有理数运算核查。s=2..12的合法筛分拆全部枚举；普遍结论由报告中的不等式证明给出。
两份LaTeX稿已稳定编译，无未定义引用或公式表格溢出；主稿也经桌面编辑器编译成功。
最终PDF页面渲染与链接检查结果见verification/。

文献与验证边界
Hachenberger完整正式全文尚未取得，当前核查仅覆盖出版社摘要和相关索引原文段落；不能据此声称已排除其所有推论。
本轮未重新构建完整Lean工程，未重跑整个原仓库一键复现流程；不把有限检查视为无限定理证明。
原先记录的3项SHA差异仅来自CRLF/LF换行，原记录与复算记录均保留。
重构和文献审计提高可读性、准确归属及可核查性，不凭空增加新定理，不承诺SCI分区或录用。

继续使用
在本目录编辑main.tex或supplement.tex，运行python build.py编译并稳定双向引用。
两份PDF放在同一目录可使用跨文档链接。
verification/literature_audit_2026-10-26/parameter_checks.py只需Python标准库，可独立复算本轮参数核查。
完整第一轮ZIP另存为output/pdf/PaperA_restructured_editable_v1.zip。
当前交付包是第二轮版本；第一轮来源快照在provenance/reconstruction_v1/。
'''
(ROOT/'重构说明.txt').write_text(readme,encoding='utf-8')
(V/'核验摘要.txt').write_text('第二轮检查通过：100个原标签；46条原定理类陈述；逐项证明保留；两条辅助引理；参数恒等式与充分条件比较。\n主稿27页、补充稿31页、中文审计9页。已有有限数学核验保留；Lean未重新全量构建。\nHa21完整正式全文后果核查尚未完成。\n',encoding='utf-8')
env=json.loads((V/'environment.json').read_text(encoding='utf-8'))
env['revision']='v2';env['literature_primary_sources_checked']=11
env['literature_fulltext_gap']='Ha21: abstract and relevant publisher-indexed passages only'
env['new_executed_checks']=['Closest-literature parameter identities and sufficient inequalities','All legal SSL sieve splits for s=2..12 as finite sanity checks','Universal sufficient-condition failure via positive polynomial inequalities','Fresh original-statement/proof preservation check','Stable compilation and desktop main compilation','PDF rendering and layout inspection']
(V/'environment.json').write_text(json.dumps(env,indent=2,ensure_ascii=False),encoding='utf-8')
(V/'desktop_compiler.json').write_text(json.dumps(dict(mainFile='main.tex',revision='v2',kind='success',message='The revised current source compiled successfully with the desktop editor compiler.'),indent=2),encoding='utf-8')
shutil.copy2(Path(__file__),V/'finalize_v2.py')

manifest=[]
def included(p):
    if not p.is_file() or '__pycache__' in p.parts:return False
    if p.suffix in {'.log','.out','.toc','.synctex','.gz'} and not p.is_relative_to(V):return False
    return p.name!='delivery_manifest.json'
for p in sorted(ROOT.rglob('*')):
    if included(p):manifest.append(dict(path=str(p.relative_to(ROOT)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ROOT/'delivery_manifest.json').write_text(json.dumps(dict(revision='v2',files=manifest),ensure_ascii=False,indent=2),encoding='utf-8')
zpath=ROOT.parent/'PaperA_restructured_editable.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in sorted(ROOT.rglob('*')):
        if included(p) or p.name=='delivery_manifest.json':
            z.write(p,arcname=ROOT.name+'/'+str(p.relative_to(ROOT)).replace('\\','/'))
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for f in manifest:
        assert hashlib.sha256(z.read(ROOT.name+'/'+f['path'])).hexdigest()==f['sha256']
print(json.dumps(dict(pdfs=pdfs,original_labels=100,original_statements=46,promoted_auxiliary_lemmas=2,zip_bytes=zpath.stat().st_size,zip_entries=len(manifest)+1,zip_crc_and_manifest_hashes='PASS'),ensure_ascii=False,indent=2))

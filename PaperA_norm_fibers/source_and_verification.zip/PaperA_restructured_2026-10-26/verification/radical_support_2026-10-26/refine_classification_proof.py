"""Use the support mechanism directly, retaining the numbered cyclotomic identity."""
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parents[1]


def main():
    path=ROOT/'main/trace_slices.tex'
    text=path.read_text(encoding='utf-8')
    at=text.index('\\label{thm:trace-positivity-classification}')
    start=text.index('\\begin{proof}',at)
    finish=text.index('\\end{proof}',start)+len('\\end{proof}')
    proof=r'''\begin{proof}
For $s\ge33$, the integer bounds in
Appendix~\ref{app:inner-cert} give $\sqrt t\ge4W(d)$.
Theorem~\ref{thm:uniform-relative-trace} then proves $M_c>0$
for every $c\ne0$. For $s=8$ and $10\le s\le32$,
Appendix~\ref{app:trace-certificates} supplies a core
$e\in\{1,3\}$ and an integer $C_s\ge4W(e)\Lambda-2$ with
$(t+1)^2>tC_s^2$. Lemma~\ref{lem:trace-prime-sieve}
proves positivity in all these slices.

Let $\Phi_j$ denote the reduction modulo two of the $j$th
cyclotomic polynomial and put
$H_j(X)=X^{\varphi(j)}\Phi_j(X+X^{-1})$.
This classical $Q$-transform \cite[\S1]{Ugo20} records the
exact order of a reciprocal trace. Since $B$ is odd,
$\Phi_B$ has simple roots, all primitive in $V$. In particular
\begin{equation}\label{eq:trace-cyclotomic-count}
 \Delta_t=\deg\gcd(\Phi_B,H_A)
 =\sum_{e\mid\operatorname{rad}(B)}\mu(e)
      \deg\gcd(X^{B/e}+1,H_A).
\end{equation}
Appendix~\ref{app:trace-certificates} retains the exact small
trace-one counts. For the exceptional supports, exact binary
polynomial divisions give
\[
 \begin{aligned}
  \gcd(H_j,\Phi_{65})&=1 &&(j=1,3,9),\\
  \gcd(H_j,\Phi_{1025})&=1 &&(j=1,3,33),\\
  H_{11}&\mid\Phi_{1025}.&
 \end{aligned}
\]
Thus $T_1=\varnothing$ at $t=8$, since $1,3,9$ are all
possible reciprocal-trace orders in $U$. At $t=32$, the
twenty roots of $H_{11}$ give all ten order-$11$ reciprocal
traces, while the other possible orders $1,3,33$ have no
primitive preimage. Hence $T_1=C_{11}\setminus\{1\}$.
The inverse-support lemma now gives exactly the empty group
$C_9=U$ in the first case, and $U^3=C_{11}$ in the second.
For the positive-population refinement below, the same
divisions give $H_1=\Phi_3$, $H_3=\Phi_5$ and
\[
 \gcd(H_{33},X^{1025}+1)=\gcd(H_{33},X^{205}+1),
 \qquad\deg\gcd(H_{33},X^{205}+1)=20,
\]
with $\gcd(H_{33},X^{41}+1)=\gcd(H_{33},X^5+1)=1$.
These identities also identify the order drop in the latter
support obstruction.

For the remaining finite range $s=2,\ldots,7,9$, every
$A=t+1$ has at most two distinct prime divisors.
Appendix~\ref{app:trace-certificates} supplies $755$
primitive support witnesses, one for every $h\in K^*$ except
$(s,h)=(3,1),(5,1)$. They prove $M_h>0$ directly through
Theorem~\ref{thm:uniform-relative-trace}. In the $731$ classes
where $A$ has two distinct prime divisors, a second witness
has image outside the inverse pair of the first, so
$|\overline{T_h}|\ge3$. The inverse-support lemma gives
$M_{hu}>0$ for every $u\in U$.
The independent verifier checks both kinds of witnesses in
degree-$4s$ binary polynomial fields, without an all-$E$
coverage mask. Unique decomposition $c=hu$ proves every
remaining slice positive. Together with the analytic range
and the two exact support obstructions, this proves
\eqref{eq:all-trace-classification}. Restriction to $K^*$,
which meets each exceptional group only at $1$, proves
\eqref{eq:trace-one-classification}.
The earlier $3319$ full-trace witness families remain a
separate check, rather than a premise of this reduction.
\end{proof}'''
    text=text[:start]+proof+text[finish:]
    path.write_text(text,encoding='utf-8')
    print('Classification proof reorganized around support obstructions and representative propagation.')


if __name__=='__main__':main()

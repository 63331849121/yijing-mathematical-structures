"""Deliver the proved support reduction, preserving the previous complete package."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
ZIP=ROOT.parent/'PaperA_restructured_editable.zip'
BACKUP=ROOT.parent/'PaperA_restructured_editable_v10_before_radical_support.zip'


def read(p):return json.loads(p.read_text(encoding='utf-8'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    previous=read(HERE/'before_radical_support/delivery_manifest.json.snapshot')
    compilation=read(HERE/'compilation.json');visual=read(HERE/'visual_review.json')
    exact=read(HERE/'independent_checks.json');preservation=read(HERE/'preservation_checks.json')
    if compilation['issues'] or not compilation['aux_stable']:raise RuntimeError('Compilation not stable/clean')
    if compilation['pdf_sha256']!=digest(ROOT/'main.pdf'):raise RuntimeError('PDF changed after compilation')
    if visual['status']!='PASS' or visual['pdf_sha256']!=digest(ROOT/'main.pdf'):raise RuntimeError('Visual review is not current')
    if exact['status']!='PASS' or preservation['status']!='PASS':raise RuntimeError('Required check failed')
    spec=importlib.util.spec_from_file_location('retained_link_inspector',
        ROOT/'verification/fulltext_structure_2026-10-26/finalize_structure.py')
    util=importlib.util.module_from_spec(spec);spec.loader.exec_module(util)
    write(HERE/'pdf_links.json',util.check_links())
    report='verification/radical_support_2026-10-26/支持集归结_严格验证与证明提升.txt'
    facts={
        'date':'2026-10-26','revision':'v11-radical-support','status':'PROVED_AND_INDEPENDENTLY_CHECKED',
        'general_lemma':{
            'group':'cyclic of odd order n>1','support':'T=T^(-1)',
            'radical_quotient':'G/H, |H|=n/rad(n)',
            'one_prime_case':'zero set is G, G^p, or empty according to empty support, image {1}, or other image',
            'two_prime_case':'If F_T(1)>0, zeros occur exactly when the radical image is an inverse pair of generators',
            'exceptional_zero_count':'2*n/(p*q)',
            'three_radical_residues_suffice':True,
            'prime_kernel_confinement_case':'If image lies in {1} x C_q and has >=2 points, zero set is G^p',
            'arbitrary_number_of_prime_divisors_claimed':False,
            'general_proof_is_CRT_argument_not_finite_extrapolation':True},
        'finite_field_interface':{
            'T_h_inversion_symmetry_proved_by_Frobenius':True,
            'M_hu_equals_F_T_h_u_from_Theorem_51_only':True,
            'no_dependency_on_Theorem_54_truth':True},
        'exceptions':{'t8':'T_1 empty, giving whole C9 empty',
            't32':'T_1=C11 minus identity, giving zero set U^3=C11'},
        'finite_proof_parameters':[2,3,4,5,6,7,9],
        'analytic_parameters':'s=8 and all s>=10, unchanged',
        'proof_central_witnesses':755,'proof_separating_witnesses':731,'proof_total_witnesses':1486,
        'redundant_s8_central_witnesses':255,'all_archived_new_witnesses':1741,
        'retained_old_family_records':3319,'old_family_records_excluding_analytic_s8':2809,
        'old_proof_already_used_compressed_families':True,
        'comparison_is_certificate_inputs_not_equal_cost_complexity_theorem':True,
        'independent_verification':{
            'different_binary_arithmetic_implementation':True,
            'central_elements_constructed_and_exact_order_checked':1010,
            'support_separation_witnesses_checked':731,
            'exact_exceptional_support_and_polynomial_identities_checked':True,
            'small_cyclic_inverse_subsets_checked':sum(x['all_inversion_stable_subsets_checked'] for x in exact['abstract_cyclic_checks']['exhaustive_rows']),
            'prime_power_quotient_lifts_checked':exact['abstract_cyclic_checks']['prime_power_lifts_checked'],
            'three_failed_extensions_have_exact_counterexamples':True,
            'external_human_peer_review_completed':False},
        'classical_background':{
            'CRT_and_unitary_Cayley_framework_prior':True,
            'new_general_graph_theory_claimed':False,
            'reference':'H. Vemuri, arXiv:1908.02445v1 (2019), Section 1',
            'reference_url':'https://arxiv.org/html/1908.02445v1',
            'scope_read':'Introduction/CRT graph framework and relevant stated context; not a full proof-level exclusion of all graph literature'},
        'academic_increment':'A reusable support obstruction and a noncircular reduced certificate proof for the existing complete finite-field classification',
        'new_parameter_range_claimed':False,'new_geometric_character_bound_claimed':False,
        'global_priority_confirmed':False,'proof_level_literature_exclusion_complete':False,
        'remaining_priority_fulltext_gap_ids':[],
        'database_actual_topic_search_completed':{'MathSciNet':False,'zbMATH_Open':True},
        'prior_five_item_fulltext_audit_retained':True,
        'preservation':preservation,'main_pages':compilation['pages'],'report':report,
        'external_messages_GitHub_push_or_journal_submission_performed':False}
    write(HERE/'findings.json',facts)
    write(HERE/'documentation_scope.json',{
        'mathematical_background_urls':['https://arxiv.org/abs/1908.02445v1','https://arxiv.org/html/1908.02445v1','https://www.combinatorics.org/ojs/index.php/eljc/article/view/v14i1r45'],
        'new_full_graph_literature_priority_audit_claimed':False,
        'OpenAI_Docs_url':'https://developers.openai.com/api/docs/models/gpt-6.1-sol',
        'model_advice':'Keep the user stated GPT-6.1 Sol max; no setting was changed',
        'model_setting_not_mathematical_verification_evidence':True})
    desc=f'''PaperA 第十一轮：取逆支持集归结与定理5.4证明改进
2026年10月26日

当前主稿 main.pdf：{compilation['pages']}页；当前main.tex项目原位更新，桌面编译和稳定本地编译通过。
全部页面已渲染核对；原LaTeX编辑器保留。外部PDFgear对旧PDF的占用已解除，同名PDF已更新。

已证明的新增结构
奇循环群的取逆稳定支持，在平方自由商群至多含两个素数坐标时有精确障碍分类。
代表迹非空时，双素数唯一剩余障碍是商群支持恰好只有一对互逆生成元；第三个不同支持像即排除它。
不能删去取逆对称、支持分离或双素数限制；三个失败推广均有精确反例。
该引理明确归属经典CRT及单位Cayley图框架，不作为新通用图论或新几何估计宣称。

C9/C11的统一判别
t=8：primitive参数支持为空，整个C9为空。
t=32：支持恰为C11去单位元，集中在3坐标核，零集恰为C11。
两种不同机制在同一支持集判别框架内处理，具体支持由精确多项式证书决定。

5.4的新证明
分析范围s=8及s>=10保留；剩余有限参数使用755个代表迹见证及731个支持分离见证。
总计1486条见证，无需以全E迹余数覆盖作为证明前提；另保存s=8的255条冗余交叉核对，总档1741条。
旧3319个压缩覆盖族全部保留；剔除同样的s=8后，旧为2809族，新有限证明为1486条局部见证。
这是证书输入与逻辑依赖的改进，不声称原证明是逐点枚举，也不将两类记录视为等成本算法复杂度。

严格核验
两套不同二元多项式算术实现；1010个代表元素实际检验迹、范数与完整阶，731个支持分离条件逐条检验。
两例外支持及全部新增多项式恒等式另行验证；一般引理有完整CRT证明。
小循环群158012个取逆子集及133632个商群提升通过，有限测试不替代一般证明。
本轮没有完成外部人类专家同行复核，也没有完整Lean形式化。

保留
5.1证明、5.4陈述及编号、5.5–5.7陈述证明编号保持；5.4证明已重写。
原100标签、原46条数学陈述证明所在核心文件、相对迹节26个既有标签编号均保持；补充稿不改动。
最新报告：{report}
当前结果以本轮findings.json及报告为准，历史报告仍保留。

投稿与归属边界
这是有实际用途的结构归结与证明提升，未扩大5.4的参数范围，未新增普适特征和理论，不保证期刊分区。
五项优先全文核查状态保留；MathSciNet主题检索仍未完成，全球绝对首创性未确认。
未推送GitHub、未联系作者、未投稿。当前档位保持用户指定的6.1 Sol max。

交付包：PaperA_restructured_editable.zip。
本轮前备份：PaperA_restructured_editable_v10_before_radical_support.zip。
'''
    (ROOT/'重构说明.txt').write_text(desc,encoding='utf-8')
    allowed={'main/trace_slices.tex','main/introduction.tex','main/abstract.tex','main/discussion.tex',
        'main/trace_certificates.tex','main/reproducibility.tex','main/bibliography.tex',
        'main.pdf','main.aux','main.log','main.out','重构说明.txt'}
    changed=[]
    for item in previous['files']:
        p=ROOT/item['path']
        if not p.is_file():raise RuntimeError('Previous payload lost: '+item['path'])
        if digest(p)!=item['sha256']:
            if item['path'] not in allowed:raise RuntimeError('Unexpected previous payload change: '+item['path'])
            changed.append(item['path'])
    write(HERE/'previous_payload_preservation.json',{'status':'PASS',
        'previous_payload_files_retained':len(previous['files']),'intentional_changes':changed,'unexpected_changes':[]})
    excluded={ROOT/'verification/systematic_novelty_2026-10-26':{
        'zbmath_queries_working.json','citation_tracking_working.json','seed_control_results.json',
        'query_syntax_controls.json','primary_acquisition_log.json','missing_title_resolution.json'},
        ROOT/'verification/fulltext_structure_2026-10-26':{'user_provided_inventory.json','public_fulltext_discovery.json'}}
    paths=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
        and p!=ROOT/'delivery_manifest.json' and p.name not in excluded.get(p.parent,set())]
    for p in paths:
        if p.suffix in {'.txt','.py','.json','.tex','.csv'} or p.name.endswith('.snapshot'):
            if re.search(rb'\d{10}@m\.scnu\.edu\.cn',p.read_bytes()):raise RuntimeError('Private institutional identifier found')
    manifest={k:v for k,v in previous.items() if k!='files'}
    manifest.update(revision='v11-radical-support',main_manuscript_revision='v11',
        mathematical_result_revision='v11-support-lemma-and-classification-proof',
        support_reduction_proved=True,classification_statement_unchanged_proof_refined=True,
        current_report=report,main_pdf_pages=compilation['pages'],
        remaining_fulltext_gap_ids=[],remaining_priority_fulltext_gap_ids=[],
        global_priority_confirmed=False,proof_level_literature_exclusion_complete=False,
        previous_reports_are_historical=True,manuscript_pdf_unchanged=False)
    manifest['files']=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(paths)]
    write(ROOT/'delivery_manifest.json',manifest)
    if digest(BACKUP)!='588b6ebc5022da2e6881e7fa7fd0e7dc9f868be50c5468c95e024cd9670d5a1b':raise RuntimeError('Previous archive backup mismatch')
    with zipfile.ZipFile(BACKUP) as z:old_names=set(z.namelist())
    with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for p in paths+[ROOT/'delivery_manifest.json']:z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(ZIP) as z:
        if z.testzip() is not None:raise RuntimeError('Archive CRC failure')
        if old_names-set(z.namelist()):raise RuntimeError('Previous archive entry lost')
        for item in manifest['files']:
            if hashlib.sha256(z.read(ROOT.name+'/'+item['path'])).hexdigest()!=item['sha256']:
                raise RuntimeError('Archive hash mismatch: '+item['path'])
        entries=len(z.infolist())
    output={'status':'PASS','revision':manifest['revision'],'main_pdf_pages':compilation['pages'],
        'main_pdf_sha256':digest(ROOT/'main.pdf'),'archive':str(ZIP),'archive_sha256':digest(ZIP),
        'entries':entries,'previous_archive':str(BACKUP),'previous_archive_sha256':digest(BACKUP),
        'all_previous_archive_entries_retained':True,'crc_and_manifest_verified':True,
        'global_priority_confirmed':False,'report':str(ROOT/report)}
    write(ROOT.parent/'PaperA_radical_support_delivery.json',output)
    print(json.dumps(output,ensure_ascii=False))


if __name__=='__main__':main()

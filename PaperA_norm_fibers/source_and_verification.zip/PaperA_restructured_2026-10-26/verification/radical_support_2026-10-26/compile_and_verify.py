"""Compile current sources and audit preserved mathematics against v10."""
from pathlib import Path
import csv
import hashlib
import json
import re
import subprocess
from pypdf import PdfReader

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BEFORE=HERE/'before_radical_support'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def write(name,obj):
    (HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def block(text,label,include_proof=True):
    at=text.index('\\label{'+label+'}')
    starts=list(re.finditer(r'\\begin\{(theorem|proposition|corollary)\}',text[:at]))
    start=starts[-1].start();kind=starts[-1].group(1)
    end=text.index('\\end{'+kind+'}',at)+len('\\end{'+kind+'}')
    if include_proof:end=text.index('\\end{proof}',end)+len('\\end{proof}')
    return text[start:end]


def main():
    stable=False
    for count in range(1,4):
        old=(ROOT/'main.aux').read_bytes()
        r=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],
                         cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if r.returncode:raise RuntimeError(r.stdout.decode(errors='replace')[-6500:])
        if count>=2 and old==(ROOT/'main.aux').read_bytes():stable=True;break
    log=(ROOT/'main.log').read_text(encoding='utf-8',errors='replace')
    issues=[x for x in log.splitlines() if any(s in x for s in
        ['Undefined control sequence','LaTeX Error:','Overfull \\hbox','Overfull \\vbox',
         'undefined references','multiply defined','has been referenced but does not exist',
         'Rerun to get cross-references right']) or re.search(r'LaTeX Warning: (?:Reference|Citation).*undefined',x)]
    if issues or not stable:raise RuntimeError(json.dumps({'issues':issues,'stable':stable}))
    aux='\n'.join((ROOT/p).read_text(encoding='utf-8') for p in ['main.aux','supplement.aux'])
    labels=dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}',aux))
    mappings=list(csv.DictReader((ROOT/'provenance/label_mapping.csv').open(encoding='utf-8-sig',newline='')))
    for row in mappings:
        if labels.get(row['Original label'])!=row['New printed number']:
            raise RuntimeError('Original label number changed: '+row['Original label'])
    previous=json.loads((BEFORE/'delivery_manifest.json.snapshot').read_text(encoding='utf-8'))
    hashes={x['path']:x['sha256'] for x in previous['files']}
    orig=json.loads((ROOT/'provenance/mathematical_preservation_audit.json').read_text(encoding='utf-8'))
    paths=sorted({x['destination'] for x in orig['results']})
    for p in paths:
        if sha(ROOT/p)!=hashes[p]:raise RuntimeError('Original mathematical source changed: '+p)
    before=(BEFORE/'main/trace_slices.tex.snapshot').read_text(encoding='utf-8')
    after=(ROOT/'main/trace_slices.tex').read_text(encoding='utf-8')
    result={}
    expected={'thm:uniform-relative-trace':'5.1','thm:trace-positivity-classification':'5.4',
        'prop:trace-norm-distribution':'5.5','cor:exceptional-trace-profiles':'5.6',
        'cor:arbitrary-norm-trace':'5.7'}
    for label,number in expected.items():
        same_statement=block(before,label,False)==block(after,label,False)
        same_proof=block(before,label)==block(after,label)
        if not same_statement or labels[label]!=number:raise RuntimeError('Statement or number changed: '+label)
        if label=='thm:trace-positivity-classification':
            if same_proof:raise RuntimeError('Classification proof was not updated')
        elif not same_proof:raise RuntimeError('Unexpected proof change: '+label)
        result[label]={'number':number,'statement_unchanged':same_statement,'statement_and_proof_unchanged':same_proof}
    # Preserve all existing numbered equation labels in this section, not just theorem numbers.
    old_labels=dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}',(BEFORE/'main.aux.snapshot').read_text(encoding='utf-8')))
    trace_labels=re.findall(r'\\label\{([^}]+)\}',before)
    for label in trace_labels:
        if labels.get(label)!=old_labels.get(label):raise RuntimeError('Existing trace label changed: '+label)
    require_unchanged=['supplement.pdf','supplement.aux']
    for p in require_unchanged:
        if sha(ROOT/p)!=hashes[p]:raise RuntimeError('Supplement changed: '+p)
    write('preservation_checks.json',{'status':'PASS','original_labels_resolved':len(mappings),
        'original_statement_proof_count':len(orig['results']),'original_core_files_unchanged':paths,
        'all_existing_trace_section_label_numbers_preserved':len(trace_labels),
        'statements_and_proofs':result,'classification_statement_unchanged_proof_replaced':True,
        'supplement_pdf_and_aux_unchanged':True})
    write('compilation.json',{'status':'PASS','built_in_compiler_success':True,'local_passes':count,
        'aux_stable':stable,'issues':issues,'pages':len(PdfReader(ROOT/'main.pdf').pages),
        'pdf_sha256':sha(ROOT/'main.pdf')})
    print(json.dumps({'status':'PASS','pages':len(PdfReader(ROOT/'main.pdf').pages),
        'original_labels':len(mappings),'original_statements':len(orig['results']),
        'trace_label_numbers_preserved':len(trace_labels),'classification_statement_unchanged_proof_refined':True}))


if __name__=='__main__':main()

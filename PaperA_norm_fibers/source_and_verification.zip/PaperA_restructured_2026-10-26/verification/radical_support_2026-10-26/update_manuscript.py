"""Install the verified support reduction in the existing main project."""
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def one(text,old,new):
    if text.count(old)!=1:raise RuntimeError('Replacement not unique: '+old[:90])
    return text.replace(old,new,1)


def main():
    p=ROOT/'main/trace_slices.tex'
    text=p.read_text(encoding='utf-8')
    if text!=(HERE/'before_radical_support/main/trace_slices.tex.snapshot').read_text(encoding='utf-8'):
        raise RuntimeError('Trace source changed after snapshot')
    definitions=r'''For $h\in K^*$ define
\[
 T_h=\{(\gamma+\gamma^{-1})/h^2\in U:
                   \gamma\in V,\ \operatorname{ord}(\gamma)=B\},
 \qquad n_h=2|T_h|.
\]
The factor two records the pair $\gamma,\gamma^{-1}$ over
each reciprocal trace. The class $hU$ consists of exactly those
$c\in E^*$ with $N_{E/K}(c)=h^2$.
'''
    if text.count(definitions)!=1:raise RuntimeError('Support definitions not unique')
    text=one(text,definitions,
        'Retain $T_h$ and $n_h$ from the inverse-support reduction above.\n')
    reduction=r'''To pass from a representative trace $h\in K^*$ to its whole
trace-norm class, we use the reciprocal-trace supports.
'''+definitions+r'''They satisfy $T_h=T_h^{-1}$: raising a primitive $\gamma$ to
the $t$th power preserves its order, fixes $h$, and sends
$(\gamma+\gamma^{-1})/h^2$ to its inverse in $U$.
This Frobenius symmetry is essential to the following reduction.
The underlying Chinese remainder description is classical in
unitary Cayley graphs; see \cite[\S1]{Vem19}. We give the
elementary argument needed here.

\hypertarget{inverse-support-lemma}{}
\begin{auxlemma}[Inverse supports with at most two prime divisors]
Let $G$ be cyclic of odd order $n>1$, let $T=T^{-1}\subseteq G$,
and put $\rho=\operatorname{rad}(n)$. Let $H$ have order $n/\rho$,
let $S$ be the image of $T$ in $G/H$, and define
\[
 F_T(u)=2\#\{z\in T:\operatorname{ord}(zu^{-2})=n\}.
\]
If $\rho=p$ is prime, the zero set of $F_T$ is $G$ when
$T=\varnothing$, is $G^p$ when $S=\{1\}$, and is empty otherwise.

Suppose $\rho=pq$ for distinct primes and $F_T(1)>0$.
Then $F_T(u)>0$ for every $u\in G$, unless
$S=\{v,v^{-1}\}$ for a generator $v$ of $G/H$.
In that exceptional case write $v=(a,b)$ under
$G/H\cong C_p\times C_q$. The zeros are exactly the $u$ with
\[
 \overline u^{\,2}\in\{(a,b^{-1}),(a^{-1},b)\},
\]
and there are $2n/(pq)$ of them. In particular $|S|\ge3$
excludes this case; the sufficient condition $|T|>2n/\rho$
also does so.

Finally, if $\rho=pq$, $S\subseteq\{1\}\times C_q$ and
$|S|\ge2$, the zero set is exactly $G^p$.
\end{auxlemma}
\begin{proof}
An element generates $G$ exactly when its image has nonidentity
coordinate at every prime dividing $\rho$. Hence
\[
 F_T(u)=0\quad\Longleftrightarrow\quad
 T\subseteq\bigcup_{p\mid\rho}u^2G^p.
\]
For $\rho=p$, a nonempty $S$ can be covered by one coordinate
value only when it is a singleton. Inversion then forces that
value to be $1$, since $p$ is odd. Squaring is bijective,
which proves the first assertion.

For $\rho=pq$ and $F_T(1)>0$, choose $v=(a,b)\in S$ with
$a,b\ne1$. Inversion puts $v^{-1}$ in $S$, and oddness gives
$a\ne a^{-1}$, $b\ne b^{-1}$. A zero must cover both points
by its row and column. Its squared image must therefore be
one of the two mixed corners $(a,b^{-1})$, $(a^{-1},b)$.
The zero set is inversion invariant, so if one mixed corner
occurs then both occur. The intersection of their row--column
unions is precisely $\{v,v^{-1}\}$. Thus $S$ must be that pair.
Conversely that pair has exactly the two stated zero corners.
Each lifts to $n/\rho$ elements, proving the formula and the
cardinality consequences.

For the final assertion, the first coordinate $1$ covers all
of $S$. Any other first coordinate would require its column
to cover two distinct points of $S$, which is impossible.
\end{proof}

By Theorem~\ref{thm:uniform-relative-trace},
$M_{hu}=F_{T_h}(u)$. Thus, when $A$ has two distinct prime
divisors, a primitive support point $z_0$ and one additional
point whose image is outside
$\{\overline z_0,\overline z_0^{-1}\}$ certify positivity
throughout $hU$. The additional condition cannot be dropped:
in $G=\langle g\rangle$ of order $15$, $T=\{g,g^{-1}\}$ has
$F_T(1)=4$ but $F_T(g^2)=F_T(g^{13})=0$.
This is a cyclic-group reduction, not an additional geometric
estimate. Neither its proof nor the support certificates below
uses the classification to be proved.

'''
    text=one(text,'\\begin{theorem}[Complete nonzero-relative-trace classification]',
        reduction+'\\begin{theorem}[Complete nonzero-relative-trace classification]')
    old=r'''For every remaining nonzero $E$-valued slice with $2\le s\le9$,
Appendix~\ref{app:trace-certificates} gives exact witness families.
They cover all $349492$ nonexceptional traces among the $349512$
traces in these eight fields. The verifier checks every coverage
condition by integer gcds and checks a constructed full-order
element for each of the $3319$ family witnesses, using independent
binary polynomial fields. The two exceptional groups, of sizes
$9$ and $11$, were proved empty above. These certificates and
the analytic range complete \eqref{eq:all-trace-classification}.'''
    new=r'''The same polynomial divisions determine the exceptional supports.
At $t=8$, no primitive $\gamma\in V$ has reciprocal trace in
$U$, so $T_1=\varnothing$. At $t=32$, the identity
$H_{11}\mid\Phi_{1025}$ gives twenty primitive parameters
over the ten order-$11$ reciprocal traces. The preceding
exclusions for trace orders $1,3,33$ therefore give
$T_1=C_{11}\setminus\{1\}$. The final assertion of the
inverse-support lemma, with $p=3$, $q=11$, makes its zero
set exactly $U^3=C_{11}$. Thus the two exceptional groups
come respectively from absent support and confinement to
one prime-coordinate kernel.

It remains to treat the other trace-norm classes in the finite
range $s=2,\ldots,7,9$, since $s=8$ was settled analytically.
Every corresponding $A=t+1$ has at most two distinct prime
divisors. Appendix~\ref{app:trace-certificates} supplies $755$
primitive support witnesses, one for every $h\in K^*$ except
the two exceptional pairs $(s,h)=(3,1),(5,1)$.
They prove $M_h>0$ directly through
Theorem~\ref{thm:uniform-relative-trace}. In the $731$ classes
where $A$ has two distinct prime divisors, a second witness
has image outside the inverse pair of the first, so
$|\overline{T_h}|\ge3$. The inverse-support lemma proves
$M_{hu}>0$ for every $u\in U$. The independent verifier
checks both kinds of witnesses in degree-$4s$ binary polynomial
fields; it does not use an all-$E$ coverage mask.
Unique decomposition $c=hu$ now proves every remaining slice
positive. Together with the analytic range and the two exact
support obstructions, this proves \eqref{eq:all-trace-classification}.
The earlier $3319$ full-trace witness families are retained
as a separate check, rather than a premise of this reduction.'''
    text=one(text,old,new)
    p.write_text(text,encoding='utf-8')

    p=ROOT/'main/trace_certificates.tex'
    text=p.read_text(encoding='utf-8')
    new=r'''\subsection*{Representative and separating support witnesses}
Write $\rho=\operatorname{rad}(A)$ and choose generators
$z\in E^*$, $\Gamma\in V$. Represent $h=z^{Aj}$,
$0\le j<t-1$. Each certificate records $k$ and $e$ with
\[
 \gcd(k,B)=1,\qquad
 \Gamma^k+\Gamma^{-k}=h^2(z^{t-1})^e.
\]
A central witness has $\gcd(e,A)=1$ and proves $M_h>0$.
When $A$ has two distinct prime divisors, a separating witness
has exponent $e'$ with
$e'\not\equiv e,-e\pmod\rho$. Inversion supplies the second
residue $-e$, so these two witnesses certify at least three
distinct points in the radical quotient. The inverse-support
lemma then proves positivity on the whole trace class $hU$.
Only these witnesses, not the complete support populations,
are required by this step of the proof.
\begin{center}
\begin{tabular}{rrrrr}
\toprule
$s$&$A$&$\rho$&Central witnesses&Separating witnesses\\
\midrule
2&5&5&3&0\\
3&9&3&6&0\\
4&17&17&15&0\\
5&33&33&30&30\\
6&65&65&63&63\\
7&129&129&127&127\\
9&513&57&511&511\\
\midrule
Total&&&755&731\\
\bottomrule
\end{tabular}
\end{center}
The omitted representatives are precisely $(s,h)=(3,1),(5,1)$,
whose supports are determined by the polynomial identities.
The case $s=8$ is already analytic; $255$ additional central
witnesses are retained as a finite check. Thus the archive
contains $1010+731=1741$ witnesses, of which $1486$ are used
by the finite part of the current proof.

The exact data are in
\path{verification/radical_support_2026-10-26/support_certificates.json}.
The producer enumerates reciprocal traces from primitive
$\gamma$ and records central and separating exponents. The
independent verifier uses single binary polynomial fields of
degree $4s$, checks irreducibility and the field embeddings,
and directly verifies every reciprocal trace and order condition.
It constructs a full-order element for each central witness.
The two exceptional supports are separately enumerated at
$s=3,5$. Neither verification nor the group-theoretic proof
uses the truth of the completed trace classification.

The older all-$E$ certificate family below is retained for
cross-checking. It already compressed traces into witness
families; the improvement here is the reduction to representative
and separating support witnesses, without checking every
trace residue for coverage. Excluding the analytic $s=8$ case,
the older proof used $2809$ family records, compared with
$1486$ support witnesses in the present finite argument.

\subsection*{Retained witness families on the whole trace field}'''
    text=one(text,'\\subsection*{Exact witness families on the whole trace field}',new)
    p.write_text(text,encoding='utf-8')

    p=ROOT/'main/reproducibility.tex'
    text=p.read_text(encoding='utf-8')
    start=text.index('For the whole $E^*$, the files in')
    end=text.index('The independent script in',start)
    new=r'''The current finite proof for the whole $E^*$ uses the files in
\path{verification/radical_support_2026-10-26/}. It has $755$
central witnesses and $731$ separating witnesses; $255$
additional central witnesses at the analytic case $s=8$
are redundant checks. A separate arithmetic implementation
transports the data to degree-$4s$ binary polynomial fields
and verifies every witness directly. The inverse-support
lemma propagates positivity from the representatives to the
whole trace classes. The two exceptional supports are
independently checked as well. The general reduction depends
only on Theorem~\ref{thm:uniform-relative-trace} and elementary
cyclic-group arguments, not on the completed classification.
Exhaustive small cyclic-group checks and counterexamples
to dropping its hypotheses are also recorded.

The earlier $3319$ exact witness families in
\path{verification/extended_trace_2026-10-26/} remain a
separate check on all $349512$ nonzero traces for
$s=2,\ldots,9$. Independent full-subgroup enumeration for
$s=2,\ldots,6$ additionally checks all $5451$ nonzero
$E$-valued populations and the stated error bounds.
The phase reduction and prime sieve prove the infinite range;
finite checks do not replace those arguments.
Appendix~\ref{app:trace-certificates} distinguishes the current
support proof from the retained all-trace certificates.

'''
    text=text[:start]+new+text[end:]
    p.write_text(text,encoding='utf-8')

    p=ROOT/'main/introduction.tex'
    text=p.read_text(encoding='utf-8')
    old=r'''and $c^{11}=1$ at $s=5$. These are subgroups of sizes $9$
and $11$; each meets $K^*$ only at $1$.'''
    new=old+r'''
For the finite range, an elementary inverse-support reduction
uses the fact that $t+1$ has at most two distinct prime
divisors there. It replaces all-trace coverage by $755$
representative witnesses and $731$ support-separation witnesses.
The exceptional groups arise from an empty support at $t=8$
and from support confined to one prime-coordinate kernel at
$t=32$. The two-prime restriction and the separation condition
are essential; they are not asserted for arbitrary supports.'''
    text=one(text,old,new)
    p.write_text(text,encoding='utf-8')

    p=ROOT/'main/abstract.tex'
    text=p.read_text(encoding='utf-8')
    text=one(text,
        r'''A prime sieve and exact finite certificates
classify all empty nonzero slices:''',
        r'''A prime sieve, an inverse-support reduction and exact
representative certificates classify all empty nonzero slices:''')
    p.write_text(text,encoding='utf-8')

    p=ROOT/'main/discussion.tex'
    text=p.read_text(encoding='utf-8')
    old=r'''The two earlier trace-one exceptions are the intersections
of these groups with $K^*$.'''
    new=old+r'''
The inverse-support reduction makes a common organization
explicit: a missing primitive support gives the whole empty
$C_9$, whereas a nonempty support confined to one prime-coordinate
kernel gives the empty $C_{11}$. For the other small norm
classes, representative positivity and one separation witness
exclude the only possible two-prime obstruction. This is a
proof reduction within a classical cyclic-group framework;
it does not supply a new general character estimate or an
unrestricted higher-prime classification.'''
    text=one(text,old,new)
    p.write_text(text,encoding='utf-8')

    p=ROOT/'main/bibliography.tex'
    text=p.read_text(encoding='utf-8')
    new=r'''\bibitem{Vem19} H.~Vemuri,
\emph{Domination in direct products of complete graphs},
arXiv:1908.02445v1 (2019),
\href{https://arxiv.org/abs/1908.02445v1}{arXiv:1908.02445v1}.
'''
    text=one(text,'\\end{thebibliography}',new+'\\end{thebibliography}')
    p.write_text(text,encoding='utf-8')
    from refine_classification_proof import main as refine_proof
    refine_proof()
    print('Current main project updated with the verified inverse-support proof reduction.')


if __name__=='__main__':main()

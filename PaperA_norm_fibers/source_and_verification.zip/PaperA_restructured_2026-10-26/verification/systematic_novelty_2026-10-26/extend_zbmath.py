"""Additional recall queries, seed controls and reference-text tracking."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import csv,json
import search_zbmath as s

EXTRA=[
 ('Z21_relative_trace_broad','trace & (relative | intermediate) & (primitive | order | norm) & cc:11T'),
 ('Z22_orders_traces','(ti:order* | ti:subgroup* | ti:torus | ti:tori) & (trace | norm) & cc:11T'),
 ('Z23_trace_product','ti:trace & ti:product* & cc:11T'),
 ('Z24_norm_generators','(generator* | primitive) & ("norm kernel" | "norm-one subgroup" | "norm one subgroup" | "projectively primitive")'),
 ('Z25_affine_companions','(ti:affine | ti:orthomorphism* | ti:"complete mapping") & (companion* | "generated group" | "translation group")'),
 ('Z26_subgroup_consecutive','(consecutive | adjacent | translate*) & ("specified order" | "prescribed order" | "multiplicative subgroup") & cc:11T'),
 ('Z27_rft_Cohen03','rft:"10.1023/A:1026295128600"'),
 ('Z28_rft_Cohen05','rft:"10.1007/s10623-004-1724-2"'),
 ('Z29_rft_Ozbudak05','rft:"10.1007/s10623-003-4193-0"'),
 ('Z30_rft_Rani23','rft:"10.1016/j.ffa.2023.102253"'),
 ('Z31_rft_CKR22','rft:"10.5802/crmath.328"'),
 ('Z32_rft_Hachenberger21','rft:"10.1007/s10801-019-00920-8"'),
 ('Z33_norm_trace_characters','(ti:character* | ti:sum*) & ("norm-one" | "norm one" | torus | tori) & cc:(11T | 11L)'),
 ('Z34_line_translate','ti:primitive & (ti:line | ti:translate)'),
 ('Z35_complete_mapping_composition','(ti:"complete mappings" | ti:orthomorphism*) & (ti:composition* | ti:group* | ti:affine | ti:companion*)'),
 ('Z36_exact_order_trace_line','(ti:"specified order" | ti:"prescribed order" | ti:"r-primitive") & (ti:trace* | ti:line | ti:translate)'),
 ('Z37_rft_Cohen03_unquoted','rft:10.1023/A:1026295128600'),
 ('Z38_rft_Cohen05_unquoted','rft:10.1007/s10623-004-1724-2'),
 ('Z39_rft_Ozbudak05_unquoted','rft:10.1007/s10623-003-4193-0'),
 ('Z40_rft_Rani23_unquoted','rft:10.1016/j.ffa.2023.102253'),
 ('Z41_rft_CKR22_unquoted','rft:10.5802/crmath.328'),
 ('Z42_rft_Hachenberger21_unquoted','rft:10.1007/s10801-019-00920-8'),
]

def main():
    path=s.HERE/'zbmath_queries_working.json'
    rows=json.loads(path.read_text(encoding='utf-8'))
    done={r['id'] for r in rows}
    with ThreadPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(s.run_query,x) for x in EXTRA if x[0] not in done]):
            r=future.result();rows.append(r)
            print(r['id'],r['status'],r.get('total'),r['retrieved'],flush=True)
            path.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    rows.sort(key=lambda r:r['id']);catalog={}
    for row in rows:
        for doc in row['results']:
            key=str(doc['id'])
            if key not in catalog:catalog[key]=dict(document=doc,query_ids=[])
            catalog[key]['query_ids'].append(row['id'])
    (s.RAW/'deduplicated_full_records.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    compact=[]
    for item in catalog.values():
        d=item['document']
        compact.append(dict(id=d['id'],identifier=d.get('identifier'),year=d.get('year'),title=d.get('title',{}).get('title'),
          authors='; '.join(x['name'] for x in d.get('contributors',{}).get('authors',[])),
          doi='; '.join(x['identifier'] for x in d.get('links',[]) if x.get('type')=='doi'),url=d.get('zbmath_url'),
          msc='; '.join(x['code'] for x in d.get('msc',[])),queries='; '.join(item['query_ids'])))
    compact.sort(key=lambda r:(str(r.get('year')),str(r.get('title'))),reverse=True)
    with (s.HERE/'zbmath_screening_catalog.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(compact[0]));w.writeheader();w.writerows(compact)
    log=json.loads((s.HERE/'zbmath_search_log.json').read_text(encoding='utf-8'))
    log.update(queries=[{k:v for k,v in r.items() if k!='results'} for r in rows],unique_records=len(catalog),
       citation_scope='Reference-text queries search the indexed reference text only. ci: is NOT used as a complete citing-paper index.')
    (s.HERE/'zbmath_search_log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    p=s.HERE/'zbmath_protocol.json';protocol=json.loads(p.read_text(encoding='utf-8'))
    protocol['queries']=[dict(id=r['id'],query=r['query']) for r in rows];p.write_text(json.dumps(protocol,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('UNIQUE',len(catalog),flush=True)

if __name__=='__main__':main()

"""Run and record an explicit zbMATH Open API novelty search.

Only public read-only endpoints are used; no credentials or personal email
are sent. Raw responses remain in tmp, while reproducible queries and
bibliographic metadata are saved in the audit directory.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
import hashlib
import json
import time
import urllib.parse
import urllib.request
import urllib.error

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RAW = ROOT.parents[2]/'tmp/pdfs/paperA-systematic-novelty-2026-10-26/zbmath'
BASE = 'https://api.zbmath.org/v1'

QUERIES = [
    ('Z01_control', 'ti:"finite field elements with specified order and traces"'),
    ('Z02_primitive_trace', 'ti:primitive & ti:trace'),
    ('Z03_primitive_norm_normal', 'ti:primitive & ti:normal & ti:norm'),
    ('Z04_norm_tori_trace', '(norm | torus | tori) & trace & cc:11T'),
    ('Z05_quartic', 'ti:quartic & (primitive | trace | norm)'),
    ('Z06_related_elements', 'ti:"related elements" & cc:11T'),
    ('Z07_prescribed_order', '(ti:order* | ti:primitive) & (ti:prescribed | ti:specified) & (trace | norm)'),
    ('Z08_unit_circle', '(primitive | order) & ("unit circle" | "norm-one" | "norm one") & (trace | quadratic)'),
    ('Z09_q_transform', '("Q-transform" | "Q-transforms" | "self-reciprocal") & (order | primitive) & cc:11T'),
    ('Z10_trace_subgroups', '(ti:trace | ti:traces) & (ti:subgroup* | ti:coset* | ti:order*) & cc:11T'),
    ('Z11_characters_curves', 'ti:character* & (ti:elliptic | ti:torus | ti:tori) & cc:(11T | 11L)'),
    ('Z12_complete_mapping_groups', 'ti:complete & ti:mapping* & (group* | affine)'),
    ('Z13_orthomorphism_groups', 'ti:orthomorphism* & (group* | affine | cyclic)'),
    ('Z14_projective_primitive', '("primitive normal" | "projective primitive") & (quartic | ovoid*)'),
    ('Z15_relative_trace', 'ti:"relative trace" & (primitive | order | norm)'),
    ('Z16_kloosterman_primitive', 'ti:Kloosterman & (primitive | subgroup* | norm)'),
    ('Z17_exception_numbers', '(65 | 1025) & (primitive | trace) & cc:11T'),
    ('Z18_gauss_period_orders', '(ti:"Gauss periods" | ti:"Gaussian periods") & (primitive | trace | order)'),
    ('Z19_index_bounds', '(primitive | orthomorphism*) & ("multiplicative subgroup" | "multiplicative subgroups") & cc:11T'),
    ('Z20_elliptic_filtered', '(primitive | "specified order" | "prescribed order") & ("elliptic curve" | "genus one") & cc:11T'),
]


def request(path, parameters, stem):
    url = BASE+path+'?'+urllib.parse.urlencode(parameters)
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={'User-Agent':'ScholarlyLiteratureAudit/1.0'})
            with urllib.request.urlopen(req, timeout=40) as response:
                data = response.read()
                final_url = response.geturl()
                status = response.status
            obj = json.loads(data)
            RAW.mkdir(parents=True, exist_ok=True)
            raw_path = RAW/(stem+'.json')
            raw_path.write_bytes(data)
            return obj, dict(url=url, final_url=final_url, http_status=status,
                             response_sha256=hashlib.sha256(data).hexdigest(),
                             raw_response=str(raw_path))
        except Exception as error:
            if isinstance(error, urllib.error.HTTPError) and error.code == 404:
                data = error.read()
                try:
                    obj = json.loads(data)
                except (ValueError, TypeError):
                    obj = None
                if (isinstance(obj, dict) and obj.get('status', {}).get('internal_code')
                        == 'successful access. No results found.'):
                    RAW.mkdir(parents=True, exist_ok=True)
                    raw_path = RAW/(stem+'.json')
                    raw_path.write_bytes(data)
                    return obj, dict(url=url, final_url=error.geturl(), http_status=404,
                                     interpretation='NO_RESULTS: explicit API status, not a generic HTTP 404',
                                     response_sha256=hashlib.sha256(data).hexdigest(),
                                     raw_response=str(raw_path))
            if attempt == 2:
                return None, dict(url=url, status='FAILED', error=type(error).__name__+': '+str(error))
            time.sleep(1+attempt)


def run_query(item):
    qid, query = item
    documents, pages = [], []
    page = 0
    total = None
    while True:
        result, record = request('/document/_search',
                                 {'search_string':query, 'results_per_page':100, 'page':page},
                                 qid+'_page_'+str(page))
        pages.append(record)
        if result is None:
            return dict(id=qid, query=query, status='FAILED', pages=pages,
                        retrieved=len(documents), results=documents)
        status = result.get('status', {})
        if status.get('internal_code') == 'successful access. No results found.':
            return dict(id=qid, query=query, status='NO_RESULTS', total=0,
                        retrieved=len(documents), pages=pages, results=documents)
        if isinstance(status,dict) and not status.get('execution_bool',False):
            return dict(id=qid,query=query,status='API_QUERY_ERROR',details=status,pages=pages,
                        retrieved=len(documents),results=documents)
        batch = result.get('result', [])
        total = status.get('nr_total_results',len(batch))
        documents.extend(batch)
        if len(documents) >= total or not batch:
            break
        if total > 600:
            return dict(id=qid,query=query,status='REFINEMENT_REQUIRED',total=total,
                        retrieved=len(documents),pages=pages,results=documents)
        page += 1
        time.sleep(0.25)
    return dict(id=qid,query=query,status='COMPLETE',total=total,
                retrieved=len(documents),pages=pages,results=documents)


def main():
    started = time.monotonic()
    protocol = dict(date='2026-10-26',timezone='Asia/Shanghai',database='zbMATH Open',
                    interface='Official public REST API v1',
                    documentation='https://api.zbmath.org/openapi.json',
                    scope='Whole current v7 manuscript, emphasizing E*-trace distribution and C9/C11 exceptional subgroup classification.',
                    language_restriction=None,publication_year_restriction=None,
                    note='A current-date database snapshot. Publication-year metadata is not the same as first-publication priority; future issue dates require separate checking.',
                    queries=[dict(id=qid,query=q) for qid,q in QUERIES])
    (HERE/'zbmath_protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    results = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs = {pool.submit(run_query,item):item[0] for item in QUERIES}
        for future in as_completed(jobs):
            row = future.result()
            results.append(row)
            print(row['id'],row['status'],'total',row.get('total'),'retrieved',row['retrieved'],flush=True)
            (HERE/'zbmath_queries_working.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    results.sort(key=lambda r:r['id'])
    catalog = {}
    for row in results:
        for doc in row['results']:
            key = str(doc['id'])
            if key not in catalog:
                catalog[key] = dict(document=doc,query_ids=[])
            catalog[key]['query_ids'].append(row['id'])
    (RAW/'deduplicated_full_records.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    compact = []
    for item in catalog.values():
        d=item['document']
        compact.append(dict(id=d['id'],identifier=d.get('identifier'),year=d.get('year'),
                            title=d.get('title',{}).get('title'),
                            authors='; '.join(x['name'] for x in d.get('contributors',{}).get('authors',[])),
                            doi='; '.join(x['identifier'] for x in d.get('links',[]) if x.get('type')=='doi'),
                            url=d.get('zbmath_url'),msc='; '.join(x['code'] for x in d.get('msc',[])),
                            queries='; '.join(item['query_ids'])))
    compact.sort(key=lambda r:(str(r.get('year')),str(r.get('title'))),reverse=True)
    with (HERE/'zbmath_screening_catalog.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(compact[0]) if compact else ['id'])
        writer.writeheader();writer.writerows(compact)
    log = [{k:v for k,v in r.items() if k!='results'} for r in results]
    output=dict(date='2026-10-26',database='zbMATH Open',queries=log,
                unique_records=len(catalog),elapsed_seconds=round(time.monotonic()-started,3))
    (HERE/'zbmath_search_log.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('FINISHED_UNIQUE',len(catalog),'SECONDS',output['elapsed_seconds'],flush=True)


if __name__=='__main__':
    main()

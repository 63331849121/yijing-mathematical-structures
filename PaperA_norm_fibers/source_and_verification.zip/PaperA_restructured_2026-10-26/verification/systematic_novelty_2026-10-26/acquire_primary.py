"""Retrieve public primary sources and preserve acquisition outcomes."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib, json, urllib.request
from pypdf import PdfReader

HERE=Path(__file__).resolve().parent
RAW=HERE.parents[3]/'tmp/pdfs/paperA-systematic-novelty-2026-10-26/primary'
SOURCES=[
 ('Ozbudak05','https://link.springer.com/content/pdf/10.1007/s10623-003-4193-0.pdf'),
 ('MKB26','https://arxiv.org/pdf/2510.14840v1'),
 ('Wan26','https://arxiv.org/pdf/2603.18511v2'),
 ('Hachenberger15','https://link.springer.com/content/pdf/10.1007/s10623-015-0051-0.pdf'),
 ('BCST19','https://www.ams.org/mcom/2019-88-316/S0025-5718-2018-03357-7/S0025-5718-2018-03357-7.pdf'),
 ('BorsWang22','https://arxiv.org/pdf/2109.03922'),
]

def fetch(item):
    name,url=item
    record=dict(id=name,url=url)
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'ScholarlyLiteratureAudit/1.0'})
        with urllib.request.urlopen(req,timeout=35) as response:
            data=response.read();record.update(http_status=response.status,final_url=response.geturl(),content_type=response.headers.get('Content-Type'))
        RAW.mkdir(parents=True,exist_ok=True)
        path=RAW/(name+'.pdf' if data.startswith(b'%PDF') else name+'.response')
        path.write_bytes(data)
        record.update(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
        if data.startswith(b'%PDF'):
            reader=PdfReader(path)
            txt='\n\n'.join('===== PAGE '+str(i+1)+' =====\n'+(p.extract_text() or '') for i,p in enumerate(reader.pages))
            text_path=RAW/(name+'.txt');text_path.write_text(txt,encoding='utf-8')
            record.update(status='PDF_ACQUIRED',pages=len(reader.pages),text_path=str(text_path),first_page=txt[:700])
        else: record['status']='NOT_A_PDF'
    except Exception as error: record.update(status='FAILED',error=type(error).__name__+': '+str(error))
    return record

def main():
    out=[]
    with ThreadPoolExecutor(max_workers=3) as pool:
        for future in as_completed([pool.submit(fetch,x) for x in SOURCES]):
            record=future.result();out.append(record);print(json.dumps(record,ensure_ascii=True),flush=True)
            (HERE/'primary_acquisition_log.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

if __name__=='__main__': main()

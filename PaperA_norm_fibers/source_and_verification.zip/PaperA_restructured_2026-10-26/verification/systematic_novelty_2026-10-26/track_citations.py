"""Read public citation metadata. Discovery only, not proof evidence."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,time,urllib.request,urllib.parse,urllib.error

HERE=Path(__file__).resolve().parent
RAW=HERE.parents[4]/'tmp/pdfs/paperA-systematic-novelty-2026-10-26/citations'
SEEDS=[('Cohen03','10.1023/A:1026295128600'),('Cohen05','10.1007/s10623-004-1724-2'),
 ('Ozbudak05','10.1007/s10623-003-4193-0'),('Rani23','10.1016/j.ffa.2023.102253'),
 ('CKR22','10.5802/crmath.328'),('Hachenberger21','10.1007/s10801-019-00920-8')]

def get(url,stem):
    record=dict(url=url)
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'ScholarlyLiteratureAudit/1.0'})
        with urllib.request.urlopen(req,timeout=30) as f:
            data=f.read();record.update(http_status=f.status,final_url=f.geturl())
        obj=json.loads(data);RAW.mkdir(parents=True,exist_ok=True)
        path=RAW/(stem+'.json');path.write_bytes(data)
        record.update(status='SUCCESS',raw_response=str(path));return obj,record
    except Exception as e:
        record.update(status='ACCESS_FAILED',error=type(e).__name__+': '+str(e));return None,record

def seed(item):
    key,doi=item;rec=dict(seed=key,doi=doi,pages=[])
    work,status=get('https://api.openalex.org/works/https://doi.org/'+doi,key+'_work')
    rec['lookup']=status
    if not work:return rec
    rec.update(openalex_id=work['id'],title=work.get('title'),reported_cited_by_count=work.get('cited_by_count'),
               locations=work.get('locations'),references=work.get('referenced_works'))
    works=[];cursor='*'
    while cursor:
        url='https://api.openalex.org/works?'+urllib.parse.urlencode({'filter':'cites:'+work['id'].split('/')[-1],'per-page':200,'cursor':cursor})
        page,st=get(url,key+'_citing_'+str(len(rec['pages'])))
        rec['pages'].append(st)
        if not page:break
        works.extend(page.get('results',[]));rec['reported_query_count']=page.get('meta',{}).get('count')
        cursor=page.get('meta',{}).get('next_cursor') if len(page.get('results',[]))==200 else None
    rec.update(retrieved_citing=len(works),citing_works=works)
    return rec

def main():
    records=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        for fut in as_completed([pool.submit(seed,x) for x in SEEDS]):
            r=fut.result();records.append(r)
            print(r['seed'],r['lookup']['status'],r.get('reported_query_count'),r.get('retrieved_citing'),flush=True)
            (HERE/'citation_tracking_working.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    compact=[]
    for r in records:
        for w in r.get('citing_works',[]):
            compact.append(dict(seed=r['seed'],id=w.get('id'),doi=w.get('doi'),title=w.get('title'),year=w.get('publication_year'),date=w.get('publication_date'),locations=w.get('locations')))
    (HERE/'citing_papers.json').write_text(json.dumps(compact,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':main()

"""Build public audit tables and package; preserve all manuscript sources/PDFs."""
from pathlib import Path
from collections import Counter
import csv,hashlib,json,re,shutil,zipfile
from pypdf import PdfReader

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORKSPACE=ROOT.parents[2]
ZRAW=WORKSPACE/'tmp/pdfs/paperA-systematic-novelty-2026-10-26/zbmath'
PRIMARY=WORKSPACE/'output/tmp/pdfs/paperA-systematic-novelty-2026-10-26/primary'
ZIP=ROOT.parent/'PaperA_restructured_editable.zip'
BACKUP=ROOT.parent/'PaperA_restructured_editable_v7_before_public_search.zip'
REPORT=HERE/'公开查新报告_2026-10-26.txt'

def read(path):return json.loads(path.read_text(encoding='utf-8'))
def write(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    snap=HERE/'before_public_search';snap.mkdir(exist_ok=True)
    for name in ['delivery_manifest.json','重构说明.txt']:
        saved=snap/(name+'.snapshot')
        if not saved.exists():shutil.copyfile(ROOT/name,saved)
    old=read(snap/'delivery_manifest.json.snapshot')
    expected={r['path']:r['sha256'] for r in old['files']}
    preserved=[]
    for rel,sha in expected.items():
        if rel.endswith('.tex') or rel in ('main.pdf','supplement.pdf','PaperA_贡献与重构审计.pdf'):
            path=ROOT/rel;actual=digest(path)
            if actual!=sha:raise RuntimeError('Unexpected manuscript change: '+rel)
            preserved.append(dict(path=rel,sha256=actual))
    preservation=dict(manuscript_tex_and_pdfs_unchanged=True,checked_files=len(preserved),files=preserved,
        compilation_this_audit=False,reason='No TeX or PDF modification; previous successful v7 compiler record remains associated with the unchanged hashes.')
    write(HERE/'manuscript_preservation.json',preservation)

    queries=read(HERE/'zbmath_queries_working.json')
    catalog=read(ZRAW/'deduplicated_full_records.json')
    controls=read(HERE/'seed_control_results.json')
    if len(queries)!=42 or any(r['status'] not in ('COMPLETE','NO_RESULTS') for r in queries):
        raise RuntimeError('Search pages incomplete')
    if any(r['status']!='COMPLETE' or r['retrieved']!=1 for r in controls):
        raise RuntimeError('Known-work DOI controls failed')
    control_summary=[{k:v for k,v in r.items() if k!='results'}|dict(document_ids=[d['id'] for d in r['results']]) for r in controls]
    write(HERE/'seed_control_summary.json',control_summary)
    seed_ids={r['id'].split('CONTROL_UNQUOTED_')[-1]:r['results'][0]['id'] for r in controls}
    validated=[]
    for q in queries:
        if '_rft_' not in q['id']:continue
        seed=q['id'].split('_rft_')[-1].replace('_unquoted','')
        target=seed_ids.get(seed);doi=next((x['query'].split('doi:',1)[-1] for x in controls if x['id'].endswith(seed)),None)
        for doc in q['results']:
            refs=doc.get('references',[])
            matched=[r for r in refs if (r.get('zbmath') or {}).get('document_id')==target or (r.get('doi') or '').lower()==(doi or '').lower()]
            validated.append(dict(query_id=q['id'],target_seed=seed,target_document_id=target,
                candidate_document_id=doc['id'],indexed_reference_match=bool(matched),matching_positions=[r.get('position') for r in matched],
                note='Only an exact indexed reference-ID/DOI match is retained as a confirmed edge; token-search hits alone are not citing papers.'))
    write(HERE/'reference_query_validation.json',validated)

    comparison=read(HERE/'claim_level_comparison.json')
    newer={str(r.get('zbmath_id')):r for r in comparison['new_primary_comparisons'] if r.get('zbmath_id')}
    gaps={str(r.get('zbmath_id')):r for r in comparison['remaining_fulltext_gaps'] if r.get('zbmath_id')}
    covered_dois={r.get('doi','').lower():r for r in comparison['new_primary_comparisons'] if r.get('doi')}
    old_rows=read(ROOT/'verification/literature_audit_2026-10-26/closest_literature_matrix.json')
    previous_dois={r['url'].removeprefix('https://doi.org/').lower():r for r in old_rows if r.get('url','').startswith('https://doi.org/')}
    previous_arxiv={re.sub(r'v\d+$','',r['url'].split('/abs/')[-1]):r for r in old_rows if '/abs/' in r.get('url','')}
    previous_arxiv['1409.6961']=dict(source='Tuxanidy–Wang',coverage='Earlier additional detailed audit; see v7 trace_slices.tex and proof_audit_51_54 records.')
    previous_arxiv['2304.08749']=dict(source='Earlier user-provided attachment audit',coverage='Earlier full-text condition audit; see cs23_attachment_2026-10-26 records.')
    previous_dois.update({x.lower():dict(source='Earlier additional detailed audit',coverage='See proof_audit_51_54 source_comparison.json and v7 trace_slices.tex') for x in ['10.1007/s10623-004-1724-2','10.1007/s10998-019-00296-z']})
    resolved={r['zbmath_id']:' '.join(r.get('title') or []) for r in read(HERE/'missing_title_resolution.json')}
    write(HERE/'missing_title_resolution_public.json',[{k:v for k,v in r.items() if k!='abstract'} for r in read(HERE/'missing_title_resolution.json')])
    decisions=[]
    for key,item in catalog.items():
        d=item['document'];title=resolved.get(key) or d.get('title',{}).get('title') or ''
        doi=next((x['identifier'] for x in d.get('links',[]) if x.get('type')=='doi'),'')
        arxiv=next((x['identifier'] for x in d.get('links',[]) if x.get('type')=='arxiv'),'')
        msc='; '.join(x['code'] for x in d.get('msc',[]))
        row=dict(zbmath_id=key,year=d.get('year'),title=title,doi=doi,arxiv=arxiv,
            authors='; '.join(x['name'] for x in d.get('contributors',{}).get('authors',[])),msc=msc,
            query_ids='; '.join(item['query_ids']),screening_basis='Title/MSC screening; missing licensed title resolved with Crossref where necessary.')
        if key in gaps:
            r=gaps[key];row.update(status='FULLTEXT_GAP_RETAINED',priority=r['priority'],coverage=r['coverage'],decision=r['status'])
        elif key in newer or doi.lower() in covered_dois:
            r=newer.get(key) or covered_dois[doi.lower()];row.update(status='NEW_SELECTED_SECTIONS_READ',priority='REVIEWED',coverage=r['coverage'],decision=r['status_51'])
        elif doi.lower() in previous_dois or re.sub(r'v\d+$','',arxiv) in previous_arxiv:
            r=previous_dois.get(doi.lower()) or previous_arxiv[re.sub(r'v\d+$','',arxiv)];row.update(status='PREVIOUS_DETAILED_AUDIT_RETAINED',priority='REVIEWED_EARLIER',coverage=r['coverage'],decision='Existing comparison retained; not counted as new full-text reading.')
        else:
            field_related=any(x.startswith(('11T','11L','12E','94A','94B')) for x in msc.split('; '))
            group_related=('complete mapping' in title.lower() or 'orthomorphism' in title.lower())
            if field_related or group_related:
                row.update(status='TITLE_SCREENED_RETAINED_FOR_TRIAGE',priority='SECONDARY',coverage='Title/MSC only unless separately recorded.',decision='Not selected for proof-level exclusion in this stage. No assertion that all its consequences have been ruled out.')
            else:
                row.update(status='TITLE_SCREENED_LOW_RELEVANCE',priority='LOW',coverage='Title/MSC only.',decision='No close object/theorem substitution identified from title/MSC; this is a relevance decision, not proof of mathematical non-implication.')
        decisions.append(row)
    decisions.sort(key=lambda r:(r['status'],str(r['year']),r['title']))
    with (HERE/'screening_decisions.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(decisions[0]));w.writeheader();w.writerows(decisions)

    inventory=[]
    sources={r['id']:r for r in comparison['new_primary_comparisons']}
    for r in comparison['new_primary_comparisons']:
        path=PRIMARY/r['pdf'];n=len(PdfReader(path).pages)
        inventory.append(dict(source_id=r['id'],source_url=r['url'],local_path=str(path),sha256=digest(path),pages=n,coverage=r['coverage'],public_package_contains_pdf=False))
    write(HERE/'primary_inventory.json',inventory)
    acquisitions=[{k:v for k,v in r.items() if k!='first_page'} for r in read(HERE/'primary_acquisition_log.json')]
    write(HERE/'primary_acquisition_summary.json',acquisitions)
    citing=read(HERE/'citing_papers.json');unique_citing={r['id']:r for r in citing}
    tracking=read(HERE/'citation_tracking_working.json')
    citation_summary=[]
    for seed in tracking:
        work_id=seed.get('openalex_id')
        matches=[work_id in w.get('referenced_works',[]) for w in seed.get('citing_works',[])]
        citation_summary.append(dict(seed=seed['seed'],doi=seed['doi'],openalex_id=work_id,
            reported_count=seed.get('reported_query_count'),retrieved=seed.get('retrieved_citing'),
            references_to_seed_present_in_metadata=sum(matches),lookup=seed['lookup'],pages=seed['pages']))
    write(HERE/'citation_tracking_summary.json',citation_summary)

    counts=Counter(r['status'] for r in queries)
    findings=dict(date='2026-10-26',status='PUBLIC_SEARCH_STAGE_COMPLETE_WITH_OPEN_FULLTEXT_GAPS',
        manuscript_revision='v7',manuscript_unchanged=True,global_priority_confirmed=False,
        databases=dict(zbMATH_Open=dict(interface='Official public REST API v1',query_count=len(queries),
          complete_queries=counts['COMPLETE'],explicit_zero_result_queries=counts['NO_RESULTS'],
          raw_hits=sum(r['retrieved'] for r in queries),unique_document_id_records=len(catalog),
          unique_real_world_papers_not_claimed=True,all_requested_pages_retrieved=True,
          title_msc_screening_completed=True,fulltext_screening_not_complete=True,known_doi_controls=len(controls)),
          MathSciNet=dict(actual_query_submitted=True,results_obtained=False,topic_search_completed=False,
            status='AUTHENTICATION_REQUIRED; user chose to continue public search',
            official_institution_entry='https://lib.scnu.edu.cn/search/waiwenshujuku/1970/0101/8288.html',
            institutional_email_not_recorded_or_transmitted=True)),
        citation_discovery=dict(seed_count=len(tracking),forward_edges=len(citing),unique_citing_records=len(unique_citing),
            backward_indexed_reference_edges=len(read(HERE/'backward_reference_edges.json')),
            completeness_not_claimed=True,rft_false_positives_checked=True),
        new_pdf_sources=len(inventory),new_pdf_pages=sum(r['pages'] for r in inventory),
        reading_scope='Only MKB26 and CK21 were read in full in this stage; other acquired PDFs have explicitly bounded selected-section coverage.',
        screening_dispositions=dict(Counter(r['status'] for r in decisions)),
        conclusions=dict(counting_object_is_prior=True,general_character_sum_method_is_prior=True,
            E_star_extension_is_short_phase_corollary=True,
            theorem_51='Candidate family-specific effective estimate; no new generic character-sum theorem claimed.',
            theorem_54='Strongest distinct novelty candidate; complete priority exclusion remains open.',
            CK21='Exact count predecessor identified; its displayed criterion t>(t-1)W(d) fails for all t>=4.'),
        fulltext_gap_ids=[r['id'] for r in comparison['remaining_fulltext_gaps']],
        report=REPORT.relative_to(ROOT).as_posix())
    write(HERE/'findings.json',findings)
    values={'QUERY_COUNT':len(queries),'RAW_HITS':sum(r['retrieved'] for r in queries),'UNIQUE_RECORDS':len(catalog),
            'COMPLETE_QUERIES':counts['COMPLETE'],'ZERO_QUERIES':counts['NO_RESULTS'],'NEW_PDF_PAGES':sum(r['pages'] for r in inventory)}
    content=REPORT.read_text(encoding='utf-8')
    for key,value in values.items():content=content.replace('{{'+key+'}}',str(value))
    if '{{' in content:raise RuntimeError('Report placeholder remains')
    REPORT.write_text(content,encoding='utf-8')

    desc=(ROOT/'重构说明.txt').read_text(encoding='utf-8')
    old_boundary='MathSciNet和zbMATH Open此前只访问过介绍/帮助入口，尚未完成针对本稿的实际数据库检索。\n本轮是数学推广、分类证明和算法核验，不构成扩大后结果的系统查新或全球首创认证。'
    new_boundary=('此前第七轮数学更新之后，已补做有记录的公开查新：zbMATH官方API执行'+str(len(queries))+'条检索式，按文献ID去重为'+str(len(catalog))+'条记录；另做6项有效DOI对照。\n'
      'OpenAlex对6篇关键文献作引文追踪，取得25条引证关系、22篇去重后续作品。上述数量不表示同等数量的全文阅读。\n'
      'MathSciNet已提交实际检索，但要求认证，未取得结果；仍不能标记为已完成检索。\n'
      '新确认CK21是相对迹计数的直接前驱，其显示判据代入后不能给出本稿结论。仍有5项不同优先级的原始全文/定理适用范围待核，全球优先权未确认。\n'
      '最新报告：verification/systematic_novelty_2026-10-26/公开查新报告_2026-10-26.txt。\n'
      '本次只更新查新材料和交付元数据，当前TeX源文件及32页main.pdf保持不变。')
    if old_boundary in desc:desc=desc.replace(old_boundary,new_boundary)
    (ROOT/'重构说明.txt').write_text(desc,encoding='utf-8')

    raw_excluded={'zbmath_queries_working.json','citation_tracking_working.json','seed_control_results.json',
        'query_syntax_controls.json','primary_acquisition_log.json','missing_title_resolution.json'}
    paths=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and not (p.parent==HERE and p.name in raw_excluded) and p!=ROOT/'delivery_manifest.json']
    # A private institutional email must never enter the public evidence/package.
    for path in paths:
        if path.parent==HERE and path.suffix in ('.json','.csv','.txt','.py'):
            if re.search(rb'\d{10}@m\.scnu\.edu\.cn',path.read_bytes()):raise RuntimeError('Private institutional identifier found')
    manifest={k:v for k,v in old.items() if k!='files'}
    manifest.update(revision='v7-public-literature-search',main_manuscript_revision='v7',
        database_actual_topic_search_completed={'MathSciNet':False,'zbMATH_Open':True},
        global_priority_confirmed=False,public_search_report=findings['report'],
        public_search_stage_complete=True,proof_level_literature_exclusion_complete=False,
        manuscript_pdf_unchanged=True,manifest_rule='Lists every archive payload file except this manifest itself; raw working responses and external PDFs are excluded.')
    manifest['files']=[dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(paths)]
    write(ROOT/'delivery_manifest.json',manifest)
    if not BACKUP.exists():shutil.copyfile(ZIP,BACKUP)
    with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for path in paths+[ROOT/'delivery_manifest.json']:
            z.write(path,ROOT.name+'/'+path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(ZIP) as z:
        if z.testzip() is not None:raise RuntimeError('Archive CRC error')
        for row in manifest['files']:
            if hashlib.sha256(z.read(ROOT.name+'/'+row['path'])).hexdigest()!=row['sha256']:
                raise RuntimeError('Archive/manifest mismatch: '+row['path'])
        entry_count=len(z.infolist())
    delivery=dict(status='PASS',archive=str(ZIP),sha256=digest(ZIP),entries=entry_count,
       previous_v7_backup=str(BACKUP),previous_v7_backup_sha256=digest(BACKUP),main_pdf_sha256=digest(ROOT/'main.pdf'),
       tex_and_pdfs_unchanged=True,archive_crc_and_manifest_verified=True,findings=findings)
    write(ROOT.parent/'PaperA_public_search_delivery.json',delivery)
    print(json.dumps(dict(status='PASS',queries=len(queries),records=len(catalog),raw_hits=values['RAW_HITS'],
        pdf_sources=len(inventory),pdf_pages=values['NEW_PDF_PAGES'],screening=findings['screening_dispositions'],
        main_pdf_unchanged=True,archive_entries=entry_count,archive_sha256=delivery['sha256']),ensure_ascii=True),flush=True)

if __name__=='__main__':main()

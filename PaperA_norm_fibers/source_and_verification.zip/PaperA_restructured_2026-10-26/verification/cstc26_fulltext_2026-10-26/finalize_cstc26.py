"""Finalize the original-fulltext comparison and preserve the v8 delivery."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ZIP = ROOT.parent/'PaperA_restructured_editable.zip'
BACKUP = ROOT.parent/'PaperA_restructured_editable_v8_before_cstc26.zip'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    previous = read(HERE/'before_cstc26/delivery_manifest.json.snapshot')
    compile_info = read(HERE/'compilation.json')
    visual = read(HERE/'visual_review.json')
    if compile_info['issues'] or not compile_info['aux_stable']:
        raise RuntimeError('Compilation not clean and stable')
    if digest(ROOT/'main.pdf') != compile_info['pdf_sha256']:
        raise RuntimeError('PDF changed after compilation verification')
    if visual['status'] != 'PASS' or visual['pdf_sha256'] != digest(ROOT/'main.pdf'):
        raise RuntimeError('Current PDF visual review incomplete')

    # Reuse only the PDF-link inspection utility; never rerun the older finalizer.
    spec = importlib.util.spec_from_file_location('previous_pdf_inspection',
               ROOT/'verification/fulltext_structure_2026-10-26/finalize_structure.py')
    utility = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(utility)
    write(HERE/'pdf_links.json', utility.check_links())
    old_findings = read(ROOT/'verification/fulltext_structure_2026-10-26/findings.json')
    gaps = [x for x in old_findings['remaining_fulltext_gaps'] if x['id'] != 'CSTC26']
    exact = read(HERE/'independent_specialization_checks.json')
    preservation = read(HERE/'preservation_checks.json')
    facts = {
        'date': '2026-10-26', 'revision': 'v9-cstc26-fulltext',
        'CSTC26_fulltext_gap_closed': True,
        'source': read(HERE/'source_inventory.json'),
        'all_17_pages_read': True,
        'count_framework_directly_contains_M_c_after_summation': True,
        'legal_specialization': {'q': 't^2', 'm': 2, 'F_c': 'X/(X+c)',
            'n1': 1, 'n2': 1, 'N': 5, 'r1': 't-1', 'r2': 't^2-1',
            'R1': 'd', 'R2': 'B', 'f1': 1, 'f2': 1, 'k1': 0, 'k2': 0,
            'first_additive_polynomial': 1, 'second_additive_polynomial': '(X-1)^2',
            'identity': 'M_c=sum_{ord(w)=A} C_{F_c,c,cw}(d,B,1,(X-1)^2)',
            'inverse_trace_not_ignored': True, 'auxiliary_elements_unique': True},
        'criterion_3_9_specialized': 't^(-2)>10*(t-1)^2*(t+1)*W(d)*W(B)',
        'all_legal_sieve_cores_fail': True,
        'general_obstruction': 'For m<=4 the left side q^(m/2-k1-k2-2)<=1; the general and sieve right sides are >=N>=2',
        'later_analytic_hypotheses': 'Lemma 3.5 and Theorem 4.3 both require m>2*(k1+k2+2)',
        'numerical_section': 'm>=7; r1=r2=2; special Corollary 4.2 uses q=11^j and only possible exceptions',
        'theorem_51': 'No direct displayed-theorem implication of the family-specific four-point estimate or its effective bound',
        'theorem_54': 'No direct displayed-theorem implication of the complete C9/C11 exception classification',
        'all_possible_future_refinements_excluded': False,
        'global_priority_confirmed': False,
        'remaining_fulltext_gaps': gaps,
        'database_actual_topic_search_completed': {'MathSciNet': False, 'zbMATH_Open': True},
        'database_scope': 'Prior public database audit retained; this stage is original-PDF scrutiny plus two additional public discovery queries, not a new database audit',
        'external_AI_request': 'Resolved directly by the original PDF; no external AI answer was used',
        'independent_verification': {
            'norm_kernel_elements_enumerated': sum(x['norm_kernel_elements_enumerated'] for x in exact['fields']),
            'full_order_elements_with_rational_function_checked': sum(x['full_order_elements_and_rational_checks'] for x in exact['fields']),
            'nonzero_relative_trace_populations_checked': sum(x['nonzero_trace_populations_checked'] for x in exact['fields']),
            'empty_nonzero_traces_checked': sum(x['zero_nonzero_trace_slices'] for x in exact['fields']),
            'finite_checks_do_not_replace_general_proof': True},
        'preservation': preservation,
        'mathematical_result_revision': 'v8; unchanged by this bibliography/comparison update',
        'main_pages': compile_info['pages'],
        'new_mathematical_theorems_claimed_this_stage': False,
        'report': 'verification/cstc26_fulltext_2026-10-26/CSTC26_全文条件与定理51_54归属核查.txt',
        'external_messages_or_GitHub_push_performed': False}
    write(HERE/'findings.json', facts)
    write(HERE/'public_search_followup.json', {
        'queries': ['"Elements of prescribed order, prescribed traces and systems" pdf Ozbudak',
                    '"Primitive normal bases for quartic and cubic extensions" filetype:pdf Hachenberger'],
        'new_original_fulltexts_obtained_for_remaining_two_papers': False,
        'official_author_page': 'https://www.uni-a.de/de/fakultaet/mntf/math/prof/opt/team/hachenberger/publikationen/',
        'institutional_record': 'https://open.metu.edu.tr/handle/11511/40865',
        'direct_open_status': 'Both direct open requests timed out; indexed snippets and earlier metadata are not original-PDF reading',
        'absence_or_nonexistence_not_inferred': True})

    desc = f'''PaperA 第九轮：CSTC26 原始全文归属核查
2026年10月26日

当前主稿 main.pdf：{compile_info['pages']}页；继续在原 main.tex 项目中原位维护，桌面编译及稳定本地编译通过。
本轮补充文献归属和有效条件比对；5.1、5.4、5.5、5.6、5.7的陈述、编号和证明保持不变。
100个原标签的重构后编号保留；原46条陈述与证明所在核心源码保持不变。补充稿及历史审计PDF保留。

CSTC26全文已补齐
A. Choudhary, J. Sharma, S. K. Tiwari, K. Chatterjee (2026)，DOI 10.1007/s40314-026-03761-x，17页全部阅读。
用合法函数F_c(X)=X/(X+c)，在基域E、扩张次数二上，将M_c精确写为其指定迹与逆元迹计数之和。
该计数框架是前驱；不能将同一计数问题本身作为原创点。
其定理3.1、推论3.2和任何合法筛核心在扩张次数m<=4时均无法满足条件：左端<=1，右端>=2。
渐近细化另需m>2(k1+k2+2)；数值段m>=7。其显示结果不直接给出本文的四点有效界或完整异常相对迹分类。
这不等于排除所有可能的方法改进，也不等于全球首创认证。

验证
新独立程序在s=2..6穷举305169个范数核元素，在204768个满阶元素上实际计算合法有理函数并核对阶与迹。
全部5451个非零相对迹计数及20个空切片的精确求和关系均通过；t=8、32、64的一般判据及筛界用精确分数核对。
通参数排除是数学不等式证明，有限核验不替代证明。当前PDF已逐页渲染检查，新增比较页及文献页另作核查。

最新报告
verification/cstc26_fulltext_2026-10-26/CSTC26_全文条件与定理51_54归属核查.txt
上一轮结构提升结果及其验证继续有效；旧报告中的CSTC26全文缺口记录现为历史状态。
先前准备请其他AI代读本篇的任务已由原始全文解决。

当前优先清单剩余原始全文缺口
Özbudak05：10.1007/s10623-003-4193-0
Hachenberger15：10.1007/s10623-015-0051-0
MathSciNet仍未取得主题检索结果；既有zbMATH公开数据库检索记录保留，不重复计数。

可编辑包仍为PaperA_restructured_editable.zip，上一版备份为PaperA_restructured_editable_v8_before_cstc26.zip。
未推送GitHub，未联系其他作者，未作完整Lean形式化；本轮没有新增数学主定理或新的期刊档次保证。
'''
    (ROOT/'重构说明.txt').write_text(desc, encoding='utf-8')
    permitted = {'main/trace_slices.tex', 'main/introduction.tex', 'main/bibliography.tex',
                 'main/reproducibility.tex', 'main.pdf', 'main.aux', 'main.log', 'main.out', '重构说明.txt'}
    changed = []
    for x in previous['files']:
        p = ROOT/x['path']
        if not p.is_file():
            raise RuntimeError('Previous payload lost: '+x['path'])
        if digest(p) != x['sha256']:
            if x['path'] not in permitted:
                raise RuntimeError('Unexpected previous-file change: '+x['path'])
            changed.append(x['path'])
    write(HERE/'previous_payload_preservation.json', {
        'status': 'PASS', 'previous_payload_files_retained': len(previous['files']),
        'intentional_changes': changed, 'unexpected_changes': []})

    excluded = {
        ROOT/'verification/systematic_novelty_2026-10-26': {
            'zbmath_queries_working.json', 'citation_tracking_working.json', 'seed_control_results.json',
            'query_syntax_controls.json', 'primary_acquisition_log.json', 'missing_title_resolution.json'},
        ROOT/'verification/fulltext_structure_2026-10-26': {
            'user_provided_inventory.json', 'public_fulltext_discovery.json'}}
    paths = [p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
             and p != ROOT/'delivery_manifest.json' and p.name not in excluded.get(p.parent, set())]
    for p in paths:
        if p.parent == HERE and p.suffix in ['.txt', '.py', '.json']:
            if re.search(rb'\d{10}@m\.scnu\.edu\.cn', p.read_bytes()):
                raise RuntimeError('Private institutional identifier found')
    manifest = {k: v for k, v in previous.items() if k != 'files'}
    manifest.update(revision='v9-cstc26-fulltext', main_manuscript_revision='v9',
                    mathematical_result_revision='v8', CSTC26_fulltext_gap_closed=True,
                    fulltext_gaps_closed_this_stage=['CSTC26'],
                    remaining_fulltext_gap_ids=[x['id'] for x in gaps],
                    current_report=facts['report'], global_priority_confirmed=False,
                    main_pdf_pages=compile_info['pages'], manuscript_pdf_unchanged=False,
                    previous_reports_are_historical=True, proof_level_literature_exclusion_complete=False)
    manifest['files'] = [{'path': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size,
                          'sha256': digest(p)} for p in sorted(paths)]
    write(ROOT/'delivery_manifest.json', manifest)
    if not BACKUP.is_file():
        raise RuntimeError('No prior archive backup')
    with zipfile.ZipFile(BACKUP) as z:
        old_names = set(z.namelist())
    with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=7) as z:
        for p in paths+[ROOT/'delivery_manifest.json']:
            z.write(p, ROOT.name+'/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(ZIP) as z:
        if z.testzip() is not None:
            raise RuntimeError('Archive CRC failure')
        if old_names-set(z.namelist()):
            raise RuntimeError('An older archive entry was lost')
        for row in manifest['files']:
            if hashlib.sha256(z.read(ROOT.name+'/'+row['path'])).hexdigest() != row['sha256']:
                raise RuntimeError('Archive manifest mismatch: '+row['path'])
        entries = len(z.infolist())
    out = {'status': 'PASS', 'revision': manifest['revision'], 'archive': str(ZIP),
           'archive_sha256': digest(ZIP), 'entries': entries,
           'previous_archive': str(BACKUP), 'previous_archive_sha256': digest(BACKUP),
           'all_previous_archive_entries_retained': True, 'crc_and_manifest_verified': True,
           'main_pdf_pages': compile_info['pages'], 'main_pdf_sha256': digest(ROOT/'main.pdf'),
           'remaining_fulltext_gap_ids': [x['id'] for x in gaps], 'global_priority_confirmed': False}
    write(ROOT.parent/'PaperA_cstc26_delivery.json', out)
    print(json.dumps(out, ensure_ascii=True))


if __name__ == '__main__':
    main()

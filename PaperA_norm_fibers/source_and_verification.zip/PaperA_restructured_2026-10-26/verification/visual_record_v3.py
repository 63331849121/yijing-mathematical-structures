from pathlib import Path
import hashlib,json,shutil
from pypdf import PdfReader
import pdfplumber
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image,ImageDraw

BASE=Path(r'C:\Users\master\Documents\Codex\mywebsite')
ROOT=BASE/'output/pdf/PaperA_restructured_2026-10-26'
QA=BASE/'tmp/pdfs/paperA-literature-2026-10-26/rendered'
V=ROOT/'verification'
path=ROOT/'PaperA_贡献与重构审计.pdf'
layout=json.loads((V/'pdf_layout_checks.json').read_text(encoding='utf-8'))
pages=[]
with pdfplumber.open(path) as doc:
    for i,page in enumerate(doc.pages):
        txt=page.extract_text() or ''
        outside=[c for c in page.chars if c['x0']<34 or c['x1']>page.width-34 or c['top']<20 or c['bottom']>page.height-20]
        assert not outside and '\ufffd' not in txt
        pages.append(dict(page=i+1,characters=len(txt),has_replacement_character=False,outside_safe_page_count=0,outside_text=''))
        (QA/f'audit-{i+1:02d}.txt').write_text(txt,encoding='utf-8')
layout['audit']=dict(pages=len(pages),page_checks=pages)
for name,filename in [('main','main.pdf'),('supplement','supplement.pdf'),('audit',path.name)]:
    layout[name]['pdf_sha256']=hashlib.sha256((ROOT/filename).read_bytes()).hexdigest()
(V/'pdf_layout_checks.json').write_text(json.dumps(layout,indent=2),encoding='utf-8')
font=TTFont('ReportBodyGlyphAudit','C:/Windows/Fonts/simsun.ttc',subfontIndex=0)
text=''.join(p.extract_text() or '' for p in PdfReader(path).pages)
missing=sorted({ord(c) for c in text if ord(c)>32 and ord(c) not in font.face.charToGlyph})
assert not missing
visual=dict(revision='v3',rendered_pages=sum(v['pages'] for v in layout.values()),
    contact_sheets_inspected=['main 1-27','supplement 1-31','audit 1-11'],
    full_page_inspection=['supplement 24','audit 6,10,11'],
    formal_source_printed_pages_visually_inspected=[87,89,94,97,103,107,112],
    report_body_font_missing_codepoints=missing,clipped_or_outside_safe_page_chars=0,
    layout_pdf_hashes={k:v['pdf_sha256'] for k,v in layout.items()})
(V/'pdf_visual_review.json').write_text(json.dumps(visual,indent=2),encoding='utf-8')
tw,th=320,449;count=len(pages)
sheet=Image.new('RGB',(3*tw,((count+2)//3)*th),'#dbe4e8');draw=ImageDraw.Draw(sheet)
for j in range(count):
    im=Image.open(QA/f'audit-{j+1:02d}.png');im.thumbnail((tw-12,th-28));x=j%3*tw+(tw-im.width)//2;y=j//3*th+24
    sheet.paste(im,(x,y));draw.text((j%3*tw+12,j//3*th+7),f'audit / {j+1}',fill='black')
sheet.save(QA/'audit-contact-1.png')
shutil.copy2(Path(__file__),V/'visual_record_v3.py')
print('Final V3 layout and glyph coverage: PASS; '+str(visual['rendered_pages'])+' pages.')

"""Exhaustively compare the projective trace-zero population and trace-one slice.

Uses exact binary-field arithmetic and the archived manuscript certificates.
No numerical approximation or third-party algebra package is required.
"""
from pathlib import Path
from collections import Counter
import importlib.util, math, json, hashlib

ROOT=Path(__file__).resolve().parents[3]
VERIFY=ROOT/'verification/independent_exact_audit.py'
spec=importlib.util.spec_from_file_location('field_arithmetic',VERIFY)
F=importlib.util.module_from_spec(spec);spec.loader.exec_module(F)

def phi(n):
    for p in F.factors(n):n=n//p*(p-1)
    return n

pn={2:96,3:1512,4:30720,5:465000,6:6531840}
expected_H={2:16,3:36,4:256,5:500,6:2880}
expected_delta={2:8,3:0,4:16,5:0,6:24}
results=[]
for row in F.TABLE.splitlines()[:5]:
    ss,ff,bb,ee=row.split();s=int(ss);n=2*s;t=1<<s;A=t+1;B=t*t+1;d=A*B
    f=int(ff,16);b=int(bb,16);w=F.power(b,int(ee),f,n);c=1^b^w
    assert F.irreducible(f,n) and F.trace(F.mul(b,F.power(c,((1<<n)-2)*2,f,n),f,n),n,f)==1
    generator=(0,1)
    assert F.epow(generator,d,b,c,f,n)==(1,0)
    assert all(F.epow(generator,d//p,b,c,f,n)!=(1,0) for p in F.factors(d))
    vals=[];indices={};x=(1,0)
    for j in range(d):
        key=x[0]|(x[1]<<n);assert key not in indices
        vals.append(key);indices[key]=j
        x=(F.mul(b,x[1],f,n),x[0]^F.mul(c,x[1],f,n))
    assert x==(1,0)
    oval=Counter();M=Counter();normal=0;D=0;example=None
    trace_to_base={}
    for j,a in enumerate(vals):
        rel=a^vals[j*t*t%d]
        assert rel<(1<<n)
        if rel not in trace_to_base:trace_to_base[rel]=F.power(rel,t,f,n)^rel
        absolute=trace_to_base[rel]
        if absolute==0:oval[j%A]+=1
        primitive=math.gcd(j,d)==1
        if not primitive:continue
        k=indices.get(a^1)
        D+=k is not None and math.gcd(k,d)==1
        if absolute!=0:
            normal+=1
            continue
        assert rel!=0
        M[rel]+=1
        rho=F.power(rel,(-4)%(t-1),f,n)
        assert (rho==1)==(rel==1)
        if s==3 and rel!=1 and example is None:
            cinv=F.power(rel,(1<<n)-2,f,n)
            xa=(a&((1<<n)-1),a>>n)
            normalized=F.emul(xa,(cinv,0),b,c,f,n)
            assert F.epow(normalized,t*t,b,c,f,n)==(normalized[0]^1,normalized[1])
            norm=F.epow(normalized,d,b,c,f,n)
            assert norm==(rho,0) and norm!=(1,0)
            example=dict(s=s,base_modulus_hex=hex(f),quadratic_b_hex=hex(b),quadratic_c_hex=hex(c),
                generator_exponent=j,unique_norm_one_rep=[hex(v) for v in xa],relative_trace_hex=hex(rel),
                trace_one_normalized_rep=[hex(v) for v in normalized],normalized_absolute_norm_hex=hex(rho))
    assert oval[0]==1 and all(oval[j]==t+1 for j in range(1,A))
    total=sum(M.values())
    assert total==phi(d)-pn[s]//phi(t-1)==expected_H[s]
    assert normal*phi(t-1)==pn[s]
    assert M[1]==expected_delta[s]
    assert total<=t*phi(A)
    if F.prime(B):assert total==t*phi(A)
    population={hex(k):v for k,v in sorted(M.items())}
    result=dict(s=s,t=t,phi_A=phi(A),phi_B=phi(B),primitive_projective_points=phi(d),
        primitive_trace_zero_points=total,trace_one_slice=M[1],full_double_order_pairs=D,
        total_oval_points_per_nontrivial_ovoid=t+1,source_table_PN4=pn[s],
        primitive_trace_zero_distribution_by_relative_trace_hex=population,
        affine_normalization_counterexample=example)
    results.append(result)
    print(json.dumps({k:v for k,v in result.items() if 'distribution' not in k},ensure_ascii=True),flush=True)

out=dict(status='PASS',source_table='Hachenberger, J. Algebraic Combinatorics 53 (2021), Table 1 p.89',
         identity='sum_{c in K*} M_c = phi(d) - PN4(t)/phi(t-1); M_1 = Delta_t',
         conclusion='The same oval incidence holds at s=3,5 while M_1=0 and D_d>0. The aggregated projective population does not imply positivity of this fixed affine slice.',
         source_math_module_sha256=hashlib.sha256(VERIFY.read_bytes()).hexdigest(),results=results)
target=Path(__file__).with_name('projective_bridge_checks.json')
target.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print('ALL_PROJECTIVE_BRIDGE_CHECKS_PASS',flush=True)

from fractions import Fraction
import json

def factors(n):
    a=[];p=3
    while p*p<=n:
        if n%p==0:
            a.append(p)
            while n%p==0:n//=p
        p+=2
    if n>1:a.append(n)
    return a

sanity=[]
for s in range(2,13):
    t=2**s;r=t-1;d=(t+1)*(t*t+1);pr=factors(d);Wd=2**len(pr)
    theta=Fraction(1)
    for p in pr:theta*=Fraction(p-1,p)
    old=theta**2*Fraction(t**4,r*r);new=theta**2*(t+1)**2
    assert old-new==theta**2*Fraction(2*t*t-1,r*r)
    assert Fraction((r*Wd)**3,r*Wd-1)>t*t
    assert r*r*Wd*Wd>t*t
    legal=0
    for mask in range(1<<len(pr)):
        missing=[p for i,p in enumerate(pr) if not(mask>>i&1)]
        delta=1-2*sum((Fraction(1,p) for p in missing),Fraction(0))
        if delta<=0:continue
        Delta=Fraction(2*len(missing)-1,1)/delta+2
        Wl=2**mask.bit_count()
        assert Delta*r*r*Wl*Wl>t*t
        legal+=1
    sanity.append(dict(s=s,t=t,omega_d=len(pr),SSL_sieve_legal_splits_checked=legal,all_conditions_fail=True))

proofs = [
 dict(identity='16(t-1)^2-t^2 at t=4+x',coefficients_ascending=[128,88,15],conclusion='positive for all real x>=0'),
 dict(identity='3(t-1)^2-t^2 at t=4+x',coefficients_ascending=[11,10,2],conclusion='positive for all real x>=0'),
 dict(identity='4[2(t-1)^2-t^2/4] at t=4+x',coefficients_ascending=[56,40,7],conclusion='positive for all real x>=0'),
]
assert all(c>0 for row in proofs for c in row['coefficients_ascending'])
checks=dict(universal_argument='W(d)>=4 follows from coprime A,B>1. In SSL Thm5 h=0 gives >=16r^2; h>=1 gives >=3r^2. CSh Thms1,3 RHS>=2r^2 and Thm4 RHS>=4r^2; any q0>=2 gives LHS<=t^2/4.',
            polynomial_proofs=proofs, finite_sanity_checks=sanity,
            center_identity='SSL_center-main_center = theta(d)^2(2t^2-1)/(t-1)^2',
            coh_identity='AB=t^3+t^2+t+1=(t^4-1)/(t-1); phi(A)phi(B)/(t^4-1)=theta(d)/(t-1)',
            distinction='These are independent checks of substitutions and inequalities, not a proof of originality or a repeat of the full mathematical audit.')

print(json.dumps(checks,indent=2))

from pathlib import Path
from fractions import Fraction
from itertools import combinations
from xml.sax.saxutils import escape
import csv, json, re, hashlib

from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT

BASE = Path(r'C:\Users\master\Documents\Codex\mywebsite')
_portable_root = Path(__file__).resolve().parents[2]
ROOT = _portable_root if (_portable_root/'main.tex').is_file() else BASE/'output/pdf/PaperA_restructured_2026-10-26'
AUD = ROOT / 'verification/literature_audit_2026-10-26'
AUD.mkdir(parents=True, exist_ok=True)

sources = [
 dict(id='Coh03', source='Cohen (2003)', location='Theorems 1.2, 1.5; Section 4',
      url='https://doi.org/10.1023/A:1026295128600',
      read_url='https://www.researchgate.net/publication/227048253_The_Orders_of_Related_Elements_of_a_Finite_Field',
      coverage='Author-uploaded full text; relevant statements and construction checked.',
      mapping='Delta_t = N_(t^4)(B,A); Theorem 1.5 at base t^2 instead requires reciprocal-trace order t^2-1.',
      finding='The same reciprocal-trace statistic and fractional linear construction are prior. The ambient estimate has center theta(d)/(t-1) and error < 2 theta(d) W(d) t^2.',
      increment='The manuscript estimates this same statistic after norm descent, with center theta(d)(t+1) and error theta(d)(4W(d)-2)sqrt(t).',
      limit='No priority claim for the statistic or the substitution; not a survey of all later refinements.'),
 dict(id='CKR22', source='Cohen-Kapetanakis-Reis (2022)', location='Theorem 16; Corollary 17',
      url='https://doi.org/10.5802/crmath.328',
      read_url='https://comptes-rendus.academie-sciences.fr/mathematique/item/10.5802/crmath.328.pdf',
      coverage='Full primary PDF downloaded and relevant pages checked.',
      mapping='Ambient field t^4; polynomials X and X+1; subgroup indices r=r=t-1; freeness parameters d,d.',
      finding='The sufficient inequality t^2 > (t-1)^2 W(d)^2 fails for all t>=4.',
      increment='The manuscript uses the specified norm geometry rather than this ambient-field sufficient bound.',
      limit='Freeness and character indicators are classical; a failed criterion does not exclude all refinements.'),
 dict(id='SSL24', source='Sharma-Sarma-Laishram (2024)', location='Proposition 3.1; Theorems 1, 5',
      url='https://doi.org/10.1007/s00574-024-00412-9',
      read_url='https://www.researchgate.net/publication/382946193_Arithmetic_Progressions_of_r-Primitive_Elements_in_a_Field',
      coverage='Author-uploaded full text; basic estimate and stronger prime sieve checked.',
      mapping='D_d = N_(t-1)(t^4,1,2).',
      finding='Its center differs from theta(d)^2(t+1)^2 by theta(d)^2(2t^2-1)/(t-1)^2. The basic condition and every legal split of the displayed Theorem 5 sieve fail numerically here.',
      increment='Uniform error control, the fiber-dependent coefficients and all-parameter closure; not a new leading density.',
      limit='The length-two sieve inequality was tested even if its preceding section restrictions are imposed; no assertion about every conceivable refinement.'),
 dict(id='CSh26', source='Choudhary-Sharma (2026; online 2025)', location='Definition 3.1; Theorems 1-5',
      url='https://doi.org/10.1080/00927872.2025.2561951',
      read_url='https://www.researchgate.net/publication/396016739_Arithmetic_progressions_of_some_special_elements_in_finite_fields',
      coverage='Author-uploaded full text checked; formal volume 54(4), pages 1502-1518 verified.',
      mapping='q=t,n=4,m=2,gamma=1,r_i=t-1,a_i=1; Q_Ri=d; N_(1,1)(d)=D_d.',
      finding='Theorems 1,3,4 fail for every legal sieve split. Even changing the base q0 with q0^n=t^4 leaves LHS<=t^2/4, below RHS>=2(t-1)^2. The r=3 application leaves (2,8) among its possible exceptions.',
      increment='An effective estimate in this growing-index quartic norm family.',
      limit='No claim of a new norm-constrained exact-order object; retain citation key CSh25 for source compatibility.'),
 dict(id='Ha21', source='Hachenberger (2021; online 2019)', location='Complete formal PDF; Sections 3.1,4.1,5.2.1,6.1,7.1,9,10',
      url='https://doi.org/10.1007/s10801-019-00920-8',
      read_url='https://link.springer.com/content/pdf/10.1007/s10801-019-00920-8.pdf',
      coverage='Complete 30-page formal publisher PDF obtained and checked; all ten sections and relevant proofs read; key pages visually verified.',
      mapping='Characteristic two: L*=K* x C_d; projective primitivity corresponds to order d for the unique norm-one representative.',
      finding='The norm-one projective model and ovoid incidence are prior. Primitive-normal bounds control the aggregate sum_c M_c, not the fixed affine slice M_1=Delta_t.',
      increment='The extra level rho([x])=N(x)/(x+x^(t^2))^4=1 fixes the norm-one trace-one slice. At t=8,32 the aggregate is positive (36,500) while M_1=0; the full D_d is 24,240.',
      limit='The earlier full-text-access gap is closed for this source. Its stated results and relevant proofs do not supply the fixed-slice distribution. This is not a proof of global originality.'),
 dict(id='KN26', source='Kudo-Nogata (2026)', location='Propositions 3.6, 4.3',
      url='https://arxiv.org/abs/2604.25461',
      read_url='https://arxiv.org/pdf/2604.25461',
      coverage='Full primary PDF v1 downloaded; relevant quadratic and quartic formulas checked.',
      mapping='Base t, extension 4, cyclotomic index t-1 and cosets (0,0) give T_d. Base t^2, extension 2 gives the quadratic norm root count.',
      finding='Ordinary membership and the elementary quadratic parametrization have direct predecessors.',
      increment='Joint generation and simultaneous exact orders require additional arithmetic filters and estimates.',
      limit='The cited unfiltered formula alone does not establish the filtered theorems; not a claim that no further derivation is possible.'),
 dict(id='AN22', source='Aguirre-Neumann (2022 preprint)', location='Theorem 3.2',
      url='https://arxiv.org/abs/2210.11504', read_url='https://arxiv.org/pdf/2210.11504',
      coverage='Full primary PDF downloaded; sufficient inequality checked.',
      mapping='F=X+1, M=2, r_i=t-1, R_i=d, trivial additive factors in the most favorable numerical specialization.',
      finding='Even the relaxed sufficient inequality t^2 >= 2(t-1)^2 W(d)^2 fails.',
      increment='The norm-specific estimate reaches parameters outside this numerical sufficient range.',
      limit='This is a favorable numerical comparison, not an assertion that all additional normality hypotheses hold for the manuscript count.'),
 dict(id='ALNR23', source='Aguirre-Lemos-Neumann-Ribas (2023 preprint v2)', location='Theorem 3.3',
      url='https://arxiv.org/abs/2211.02114', read_url='https://arxiv.org/pdf/2211.02114',
      coverage='Full primary PDF v2 downloaded; sufficient inequality checked.',
      mapping='Length m=2; r_i=t-1; R_i=d; most favorable k=0 and trivial additive factor.',
      finding='Its favorable numerical bound again requires t^2 >= 2(t-1)^2 W(d)^2.',
      increment='The growing-index norm family requires finer cancellation.',
      limit='Normality and the exact-order-only statistic are distinct. Bibliography cites the verified preprint version.'),
 dict(id='CSST24', source='Chatterjee-Sharma-Shukla-Tiwari (2024 preprint v3)', location='Theorem 4.1 and definitions',
      url='https://arxiv.org/abs/2401.01819', read_url='https://arxiv.org/pdf/2401.01819',
      coverage='Full primary PDF downloaded; definitions and principal sufficient condition checked.',
      mapping='Norms and arithmetic progressions are close context, but its elements are ambient primitive and its main condition has n>2m.',
      finding='At natural base t, n=4,m=2 is outside that dimension assumption; ambient primitive order also differs from d.',
      increment='Background context rather than a direct theorem for D_d.',
      limit='Changing the base does not remove the order mismatch; do not use this as the strongest predecessor.'),
 dict(id='FFSTV13', source='Farashahi-Fouque-Shparlinski-Tibouchi-Voloch (2013)', location='Section 4, Lemma 1',
      url='https://doi.org/10.1090/S0025-5718-2012-02606-8',
      read_url='https://www.normalesup.org/~tibouchi/papers/welldistributed.pdf',
      coverage='Full author PDF downloaded; curve-character estimate checked.',
      mapping='Genus one and active tame conductor degree <=8 yield <=8 sqrt(t) once geometric nontriviality is established.',
      finding='The curve character bound is classical.',
      increment='The manuscript verifies descent, inertia, constant exceptions and conductor for its specific covers.',
      limit='Applying this lemma is not a new general character-sum theorem.'),
 dict(id='Katz89', source='Katz (1989)', location='Pages 198-199: Lang-cover character interpretation',
      url='https://web.math.princeton.edu/~nmk/old/estcharsums.pdf',
      read_url='https://web.math.princeton.edu/~nmk/old/estcharsums.pdf',
      coverage='Full author PDF downloaded; Lang interpretation checked.',
      mapping='Characters of rational points of a norm torus are realized by the descended Lang pullback.',
      finding='The general construction is prior.',
      increment='The manuscript makes the relevant Frobenius trace and geometric independence explicit.',
      limit='A geometric Kummer equation alone is not enough to identify a rational-point character trace.'),
 dict(id='Shin26', source='Shin (2026 preprint v1)', location='Main Theorem 2; Proposition 5.6; Theorems 5.7-5.8',
      url='https://arxiv.org/abs/2605.21939', read_url='https://arxiv.org/pdf/2605.21939',
      coverage='Full 79-page PDF downloaded; main subgroup-coset theorem and smooth proof in Section 5 checked. Not a full audit of the entire paper.',
      mapping='Finite etale cubic norm tori, characteristic different from 2,3; smooth trace/norm fibers; subgroup cosets.',
      finding='Uniform square-root trace equidistribution, Lang sheaves and geometric Kummer analysis are prior.',
      increment='The manuscript treats binary quartic relative traces, with four boundary points and a complete exact-order exception classification.',
      limit='The stated cubic theorem excludes this characteristic; this is not a new general sheaf method or a global priority certificate.'),
 dict(id='Rani23', source='Rani-Sharma-Tiwari-Panigrahi (2023)', location='Publisher abstract and accessible section previews only',
      url='https://doi.org/10.1016/j.ffa.2023.102253', read_url='https://www.sciencedirect.com/science/article/abs/pii/S1071579723000953',
      coverage='Abstract and section previews accessed. Full finer sufficient conditions and proofs have not been audited.',
      mapping='r-primitive k-normal elements with prescribed norm and absolute trace; our nonzero relative-trace elements are 1-normal.',
      finding='The stated eventual range fixes r,k and assumes n>=4k+5; here r=t-1 varies and n=4,k=1.',
      increment='The present theorem specifies all relative traces in a binary quartic norm-one family and all empty slices.',
      limit='No assertion that every finer criterion in this source has been excluded; abstract-level context only.'),
]
with (AUD / 'closest_literature_matrix.csv').open('w', newline='', encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(sources[0]));w.writeheader();w.writerows(sources)
(AUD / 'closest_literature_matrix.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')

# Independent rational arithmetic for the parameter substitutions. The
# polynomial identities below, with nonnegative coefficients at t=4+x,
# establish the universal inequalities. Small finite runs are sanity checks.
def factors(n):
    a=[];p=3
    while p*p<=n:
        if n%p==0:
            a.append(p)
            while n%p==0:n//=p
        p+=2
    if n>1:a.append(n)
    return a

sanity=[]
for s in range(2,13):
    t=2**s;r=t-1;d=(t+1)*(t*t+1);pr=factors(d);Wd=2**len(pr)
    theta=Fraction(1)
    for p in pr:theta*=Fraction(p-1,p)
    old=theta**2*Fraction(t**4,r*r);new=theta**2*(t+1)**2
    assert old-new==theta**2*Fraction(2*t*t-1,r*r)
    assert Fraction((r*Wd)**3,r*Wd-1)>t*t
    assert r*r*Wd*Wd>t*t
    legal=0
    for mask in range(1<<len(pr)):
        missing=[p for i,p in enumerate(pr) if not(mask>>i&1)]
        delta=1-2*sum((Fraction(1,p) for p in missing),Fraction(0))
        if delta<=0:continue
        Delta=Fraction(2*len(missing)-1,1)/delta+2
        Wl=2**mask.bit_count()
        assert Delta*r*r*Wl*Wl>t*t
        legal+=1
    sanity.append(dict(s=s,t=t,omega_d=len(pr),SSL_sieve_legal_splits_checked=legal,all_conditions_fail=True))

proofs = [
 dict(identity='16(t-1)^2-t^2 at t=4+x',coefficients_ascending=[128,88,15],conclusion='positive for all real x>=0'),
 dict(identity='3(t-1)^2-t^2 at t=4+x',coefficients_ascending=[11,10,2],conclusion='positive for all real x>=0'),
 dict(identity='4[2(t-1)^2-t^2/4] at t=4+x',coefficients_ascending=[56,40,7],conclusion='positive for all real x>=0'),
]
assert all(c>0 for row in proofs for c in row['coefficients_ascending'])
checks=dict(universal_argument='W(d)>=4 follows from coprime A,B>1. In SSL Thm5 h=0 gives >=16r^2; h>=1 gives >=3r^2. CSh Thms1,3 RHS>=2r^2 and Thm4 RHS>=4r^2; any q0>=2 gives LHS<=t^2/4.',
            polynomial_proofs=proofs, finite_sanity_checks=sanity,
            center_identity='SSL_center-main_center = theta(d)^2(2t^2-1)/(t-1)^2',
            coh_identity='AB=t^3+t^2+t+1=(t^4-1)/(t-1); phi(A)phi(B)/(t^4-1)=theta(d)/(t-1)',
            distinction='These are independent checks of substitutions and inequalities, not a proof of originality or a repeat of the full mathematical audit.')
(AUD / 'parameter_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
own_source=Path(__file__).read_text(encoding='utf-8')
numeric_start=own_source.index('def factors(n):')
numeric_end=own_source.index("(AUD / 'parameter_checks.json').write_text")
numeric_source='from fractions import Fraction\nimport json\n\n'+own_source[numeric_start:numeric_end]+'\nprint(json.dumps(checks,indent=2))\n'
(AUD / 'parameter_checks.py').write_text(numeric_source,encoding='utf-8')
# The archived complete source below is the authoritative reproducible report
# generator; the short numeric verifier above is also preserved in it.

# Report authoring
pdfmetrics.registerFont(TTFont('Song',r'C:\Windows\Fonts\simsun.ttc',subfontIndex=0))
pdfmetrics.registerFont(TTFont('Hei',r'C:\Windows\Fonts\simhei.ttf'))
pdfmetrics.registerFontFamily('Song',normal='Song',bold='Hei',italic='Song',boldItalic='Hei')
navy=colors.HexColor('#12394B');teal=colors.HexColor('#087E8B');ink=colors.HexColor('#243746')
muted=colors.HexColor('#657886');pale=colors.HexColor('#EDF5F6');line=colors.HexColor('#CFDFE4')
S={
 'title':ParagraphStyle('title',fontName='Hei',fontSize=27,leading=37,textColor=navy,spaceAfter=20),
 'h1':ParagraphStyle('h1',fontName='Hei',fontSize=19,leading=28,textColor=navy,spaceAfter=15),
 'h2':ParagraphStyle('h2',fontName='Hei',fontSize=12.5,leading=19,textColor=teal,spaceBefore=12,spaceAfter=7),
 'body':ParagraphStyle('body',fontName='Song',fontSize=10.7,leading=18,textColor=ink,spaceAfter=9,wordWrap='CJK'),
 'small':ParagraphStyle('small',fontName='Song',fontSize=9,leading=14,textColor=muted,spaceAfter=7,wordWrap='CJK'),
 'table':ParagraphStyle('table',fontName='Song',fontSize=9.6,leading=15,textColor=ink,wordWrap='CJK'),
 'th':ParagraphStyle('th',fontName='Hei',fontSize=9.6,leading=15,textColor=colors.white,wordWrap='CJK'),
 'formula':ParagraphStyle('formula',fontName='Helvetica',fontSize=10,leading=16,textColor=navy,spaceAfter=9),
}
story=[]
def supported_text(text):
    return text.replace('⁴','<super>4</super>')
def p(text,style='body'):story.append(Paragraph(supported_text(text),S[style]))
def heading(n,title):
    if story:story.append(PageBreak())
    p(f'{n:02d}  /  {title}','h1')
def h(text):p(text,'h2')
def math(*lines):
    t=Table([[Paragraph(escape(x),S['formula'])] for x in lines],colWidths=[479])
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),pale),('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),1)]))
    story.extend([t,Spacer(1,11)])
def table(headers,rows,widths):
    data=[[Paragraph(escape(x),S['th']) for x in headers]]
    data += [[Paragraph(supported_text(x),S['table']) for x in row] for row in rows]
    t=Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),navy),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,pale]),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,0),0.5,navy),('LINEBELOW',(0,-1),(-1,-1),0.5,line)]))
    story.extend([t,Spacer(1,11)])
def link(key,label=None):
    src=next(x for x in sources if x['id']==key)
    return f'<link href="{escape(src["url"], {chr(34): "&quot;"})}" color="#087E8B">[{key}] {escape(label or src["source"])}</link>'

p('论文贡献与重构审计','title')
p('PaperA · 第四轮数学提升与完整例外分类','h2')
p('核查日期：2026年10月26日','small')
p('基准：52页原稿及前三轮重构与文献审计。本轮在稿内加入统一非零相对迹定理、有效素数筛和完整空切片分类；本报告区分稿内证明、外部优先权、有限证书与叙述质量。')
h('核心判断')
p('<b>最值得保留并加强的主线，是特定四次扩域范数族的有效分布理论。</b>主线现在从好范数纤维上的密度，进一步延伸到全部非零相对迹的统一分布，以及所有空切片的完整分类。两个小参数空例有了不同的代数解释。')
p('本轮核查同时收紧两项表述：相邻双满阶计数已有直接前驱；倒数迹的指定阶计数在 Cohen 2003 中也已出现。不能将统计对象、分式线性代换或领先密度本身作为主要新颖性依据。')
h('如何评价理论层级')
p('目前证据支持“明确参数族上的定量推进，结合结构公式与完整存在性论证”的定位。它有形成高质量专业论文的基础；尚不足以据此宣称建立了一套普适新理论。真正的理论价值取决于误差改进是否实质、几何验证是否完整、结论是否超出已知定理的直接推论，以及方法能否解释或推广更多现象。')
h('本轮交付')
p('修订主稿与补充稿；新增4个编号结论及证明；24项有限素数筛比较；8个迹1多项式计数；覆盖全部小参数非例外切片的1010个满阶元素证书；13项分层文献对照。前三轮版本已保留。')
p('<b>判断边界：</b>这是有明确覆盖范围的文献与论证审计，不是新颖性的最终证明。Hachenberger 的30页正式全文已取得并核查，原访问缺口已关闭；新增统一相对迹定理及完整分类已写入稿内并核查证明链；全球优先权仍未获得外部确认，Lean 全工程未重新构建。','small')

heading(2,'贡献主张：哪些成立，哪些要收紧')
table(['主张','本轮判断','论文应如何表述'],[
 ['定义了新的相邻指定阶问题','不成立为主要创新。SSL24 与 CSh26 的计数直接包含 D_d。','引用直接前驱；把贡献放在误差、局部纤维信息与全参数结论。'],
 ['得到双满阶领先密度','领先项已有渐近等价的前驱中心。','展示两个中心仅差 O(1)，随后比较误差能否小于主项。'],
 ['倒数迹代换或计数是新的','代换及同一指定阶计数均有 Cohen 2003 前驱。','突出同一统计量在额外范数几何下的更精细估计。'],
 ['8 sqrt(t) 混合特征和','稿内给出针对这些纤维的几何验证。通用曲线界属于经典工具。','说明下降、几何非平凡性与导子控制分别完成什么工作。'],
 ['共同生成与双满阶有不同密度','属于本稿有意义的统计区分。','清楚区分 theta_2(d) 与 theta(d)^2，以及各自应用。'],
 ['对全部 s>=2 存在','稿内论证结合无限范围估计与有限证书。','以完整迹切片分类收束；完整双满阶族仅在 s=3,5 另用有限域证书。'],
 ['所有非零相对迹的统一估计','新增稿内证明；4点导子界不依赖 c。','定义 M_c，给出精确未筛中心和统一误差。'],
 ['全部空切片的完整分类','仅 (s,c)=(3,1),(5,1)；其余参数均正。','无限范围由估计和筛法；小范围由1010个满阶证书。'],
 ['1/4 边界已经完全解决','表述过强；尚有对数间隙。','称为统一指数最优，明确充分范围与逐指数分类仍有差距。'],
], [122,176,181])
p('“稿内已证明”与“文献中首次”是两条不同证据链。保留完整证明不能自动确立优先权；某篇文章的充分条件失效也不能自动确立优先权。','small')

heading(3,'最直接前驱：相邻双满阶统计')
p(link('SSL24'))
p('令 r=t-1，d=(t+1)(t²+1)，W(d)=2^omega(d)。SSL24 的 Proposition 3.1 取域大小 t⁴、公差 1、长度 2，计数恰为本稿 D_d。')
math('D_d = N_(t-1)(t^4, 1, 2)',
     'M_SSL = theta(d)^2 t^4 / (t-1)^2',
     'M_paper = theta(d)^2 (t+1)^2',
     'M_SSL - M_paper = theta(d)^2 (2t^2-1)/(t-1)^2 = O(1)')
p('因此，不能把 theta(d)² 这一领先密度写成与已有工作不同的新发现。两种中心相容；实际增量必须由更小且有效的误差、纤维分布信息与存在性范围承担。')
h('基本条件为什么不够')
p('Theorem 1 的正性条件代入后要求 t² 不小于 (rW(d))³/(rW(d)-1)。A=t+1 与 B=t²+1 互素且均大于 1，故 W(d)≥4；右侧大于 16r²，而 t≥4 时 16r²>t²。')
h('更强的素数筛也已检查')
p('对 Theorem 5 展示的筛条件，即使允许长度 2，它仍要求 t²≥Delta·r²W(l)²。若没有遗漏素数，则 W(l)=W(d)≥4；若遗漏至少一个素数且 delta>0，则 Delta≥3。两类分别给出右侧至少 16r² 或 3r²，均超过 t²。')
p('这个比较检查的是该文展示的所有合法素数分拆；没有把结果扩大成“既有方法不可能改进”。已用独立有理数运算复核中心恒等式，并对 s=2..12 枚举合法分拆作一致性检查。普遍结论来自上述代数不等式。','small')

heading(4,'第二个关键前驱：倒数迹指定阶')
p(link('Coh03'))
p('Cohen 的 N_Q(u,v) 计数 ord(gamma)=u、ord(gamma+gamma^(-1))=v 的元素。本稿 Delta_t 恰好对应 Q=t⁴、u=B、v=A，因为精确阶已自动强制落入所需的两个范数一群。')
math('Delta_t = N_(t^4)(B,A)',
     'Cohen: |Delta_t - theta(d)/(t-1)|',
     '        < 2 theta(d) W(d) t^2',
     'Paper: |Delta_t - theta(d)(t+1)|',
     '        <= theta(d)(4W(d)-2) sqrt(t)')
p('这里出现不同中心没有矛盾：Cohen 的通用误差足够大，掩盖了本参数族的子域集中现象。本稿更有价值的解释，是同一计数在额外范数关系下集中于约 t 个点，并可在基域尺度取得平方根误差。')
h('为何不能直接调用其存在性定理')
p('Cohen Theorem 1.5 以 t² 为基域参数时，给出 gamma 阶 t²+1，但倒数迹阶为 t²-1；本稿需要更小的阶 t+1。二者的范数条件不同。Section 4 的代换 a=(1+gamma)^(-1) 及 Frobenius 联系仍应明确归于经典前驱。')
h('叙述上的调整')
p('修订引言加入了“Delta_t 是既有统计量”的精确对应，并将主张改为范数下降后的有效估计。这样，读者看到的是一个可量化的改进，而不必先接受“提出了新对象”的泛化说法。')
p('本页两组误差必须结合各自假设理解；比较不构成对 Cohen 全文所有推论或后续文献的穷尽排除。','small')

heading(5,'规定范数的进展与其他充分条件')
p(link('CSh26'))
p('其 Definition 3.1 在 q=t、n=4、m=2、公差 1、r_i=t-1、规定范数均为 1 时，计数也是 D_d。正式卷页现为 Communications in Algebra 54(4) (2026), 1502-1518；两份稿件已更新。')
table(['已核条件','代入或统一下界','结果'],[
 ['Theorem 1','自然基域下左侧为 1；右侧为 2r²W(d)²。','不能给出正性。'],
 ['Theorem 3 素数筛','所有合法分拆的右侧至少为 2r²。','仍不能覆盖。'],
 ['Theorem 4 改良筛','正分母至多 1，分子至少 2；完整右侧至少 4r²。','仍不能覆盖。'],
 ['改换基域 q0','若 q0^n=t⁴，则左侧 t²/q0²≤t²/4<2r²。','不能靠此改变上述比较。'],
 ['Theorem 5 的 r=3 应用','只可能关联 s=2；基域选择 (2,8) 位于其可能例外表中。','仍无现成覆盖。'],
], [116,258,105])
h('并行核查的其他框架')
p(link('CKR22')+' 的 Corollary 17 要求 t²>r²W(d)²；'+link('AN22')+' 与 '+link('ALNR23')+' 的相关充分式，即便采用最有利的平凡加法因子，仍要求 t²≥2r²W(d)²。这些数值条件均失效。')
p(link('CSST24')+' 的主结果包含 ambient primitive 与 normal 条件；它不是 D_d 的同义定理。自然基域下的 n>2m 假设也在 n=4,m=2 时不满足，故不应把它当成最强的直接对手。')
p('以上结论只针对列出的定理和条件；尤其 AN22 的有利数值比较不声称其全部额外正规性条件已经满足。','small')

heading(6,'几何前驱：全文核查后的结论')
p(link('Ha21'))
p('本轮已从出版社取得30页正式全文，并阅读全部10节及相关证明。特征2下的范数一代表、原始 ovoid 与迹零椭圆截面确实是直接前驱，不能仅以射影语言和范数语言不同区分对象。')
h('哪些结果直接重合')
p('Section 3.1、Proposition 4.1、Remark 4.2 与 Proposition 7.1 分别给出范数一代表、ovoid 分解、全局原始点数与迹零截面。相应原文位于正式页94、97、107；重合内容已在主稿和补充稿明确归属。')
h('精确差别：固定一个额外仿射切片')
p('对迹零原始点 [x]，相对迹 c=x+x^(t²) 属于 K 的非零元素。比值 rho([x])=N(x)/c^4 不随射影代表缩放而改变。把代表除以 c 后，相对迹成为1，范数恰为 rho；因此本稿特殊子族对应额外条件 rho=1。')
p('Ha21 的原始正规元界控制所有 c 的合计，未给出固定 c=1 的分布。独立穷举验证：t=8、32 时，迹零原始点总数分别为36、500，但迹1子族均为空，而完整双满阶族仍分别有24、240个元素。')
p('<b>本项结论：</b>“未取得完整正式全文、无法核对其相关定理与证明”的指定缺口已关闭。该文列示结果不能作为本稿固定切片估计及全参数结论的现成替代；这仍不等于已经证明全球文献中的首创性。后附覆盖表和对应恒等式给出完整对照。')
h('普通交集与经典工具')
p(link('KN26')+' 的 Proposition 4.3 直接涉及未筛阶的 T_d，Proposition 3.6 涉及二次范数根计数。修订稿将二次参数化明确作为辅助化简，不再让它承担主要创新。')
p(link('FFSTV13')+' 与 '+link('Katz89')+' 提供经典曲线特征界和 Lang 构造。本稿真正需要检查的是特定下降、几何非平凡性、常值例外和有效导子；证明这些假设的工作不应被一句“由标准界”省略。')

heading(7,'为何这样重构：科学问题决定文章顺序')
table(['层面','原52页稿的阅读成本','本次重构后的变化'],[
 ['中心问题','坐标、分类、群论和数论交错；核心定量结果不易迅速定位。','以 linked subgroup elements 的分布为开端；仿射群提供精确应用。'],
 ['主证明链','一个大章节承载多个尺度和多个统计量。','结构归约 → 范数纤维 → 混合特征和 → 密度 → 全参数存在性。'],
 ['贡献陈述','读者需要自行分辨经典构造与实质增量。','明确对应最近文献；用误差、系数和适用参数说明增量。'],
 ['经典工具','容易与新结果在叙述上混在一起。','为二次根计数、Lang 构造、特征界和代换逐项归属。'],
 ['不同统计量','成员资格、共同生成、单满阶、双满阶、特殊子族容易混淆。','分开定义；保留小参数计数表，解释不同密度与例外。'],
 ['次级结果','全部内容争夺正文注意力。','完整证明放入补充稿；坐标、spread、非线性应用仍可追溯。'],
 ['复现与编辑说明','来源存档和工作流描述容易进入论文主叙述。','正文只留数据与验证范围；详细文件、版本和审计放入交付包。'],
], [69,204,206])
h('从叙述重构推进到可检验的数学增量')
p('46条原有带标签的定理类陈述及对应证明继续逐项保留；另两条原无编号辅助引理保留并编号。本轮新增统一相对迹定理、经典Kloosterman恒等式的自包含证明、经典素数筛在本曲线上的应用，以及完整非零迹空切片分类。后两项经典工具的编号不应被计算为独立原创方法。')

heading(8,'高价值、高品质的评价标准与下一步')
table(['维度','可检验的高水平标准','当前状态与动作'],[
 ['问题价值','有自然来源，答案改变我们对某类结构或分布的认识。','范数族与群实现有清楚联系；引言已把两者接上。'],
 ['实质新颖性','精确说明最接近定理为何不能直接推出本结果。','列明文献分层比较；Rani23限摘要节选；全局优先权仍需领域审读。'],
 ['技术深度','识别真实障碍，并解释方法为何绕过它。','突出固定范数常值例外、几何单值性与导子验证。'],
 ['正确与完整','所有假设、坏纤维、有限例外都进入证明。','原46条陈述与证明保留；新增曲线证明和无限范围论证；有限范围另有证书。'],
 ['定量强度','误差有效且足以支撑明确结论。','统一控制每个非零迹；解析正性范围由 s>=33 推进到 s>=10，再完整封闭有限范围。'],
 ['解释与推广','解释现象，说明参数限制来自哪里。','非零迹推广完成；两个空例获得代数解释；更高塔仍是研究任务。'],
 ['叙述组织','问题、结果、困难、方法按因果关系推进。','主稿聚焦一条证明链；补充稿保存独立支线。'],
 ['可核查性','读者能复查计算、来源、版本和证明依赖。','新增24项精确有理数筛比较、1010个逐项满阶证书和两项空例的Bezout恒等式。'],
 ['边界与克制','明确未解决之处，贡献强度与证据一致。','保留对数间隙、逐范数纤维例外、外部优先权和形式化边界。'],
], [69,204,206])
p('<b>下一步最高优先级：</b>对新增四点Lang覆盖证明和完整例外分类进行领域专家独立审读，并继续检查最接近的指定范数、相对迹与精确阶文献。稿内结果已经更强，但进入投稿前还要回答其在文献中的实质新颖程度。更高塔与对数边界属于下一轮研究问题。')
p('投稿定位应在上述归属问题关闭后，结合目标期刊近年论文的深度、篇幅与范围确定；本轮不依据形式重构承诺 SCI 分区或录用。','small')

heading(9,'来源、交付与验证边界')
p('下列标识与交付包中的 closest_literature_matrix.csv 一一对应。链接优先指向 DOI 或作者预印本；实际读取途径与细分覆盖范围另列于矩阵。','small')
for src in sources:
    p(link(src['id'])+' | '+escape(src['location']), 'small')
h('验证记录')
p('新增核验包括全部非零迹的独立小域计数、Kloosterman恒等式、24项有理数素数筛比较、8个迹1计数和1010个直接满阶证书。此前Ha21正式全文、射影合计及31组原有限域证书等记录继续保留。原定理与证明保留、引用、稳定编译和页面渲染按本轮稿件重新检查。')
p('原始输入固定于公开仓库版本 d33c51696f81492de67b8df2166d0c887666176c，仓库论文 PDF 与附件52页版本逐字节相同。本轮依用户授权在本地新增数学陈述与证明，并完整记录验证边界；作者姓名保留，没有向GitHub推送。')
p('未完成的部分：外部领域专家的独立全证明复审；更广的后续文献优先权核查；Lean全工程重新构建；更高塔推广。新增Rani23仅核查摘要和可访问节选，未声称排除其全部细化条件。Ha21完整全文的本项核查已完成。有限数值检查不能替代这些工作。')


heading(10,'Ha21 全文覆盖与排除直接覆盖的依据')
p('正式版本：Journal of Algebraic Combinatorics 53 (2021), 85-114，出版社PDF共30页。核查日期：2026年10月26日。文中的 F、K、E 分别对应本稿 K、E、L，且 q=t。','small')
table(['原文项目与页码','内容及本稿关系'],[
 ['Theorems 1.1-1.3、Remark 1.4；pp.86-91；Section 10，pp.113-114','正规原始元的总量、特殊素数情形及比例。换算后约束所有非零相对迹切片之和，未固定迹1。'],
 ['Remark 2.1、Proposition 2.2；pp.93-94','截面与分拆的几何计数；既未筛定椭圆内的精确阶，也未控制仿射归一化。'],
 ['Section 3.1、Lemma 3.1、Proposition 3.2；pp.94,96-97','乘法群直积分解、迹排除与不共线性。范数一代表及射影原始性确为已有。'],
 ['Proposition 4.1、Remark 4.2、Section 4.4；pp.97,99-100','原始 ovoid 含 phi(B) 个原始点是全 ovoid 计数，不是固定截面的阶分布。'],
 ['Remarks 5.1,5.2；Sections 5.2.1,6.1；pp.101-104','识别非正规平面，并得到各原始椭圆至多 t 个原始点；合计给出上界，未给出 M_1 的正下界。'],
 ['Proposition 7.1 及证明；p.107','非平凡 ovoid 与迹零平面交于 t+1 点。这个环境截面完全重合，仍需固定 rho=1。'],
 ['奇特征相关结果；<br/>pp.95-96,98-99,104-111','已核对适用范围；其奇特征假设不适用于 t=2^s，不能直接调用。'],
], [179,300])
p('结论限定为该文正式列示结果及相关证明的直接覆盖检查。附加的比值 rho 与切片恒等式是本次对照推导，不将它们冒充原文命题，也不作为新增原创主定理。','small')

heading(11,'把几何总量与本稿切片精确对齐')
p('在迹零原始点 [x] 上，c=Tr_(L/E)(x) 属于 K*，否则 x 落入二次子域而不可能原始。用 x/c 归一化相对迹时，范数随之变为以下射影不变量：')
math('rho([x]) = N_(L/K)(x) / Tr_(L/E)(x)^4',
     'rho([lambda x]) = rho([x])    (lambda in K*)',
     'rho([x]) = 1  <=>  normalized representative has norm 1')
p('令 M_c 计数满阶范数一代表 a 满足 a+a^(t²)=c。每个原始射影点含 phi(t-1) 个环境域原始元，特征2下正规点恰在迹零平面之外，因此：')
math('sum_(c in K*) M_c = phi(d) - PN_4(t)/phi(t-1)',
     'M_1 = Delta_t',
     'Ha21: sum_c M_c <= t phi(t+1)',
     'Equality holds in the last line when t^2+1 is prime.')
table(['s','t','迹零原始点合计','迹1子族 Delta_t','完整双满阶 D_d'],[
 ['2','4','16','8','8'],['3','8','36','0','24'],['4','16','256','16','208'],['5','32','500','0','240'],['6','64','2880','24','1992'],
], [35,45,143,143,113])
p('本次使用精确二元域运算独立遍历 s=2..6 的整个范数一群，核对上述恒等式、原文Table 1中的正规原始元数、各非平凡ovoid的t+1个迹零点，以及固定切片计数。另保存一个t=8的具体例子：归一化相对迹为1后范数从1变为非1，验证归一化不能自动保持范数。')
p('t=8和32说明：原始ovoid的非空迹零截面，不能单独保证固定迹1子族非空。它们不否定完整 D_d 的全参数存在性；恰恰说明有限参数需要完整族证书。所有穷举仅支持这些有限事实，普遍区别由上面的缩放恒等式给出。','small')


heading(12,'本轮新增：统一分布与完整例外分类')
p('设 t=2^s，K=F_t，L=F_(t^4)，d=(t+1)(t²+1)。M_c 是范数一群中阶恰为 d 且 a+a^(t²)=c 的元素数。原稿只估计迹1；现在 c 取遍 K 的非零元素。')
h('统一曲线，而非逐个迹重复估计')
math('a = c/(1+gamma),   w = (gamma+gamma^(-1))/c^2',
     '(x+1)^2 (y+1)^2 = c^4 x y',
     '|M_c - theta(d) Q_c| <= 4 theta(d)(W(d)-1) sqrt(t)',
     '|M_c - theta(d)(t+1)| <= theta(d)(4W(d)-2) sqrt(t)')
p('对所有非零 c，曲线光滑、几何连通且亏格1；四个边界点形成Frobenius四循环，没有基域点。实际Lang覆盖的边界赋值不随c改变，每个非平凡特征对均有总导子4。这是统一误差的证明依据。未筛中心 Q_c=t+1+Kl_t(c^(-4)) 另以经典二元Kloosterman恒等式表达。')
h('完整结论')
math('M_c = 0  <=>  (s,c) = (3,1) or (5,1),   s>=2, c!=0',
     'Delta_t = M_1 > 0  <=>  s not in {3,5}')
p('原来的“s>=33保证迹1为正，发现s=3,5为空”，现在变为“所有非零迹统一估计，全部空切片只有两个”。素数筛覆盖s>=10；其余小域使用逐切片满阶证书。这提高的是范围、解释力和证明闭合程度。')
p('<b>归属边界：</b>倒数迹代换、Lang方法、曲线界、Kloosterman恒等式及素数筛都属于经典工具。新增编号不等于新增原创方法。Shin26已有三次范数环面迹等分布；本稿的特征2四次曲线和完整阶例外分类仍需单独比较优先权。','small')

heading(13,'有限证书如何支撑完整分类')
table(['s','非零迹切片数','最小 M_c','空切片'],[
 ['2','3','4','无'],['3','7','0','c=1'],['4','15','12','无'],['5','31','0','c=1'],
 ['6','63','24','无'],['7','127','40','无'],['8','255','228','无'],['9','511','200','无'],
], [35,144,130,170])
p('以上1012个切片中，1010个非空切片各有一个明确元素，逐项检查 a+a^(t²)=c、a^d=1、每个素因子p对应 a^(d/p)≠1，并核对所用扩域不可约性。计数通过倒数迹递推取得；s<=6另与全范数一群直接枚举相符。正性由具体元素保证，不只依赖正的统计输出。')
h('两个空例的原因不同')
p('<b>s=3：</b>倒数迹无法具有所需的阶9；相应多项式gcd为1。<b>s=5：</b>倒数迹阶33的20个候选参数全部只有阶205，而需要阶1025，缺少额外因子5。两例都有明确Bezout恒等式核验；未筛迹1切片仍分别有4和44个元素。')
h('哪些是无限证明，哪些是有限核验')
p('s>=33使用原有整数界和新统一曲线估计；s=8及10..32用24个精确有理数筛比较；2..9用上述逐切片证书。三个层次覆盖全部参数。完整双满阶存在性只需在s=3,5使用完整族证书，其余参数由迹1子族给出。')
p('本轮新增两条定理、两条引理，原46条带标签陈述与证明继续保留；原迹1专门证明移入补充稿，正文使用更一般的统一定理。有限证书已执行；几何推导在稿内完整呈现，但不等于已获得外部专家确认或Lean全形式化。','small')


def decorate(c,doc):
    w,h=doc.pagesize
    c.setStrokeColor(teal);c.setLineWidth(2);c.line(50,h-35,w-50,h-35)
    c.setFont('Hei',8);c.setFillColor(muted)
    c.drawString(50,h-28,'PaperA / 贡献与重构审计 / 2026.10.26')
    c.setStrokeColor(line);c.setLineWidth(.5);c.line(50,43,w-50,43)
    c.setFont('Song',8);c.drawString(50,29,'研究判断以列明的文献覆盖与数学验证范围为限')
    c.setFont('Helvetica',8);c.drawRightString(w-50,29,str(doc.page))

out=ROOT/'PaperA_贡献与重构审计.pdf'
doc=SimpleDocTemplate(str(out),pagesize=(595.276,841.89),leftMargin=58,rightMargin=58,topMargin=61,bottomMargin=60,title='PaperA 贡献与重构审计',author='Codex research and editorial audit')
doc.build(story,onFirstPage=decorate,onLaterPages=decorate)
shutil_path=AUD/'create_audit.py'
shutil_path.write_bytes(Path(__file__).read_bytes())
print(json.dumps(dict(report=str(out),sources=len(sources),finite_parameter_checks=len(sanity),sha256=hashlib.sha256(out.read_bytes()).hexdigest()),ensure_ascii=False))

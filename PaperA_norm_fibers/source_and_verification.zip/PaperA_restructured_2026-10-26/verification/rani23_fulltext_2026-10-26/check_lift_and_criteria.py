"""Exact group checks for the newly identified Rani23 count map.

No finite-field modules from earlier verifiers are imported.  The cyclic
group model checks multiplicative orders, prescribed norms and uniqueness
of the primitive lift.  Trace identities are proved in the accompanying
report, not tested by this multiplicative-group check.
"""
from fractions import Fraction
from math import gcd
from pathlib import Path
import hashlib
import json


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    rows = []
    for s in (2, 3, 4):
        t = 2**s
        r, a_order, b_order = t-1, t+1, t*t+1
        d = a_order*b_order
        group_order = r*d
        for base_degree in (1, 2):
            q = t**base_degree
            base_order = q-1
            norm_power = 4//base_degree
            root_checks = 0
            primitive_root_checks = 0
            for u in range(d):
                # a=g^(r*u); its order divides d.  A primitive prescribed
                # norm can exist only when u is coprime to t+1 in base E.
                if base_degree == 2 and gcd(u, a_order) != 1:
                    continue
                for j in range(base_order):
                    if gcd(j, base_order) != 1:
                        continue
                    if (r*u-r*j) % base_order:
                        continue
                    # All r-th roots: alpha=g^(u+k*d).  The norm condition
                    # is u+k*d == j modulo q-1.
                    candidates = [u+k*d for k in range(r)
                                  if (u+k*d-j) % base_order == 0]
                    require(len(candidates) == 1, (s, base_degree, u, j))
                    root = candidates[0]
                    require((r*root-r*u) % group_order == 0, 'power map')
                    require((root-j) % base_order == 0, 'prescribed norm')
                    require(gcd(root, group_order) == gcd(u, d),
                            'primitive lift iff exact order d')
                    root_checks += 1
                    if gcd(u, d) == 1:
                        primitive_root_checks += 1
            require(gcd(norm_power, r) == 1, 'norm on root group')
            rows.append(dict(s=s, t=t, base_degree=base_degree,
                             all_compatible_lifts=root_checks,
                             primitive_lifts=primitive_root_checks))

    inequalities = []
    for s in range(2, 34):
        t = 2**s
        r, b_order, q = t-1, t*t+1, t*t
        # W(Q), W(H) >= 1, so failure against r proves failure for every
        # admissible core in the stated Theorem 4.1 conditions.
        require(Fraction(1, t) < r, 'zero-trace condition')
        require(Fraction(1, t*t) < r, 'nonzero-trace condition')
        # The least possible W(B)-1 is one.  Even the exact unfiltered
        # center is <=2 and cannot overcome this displayed error bound.
        require(r*q > 2, 'retained S11 bound')
        # The uncompressed lower bound after bounding S11 also fails,
        # already with W(B)=1.
        require(q*q-1 < r*q*q*(q-1), 'uncompressed bound')
        require(4 < 4*1+5 and 2 < 4*0+5, 'eventual degree range')
        inequalities.append(dict(s=s, t=t,
                                  zero_trace_left=str(Fraction(1, t)),
                                  nonzero_trace_left=str(Fraction(1, t*t)),
                                  right_lower_bound=r,
                                  retained_S11_error_coefficient_lower_bound=r*q))

    script = Path(__file__)
    result = dict(status='PASS',
                  scope='Cyclic-group lift/norm bijections and exact rational criterion obstructions; no new trace-field enumeration.',
                  script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),
                  all_compatible_lifts=sum(x['all_compatible_lifts'] for x in rows),
                  primitive_lifts=sum(x['primitive_lifts'] for x in rows),
                  lift_rows=rows, inequality_rows=inequalities,
                  universal_argument='For every t>=4, t^-1 and t^-2 are <1, r=t-1>=3, and r*t^2>=48>2. Finite rows only illustrate the algebraic all-t proof.')
    (script.parent/'lift_and_criteria_checks.json').write_text(
        json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','all_compatible_lifts','primitive_lifts')}))


if __name__ == '__main__':
    main()

"""Package v8 while retaining the entire previous delivery and its audits."""
from pathlib import Path
import csv
import hashlib
import json
import re
import zipfile
from pypdf import PdfReader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ZIP = ROOT.parent/'PaperA_restructured_editable.zip'
BACKUP = ROOT.parent/'PaperA_restructured_editable_v7_before_structure.zip'


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def write(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check_links():
    docs = {name: PdfReader(ROOT/name) for name in ['main.pdf', 'supplement.pdf']}
    destinations = {name: set(doc.named_destinations) for name, doc in docs.items()}
    checked, failures = [], []
    for name, doc in docs.items():
        for pn, page in enumerate(doc.pages, 1):
            for annotation in page.get('/Annots', []):
                a = annotation.get_object()
                action = a.get('/A')
                if action:
                    action = action.get_object()
                    kind, target = action.get('/S'), action.get('/D')
                    if kind == '/GoToR':
                        file = action.get('/F')
                        if hasattr(file, 'get'):
                            file = file.get('/F') or file.get('/UF')
                        if str(file) in docs and isinstance(target, str):
                            ok = target in destinations[str(file)]
                            checked.append([name, pn, str(file), target, ok])
                            if not ok:
                                failures.append(checked[-1])
                    elif kind == '/GoTo' and isinstance(target, str):
                        if target not in destinations[name]:
                            failures.append([name, pn, name, target, False])
    if failures:
        raise RuntimeError('Unresolved PDF links: '+str(failures[:5]))
    return {'status': 'PASS', 'cross_pdf_named_links_checked': len(checked),
            'named_destination_counts': {k: len(v) for k, v in destinations.items()},
            'failures': failures}


def main():
    previous = read(HERE/'before_structure/delivery_manifest.json.snapshot')
    compilation = read(HERE/'compilation.json')
    preservation = read(HERE/'preservation_checks.json')
    arithmetic = read(HERE/'structure_verification.json')
    sources = read(HERE/'provided_sources_public.json')
    if compilation['issues'] or not compilation['aux_stable']:
        raise RuntimeError('Compilation is not clean and stable')
    if digest(ROOT/'main.pdf') != compilation['pdf_sha256']:
        raise RuntimeError('PDF differs from the verified compilation')
    write(HERE/'pdf_links.json', check_links())
    visual = read(HERE/'visual_review.json')
    if visual['status'] != 'PASS':
        raise RuntimeError('Visual review incomplete')

    oldcomparison = read(ROOT/'verification/systematic_novelty_2026-10-26/claim_level_comparison.json')
    gaps = [x for x in oldcomparison['remaining_fulltext_gaps']
            if x['id'] not in ['ST26', 'OV27online26']]
    facts = {
        'date': '2026-10-26', 'revision': 'v8-fulltext-and-structure',
        'global_priority_confirmed': False,
        'original_manuscript_theorem_numbers_preserved': ['5.1', '5.4'],
        'new_results': [
            {'number': '5.5', 'kind': 'Proposition',
             'content': 'Exact cyclic convolution, mean, radical period, variance and zero proportion bound',
             'method_status': 'Classical Fourier tools applied to the family-specific four-point estimate'},
            {'number': '5.6', 'kind': 'Corollary',
             'content': 'Exact exceptional norm-one profile: 0 on 11 traces, 20 on 2 traces, 18 on 20 traces at t=32',
             'method_status': 'Exact support certificate plus elementary cyclic prime-component mechanism'},
            {'number': '5.7', 'kind': 'Corollary',
             'content': 'All nonzero K-norm fibers, their maximum orders, E-valued trace classification and Kloosterman formula',
             'method_status': 'Explicit scaling consequence; no independent-method novelty claimed'}],
        'fulltext_gaps_closed_this_stage': ['ST26', 'OV27online26'],
        'unique_new_fulltexts_read': 2, 'unique_new_fulltext_pages_read': 46,
        'issue_articles_title_abstract_screened': 19,
        'all_19_issue_articles_read_in_full': False,
        'OV27_duplicate_text_identical': True,
        'ST26': {'Theorem_1_5_nonzero_trace_criterion':
                 'Fails for every permitted index decomposition at all t=2^s, s>=2; proof in manuscript',
                 'direct_prior_special_case': 'Theorem 1.6 gives the s=2 nonzero-trace positivity',
                 'Theorem_1_2_as_printed': 'Exact F16/F4 counterexample independently verified; interpretation/correction not resolved',
                 'does_not_claim_all_other_results_incorrect': True},
        'OV27': {'displayed_theorems_compared': True,
                 'direct_full_classification_match_found': False,
                 'arbitrary_future_refinements_excluded': False},
        'remaining_fulltext_gaps': gaps,
        'database_actual_topic_search_completed': {'MathSciNet': False, 'zbMATH_Open': True},
        'database_search_scope': 'Prior v7 public search retained; not rerun or double-counted in this stage',
        'pending_external_AI_evidence_request': {'paper': 'CSTC26',
            'purpose': 'Original theorem/page/hypothesis evidence and explicit substitutions',
            'answer_obtained_at_packaging': False,
            'an_AI_answer_without_checkable_source_is_not_a_fulltext_audit': True},
        'independent_checks': {
            'ambient_nonzero_elements_enumerated': sum(x['all_field_elements_enumerated'] for x in arithmetic['fields']),
            'norm_trace_scaling_cases': sum(x['norm_trace_scaling_checks'] for x in arithmetic['fields']),
            'cyclic_convolution_cases': sum(x['convolution_checks'] for x in arithmetic['fields']),
            'norm_trace_exception_cases': sum(x['norm_trace_exception_classification_checks'] for x in arithmetic['fields']),
            'norm_trace_kloosterman_cases': sum(x['arbitrary_norm_kloosterman_checks'] for x in arithmetic['fields']),
            'finite_cases_do_not_replace_general_proofs': True},
        'formalization': 'No fresh complete Lean build; new results not Lean-formalized',
        'publication_quality': 'CAS zone 2 remains a research/submission target, not a certified grade or acceptance forecast',
        'report': 'verification/fulltext_structure_2026-10-26/全文补缺与结构提升报告_2026-10-26.txt',
        'main_pages': compilation['pages'], 'preservation': preservation,
        'external_messages_or_GitHub_push_performed': False}
    write(HERE/'findings.json', facts)

    desc = r'''PaperA 第八轮：两篇全文核对与范数—相对迹结构提升
2026年10月26日

当前 main.pdf：35页；在现有 main.tex 项目原位更新。桌面编译通过，稳定本地编译无未解析引用或溢出。
100个原标签的重构后编号保留，原46条数学陈述及证明所在核心源码保持不变。
此前定理5.1、5.4的编号、陈述与证明不变；新增命题5.5、推论5.6、推论5.7。
补充稿和此前中文审计PDF保留；历史审计反映当时范围，最新状态以本说明和v8报告为准。

新增数学内容
5.5：每个固定范数相对迹类的精确循环卷积、均值、周期及不含W(A)的方差界。
5.6：t=32时T_1=C_11\{1}，解释11个零计数、2个计数20、20个计数18。
5.7：任意非零K-范数纤维的最大阶及E值相对迹分类；范数本原时给出环境域本原元。
Fourier和缩放均按经典工具及原结果的结构推论定位，不独立包装为新的一般方法。

全文与归属核查
用户提供的ST26（22页）和OV27（24页）已完整阅读；ZIP内19篇完成题名摘要筛查，非19篇全部全文审读。
ST26定理1.5的显示判据对本文参数的所有合法拆分均失败，证明已入主稿；其r=3分类覆盖s=2，已补充归属。
ST26定理1.2印刷表述的小域反例单独记录在核查报告，不据此断言其余结果均错误。
OV27的已读显示定理不直接给出本文四点界和C_9、C_11分类；不声称穷尽其方法的一切可能改进。
剩余原始全文缺口：CSTC26、Özbudak05、Hachenberger15。已向用户提供可转交其他AI的原文条件核查任务。
MathSciNet仍未取得主题检索结果；此前zbMATH公开查询和引文追踪记录保留。全球首创性未确认。

独立验证
verify_structure.py在s=2..5穷举1,118,460个非零环境域元素，检查36,080个范数—迹缩放对、1,356个卷积计数。
另检查36,024个非零迹范数对的异常方程及Kloosterman公式；均值、方差、周期和异常支集多项式除法全部通过。
通参数结论由主稿证明给出，有限核验不替代理论证明。

最新完整报告
verification/fulltext_structure_2026-10-26/全文补缺与结构提升报告_2026-10-26.txt
可编辑交付包：PaperA_restructured_editable.zip；上一版另存PaperA_restructured_editable_v7_before_structure.zip。
尚未做完整Lean形式化、外部专家复审或GitHub推送。中科院二区是投稿目标，非本轮已获认证的水平或录用预测。
'''
    (ROOT/'重构说明.txt').write_text(desc, encoding='utf-8')
    permitted = {'main/abstract.tex', 'main/bibliography.tex', 'main/discussion.tex',
                 'main/introduction.tex', 'main/reproducibility.tex', 'main/trace_slices.tex',
                 'main.aux', 'main.log', 'main.out', 'main.pdf', '重构说明.txt'}
    changed = []
    for x in previous['files']:
        p = ROOT/x['path']
        if not p.is_file():
            raise RuntimeError('Previous payload lost: '+x['path'])
        if digest(p) != x['sha256']:
            if x['path'] not in permitted:
                raise RuntimeError('Unexpected previous-file mutation: '+x['path'])
            changed.append(x['path'])
    write(HERE/'previous_payload_preservation.json',
          {'status': 'PASS', 'previous_files_retained': len(previous['files']),
           'intentional_changes': changed, 'unexpected_changes': []})

    oldraw = {'zbmath_queries_working.json', 'citation_tracking_working.json',
              'seed_control_results.json', 'query_syntax_controls.json',
              'primary_acquisition_log.json', 'missing_title_resolution.json'}
    newraw = {'user_provided_inventory.json', 'public_fulltext_discovery.json'}
    olddir = ROOT/'verification/systematic_novelty_2026-10-26'
    paths = [p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
             and p != ROOT/'delivery_manifest.json'
             and not (p.parent == olddir and p.name in oldraw)
             and not (p.parent == HERE and p.name in newraw)]
    for p in paths:
        if p.parent == HERE and p.suffix in ['.json', '.txt', '.csv', '.py']:
            if re.search(rb'\d{10}@m\.scnu\.edu\.cn', p.read_bytes()):
                raise RuntimeError('Private institutional identifier in public material')
    manifest = {k: v for k, v in previous.items() if k != 'files'}
    manifest.update(revision='v8-fulltext-and-structure', main_manuscript_revision='v8',
                    manuscript_pdf_unchanged=False, global_priority_confirmed=False,
                    fulltext_gaps_closed_this_stage=['ST26', 'OV27online26'],
                    remaining_fulltext_gap_ids=[x['id'] for x in gaps],
                    current_report=facts['report'], previous_reports_are_historical=True,
                    proof_level_literature_exclusion_complete=False,
                    main_pdf_pages=compilation['pages'],
                    manifest_rule='All payload files except this root manifest; raw third-party excerpts, working search responses, and external article PDFs are excluded.')
    manifest['files'] = [{'path': p.relative_to(ROOT).as_posix(),
                          'bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(paths)]
    write(ROOT/'delivery_manifest.json', manifest)
    if not BACKUP.is_file():
        raise RuntimeError('Previous archive was not backed up')
    with zipfile.ZipFile(BACKUP) as z:
        oldnames = set(z.namelist())
    with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=7) as z:
        for p in paths+[ROOT/'delivery_manifest.json']:
            z.write(p, ROOT.name+'/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(ZIP) as z:
        if z.testzip() is not None:
            raise RuntimeError('Archive CRC failure')
        missing = oldnames-set(z.namelist())
        if missing:
            raise RuntimeError('Previous archive entry lost: '+str(missing))
        for row in manifest['files']:
            if hashlib.sha256(z.read(ROOT.name+'/'+row['path'])).hexdigest() != row['sha256']:
                raise RuntimeError('Archive/manifest mismatch: '+row['path'])
        entries = len(z.infolist())
    delivery = {'status': 'PASS', 'revision': manifest['revision'],
                'archive': str(ZIP), 'archive_sha256': digest(ZIP), 'entries': entries,
                'previous_archive': str(BACKUP), 'previous_archive_sha256': digest(BACKUP),
                'all_previous_archive_entries_retained': True,
                'main_pdf_sha256': digest(ROOT/'main.pdf'), 'main_pdf_pages': compilation['pages'],
                'crc_and_payload_manifest_verified': True, 'global_priority_confirmed': False}
    write(ROOT.parent/'PaperA_structure_delivery.json', delivery)
    print(json.dumps(delivery, ensure_ascii=True))


if __name__ == '__main__':
    main()

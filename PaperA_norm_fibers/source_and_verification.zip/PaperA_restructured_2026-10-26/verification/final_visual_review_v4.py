"""Final PDF geometry, glyph and hash checks after visual page inspection."""
from pathlib import Path
import json
import hashlib
from pypdf import PdfReader
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parents[1]
V=ROOT/'verification'
layout=json.loads((V/'pdf_layout_checks.json').read_text(encoding='utf-8'))
names={'main':'main.pdf','supplement':'supplement.pdf','audit':'PaperA_贡献与重构审计.pdf'}
for key,filename in names.items():
    path=ROOT/filename
    assert layout[key]['pages']==len(PdfReader(path).pages)
    assert all(row['outside_safe_page_count']==0 and not row['has_replacement_character']
               for row in layout[key]['page_checks'])
    layout[key]['pdf_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
font=TTFont('ReportGlyphCheck','C:/Windows/Fonts/simsun.ttc',subfontIndex=0)
report=''.join(p.extract_text() or '' for p in PdfReader(ROOT/names['audit']).pages)
missing=sorted({ord(c) for c in report if ord(c)>32 and ord(c) not in font.face.charToGlyph})
assert not missing
assert sum(row['pages'] for row in layout.values())==77
record=dict(revision='v4',rendered_pages=77,
    contact_sheets_inspected=['main 1-30','supplement 1-34','audit 1-13'],
    final_full_page_inspection=['main 17','supplement 34','audit 8,12,13'],
    bibliography_orphan_page_fixed=True,
    report_body_font_missing_codepoints=missing,
    clipped_or_outside_safe_page_chars=0,
    layout_pdf_hashes={key:row['pdf_sha256'] for key,row in layout.items()},
    scope='All pages rendered; contact sheets visually inspected, selected dense and changed pages inspected at full size. No claim of external peer review.')
(V/'pdf_layout_checks.json').write_text(json.dumps(layout,indent=2),encoding='utf-8')
(V/'pdf_visual_review.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print('V4_FINAL_PDF_CHECKS_PASS',record['rendered_pages'],'PAGES')

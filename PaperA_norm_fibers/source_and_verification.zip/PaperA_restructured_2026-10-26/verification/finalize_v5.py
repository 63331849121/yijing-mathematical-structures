"""Preservation, current-main PDF QA and delivery manifest for the v5 audit.

Does not compile or modify the supplementary or earlier Chinese audit PDF.
Run after the saved main source has compiled and its final renders were inspected.
"""
from pathlib import Path
import csv
import hashlib
import json
import re
import shutil
import zipfile
import pdfplumber
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
V = ROOT/'verification'
A = V/'proof_audit_51_54_2026-10-26'
REVISION = 'v5'


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(text):
    return re.sub(r'\s+', '', re.sub(r'%[^\n]*', '', text))


def aux_labels(path):
    def group(s, i):
        assert s[i] == '{'
        start, depth = i+1, 1
        i += 1
        while depth:
            depth += (s[i] == '{')-(s[i] == '}')
            i += 1
        return s[start:i-1], i
    out = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith(r'\newlabel{'):
            continue
        key, i = group(line, len(r'\newlabel'))
        payload, _ = group(line, i)
        num, i = group(payload, 0)
        page, i = group(payload, i)
        while num.startswith('{') and num.endswith('}'):
            num = num[1:-1]
        out[key] = (num, page)
    return out


# Preserve earlier revision-wide records before replacing their current summaries.
backup = ROOT/'provenance/reconstruction_v4/verification'
backup.mkdir(exist_ok=True)
for name in ('pdf_visual_review.json', 'pdf_layout_checks.json', 'environment.json',
             'compilation.json', 'desktop_compiler.json', 'pdf_links_and_hashes.json'):
    if not (backup/name).exists():
        shutil.copy2(V/name, backup/name)
prior_visual = json.loads((backup/'pdf_visual_review.json').read_text(encoding='utf-8'))

old = (ROOT/'provenance/PaperA_original_52pages.tex').read_text(encoding='utf-8')
files = {str(p.relative_to(ROOT)).replace('\\', '/'): p.read_text(encoding='utf-8')
         for folder in ('main', 'supplement') for p in (ROOT/folder).glob('*.tex')}
where = {}
for name, text in files.items():
    for label in re.findall(r'\\label\{([^}]+)\}', text):
        assert label not in where, label
        where[label] = name
oldlabels = re.findall(r'\\label\{([^}]+)\}', old)
assert len(oldlabels) == 100 and set(oldlabels) <= set(where)
pattern = re.compile(r'\\begin\{(theorem|lemma|proposition|corollary)\}(.*?)\\end\{\1\}', re.S)
preserved = []
for m in pattern.finditer(old):
    labels = re.findall(r'\\label\{([^}]+)\}', m[2])
    if not labels:
        continue
    key = labels[0]
    current_text = files[where[key]]
    found = [x for x in pattern.finditer(current_text) if r'\label{'+key+'}' in x[2]]
    assert len(found) == 1
    n = found[0]
    assert canonical(m[0]) == canonical(n[0]), key
    ap = re.match(r'\s*(\\begin\{proof\}.*?\\end\{proof\})', old[m.end():], re.S)
    bp = re.match(r'\s*(\\begin\{proof\}.*?\\end\{proof\})', current_text[n.end():], re.S)
    if ap:
        expected = ap[1]
        if key == 'thm:inner-double-count':
            expected = expected.replace(
                'Apply the primitive-character indicator proved in\nTheorem~\\ref{thm:inner-primitive-count} separately to these three\nvariables.',
                'Apply Lemma~\\ref{lem:primitive-indicator} separately to these three\nvariables.')
        assert bp and canonical(expected) == canonical(bp[1]), key
    else:
        assert bp is None
    preserved.append(dict(label=key, destination=where[key], statement_preserved=True,
                          proof_preserved=True, has_immediate_proof=bool(ap)))
assert len(preserved) == 46

current = {x: aux_labels(ROOT/(x+'.aux')) for x in ('main', 'supplement')}
with (ROOT/'provenance/label_mapping.csv').open(encoding='utf-8-sig', newline='') as f:
    original_numbers = {row['Original label']: row['Original printed number'] for row in csv.DictReader(f)}
with (ROOT/'provenance/label_mapping.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['Original label', 'Original printed number', 'New printed number',
                     'New PDF', 'New PDF page', 'New source file'])
    for key in oldlabels:
        name = where[key]
        doc = name.split('/')[0]
        number, page = current[doc][key]
        writer.writerow([key, original_numbers[key], number, doc+'.pdf', page, name])

promoted = []
for key, title in [('lem:character-decomposition', 'Character decomposition'),
                   ('lem:local-averaging', 'Local averaging in a cyclic group')]:
    ap = re.search(r'\\begin\{auxlemma\}\['+re.escape(title)+r'\](.*?)\\end\{auxlemma\}\s*(\\begin\{proof\}.*?\\end\{proof\})', old, re.S)
    bp = re.search(r'\\begin\{lemma\}\['+re.escape(title)+r'\]\\label\{'+re.escape(key)+r'\}(.*?)\\end\{lemma\}\s*(\\begin\{proof\}.*?\\end\{proof\})', files[where[key]], re.S)
    assert ap and bp and canonical(ap[1]) == canonical(bp[1]) and canonical(ap[2]) == canonical(bp[2])
    promoted.append(dict(label=key, statement_body_preserved=True, proof_preserved=True))

new_keys = ['thm:uniform-relative-trace', 'lem:trace-kloosterman',
            'lem:trace-prime-sieve', 'thm:trace-positivity-classification']
previous = (ROOT/'provenance/reconstruction_v4/main/trace_slices.tex').read_text(encoding='utf-8')
for key in new_keys:
    ap = [x for x in pattern.finditer(previous) if r'\label{'+key+'}' in x[2]]
    bp = [x for x in pattern.finditer(files[where[key]]) if r'\label{'+key+'}' in x[2]]
    assert len(ap) == len(bp) == 1 and canonical(ap[0][0]) == canonical(bp[0][0])
assert current['main'][new_keys[0]][0] == '5.1'
assert current['main'][new_keys[-1]][0] == '5.4'
audit = dict(revision=REVISION, original_label_count=100, preserved_label_count=100,
             statement_count=46, results=preserved, promoted_auxiliary_lemmas=promoted,
             explained_proof_edit={'thm:inner-double-count': 'Previously documented classical primitive-indicator citation redirect only.'},
             all_100_original_labels_resolved=True, v4_new_theorem_statements_preserved=True,
             new_numbered_results=[dict(label=k, number=current['main'][k][0],
                                        page=current['main'][k][1], source=where[k]) for k in new_keys])
dump(ROOT/'provenance/mathematical_preservation_audit.json', audit)

# Every cross-PDF named destination must still exist after changing the main layout.
readers = {p.name: PdfReader(p) for p in ROOT.glob('*.pdf')}
pdfs = {}
for name, doc in readers.items():
    remote, remote_checked, web = [], 0, 0
    for page in doc.pages:
        for ref in page.get('/Annots', []):
            action = ref.get_object().get('/A')
            if not action:
                continue
            action = action.get_object()
            if str(action.get('/S')) == '/URI':
                web += 1
            if str(action.get('/S')) != '/GoToR':
                continue
            target = action.get('/F')
            target = target.get_object() if hasattr(target, 'get_object') else target
            if isinstance(target, dict):
                target = target.get('/F')
            target = str(target)
            remote.append(target)
            if name in ('main.pdf', 'supplement.pdf'):
                assert target == ('supplement.pdf' if name == 'main.pdf' else 'main.pdf')
                dest = action.get('/D')
                if isinstance(dest, str):
                    assert dest in readers[target].named_destinations, (name, target, dest)
                    remote_checked += 1
    pdfs[Path(name).stem] = dict(pages=len(doc.pages), pdf_sha256=sha(ROOT/name),
                               external_document_links=len(remote),
                               external_named_destinations_verified=remote_checked,
                               external_document_targets=sorted(set(remote)), web_links=web)
assert pdfs['supplement']['pdf_sha256'] == prior_visual['layout_pdf_hashes']['supplement']
assert pdfs['PaperA_贡献与重构审计']['pdf_sha256'] == prior_visual['layout_pdf_hashes']['audit']
dump(V/'pdf_links_and_hashes.json', pdfs)

bad, replacement, page_metrics = [], 0, []
with pdfplumber.open(ROOT/'main.pdf') as doc:
    for number, page in enumerate(doc.pages, 1):
        outside = [ch for ch in page.chars if ch['x0'] < 32 or ch['x1'] > page.width-32
                   or ch['top'] < 25 or ch['bottom'] > page.height-25]
        bad.extend(dict(page=number, text=ch['text']) for ch in outside)
        replacement += sum('\ufffd' in ch['text'] for ch in page.chars)
        page_metrics.append(dict(page=number, chars=len(page.chars), out_of_safe_area=len(outside)))
assert not bad and replacement == 0
dump(V/'pdf_layout_checks.json', dict(revision=REVISION, scope='Current main only',
                                    pdf_sha256=pdfs['main']['pdf_sha256'], pages=page_metrics,
                                    outside_safe_area_chars=0, replacement_characters=0))
visual = dict(revision=REVISION, rendered_pages_this_revision=pdfs['main']['pages'],
              current_main_contact_sheets_inspected=['1-12', '13-24', '25-30'],
              current_main_full_pages_inspected=[14, 15, 16, 17, 18, 29, 30],
              bibliography_orphan_page_fixed=True,
              carried_forward_review='Supplement 34 pages and earlier audit 13 pages: v4 review retained; PDF hashes unchanged.',
              layout_pdf_hashes={'main': pdfs['main']['pdf_sha256'],
                                 'supplement': pdfs['supplement']['pdf_sha256'],
                                 'audit': pdfs['PaperA_贡献与重构审计']['pdf_sha256']},
              scope='Final current-main pages rendered and visually inspected; unchanged PDFs were not recompiled or newly reviewed.')
dump(V/'pdf_visual_review.json', visual)

compile_record = json.loads((A/'compilation.json').read_text(encoding='utf-8'))
assert not compile_record['issues'] and compile_record['pdf_sha256'] == pdfs['main']['pdf_sha256']
compilations = json.loads((backup/'compilation.json').read_text(encoding='utf-8'))
for row in compilations:
    row['revision'] = 'v4 unchanged'
    if row['document'] == 'main':
        row.update(revision=REVISION, compilation_cycles=compile_record['cycles'],
                   issues=[], pdf_bytes=(ROOT/'main.pdf').stat().st_size)
dump(V/'compilation.json', compilations)
dump(V/'desktop_compiler.json', json.loads((A/'desktop_compiler.json').read_text(encoding='utf-8')))

independent = json.loads((A/'independent_flat_field_results.json').read_text(encoding='utf-8'))
assert independent['status'] == 'PASS'
assert independent['source_certificate_sha256'] == sha(V/'uniform_trace/uniform_trace_checks.json')
assert sum(x['checked_full_order_witnesses'] for x in independent['flat_fields']) == 1010
comparison = json.loads((A/'source_comparison.json').read_text(encoding='utf-8'))
assert not comparison['global_priority_confirmed']
env = json.loads((backup/'environment.json').read_text(encoding='utf-8'))
env.update(revision=REVISION,
           added_source_comparisons=['Cohen 2005', 'Tuxanidy-Wang 2015 v2', 'Ugolini 2020 / 2018 v2'],
           literature_fulltext_gap={'Rani23': 'Full finer sufficient conditions unavailable; both degree-four 1-normal and degree-two relative-trace substitutions identified.'},
           current_audit='verification/proof_audit_51_54_2026-10-26/source_comparison.json',
           current_main_only_compiled=True, unchanged_supplement_and_chinese_audit=True)
dump(V/'environment.json', env)
dump(V/'new_mathematical_results_v5.json', dict(revision=REVISION, theorem_statements_unchanged=True,
     original_statements_and_proofs_preserved=46, original_labels_resolved=100,
     theorem_5_1=comparison['theorem_5_1'], theorem_5_4=comparison['theorem_5_4'],
     global_priority_confirmed=False, expert_independent_review_completed=False,
     full_Lean_build_completed=False, independent_finite_checks=comparison['executed_independent_checks']))

readme = '''PaperA 第五轮：定理5.1、5.4的证明与前驱核查
2026年10月26日

当前主稿 main.pdf：30页。当前编辑入口 main.tex，原位修订并通过桌面编辑器编译。
定理5.1、5.4的陈述与编号不变；本轮补充证明说明、直接前驱与参数比较。
补充稿 supplement.pdf（34页）和此前中文审计PDF（13页）保持第四轮内容，未在本轮重新编译。
本轮新增判断请看 verification/proof_audit_51_54_2026-10-26/核查结论_定理5.1与5.4.txt。

主要判断
1. Cohen（2005）与Tuxanidy–Wang（2015）直接包含相同指定阶、指定迹计数。
2. 5.1的4 sqrt(t)界是几何核验后对经典曲线字符定理的有效应用；小误差及统一性是应比较的增量。
3. 5.4给出本族完整例外分类，已读最接近结果未见同一分类；全球首创性未确认。
4. Rani等（2023）的细化条件仍缺全文核查，不能声称已全部排除。

新增执行证据
独立有限域实现重新检查1010个满阶元素见证；s<=6的全部Q_c、M_c也以单一二元多项式域直接枚举。
8项迹1多项式计数、两项空切片Bezout恒等式、24项有理数筛、81项整数界及统一尾部常数均通过。
运行 verification/proof_audit_51_54_2026-10-26/independent_flat_field_audit.py（Python标准库，勿使用-O）。
该目录的 independent_flat_field_results.json 是本轮实际执行结果。
source_comparison.json 记录文献链接、实际阅读范围、参数代入和判断边界。

原文保留
100个原标签全部保留且可解析；46条原带标签定理类陈述及其证明逐项核对，保留先前已说明的唯一引文重定向。
两条原无编号辅助引理的内容与证明保留。本轮没有新增或删除编号定理。
provenance/label_mapping.csv 已按当前主稿页码更新。

编译与交付
本轮仅编译当前main.tex。一般双文档维护仍可使用原build.py。
当前30页已渲染，联系表及关键页已人工视觉检查，无编译引用错误、溢出或缺字。
两份稿件的全部跨PDF命名目标已检查。
当前可编辑ZIP包含最新主稿、原补充稿、已有中文审计PDF及新增核查材料。
原第四轮完整ZIP归档为 PaperA_restructured_editable_v4.zip；第四轮主稿源码快照在 provenance/reconstruction_v4。
此前v1、v2、v3归档继续保留。未向GitHub推送，未进行外部专家复审或完整Lean重建。
'''
(ROOT/'重构说明.txt').write_text(readme, encoding='utf-8')
(V/'核验摘要.txt').write_text('第五轮：原100个标签、46条原带标签定理类陈述和证明保留。\n1010个见证已由不同域表示独立实现复核；两项空切片恒等式、24项筛及81项整数界均通过。\n仅更新并检查当前30页主稿；全球优先权未确认，Rani23细化全文仍未排除。\n', encoding='utf-8')


def included(path):
    if not path.is_file() or '__pycache__' in path.parts:
        return False
    if path.suffix in {'.log', '.out', '.toc', '.synctex', '.gz'} and not path.is_relative_to(V):
        return False
    return path.name != 'delivery_manifest.json'


manifest = [dict(path=str(p.relative_to(ROOT)).replace('\\', '/'), bytes=p.stat().st_size, sha256=sha(p))
            for p in sorted(ROOT.rglob('*')) if included(p)]
dump(ROOT/'delivery_manifest.json', dict(revision=REVISION, files=manifest))
archive = ROOT.parent/'PaperA_restructured_editable.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for p in sorted(ROOT.rglob('*')):
        if included(p) or p.name == 'delivery_manifest.json':
            z.write(p, arcname=ROOT.name+'/'+str(p.relative_to(ROOT)).replace('\\', '/'))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        assert hashlib.sha256(z.read(ROOT.name+'/'+row['path'])).hexdigest() == row['sha256']
print(json.dumps(dict(revision=REVISION, original_labels=100, preserved_statements_and_proofs=46,
                     current_main_pages=pdfs['main']['pages'], all_cross_pdf_named_destinations='PASS',
                     layout='PASS', independent_witnesses=1010, zip_entries=len(manifest)+1,
                     zip_bytes=archive.stat().st_size, zip_sha256=sha(archive),
                     crc_and_manifest='PASS', global_priority_confirmed=False), ensure_ascii=False, indent=2))

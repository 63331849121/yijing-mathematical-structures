from pathlib import Path
import re, csv, json, hashlib, zipfile, shutil
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
V=ROOT/'verification'
old=(ROOT/'provenance/PaperA_original_52pages.tex').read_text(encoding='utf-8')
files={str(p.relative_to(ROOT)).replace('\\','/'):p.read_text(encoding='utf-8') for folder in ('main','supplement') for p in (ROOT/folder).glob('*.tex')}
where={}
for path,txt in files.items():
    for label in re.findall(r'\\label\{([^}]+)\}',txt):
        assert label not in where,('Duplicate label',label)
        where[label]=path
oldlabels=re.findall(r'\\label\{([^}]+)\}',old)
assert set(oldlabels)<=set(where)
def canonical(txt):return re.sub(r'\s+','',re.sub(r'%[^\n]*','',txt))
pattern=re.compile(r'\\begin\{(theorem|lemma|proposition|corollary)\}(.*?)\\end\{\1\}',re.S)
proofs=[]
for m in pattern.finditer(old):
    labels=re.findall(r'\\label\{([^}]+)\}',m[2])
    if not labels:continue
    label=labels[0];txt=files[where[label]]
    n=[x for x in pattern.finditer(txt) if r'\label{'+label+'}' in x[2]]
    assert len(n)==1; n=n[0]
    assert canonical(m[0])==canonical(n[0]),label
    a=re.match(r'\s*(\\begin\{proof\}.*?\\end\{proof\})',old[m.end():],re.S)
    b=re.match(r'\s*(\\begin\{proof\}.*?\\end\{proof\})',txt[n.end():],re.S)
    if a:
        assert b,label
        expected=a[1]
        if label=='thm:inner-double-count':
            expected=expected.replace('Apply the primitive-character indicator proved in\nTheorem~\\ref{thm:inner-primitive-count} separately to these three\nvariables.','Apply Lemma~\\ref{lem:primitive-indicator} separately to these three\nvariables.')
        assert canonical(expected)==canonical(b[1]),label
    else:assert b is None,label
    proofs.append(dict(label=label,destination=where[label],statement_preserved=True,proof_preserved=True,has_immediate_proof=bool(a)))
assert len(proofs)==46

def aux_labels(path):
    def group(s,i):
        assert s[i]=='{';start=i+1;depth=1;i+=1
        while depth:
            depth+=(s[i]=='{')-(s[i]=='}');i+=1
        return s[start:i-1],i
    out={}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith(r'\newlabel{'):continue
        key,i=group(line,len(r'\newlabel'));payload,_=group(line,i)
        num,i=group(payload,0);page,i=group(payload,i)
        while num.startswith('{') and num.endswith('}'):num=num[1:-1]
        out[key]=(num,page)
    return out
with (ROOT/'provenance/label_mapping.csv').open(encoding='utf-8-sig', newline='') as f:
    orig={r['Original label']:(r['Original printed number'],'') for r in csv.DictReader(f)}
current={x:aux_labels(ROOT/(x+'.aux')) for x in ('main','supplement')}
with (ROOT/'provenance/label_mapping.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['Original label','Original printed number','New printed number','New PDF','New PDF page','New source file'])
    for key in oldlabels:
        path=where[key];doc=path.split('/')[0];num,page=current[doc][key]
        w.writerow([key,orig[key][0],num,doc+'.pdf',page,path])

aux=[]
for label,title in [('lem:character-decomposition','Character decomposition'),('lem:local-averaging','Local averaging in a cyclic group')]:
    a=re.search(r'\\begin\{auxlemma\}\['+re.escape(title)+r'\](.*?)\\end\{auxlemma\}\s*(\\begin\{proof\}.*?\\end\{proof\})',old,re.S)
    txt=files[where[label]]
    b=re.search(r'\\begin\{lemma\}\['+re.escape(title)+r'\]\\label\{'+re.escape(label)+r'\}(.*?)\\end\{lemma\}\s*(\\begin\{proof\}.*?\\end\{proof\})',txt,re.S)
    assert a and b and canonical(a[1])==canonical(b[1]) and canonical(a[2])==canonical(b[2])
    aux.append(dict(original_heading=title,new_label=label,new_number=current[where[label].split('/')[0]][label][0],statement_body_preserved=True,proof_preserved=True,edit='Originally unnumbered auxiliary lemma promoted to a numbered lemma.'))
audit=dict(original_label_count=100,preserved_label_count=100,statement_count=46,
    explained_proof_edit={'thm:inner-double-count':'Only the primitive-indicator citation is redirected to the standalone classical lemma; the expected replacement has been checked exactly.'},
    results=proofs,promoted_auxiliary_lemmas=aux,all_100_original_labels_resolved=True,
    revision='v4: 46 original labelled statements and their proofs preserved; original trace-one proposition relocated to supplementary Section S8; four additional numbered results in main Section 5')
(ROOT/'provenance/mathematical_preservation_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')

pdfs={}
for p in sorted(ROOT.glob('*.pdf')):
    doc=PdfReader(p);remote=[];web=0
    for page in doc.pages:
        for ref in page.get('/Annots',[]):
            obj=ref.get_object();a=obj.get('/A')
            if not a:continue
            a=a.get_object()
            if str(a.get('/S'))=='/URI':web+=1
            if str(a.get('/S'))=='/GoToR':
                target=a.get('/F');target=target.get_object() if hasattr(target,'get_object') else target
                if isinstance(target,dict):target=target.get('/F')
                remote.append(str(target))
    if p.stem in ('main','supplement'):
        assert all(x==('supplement.pdf' if p.stem=='main' else 'main.pdf') for x in remote)
    pdfs[p.stem]=dict(pages=len(doc.pages),external_document_links=len(remote),external_document_targets=sorted(set(remote)),web_links=web,pdf_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(V/'pdf_links_and_hashes.json').write_text(json.dumps(pdfs,indent=2,ensure_ascii=False),encoding='utf-8')


new_keys=['thm:uniform-relative-trace','lem:trace-kloosterman','lem:trace-prime-sieve','thm:trace-positivity-classification']
assert all(k in where and k in current['main'] for k in new_keys)
checks=json.loads((V/'uniform_trace/uniform_trace_checks.json').read_text(encoding='utf-8'))
assert checks['status']=='PASS'
assert len(checks['prime_sieve_certificates'])==24
assert len(checks['exact_trace_one'])==8
finite=checks['complete_finite_slice_certificates']
assert sum(row['full_order_witnesses'] for row in finite)==1010
assert sum(row['total_slices'] for row in finite)==1012
assert [(r['s'],c) for r in finite for c in r['zero_slices_hex']]==[(3,'0x1'),(5,'0x1')]
for row in finite:
    assert len(row['slices'])==row['total_slices']
    assert sum(x.get('direct_trace_norm_and_order_check')=='PASS' for x in row['slices'])==row['full_order_witnesses']
assert all(row['Delta']=={2:8,3:0,4:16,5:0,6:24,7:84,8:288,9:216}[row['s']] for row in checks['exact_trace_one'])
assert 'from finite_slice_witnesses import verify_all_slices' in (V/'uniform_trace/verify_uniform_traces.py').read_text(encoding='utf-8')
new_claims=dict(revision='v4', status='Manuscript proofs and executed finite certificates; not external expert review or complete formalization.',
    numbered_results=[dict(label=k,number=current['main'][k][0],page=current['main'][k][1],source=where[k]) for k in new_keys],
    mathematical_increment=['Uniform four-point bound for every nonzero relative trace',
                           'Complete empty-slice classification: exactly (s,c)=(3,1),(5,1)',
                           'Analytic positivity for all nonzero traces at s>=10 (also s=8)',
                           'Only two exceptional field certificates needed for full adjacent-pair existence'],
    classical_inputs=['Lang construction and curve character bound','Reciprocal-trace substitution','Binary Kloosterman identity','Prime-freeness sieve'],
    finite_checks=dict(prime_sieve_rows=24,trace_one_counts=8,direct_full_order_witnesses=1010,finite_slices=1012,zero_slice_Bezout_certificates=2,independent_all_trace_field_enumerations='s=2..6'),
    infinite_proof='Section 5 geometric proof, prime sieve and Appendix A integer bounds for s>=33',
    global_priority_confirmed=False,expert_independent_review_completed=False,full_Lean_build_completed=False)
(V/'new_mathematical_results_v4.json').write_text(json.dumps(new_claims,ensure_ascii=False,indent=2),encoding='utf-8')
audit['new_numbered_results']=new_claims['numbered_results']
(ROOT/'provenance/mathematical_preservation_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')

visual=json.loads((V/'pdf_visual_review.json').read_text(encoding='utf-8'))
assert visual['revision']=='v4'
assert visual['rendered_pages']==sum(x['pages'] for x in pdfs.values())
for key,stem in [('main','main'),('supplement','supplement'),('audit','PaperA_贡献与重构审计')]:
    assert visual['layout_pdf_hashes'][key]==pdfs[stem]['pdf_sha256']
comp=json.loads((V/'compilation.json').read_text(encoding='utf-8'))
assert all(not row['issues'] for row in comp)

readme=f'''PaperA 第四轮：统一相对迹与完整空切片分类
2026年10月26日

当前交付
main.pdf：{pdfs['main']['pages']}页修订主稿。
supplement.pdf：{pdfs['supplement']['pages']}页补充稿。
PaperA_贡献与重构审计.pdf：{pdfs['PaperA_贡献与重构审计']['pages']}页中文报告。
main.tex / supplement.tex：可继续编辑的LaTeX入口。

本轮数学内容提升
1. Section 5统一估计每个非零相对迹切片，给出4 sqrt(t)特征和界，常数不依赖c。
2. 误差先以精确未筛群体Q_c为中心；Q_c用经典二元Kloosterman恒等式表达。
3. 经典素数筛在该曲线上给出s>=10时全部非零迹正性；s=8亦由同一筛证得。
4. 全部非零迹切片的完整分类：仅(s,c)=(3,1),(5,1)没有满阶元素。
5. s=3不存在所需的阶9倒数迹；s=5的20个候选参数阶都为205而非1025。两项有精确多项式Bezout证书。
6. 2<=s<=9共1012个非零迹切片，1010个非空切片各提供一个满阶元素，逐项检查迹、范数、精确阶与扩域不可约性。
7. 完整相邻双满阶族的全参数存在性，只需对s=3,5使用完整族元素；其余由迹1子族得到。

叙述与结构
正文采用更一般的统一迹定理，原迹1命题与完整证明移入补充稿S8。
原46个带标签的定理类陈述与证明逐项保留；原100个标签全部可解析。
两条原无编号辅助引理保留并编号；本轮新增两条定理和两条引理。
新增编号中的Kloosterman恒等式、筛法应用均明确归为经典工具，不计作原创通用方法。
新旧标签、编号、页码见provenance/label_mapping.csv。

可执行证据
verification/uniform_trace/verify_uniform_traces.py：总入口，仅需Python标准库，勿使用-O。
verification/uniform_trace/finite_slice_witnesses.py：1010个逐切片证书的生成与直接核验。
verification/uniform_trace/uniform_trace_checks.json：24项精确有理数筛证书、8个迹1计数、两项Bezout恒等式及逐切片元素。
verification/uniform_trace/verification.log：本轮实际执行记录。
verification/new_mathematical_results_v4.json：新增结果、证明依赖与验证边界。
原31组双满阶证书、81个中间整数界、作者递归素性验证与其他既有记录继续保留。
新筛法的因子分解已与原递归素性证书所用列表核对，包括重数。

文献归属边界
文献矩阵扩展为13项，逐项列明实际阅读范围。
Ha21正式全文的指定访问与核查缺口已在前轮关闭，固定切片与射影合计的精确区别保留。
Shin26的三次范数环面迹等分布说明一般几何框架已有前驱；本轮核查其主定理和Section 5光滑情形证明，未审读全部79页。
Rani23只核查出版社摘要与可访问节选，其全部细化充分条件仍未逐条排除。
稿内证明和有限核验不等于全球首创性证明，不等于外部领域专家独立复审或Lean完整形式化。
本轮没有向GitHub推送；原作者姓名保留。原始52页输入及固定公开仓库版本存档保留。

编译与交付检查
在本目录运行python build.py，稳定两份稿件的双向引用。
两份PDF放在同一目录可使用跨文档链接。
本轮两份稿件稳定编译；主稿另经桌面编辑器编译成功。
最终{visual['rendered_pages']}页已渲染检查，无越界文字或缺字；交付包通过CRC和逐文件SHA校验。
更高塔推广、一般指标的对数间隙仍未解决；没有重新构建完整Lean工程。

版本保留
前三轮完整ZIP分别另存为PaperA_restructured_editable_v1.zip、_v2.zip、_v3.zip。
相应源码快照在provenance/reconstruction_v1、reconstruction_v2、reconstruction_v3。
当前PaperA_restructured_editable.zip为第四轮完整可编辑项目。
'''
(ROOT/'重构说明.txt').write_text(readme,encoding='utf-8')
(V/'核验摘要.txt').write_text(f'第四轮：100个原标签、46条原定理类陈述与证明保留；另2条原辅助引理；新增4个编号结果。\n24项素数筛、8个迹1计数、1010个满阶元素证书均通过。\n最终PDF共{visual["rendered_pages"]}页，无未定义引用、溢出或缺字；全球优先权与外部专家复审未获确认，Lean未全量重建。\n',encoding='utf-8')
env=json.loads((V/'environment.json').read_text(encoding='utf-8'))
env.update(revision='v4',literature_primary_sources_checked=13,
    new_source_coverage={'Shin26':'Main theorem and Section 5 smooth proof only','Rani23':'Publisher abstract and previews only; finer criteria unaudited'},
    new_executed_checks=['24 exact rational prime-sieve rows','8 polynomial trace-one counts','2 Bezout emptiness certificates','1010 direct full-order witnesses over s=2..9','Independent nonzero-trace parameterizations and Kloosterman identity for s=2..6','100 original labels and 46 original statements/proofs preserved','Stable TeX compilation, desktop main compilation, full PDF rendering and glyph audit'])
env['literature_fulltext_gap']={'Rani23':'Only abstract and accessible previews checked; finer sufficient criteria unaudited.'}
(V/'environment.json').write_text(json.dumps(env,indent=2,ensure_ascii=False),encoding='utf-8')
(V/'desktop_compiler.json').write_text(json.dumps(dict(mainFile='main.tex',revision='v4',kind='success',message='Current mathematical source compiled successfully with the desktop editor compiler; final typographical adjustment was also compiled by the project build.'),indent=2),encoding='utf-8')

manifest=[]
def included(p):
    if not p.is_file() or '__pycache__' in p.parts:return False
    if p.suffix in {'.log','.out','.toc','.synctex','.gz'} and not p.is_relative_to(V):return False
    return p.name!='delivery_manifest.json'
for p in sorted(ROOT.rglob('*')):
    if included(p):manifest.append(dict(path=str(p.relative_to(ROOT)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ROOT/'delivery_manifest.json').write_text(json.dumps(dict(revision='v4',files=manifest),ensure_ascii=False,indent=2),encoding='utf-8')
zpath=ROOT.parent/'PaperA_restructured_editable.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in sorted(ROOT.rglob('*')):
        if included(p) or p.name=='delivery_manifest.json':z.write(p,arcname=ROOT.name+'/'+str(p.relative_to(ROOT)).replace('\\','/'))
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for row in manifest:
        assert hashlib.sha256(z.read(ROOT.name+'/'+row['path'])).hexdigest()==row['sha256']
print(json.dumps(dict(revision='v4',pdfs=pdfs,original_labels=100,preserved_statements_and_proofs=46,new_numbered_results=4,
                     finite_full_order_witnesses=1010,zip_bytes=zpath.stat().st_size,zip_entries=len(manifest)+1,
                     zip_sha256=hashlib.sha256(zpath.read_bytes()).hexdigest(),crc_and_manifest='PASS'),ensure_ascii=False,indent=2))

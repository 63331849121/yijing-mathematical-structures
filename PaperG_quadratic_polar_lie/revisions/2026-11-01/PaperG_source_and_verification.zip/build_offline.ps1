$ErrorActionPreference = 'Stop'
$paperRoot = $PSScriptRoot
$paperCompiler = 'C:/Users/master/.codex/plugins/cache/openai-bundled/latex/0.2.4/bin/tectonic.exe'
$paperCache = Join-Path $paperRoot '.tex_runtime_cache'
if (-not (Test-Path -LiteralPath $paperCompiler)) { throw 'The bundled Tectonic compiler was not found.' }
if (-not (Test-Path -LiteralPath $paperCache)) { throw 'The project-local offline TeX cache was not found.' }
$savedPaperCacheSetting = $env:TECTONIC_CACHE_DIR
try {
    $env:TECTONIC_CACHE_DIR = $paperCache
    Push-Location -LiteralPath $paperRoot
    try {
        & $paperCompiler -X compile main.tex --only-cached --untrusted --keep-logs --keep-intermediates --reruns 3
        if ($LASTEXITCODE -ne 0) { throw "LaTeX compilation failed (exit $LASTEXITCODE)." }
    } finally { Pop-Location }
} finally { $env:TECTONIC_CACHE_DIR = $savedPaperCacheSetting }

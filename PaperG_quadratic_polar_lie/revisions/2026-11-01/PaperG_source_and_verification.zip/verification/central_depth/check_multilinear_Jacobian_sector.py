"""Check the classical multilinear Jacobian sector and the suspension obstruction."""
from pathlib import Path
from functools import lru_cache
import itertools
import json

HERE=Path(__file__).resolve().parent

def insert(v,piv):
    while v:
        k=v.bit_length()-1
        if k not in piv:piv[k]=v;return
        v^=piv[k]

def reduce(v,piv):
    for k in sorted(piv,reverse=True):
        if (v>>k)&1:v^=piv[k]
    return v

def pair(a,b):return tuple(sorted((a,b)))

@lru_cache(None)
def component(n):
    edges=list(itertools.combinations(range(n),2))
    variables=[(a,b) for j,a in enumerate(edges) for b in edges[j+1:] if not set(a)&set(b)]
    ix={v:i for i,v in enumerate(variables)}
    rows={}
    for tri in itertools.combinations(range(n),3):
        for edge in edges:
            if set(tri)&set(edge):continue
            row=0
            for i in tri:
                other=tuple(j for j in tri if j!=i)
                key=tuple(sorted((other,edge)))
                row^=1<<ix[key]
            insert(row,rows)
    eix={edge:i for i,edge in enumerate(edges)}
    images=[];mupiv={}
    for (a,b),(c,d) in variables:
        image=0
        for edge in (pair(a,c),pair(a,d),pair(b,c),pair(b,d)):image^=1<<eix[edge]
        images.append(image);insert(image,mupiv)
    def image(val):
        ans=0
        while val:
            low=val&-val;ans^=images[low.bit_length()-1];val-=low
        return ans
    assert all(not image(row) for row in rows.values())
    w=sum(1<<ix[tuple(sorted((a,b)))] for a,b in (((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))))
    assert reduce(w,rows) and not image(w)
    return ix,rows,len(variables)-len(rows),len(mupiv)

def main():
    results=[]
    for n in range(5,11):
        ix,rows,dim,rank=component(n)
        assert dim==(n-1)*(n-2)//2 and dim-rank==1
        target_ix,target_rows,_,_=component(n+1)
        for i in range(n):
            val=0
            for a,b in (((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))):
                if i not in a and i not in b:continue  # coefficient action is zero
                first,second=(a,b) if i in a else (b,a)
                other=first[0] if first[1]==i else first[1]
                # t_y c_first c_second + t_i c_other,y c_second.
                val^=1<<target_ix[tuple(sorted((first,second)))]
                val^=1<<target_ix[tuple(sorted((pair(other,n),second)))]
            assert not reduce(val,target_rows)
        results.append({'rank':n,'multilinear_B_dimension':dim,'Koszul_image_rank':rank,
                        'Jacobian_kernel_dimension':dim-rank,'all_suspensions_kill_Jacobian':True})
    out={'status':'PASS','results':results,
         'meaning':'Classical Jacobian kernel, and a concrete limit of the current suspension method. No nonvanishing claim about a fifth central Lie layer.'}
    (HERE/'multilinear_Jacobian_sector_controls.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()

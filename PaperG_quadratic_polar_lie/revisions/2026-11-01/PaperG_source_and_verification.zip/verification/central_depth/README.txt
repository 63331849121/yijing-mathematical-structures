Central-depth verification (ordinary three-Engel Lie algebras over F4)
====================================================================
Use Python 3.12 or later; only its standard library is needed. Run from
this directory. The general proofs are in Appendix "Central-depth bounds
and their exact starting systems". Reports are written beside the inputs.

python verify_sparse_seed.py
  Expands the 22-node collecting identity in a free associative algebra;
  checks that all substituted inputs are Lie polynomials; rejects three
  damaged-certificate controls.
python verify_rank4_chain.py
  Reconstructs the 40 -> 41 -> 42 dimensional boundary chain and its
  actual central quotient maps, not coordinate-prefix projections.
python verify_rank5_depth4_model.py
  Reconstructs the 178-dimensional positive model, complete cubic Engel
  coefficients over F4, Jacobi, central-depth dimensions and its quotients.
python replay_capped_universality.py 4,1,1,1,1,1
python replay_capped_universality.py 3,2,1,1,1,1
python replay_capped_universality.py 2,2,2,1,1,1
  Each command replays all weights 2--9, independently of the constructor.
  It verifies the full relation ranks and that the new bracket coordinates
  span the entire universal kernel. The three weight-nine kernels vanish.
python check_fourth_layer_suspension.py
  Checks the displayed symbolic spanning constructions in ranks 7--10.
python check_multilinear_Jacobian_sector.py
  Checks the classical multilinear kernel and the limit of the current
  suspension method. This is not a fifth-layer nonvanishing theorem.

Finite model checks and general rank propagation have separate roles.
The rank-six universal kernels are the computer-assisted starting step;
arbitrary-rank propagation is proved symbolically in the manuscript.
No Lean formalization of these additions is supplied.

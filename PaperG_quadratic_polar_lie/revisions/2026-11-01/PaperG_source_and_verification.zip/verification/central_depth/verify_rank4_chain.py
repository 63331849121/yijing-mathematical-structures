"""Independent complete-coefficient check of the rank-four boundary chain.

Tables have coefficients in F2 and are extended to F4. Checking each
coefficient of the cubic Engel polynomial is therefore a test over F4,
not a sample restricted to binary-coordinate inputs.
"""
from pathlib import Path
from itertools import combinations, permutations
import json,time,hashlib

HERE=Path(__file__).resolve().parent
def bits(v):
    while v:
        lo=v&-v
        yield lo.bit_length()-1
        v^=lo
def bracket(t,a,b):
    ans=0
    for i in bits(a):
        for j in bits(b):ans^=t[i][j]
    return ans
def span(values):
    piv={}
    for v in values:
        while v:
            k=v.bit_length()-1
            if k not in piv:
                piv[k]=v
                break
            v^=piv[k]
    return list(piv.values())
def action(t,space):
    return span(bracket(t,a,1<<j) for a in space for j in range(len(t)))
def series(t,first):
    result=[]
    while first:
        result.append(len(first))
        first=action(t,first)
        assert len(result)<=len(t)
    return result+[0]
def quotient(t,kernel):
    # Use least-bit pivots so the retained ordered basis agrees with the
    # published tables. This is an actual quotient map, not a prefix cut.
    piv={}
    for v in kernel:
        for k in sorted(piv):
            if (v>>k)&1:v^=piv[k]
        if v:piv[(v&-v).bit_length()-1]=v
    assert all(not bracket(t,v,1<<j) for v in piv.values() for j in range(len(t)))
    keep=[i for i in range(len(t)) if i not in piv]
    pos={old:new for new,old in enumerate(keep)}
    def project(v):
        for k in sorted(piv):
            if (v>>k)&1:v^=piv[k]
        return sum(1<<pos[k] for k in bits(v))
    return [[project(t[i][j]) for j in keep] for i in keep]
def check(t,g):
    n=len(t);mask=(1<<n)-1;top=max(g)
    for i in range(n):
        assert t[i][i]==0
        for j in range(n):
            assert t[i][j]==t[j][i] and not(t[i][j]&~mask)
            assert all(g[k]==g[i]+g[j] for k in bits(t[i][j]))
    jc=ec=0
    for i,j,k in combinations(range(n),3):
        if g[i]+g[j]+g[k]>top:continue
        assert not(bracket(t,t[i][j],1<<k)^bracket(t,t[j][k],1<<i)^bracket(t,t[k][i],1<<j))
        jc+=1
    def word(y,a,b,c):
        return bracket(t,bracket(t,t[y][a],1<<b),1<<c)
    for y in range(n):
        for i in range(n):
            if g[y]+3*g[i]<=top:
                assert not word(y,i,i,i)
                ec+=1
            for j in range(n):
                if i!=j and g[y]+2*g[i]+g[j]<=top:
                    assert not(word(y,i,i,j)^word(y,i,j,i)^word(y,j,i,i))
                    ec+=1
        for abc in combinations(range(n),3):
            if g[y]+sum(g[a] for a in abc)>top:continue
            value=0
            for a,b,c in permutations(abc):value^=word(y,a,b,c)
            assert not value
            ec+=1
    first=span(t[i][j] for i,j in combinations(range(n),2))
    second=span(bracket(t,a,b) for a in first for b in first)
    return {'dimension':n,'ordinary_generator_rank':n-len(first),
            'class':len(series(t,[1<<i for i in range(n)]))-1,
            'lower_dimensions':series(t,[1<<i for i in range(n)]),
            'second_derived_depth_dimensions':series(t,second),
            'Jacobi_coefficients':jc,'complete_cubic_Engel_coefficients':ec}
def main():
    start=time.monotonic()
    source=HERE/'rank4_chain_models.json'
    data=json.loads(source.read_text(encoding='utf-8-sig'))
    report={name:check(data[name]['table'],data[name]['grades']) for name in ('E','B','A')}
    assert [report[n]['dimension'] for n in ('E','B','A')]==[40,41,42]
    assert [report[n]['class'] for n in ('E','B','A')]==[6,6,7]
    for depth,name in enumerate(('E','B','A'),1):
        assert report[name]['ordinary_generator_rank']==4
        assert len(report[name]['second_derived_depth_dimensions'])-1<=depth
    at=data['A']['table']
    assert quotient(at,[1<<i for i,w in enumerate(data['A']['grades']) if w==7])==data['B']['table']
    bt=data['B']['table']
    first=span(bt[i][j] for i,j in combinations(range(len(bt)),2))
    second=span(bracket(bt,a,b) for a in first for b in first)
    assert quotient(bt,action(bt,second))==data['E']['table']
    out={'status':'PASS','models':report,'actual_central_quotient_maps':'PASS',
         'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
         'seconds':time.monotonic()-start}
    (HERE/'rank4_chain_check.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()

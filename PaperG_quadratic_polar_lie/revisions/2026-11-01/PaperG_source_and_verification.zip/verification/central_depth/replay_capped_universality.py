"""Independent replay of every graded universal-extension step.

This does not import the constructor or its matrix routines. Least-bit
pivots and a separate iteration order check the complete coefficient
systems, and check that the stored new brackets span each kernel.
"""
from pathlib import Path
from collections import defaultdict
import hashlib
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent

def bits(v):
    while v:
        x=v&-v;yield x.bit_length()-1;v-=x

def rem(v,piv):
    for k in sorted(piv):
        if (v>>k)&1:v^=piv[k]
    return v

def insert(v,piv):
    v=rem(v,piv)
    if v:piv[(v&-v).bit_length()-1]=v

def bracket(t,a,b):
    ans=0
    for i in bits(a):
        for j in bits(b):ans^=t[i][j]
    return ans

def main():
    cap=tuple(map(int,sys.argv[1].split(','))) if len(sys.argv)>1 else (4,1,1,1,1,1)
    assert len(cap)==6 and sum(cap)==9
    suffix='' if cap==(4,1,1,1,1,1) else '_cap_'+'_'.join(map(str,cap))
    source=HERE/f'capped_depth4_d6{suffix}_model.json'
    raw=json.loads(source.read_text());t=raw['table'];gr=raw['grades'];ms=list(map(tuple,raw['multis']))
    start=time.monotonic();reports=[]
    nall=len(t)
    assert all(gr[i]<=gr[i+1] for i in range(nall-1))
    assert gr[:6]==[1]*6
    for i in range(nall):
        assert t[i][i]==0
        for j in range(i+1,nall):
            assert t[i][j]==t[j][i]
            expected=tuple(a+b for a,b in zip(ms[i],ms[j]))
            assert all(gr[k]==gr[i]+gr[j] and ms[k]==expected for k in bits(t[i][j]))
    def within(m):return all(a<=b for a,b in zip(m,cap))
    def total(indices):return tuple(sum(ms[i][j] for i in indices) for j in range(6))
    for weight in range(2,10):
        n=next((i for i,g in enumerate(gr) if g>=weight),nall)
        bg=defaultdict(list)
        for i in range(n):bg[gr[i]].append(i)
        pairs=[]
        for i in range(n):
            for j in bg[weight-gr[i]]:
                if j>i and within(total((i,j))):pairs.append((i,j))
        pix={ij:k for k,ij in enumerate(pairs)}
        def wedge(v,j):
            ans=0
            for i in bits(v):
                if i==j:continue
                k=pix.get((min(i,j),max(i,j)))
                if k is not None:ans^=1<<k
            return ans
        piv={};counts=defaultdict(int)
        def equation(row,kind):
            insert(row,piv);counts[kind]+=1
        for i in range(n):
            if 3*gr[i]>weight:break
            for j in range(i+1,n):
                if gr[i]+2*gr[j]>weight:break
                for k in bg[weight-gr[i]-gr[j]]:
                    if k<=j or not within(total((i,j,k))):continue
                    equation(wedge(t[i][j],k)^wedge(t[j][k],i)^wedge(t[k][i],j),'Jacobi')
        rank_ce=len(piv)
        cache={}
        for i in range(n):
            if 3*gr[i]>=weight:break
            for j in range(i,n):
                if gr[i]+2*gr[j]>=weight:break
                for wk in range(gr[j],weight-gr[i]-gr[j]):
                    for k in bg[wk]:
                        if k<j:continue
                        partial=total((i,j,k))
                        if not within(partial):continue
                        for y in bg[weight-gr[i]-gr[j]-gr[k]]:
                            if not within(tuple(a+b for a,b in zip(partial,ms[y]))):continue
                            row=0
                            for a,b,c in set(itertools.permutations((i,j,k))):
                                key=(y,a,b)
                                if key not in cache:cache[key]=bracket(t,t[y][a],1<<b)
                                row^=wedge(cache[key],c)
                            equation(row,'cubic_Engel')
        rank_engel=len(piv)
        if weight>=8:
            # M3 of the prefix only needs weights <= weight-1. Therefore
            # its initial M0 may be cut at weight-4, without losing any
            # contribution to the weight-th extension constraints.
            layer={}
            for i in range(6,n):
                for j in range(i+1,n):
                    if gr[i]+gr[j]>weight-4:break
                    insert(t[i][j],layer)
            for step in range(1,4):
                nxt={};limit=weight-4+step
                for val in layer.values():
                    index=(val&-val).bit_length()-1
                    assert all(gr[k]==gr[index] and ms[k]==ms[index] for k in bits(val))
                    for j in range(n):
                        if gr[index]+gr[j]>limit:break
                        if within(tuple(a+b for a,b in zip(ms[index],ms[j]))):
                            insert(bracket(t,val,1<<j),nxt)
                layer=nxt
            for val in layer.values():
                index=(val&-val).bit_length()-1
                for j in bg[weight-gr[index]]:
                    if within(tuple(a+b for a,b in zip(ms[index],ms[j]))):
                        row=wedge(val,j)
                        if row:equation(row,'depth4')
        added=[i for i,g in enumerate(gr) if g==weight]
        actual={i:0 for i in added}
        for pos,(i,j) in enumerate(pairs):
            for k in bits(t[i][j]):actual[k]^=1<<pos
        assert len(added)==len(pairs)-len(piv),('Wrong universal dimension',weight,len(added),len(pairs),len(piv))
        rank_actual={}
        for form in actual.values():
            assert all((form&row).bit_count()%2==0 for row in piv.values())
            insert(form,rank_actual)
        assert len(rank_actual)==len(added),'Stored bracket coordinates do not span the universal kernel'
        report={'weight':weight,'prefix_dimension':n,'cochain_columns':len(pairs),
                'Jacobi_rank':rank_ce,'Jacobi_Engel_rank':rank_engel,'full_rank':len(piv),
                'universal_kernel_dimension':len(added),'actual_kernel_rank':len(rank_actual),
                'equations':dict(counts),'seconds':time.monotonic()-start}
        reports.append(report);print(json.dumps(report),flush=True)
        assert time.monotonic()-start<180,'Bounded audit time exceeded'
    assert reports[-1]['universal_kernel_dimension']==0
    out={'status':'PASS','cap':cap,'stages':reports,
         'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
         'independent_implementation':'No constructor imports; least-bit pivots; every stored kernel checked',
         'meaning':'Inductive universal-extension replay, not just validation of a finite example.',
         'seconds':time.monotonic()-start}
    dest=HERE/('universal_replay_'+'_'.join(map(str,cap))+'.json')
    dest.write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()

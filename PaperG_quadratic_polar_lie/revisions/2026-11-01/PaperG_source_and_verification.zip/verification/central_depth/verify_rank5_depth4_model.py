"""Independently check the concrete rank-five depth-four witness over F4.

Only standard-library arithmetic is used. Full cubic coefficients are
checked, rather than samples with binary input coordinates.
"""
from pathlib import Path
import itertools
import json
import time

HERE=Path(__file__).resolve().parent

def bits(v):
    while v:
        lo=v&-v;yield lo.bit_length()-1;v-=lo

def bracket(table,a,b):
    out=0
    for i in bits(a):
        for j in bits(b):out^=table[i][j]
    return out

def reduce(v,piv):
    for k in sorted(piv):
        if (v>>k)&1:v^=piv[k]
    return v

def span(values):
    piv={}
    for val in values:
        val=reduce(val,piv)
        if val:piv[(val&-val).bit_length()-1]=val
    return piv

def comm(table,a,b):return span(bracket(table,x,y) for x in a for y in b)

def series(table):
    gs=[1<<i for i in range(len(table))];cur=gs;dims=[len(cur)]
    while cur:
        cur=list(comm(table,cur,gs).values());dims.append(len(cur))
        assert len(dims)<=10
    return dims

def quotient(table,ideal):
    assert all(not reduce(bracket(table,x,1<<i),ideal) for x in ideal.values() for i in range(len(table)))
    keep=[i for i in range(len(table)) if i not in ideal];ix={i:j for j,i in enumerate(keep)}
    project=lambda v:sum(1<<ix[i] for i in bits(reduce(v,ideal)))
    return [[project(table[i][j]) for j in keep] for i in keep]

def main():
    start=time.monotonic()
    raw=json.loads((HERE/'capped_depth4_d5_model.json').read_text())
    table=raw['table'];grades=raw['grades'];multis=raw['multis'];n=len(table)
    I=[1<<i for i in range(n)];cap=(4,1,1,1,1)
    for i in range(n):
        assert table[i][i]==0
        for j in range(n):
            assert table[i][j]==table[j][i]
            expected=tuple(a+b for a,b in zip(multis[i],multis[j]))
            assert all(grades[k]==grades[i]+grades[j] and tuple(multis[k])==expected for k in bits(table[i][j]))
    def feasible(indices):
        return sum(grades[i] for i in indices)<=8 and all(sum(multis[i][j] for i in indices)<=cap[j] for j in range(5))
    jacobi=0
    for i,j,k in itertools.combinations(range(n),3):
        if not feasible((i,j,k)):continue
        assert not (bracket(table,table[i][j],I[k])^bracket(table,table[j][k],I[i])^bracket(table,table[k][i],I[j]))
        jacobi+=1
    triples=[]
    for tri in itertools.combinations_with_replacement(range(n),3):
        if feasible(tri) and sum(grades[i] for i in tri)<=7:
            triples.append((tri,tuple(set(itertools.permutations(tri)))))
    cubic=0
    for y in range(n):
        for tri,perms in triples:
            if not feasible((y,)+tri):continue
            val=0
            for i,j,k in perms:
                val^=bracket(table,bracket(table,table[y][i],I[j]),I[k])
            assert val==0
            cubic+=1
    derived=span(table[i][j] for i,j in itertools.combinations(range(n),2))
    layer=comm(table,list(derived.values()),list(derived.values()));layers=[layer]
    for _ in range(4):layers.append(comm(table,list(layers[-1].values()),I))
    assert layers[3] and not layers[4]
    generated=span(I[:5])
    while True:
        expanded=span([*generated.values(),*(bracket(table,x,y) for x in generated.values() for y in I[:5])])
        if len(expanded)==len(generated):break
        generated=expanded
    assert len(generated)==n and len(derived)==n-5
    dims=series(table);assert len(dims)-1==8
    p,q,a,h,r=I[:5]
    def word(x,*rest):
        for y in rest:x=bracket(table,x,y)
        return x
    witness=word(bracket(table,word(p,q,p),bracket(table,p,a)),h,p,r)
    assert witness and not reduce(witness,layers[3])
    assert all(grades[i]==8 for i in bits(witness))
    chain=[]
    for depth in (1,2,3):
        qt=quotient(table,layers[depth]);lower=series(qt)
        d=span(qt[i][j] for i,j in itertools.combinations(range(len(qt)),2))
        chain.append({'quotient_by':f'M{depth}','dimension':len(qt),
                      'class':len(lower)-1,'rank':len(qt)-len(d),'lower_dimensions':lower})
    assert [item['class'] for item in chain]==[7,7,7]
    assert all(item['rank']==5 for item in chain)
    out={'status':'PASS','field':'F4','dimension':n,'generator_rank':5,'class':8,
         'lower_dimensions':dims,'second_derived_depth_dimensions':[len(x) for x in layers],
         'complete_cubic_coefficients_checked':cubic,'Jacobi_triples_checked':jacobi,
         'excluded_equations':'Zero by the verified grading and multidegree support.',
         'nonzero_word':'[[[p,q],p],[p,a],h,p,r]',
         'nonzero_word_coordinates':list(bits(witness)),'quotients':chain,
         'scope':'A concrete rank-five ordinary F4 Lie algebra, not an arbitrary-rank family.',
         'seconds':time.monotonic()-start}
    (HERE/'rank5_depth4_independent_model_check.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()

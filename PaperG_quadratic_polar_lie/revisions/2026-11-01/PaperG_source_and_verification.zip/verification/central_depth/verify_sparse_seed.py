"""Independent replay: 3-bit noncommutative words, no prior algebra imports."""
from pathlib import Path
from collections import Counter
import copy
import itertools
import json

HERE=Path(__file__).resolve().parent

def plus(*polys):
    counts=Counter()
    for poly in polys:counts.update(poly)
    return frozenset(mon for mon,n in counts.items() if n%2)

def bracket(a,b):
    counts=Counter()
    for na,wa in a:
        for nb,wb in b:
            counts[(na+nb,(wa<<(3*nb))|wb)]+=1
            counts[(na+nb,(wb<<(3*na))|wa)]+=1
    return frozenset(mon for mon,n in counts.items() if n%2)

def word(a,*rest):
    for b in rest:a=bracket(a,b)
    return a

def parse(poly):
    out=[]
    for mon in poly:
        value=0
        for i in mon:
            assert 0<=i<5
            value=(value<<3)|i
        out.append((len(mon),value))
    assert len(set(out))==len(out)
    return frozenset(out)

G=[frozenset({(1,i)}) for i in range(5)]
ALLOWED=set(G)
for x,y in itertools.product(G,repeat=2):
    b=bracket(x,y)
    ALLOWED.add(b)
    for z in G:ALLOWED.add(bracket(b,z))

def replay(data):
    values=[];counts=Counter()
    for i,node in enumerate(data['nodes']):
        kind=node['kind'];counts[kind]+=1
        if kind=='engel_coefficient':
            y=parse(node['y']);fs=list(map(parse,node['factors']))
            assert len(fs)==3 and all(x in ALLOWED for x in [y]+fs)
            pat=node['index_pattern'];assert len(pat)==3
            mp={x:fs[j] for j,x in enumerate(pat)}
            assert all(mp[x]==fs[j] for j,x in enumerate(pat))
            value=plus(*(word(y,*(mp[x] for x in seq)) for seq in set(itertools.permutations(pat))))
        elif kind=='second_derived_depth_three':
            fs=list(map(parse,node['factors']))
            assert len(fs)==7 and all(x in ALLOWED for x in fs)
            value=word(bracket(bracket(fs[0],fs[1]),bracket(fs[2],fs[3])),*fs[4:])
        elif kind=='bracket':
            assert 0<=node['left']<i
            right=parse(node['right']);assert right in ALLOWED
            value=bracket(values[node['left']],right)
        elif kind=='xor':
            assert all(0<=j<i for j in node['children'])
            value=plus(*(values[j] for j in node['children']))
        else:raise AssertionError(kind)
        values.append(value)
    p,q,a,h,r=G
    expected=word(bracket(word(bracket(p,q),q,r),bracket(p,a)),h,r)
    assert values[data['root']]==parse(data['target'])==expected
    return dict(counts)

def main():
    data=json.loads((HERE/'sparse_seed_certificate.json').read_text())
    counts=replay(data)
    mutations=[]
    bad=copy.deepcopy(data);bad['nodes'][bad['root']]['children'].pop()
    mutations.append(('omit_a_depth_value',bad))
    bad=copy.deepcopy(data);bad['nodes'][0]['index_pattern']=[0,1,2]
    mutations.append(('double_count_repeated_Engel_slots',bad))
    bad=copy.deepcopy(data);bad['nodes'][0]['y']=[[0,0]]
    mutations.append(('non_Lie_input',bad))
    rejected=[]
    for label,bad in mutations:
        try:replay(bad)
        except (AssertionError,KeyError,IndexError):rejected.append(label)
    assert len(rejected)==len(mutations)
    out={'status':'PASS','nodes':len(data['nodes']),'node_kinds':counts,
         'negative_controls_rejected':rejected,
         'implementation':'3-bit words and parity counters; no generator or previous verifier imports',
         'meaning':'Universal polynomial proof. Not finite-model sampling, external peer review, or Lean.'}
    (HERE/'sparse_seed_independent_replay.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()

"""Coordinate checks of the symbolic suspension spanning proof over F4."""
from pathlib import Path
import itertools
import json
import time

HERE=Path(__file__).resolve().parent

def mul(a,b):
    out=0
    while b:
        if b&1:out^=a
        b>>=1;a<<=1
        if a&4:a^=7
    return out

def put(p,key,value=1):
    p[key]=p.get(key,0)^value
    if not p[key]:del p[key]

def add(*polys):
    p={}
    for q in polys:
        for key,value in q.items():put(p,key,value)
    return p

def scalar(poly,a):return {key:mul(v,a) for key,v in poly.items() if mul(v,a)}

def term(mask,a,b):return {(mask,tuple(sorted((a,b)))):1}

def sigma(poly,i,y):
    out={}
    for (mask,pair),value in poly.items():
        if pair.count(i)!=1:continue
        z=pair[1] if pair[0]==i else pair[0]
        if not (mask>>y)&1:put(out,(mask|(1<<y),tuple(sorted((i,z)))),value)
        if not (mask>>i)&1:put(out,(mask|(1<<i),tuple(sorted((y,z)))),value)
    return out

def shear(poly,i,j):
    out={}
    for (mask,(a,b)),value in poly.items():
        masks=[mask]
        if (mask>>i)&1 and not (mask>>j)&1:masks.append((mask^(1<<i))|(1<<j))
        aa=[a,j] if a==i else [a]
        bb=[b,j] if b==i else [b]
        for r,x,y in itertools.product(masks,aa,bb):
            put(out,(r,tuple(sorted((x,y)))),value)
    return out

def diagonal(poly,i):
    out={}
    for (mask,pair),value in poly.items():
        degree=((mask>>i)&1)+pair.count(i)
        factor=(1,2,3)[degree%3]
        put(out,(mask,pair),mul(value,factor))
    return out

def boundary(poly):
    out={}
    for (mask,(a,b)),value in poly.items():
        if not (mask>>a)&1:put(out,(mask|(1<<a),b),value)
        if not (mask>>b)&1:put(out,(mask|(1<<b),a),value)
    return out

def run(n):
    allmask=(1<<n)-1;counts={'missing_cross':0,'missing_square':0,'full_support_difference':0,'full_support_square':0}
    for u,v in itertools.product(range(n),repeat=2):
        for j in range(n):
            others=[a for a in range(n) if a!=j]
            for a,b in itertools.combinations(others,2):
                y=next(k for k in range(n) if k not in {j,a,b,u,v})
                oldmask=allmask^(1<<y)
                source=term(oldmask^(1<<j),a,b)
                target=term(allmask^(1<<j),a,b)
                assert not boundary(source) and sigma(source,a,y)==target
                counts['missing_cross']+=1
            for b in others:
                a=next(k for k in range(n) if k not in {j,b,u,v})
                cross=term(allmask^(1<<j),a,b)
                target=term(allmask^(1<<j),b,b)
                assert add(shear(cross,a,b),cross)==target
                assert a not in {u,v}
                counts['missing_square']+=1
        for i in range(n):
            others=[a for a in range(n) if a!=i]
            for a,b in itertools.combinations(others,2):
                y=next(k for k in range(n) if k not in {i,a,b,u,v})
                oldmask=allmask^(1<<y)
                source=add(term(oldmask^(1<<i),i,i),term(oldmask^(1<<a),i,a),term(oldmask^(1<<b),i,b))
                target=add(term(allmask^(1<<a),i,a),term(allmask^(1<<b),i,b))
                assert not boundary(source) and sigma(source,i,y)==target
                counts['full_support_difference']+=1
        for j in range(n):
            i=next(k for k in range(n) if k not in {j,u,v})
            missing=term(allmask^(1<<j),i,i)
            other=term(allmask^(1<<i),j,j)
            both=add(shear(missing,i,j),missing,other)
            assert both==add(term(allmask^(1<<i),i,i),term(allmask^(1<<j),j,j))
            isolated=add(diagonal(both,i),scalar(both,3))
            assert isolated==term(allmask^(1<<j),j,j)
            assert not boundary(isolated)
            counts['full_support_square']+=1
    return {'rank':n,'cases':counts,'total_cases':sum(counts.values()),
            'kernel_dimension':n*(n-1)*(n+2)//2}

def main():
    start=time.monotonic();results=[run(n) for n in range(7,11)]
    out={'status':'PASS','field':'F4','ranks':[7,10],'results':results,
         'total_cases':sum(r['total_cases'] for r in results),'seconds':time.monotonic()-start,
         'scope':'Exact controls of every displayed spanning construction. The arbitrary-rank claim uses the symbolic proof.'}
    (HERE/'fourth_layer_suspension_controls.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()

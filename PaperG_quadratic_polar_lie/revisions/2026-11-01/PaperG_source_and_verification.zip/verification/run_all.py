"""Replay all controls in an isolated copy; never overwrite supplied JSON.

Run from the source-project directory:
    python verification/run_all.py
    python verification/run_all.py --output-dir ../PaperG_replay
    python verification/run_all.py --no-write

Python >=3.10; the rank checker requires SymPy (tested with 1.14.0).
The last option leaves no persistent runner output. Failures are collected
across all programs. These controls do not replace the general proofs.
"""
from pathlib import Path
from datetime import datetime, timezone
from importlib import metadata
import argparse
import hashlib
import json
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
PROGRAMS = (
    'check_chain_rank_certificates.py',
    'audit_metabelian_symbolic_interfaces.py',
    'manuscript_transcription_checks.py',
    'canonical_family_controls.py',
    'remaining_data_cohomology_controls.py',
    'automorphism_kernel_controls.py',
    'low_class_parameter_orbits.py',
    'mu_extremizers/mu_module_controls.py',
    'mu_extremizers/parabolic_action_controls.py',
    'mu_extremizers/root_mu_action_controls.py',
    'mu_extremizers/root_mu_d4_orbits.py',
    'mu_extremizers/mu_orbit_fresh_controls.py',
    'mu_extremizers/aut_kernel_fresh_controls.py',
    'near_minimum_controls.py',
    'fixed_surplus/fixed_r_lower_controls.py',
    'fixed_surplus/count_bookkeeping_checks.py',
    'fixed_surplus/nonsplit_module_checks.py',
    'fixed_surplus/finite_field_scope_controls.py',
    'surplus_transition/transition_quotient_controls.py',
    'surplus_transition/exact_cohomology_controls.py',
    'surplus_transition/shear_and_exterior_controls.py',
    'critical_constant/action_subspace_controls.py',
    'critical_constant/all_fixed_r_controls.py',
    'critical_constant/coupled_defect_controls.py',
    'critical_window/growing_principal_controls.py',
    'critical_window/higher_coupled_defect_controls.py',
    'action_cohomology/check_defect_one_interfaces.py',
    'action_cohomology/check_ce_deficit.py',
    'action_cohomology/check_population_interfaces.py',
    'critical_refinement/check_maxsoc_rigidity.py',
    'critical_refinement/check_critical_staircase.py',
    'structural_reconstruction/check_canonical_interfaces.py',
    'structural_reconstruction/check_lie_twist.py',
    'structural_reconstruction/check_graph_interfaces.py',
    'structural_reconstruction/check_hidden_linearization.py',
    'structural_reconstruction/check_cohomology_rotation.py',
    'structural_reconstruction/check_freeclass3_rank2_rotation.py',
    'structural_reconstruction/check_rank3_class4_seed.py',
    'structural_reconstruction/verify_aut_f14.py',
    'structural_reconstruction/verify_two_frame.py',
    'general_structure/check_explicit_models.py',
    'general_structure/check_derived_factor_counterexample.py',
    'general_structure/check_reset_family.py',
    'general_structure/check_quadratic_invariants.py',
    'general_structure/check_free_binary_ce.py',
    'general_structure/check_orientation_rigidity.py',
    'general_structure/check_normal_center.py',
    'general_structure/check_global_stability_interfaces.py',
    'general_structure/check_rank_class_bridge.py',
    'general_structure/check_ordinary_top_cover.py',
)

# New controls require explicit fresh report paths. Older controls run
# unchanged in the existing isolated verification copy.
REPORT_CONTROLS = (
    'critical_constant/action_subspace_controls.py',
    'critical_constant/all_fixed_r_controls.py',
    'critical_constant/coupled_defect_controls.py',
    'critical_window/growing_principal_controls.py',
    'critical_window/higher_coupled_defect_controls.py',
    'action_cohomology/check_defect_one_interfaces.py',
    'action_cohomology/check_ce_deficit.py',
    'action_cohomology/check_population_interfaces.py',
    'critical_refinement/check_maxsoc_rigidity.py',
    'critical_refinement/check_critical_staircase.py',
    'structural_reconstruction/check_canonical_interfaces.py',
    'structural_reconstruction/check_lie_twist.py',
    'structural_reconstruction/check_graph_interfaces.py',
    'structural_reconstruction/check_hidden_linearization.py',
    'structural_reconstruction/check_cohomology_rotation.py',
    'structural_reconstruction/check_freeclass3_rank2_rotation.py',
    'structural_reconstruction/check_rank3_class4_seed.py',
    'structural_reconstruction/verify_aut_f14.py',
    'structural_reconstruction/verify_two_frame.py',
    'general_structure/check_explicit_models.py',
    'general_structure/check_derived_factor_counterexample.py',
    'general_structure/check_reset_family.py',
    'general_structure/check_quadratic_invariants.py',
    'general_structure/check_free_binary_ce.py',
    'general_structure/check_orientation_rigidity.py',
    'general_structure/check_normal_center.py',
    'general_structure/check_global_stability_interfaces.py',
    'general_structure/check_rank_class_bridge.py',
    'general_structure/check_ordinary_top_cover.py',
)


def json_hashes():
    return {str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(HERE.rglob('*.json'))}


def run(output, timeout):
    work, logs = output / 'verification', output / 'logs'
    shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    logs.mkdir()
    before = json_hashes()
    records = []
    started = time.monotonic()
    try:
        sympy_version = metadata.version('sympy')
    except metadata.PackageNotFoundError:
        sympy_version = None
    for index, name in enumerate(PROGRAMS, 1):
        task_start = time.monotonic()
        command = [sys.executable, '-E', '-X', 'utf8', str(work / name)]
        if name in REPORT_CONTROLS:
            command.extend(['--report', str(logs / f'{index:02d}_{Path(name).stem}.json')])
        try:
            result = subprocess.run(
                command,
                cwd=work, capture_output=True, text=True, encoding='utf-8',
                errors='replace', timeout=timeout)
            stdout, stderr, code = result.stdout, result.stderr, result.returncode
            # Checkers use both compact and pretty-printed JSON; some print
            # several top-level records. Decode whole objects, not last lines.
            statuses = []
            decoder = json.JSONDecoder()
            for match in re.finditer(r'(?m)^\{', stdout):
                try:
                    item, _ = decoder.raw_decode(stdout, match.start())
                except ValueError:
                    continue
                if isinstance(item, dict) and 'status' in item:
                    statuses.append(item['status'])
            reported_status = ('PASS' if statuses and all(s == 'PASS' for s in statuses)
                               else 'FAIL' if statuses else None)
            passed = code == 0 and reported_status == 'PASS'
        except subprocess.TimeoutExpired as exc:
            stdout, stderr, code = '', f'TIMEOUT after {timeout}s: {exc}', None
            reported_status, passed = None, False
        except OSError as exc:
            stdout, stderr, code = '', str(exc), None
            reported_status, passed = None, False
        log_name = f'{index:02d}_{Path(name).stem}.txt'
        (logs / log_name).write_text(stdout + '\nSTDERR\n' + stderr, encoding='utf-8')
        record = {'program': name, 'status': 'PASS' if passed else 'FAIL',
                  'exit_code': code, 'reported_status': reported_status,
                  'seconds': round(time.monotonic() - task_start, 3),
                  'log': f'logs/{log_name}'}
        records.append(record)
        print(f"[{index}/{len(PROGRAMS)}] {record['status']} {name}", flush=True)
    after = json_hashes()
    source_unchanged = before == after
    failures = [r['program'] for r in records if r['status'] != 'PASS']
    report = {
        'status': 'PASS' if not failures and source_unchanged else 'FAIL',
        'python_version': platform.python_version(),
        'python_implementation': platform.python_implementation(),
        'sympy_version': sympy_version,
        'verified_at_utc': datetime.now(timezone.utc).isoformat(),
        'seconds': round(time.monotonic() - started, 3),
        'program_count': len(PROGRAMS), 'failed_programs': failures,
        'source_json_unchanged': source_unchanged,
        'source_json_sha256': before, 'records': records,
        'scope': 'Exact certificate/orbit/rank checks and labelled sampled controls; '
                 'not an all-parameter proof or a proof-assistant formalization.'}
    (output / 'replay_summary.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--output-dir', type=Path, help='Use a new or empty directory outside verification/.')
    group.add_argument('--no-write', action='store_true', help='Run in a temporary copy, then discard outputs.')
    parser.add_argument('--timeout', type=float, default=300, help='Per-program timeout in seconds (default: 300).')
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        parser.error('Python 3.10 or later is required')
    if args.timeout <= 0:
        parser.error('--timeout must be positive')
    if args.no_write:
        # Keep transient writes beside the project, avoiding redirected or
        # read-only system temporary directories on restricted Windows hosts.
        with tempfile.TemporaryDirectory(prefix='.PaperG_replay_', dir=HERE.parent) as temp:
            temp_path = Path(temp).resolve()
            assert temp_path.parent == HERE.parent
            assert temp_path.name.startswith('.PaperG_replay_')
            report = run(temp_path, args.timeout)
        print(json.dumps({key: value for key, value in report.items()
                          if key not in ('source_json_sha256', 'records')}, ensure_ascii=False))
    else:
        output = (args.output_dir or HERE.parent / 'verification_runs' /
                  datetime.now().strftime('%Y%m%d_%H%M%S_%f')).resolve()
        if output == HERE or HERE in output.parents:
            parser.error('Output must be outside verification/ to prevent recursive copying')
        if output.exists() and (not output.is_dir() or any(output.iterdir())):
            parser.error('Output directory must be new or empty')
        output.mkdir(parents=True, exist_ok=True)
        report = run(output, args.timeout)
        print(json.dumps({'status': report['status'], 'program_count': report['program_count'],
                          'failed_programs': report['failed_programs'],
                          'source_json_unchanged': report['source_json_unchanged'],
                          'report': str(output / 'replay_summary.json')}, ensure_ascii=False))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())

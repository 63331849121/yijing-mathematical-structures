"""Exact finite ordinary-F4 Engel control primitives.

The raw universal module is reconstructed from square-zero monomials and
all Jacobi relations. No certificate, construction input, network, or path
outside this verification package is read. Helpers are not separate controls.
"""
import itertools
import random
import time

def bits(x):
    while x:
        bit = x & -x
        yield bit.bit_length() - 1
        x ^= bit

def insert(pivots, row):
    while row:
        p = row.bit_length() - 1
        if p in pivots:
            row ^= pivots[p]
        else:
            pivots[p] = row
            return True
    return False

def remainder(pivots, row):
    out = 0
    while row:
        p = row.bit_length() - 1
        if p in pivots:
            row ^= pivots[p]
        else:
            out ^= 1 << p
            row ^= 1 << p
    return out

def nullspace(pivots, width):
    result = []
    for f in range(width):
        if f in pivots:
            continue
        row = 1 << f
        for p in sorted(pivots):
            if (pivots[p] & row).bit_count() & 1:
                row ^= 1 << p
        result.append(row)
    return result

def make_H(d):
    pairs = list(itertools.combinations(range(d), 2))
    pindex = {p: i for i, p in enumerate(pairs)}
    size = 1 << d
    relations = {}
    for i, j, k in itertools.combinations(range(d), 3):
        for mask in range(size):
            row = 0
            for pair, a in (((i,j), k), ((i,k), j), ((j,k), i)):
                if not (mask >> a) & 1:
                    row ^= 1 << (pindex[pair]*size + (mask | (1 << a)))
            insert(relations, row)
    free = [j for j in range(len(pairs)*size) if j not in relations]
    f_index = {raw: i+d for i, raw in enumerate(free)}

    def quotient(raw):
        reduced = remainder(relations, raw)
        out = 0
        for j in bits(reduced):
            out ^= 1 << f_index[j]
        return out

    n = d + len(free)
    table = [[0]*n for _ in range(n)]
    for i,j in pairs:
        table[i][j] = table[j][i] = quotient(1 << (pindex[(i,j)]*size))
    labels = [f'x{i+1}' for i in range(d)]
    for raw in free:
        p, mask = divmod(raw, size)
        i,j = pairs[p]
        support = ''.join(str(k+1) for k in bits(mask))
        labels.append(f'a{i+1}{j+1}*t[{support}]' if mask else f'a{i+1}{j+1}')
        col = f_index[raw]
        for a in range(d):
            value = 0 if (mask >> a) & 1 else quotient(1 << (p*size+(mask | (1 << a))))
            table[a][col] = table[col][a] = value
    return table, labels

def bracket(table, u, v):
    out = 0
    for a in bits(u):
        for b in bits(v):
            out ^= table[a][b]
    return out

def lower(table):
    n = len(table)
    current = {i:1 << i for i in range(n)}
    series = [list(current.values())]
    while current:
        nxt = {}
        for u in current.values():
            for i in range(n):
                insert(nxt, bracket(table,u,1 << i))
        series.append(list(nxt.values()))
        current = nxt
    return series

def generated_dimension(table, d):
    pivots = {i:1 << i for i in range(d)}
    while True:
        old = list(pivots.values())
        count = len(pivots)
        for i, u in enumerate(old):
            for v in old[i+1:]:
                insert(pivots, bracket(table, u, v))
        if len(pivots) == count:
            return count

def actual_F4_Engel_control(table, quotient_n):
    mul=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
    n=len(table)
    supports=[[tuple(bits(table[i][j])) for j in range(n)] for i in range(n)]

    def b(u,x):
        out=[0]*n
        for i,ui in enumerate(u):
            if not ui:
                continue
            for j,xj in enumerate(x):
                if not xj:
                    continue
                coefficient=mul[ui][xj]
                for k in supports[i][j]:
                    out[k]^=coefficient
        return out

    if quotient_n==6:
        inputs=itertools.product(range(4),repeat=quotient_n)
        scope='All 4096 F4 inputs of H2, with all six F4 basis y; central coordinate irrelevant.'
    else:
        rng=random.Random(20261031)
        inputs=(tuple(rng.randrange(4) for _ in range(quotient_n)) for _ in range(64))
        scope='64 deterministic dense F4 input controls; complete cubic coefficient check supplies the all-input result.'
    count=0
    for raw in inputs:
        x=list(raw)+[0]*(n-quotient_n)
        for yi in range(quotient_n):
            y=[0]*n
            y[yi]=1
            for _ in range(3):
                y=b(y,x)
            assert not any(y)
        count+=1
    return {'input_vectors_checked':count,'basis_y_checked_per_input':quotient_n,'scope':scope}

def ordinary_ce_control(d, table=None, labels=None):
    if table is None:
        table, labels = make_H(d)
    n = len(table)
    pairs = list(itertools.combinations(range(n), 2))
    pairindex = {p:i for i,p in enumerate(pairs)}
    width = len(pairs)

    def wedge(v, a):
        row = 0
        for b in bits(v):
            if b != a:
                row ^= 1 << pairindex[tuple(sorted((a,b)))]
        return row

    ce_rows = []
    for a,b,c in itertools.combinations(range(n),3):
        row = wedge(table[a][b], c) ^ wedge(table[b][c], a) ^ wedge(table[c][a], b)
        ce_rows.append(row)
    ce_pivots = {}
    for row in ce_rows:
        insert(ce_pivots, row)

    # Independently check the actual quotient Lie table has Jacobi.
    for a,b,c in itertools.combinations(range(n),3):
        assert (bracket(table,table[a][b],1 << c)
                ^ bracket(table,table[b][c],1 << a)
                ^ bracket(table,table[c][a],1 << b)) == 0
    assert generated_dimension(table,d) == n

    cubic_rows = []
    nested = [[[bracket(table,table[y][i],1 << j) for j in range(n)]
               for i in range(n)] for y in range(n)]
    for y in range(n):
        for triple in itertools.combinations_with_replacement(range(n),3):
            row = 0
            base_value=0
            for i,j,k in set(itertools.permutations(triple)):
                row ^= wedge(nested[y][i][j],k)
                base_value ^= bracket(table,nested[y][i][j],1 << k)
            assert base_value==0
            cubic_rows.append(row)
    all_pivots = dict(ce_pivots)
    for row in cubic_rows:
        insert(all_pivots,row)
    z_basis = nullspace(all_pivots,width)
    for z in z_basis:
        assert all(not ((row & z).bit_count() & 1) for row in ce_rows)
        assert all(not ((row & z).bit_count() & 1) for row in cubic_rows)

    coboundary_pivots = {}
    for target in range(n):
        row = sum(1 << p for p,(a,b) in enumerate(pairs)
                  if (table[a][b] >> target) & 1)
        insert(coboundary_pivots,row)
        assert all(not ((r & row).bit_count() & 1) for r in ce_rows+cubic_rows)

    series = lower(table)
    cls = len(series)-1
    top = series[-2]
    top_rows = [wedge(v,i) for v in top for i in range(n)]
    for b in coboundary_pivots.values():
        assert all(not ((r & b).bit_count() & 1) for r in top_rows)
    restriction_pivots = {}
    for row in top_rows:
        image = sum(1 << i for i,z in enumerate(z_basis)
                    if (row & z).bit_count() & 1)
        insert(restriction_pivots,image)

    witnesses = [z for z in z_basis if any((r & z).bit_count() & 1 for r in top_rows)]
    witness_data = None
    if witnesses:
        # A short canonical-nullspace representative; no global weight minimum claimed.
        witness = min(witnesses,key=lambda z:(z.bit_count(),z))
        ext = [row+[0] for row in table]+[[0]*(n+1)]
        for i,(a,b) in enumerate(pairs):
            if (witness >> i) & 1:
                ext[a][b] ^= 1 << n
                ext[b][a] ^= 1 << n
        extseries = lower(ext)
        assert len(extseries)-1 == cls+1
        assert generated_dimension(ext,d) == n+1
        weight_one_top_witnesses=[p for p in range(width)
            if all(not ((row >> p)&1) for row in ce_rows+cubic_rows)
            and any((row >> p)&1 for row in top_rows)]
        minimum_is_two=not weight_one_top_witnesses and witness.bit_count()==2
        witness_data = {
            'nonzero_alpha_basis_pairs': [[labels[a],labels[b]] for i,(a,b) in enumerate(pairs)
                                         if (witness >> i) & 1],
            'coefficient_on_each_displayed_pair':1,
            'extension_F4_dimension':n+1,
            'extension_class':len(extseries)-1,
            'extension_lower_F4_dimensions_including_zero':list(map(len,extseries)),
            'original_d_generators_span_extension':True,
            'all_CE_and_full_F4_cubic_coefficients_checked':True,
            'actual_F4_Engel_controls':actual_F4_Engel_control(ext,n),
            'coordinate_bitmask_hex':hex(witness),
            'minimal_nonzero_cochain_support_size':2 if minimum_is_two else None,
            'minimality_scope':('Every one-coordinate top witness is ruled out by the full linear constraints; this witness has exactly two nonzero coordinates.' if minimum_is_two else 'Short canonical-nullspace representative; no global support optimum asserted.'),
        }
    certificate=None
    if n==8:
        def cochain_terms(z):
            return [[labels[a],labels[b]] for i,(a,b) in enumerate(pairs)
                    if (z >> i)&1]
        certificate={
            'cochain_coordinate_basis_pairs':[[labels[a],labels[b]] for a,b in pairs],
            'bracket_table_binary_output_masks':table,
            'combined_constraint_pivot_rows_hex':[hex(all_pivots[p]) for p in sorted(all_pivots)],
            'Engel_cocycle_basis_pairs':[cochain_terms(z) for z in z_basis],
            'CE_coboundary_basis_pairs':[cochain_terms(z) for z in coboundary_pivots.values()],
            'coefficient_on_each_pair':1,
        }
    return {
        'd':d,'F4_dimension':n,'basis_labels':labels,
        'class':cls,'lower_F4_dimensions_including_zero':list(map(len,series)),
        'CE_C2_dimension':width,'CE_constraint_rank':len(ce_pivots),
        'CE_cocycle_dimension':width-len(ce_pivots),
        'CE_coboundary_dimension':len(coboundary_pivots),
        'CE_H2_dimension':width-len(ce_pivots)-len(coboundary_pivots),
        'full_F4_cubic_coefficients_checked':len(cubic_rows),
        'combined_CE_Engel_constraint_rank':len(all_pivots),
        'Engel_cocycle_dimension':len(z_basis),
        'Engel_extension_class_dimension':len(z_basis)-len(coboundary_pivots),
        'top_gamma_c_dimension':len(top),
        'top_restriction_rank':len(restriction_pivots),
        'class_increasing_rank_preserving_extension_exists':bool(witnesses),
        'witness':witness_data,
        'exact_linear_certificate':certificate,
    }

def degree(label):
    if label.startswith('x'):
        return 1
    if '*t[' not in label:
        return 2
    return 2+len(label.split('*t[')[1].rstrip(']'))

def check_deadline(deadline):
    if time.monotonic()>deadline:
        raise TimeoutError('Five-minute route limit reached; no larger rank is allowed.')

def graded_control(d,deadline):
    start=time.monotonic()
    table,labels=make_H(d)
    grades=list(map(degree,labels))
    n=len(table)
    cls=max(4,d+1)
    assert max(grades)==cls
    target=cls+1
    pairs=[(i,j) for i,j in itertools.combinations(range(n),2)
           if grades[i]+grades[j]==target]
    pairindex={p:k for k,p in enumerate(pairs)}
    width=len(pairs)

    def wedge(v,k):
        row=0
        for i in bits(v):
            p=pairindex.get(tuple(sorted((i,k))))
            if p is not None:
                row^=1 << p
        return row

    ce_rows=[]
    for a,b,c in itertools.combinations(range(n),3):
        if grades[a]+grades[b]+grades[c]!=target:
            continue
        row=wedge(table[a][b],c)^wedge(table[b][c],a)^wedge(table[c][a],b)
        ce_rows.append(row)
    ce_pivots={}
    for row in ce_rows:
        insert(ce_pivots,row)
    check_deadline(deadline)

    triples_by_weight={}
    for triple in itertools.combinations_with_replacement(range(n),3):
        weight=sum(grades[i] for i in triple)
        if weight<target:
            triples_by_weight.setdefault(weight,[]).append(tuple(set(itertools.permutations(triple))))
    nested_cache={}
    wedge_cache={}
    cubic_rows=[]
    for y in range(n):
        for permutations in triples_by_weight.get(target-grades[y],[]):
            row=0
            base_value=0
            for i,j,k in permutations:
                key=(y,i,j)
                if key not in nested_cache:
                    nested_cache[key]=bracket(table,table[y][i],1 << j)
                v=nested_cache[key]
                wk=(v,k)
                if wk not in wedge_cache:
                    wedge_cache[wk]=wedge(v,k)
                row^=wedge_cache[wk]
                base_value^=bracket(table,v,1 << k)
            assert base_value==0
            cubic_rows.append(row)
        check_deadline(deadline)
    pivots=dict(ce_pivots)
    for row in cubic_rows:
        insert(pivots,row)
    check_deadline(deadline)
    kernel=nullspace(pivots,width)
    for z in kernel:
        assert all(not ((r&z).bit_count()&1) for r in pivots.values())
    top_columns=[p for p,(i,j) in enumerate(pairs)
                 if (grades[i],grades[j]) in ((1,cls),(cls,1))]
    top_mask=sum(1 << p for p in top_columns)
    top_pivots={}
    for p in top_columns:
        image=sum(1 << i for i,z in enumerate(kernel) if (z >> p)&1)
        insert(top_pivots,image)
    witnesses=[z for z in kernel if z&top_mask]
    witness_data=None
    if witnesses:
        witness=min(witnesses,key=lambda z:(z.bit_count(),z))
        assert all(not ((r&witness).bit_count()&1) for r in ce_rows+cubic_rows)
        ext=[r+[0] for r in table]+[[0]*(n+1)]
        for p,(i,j) in enumerate(pairs):
            if (witness >> p)&1:
                ext[i][j]^=1 << n
                ext[j][i]^=1 << n
        series=lower(ext)
        assert len(series)-1==target
        assert generated_dimension(ext,d)==n+1
        witness_data={
            'alpha_nonzero_pairs':[[labels[i],labels[j]] for p,(i,j) in enumerate(pairs)
                                   if (witness >> p)&1],
            'coefficient_on_each_pair':1,
            'class':len(series)-1,
            'ordinary_generator_rank':d,
            'F4_dimension':n+1,
            'lower_F4_dimensions_including_zero':list(map(len,series)),
            'cochain_hex':hex(witness),
            'support_size':witness.bit_count(),
            'support_minimality':'Shortest canonical-nullspace basis vector with nonzero top; no global weight optimum asserted.',
        }
    forced_zero=all(remainder(pivots,1 << p)==0 for p in top_columns)
    assert forced_zero==(not witnesses)
    certificate={
        'd':d,'field':'F4; every matrix coefficient in F2',
        'cochain_weight':target,
        'basis_labels':labels,'basis_grades':grades,
        'cochain_coordinate_pairs':[[labels[i],labels[j]] for i,j in pairs],
        'CE_rank':len(ce_pivots),
        'combined_rank':len(pivots),
        'combined_pivot_rows_hex':[hex(pivots[p]) for p in sorted(pivots)],
        'top_coordinate_indices':top_columns,
        'top_coordinates_in_constraint_rowspace':forced_zero,
        'cochain_kernel_basis_hex':[hex(z) for z in kernel],
    }
    summary={
        'd':d,'H_F4_dimension':n,'H_class':cls,
        'grade_dimensions':{j:grades.count(j) for j in sorted(set(grades))},
        'target_central_weight':target,'cochain_variable_count':width,
        'CE_rows':len(ce_rows),'CE_rank':len(ce_pivots),
        'full_F4_cubic_coefficient_rows':len(cubic_rows),
        'combined_rank':len(pivots),'allowed_graded_cocycle_dimension':len(kernel),
        'coboundary_dimension_at_this_weight':0,
        'top_pair_count':len(top_columns),'top_restriction_rank':len(top_pivots),
        'all_top_coordinates_forced_zero':forced_zero,
        'class_increasing_extension_exists':bool(witnesses),
        'witness':witness_data,'seconds':time.monotonic()-start,
    }
    return summary,certificate

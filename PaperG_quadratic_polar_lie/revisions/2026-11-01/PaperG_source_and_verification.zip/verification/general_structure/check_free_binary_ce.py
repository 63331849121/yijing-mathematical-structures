"""Independent sparse CE check. Default read-only; --report uses exclusive create.

Constructs the actual binary polar bracket, not a stored CE matrix. Checks
Jacobi, ranks of d_2 and d_3, the deformation comparison, and the b2 formula
for d=1,2,3. No finite-field point enumeration or manuscript mutation.
"""
import argparse
import itertools
import json
from pathlib import Path


def mul(a, b):
    out = 0
    for _ in range(2):
        if b & 1:
            out ^= a
        a <<= 1
        if a & 4:
            a ^= 7
        b >>= 1
    return out


def rank(columns):
    pivots = {}
    for col in columns:
        while col:
            p = col.bit_length() - 1
            if p in pivots:
                col ^= pivots[p]
            else:
                pivots[p] = col
                break
    return len(pivots)


def build(d, deformed):
    edges = list(itertools.combinations(range(d), 2))
    edge_index = {edge: j for j, edge in enumerate(edges)}
    tensors = [(i, edge) for i in range(d) for edge in edges]
    # For i>k>j, remove i tensor (j,k) using its Jacobi relation.
    tbasis = [(i, edge) for i, edge in tensors if not i > edge[1]]
    tindex = {key: d + len(edges) + j for j, key in enumerate(tbasis)}
    n4 = d + len(edges) + len(tbasis)
    n = 2 * n4

    def tterms(i, edge):
        if (i, edge) in tindex:
            return [tindex[(i, edge)]]
        j, k = edge
        return [tindex[(j, (k, i))], tindex[(k, (j, i))]]

    def term(coord, coefficient):
        return coefficient << (2 * coord)

    def bracket_pair(a, b):
        i, aa = divmod(a, 2)
        j, bb = divmod(b, 2)
        ca, cb = 1 << aa, 1 << bb
        result = 0
        if i < d and j < d:
            if i == j:
                return 0
            if i > j:
                i, j, ca, cb = j, i, cb, ca
            edge = (i, j)
            result ^= term(d + edge_index[edge], mul(ca, cb))
            if deformed:
                for ti in tterms(i, edge):
                    result ^= term(ti, mul(mul(ca, ca), cb))
                for ti in tterms(j, edge):
                    result ^= term(ti, mul(ca, mul(cb, cb)))
        elif i < d and d <= j < d + len(edges):
            for ti in tterms(i, edges[j - d]):
                result ^= term(ti, mul(ca, cb))
        return result

    brackets = {(a, b): bracket_pair(a, b) for a, b in itertools.combinations(range(n), 2)}

    def br(a, b):
        if a == b:
            return 0
        return brackets[tuple(sorted((a, b)))]

    def br_vec(a, vec):
        out = 0
        while vec:
            low = vec & -vec
            j = low.bit_length() - 1
            out ^= br(a, j)
            vec ^= low
        return out

    pairs = list(itertools.combinations(range(n), 2))
    pindex = {pair: i for i, pair in enumerate(pairs)}

    def wedge(vec, a):
        out = 0
        while vec:
            low = vec & -vec
            j = low.bit_length() - 1
            if j != a:
                out ^= 1 << pindex[tuple(sorted((a, j)))]
            vec ^= low
        return out

    jacobi_checked = 0
    columns = []
    for a, b, c in itertools.combinations(range(n), 3):
        assert br_vec(a, br(b, c)) ^ br_vec(b, br(a, c)) ^ br_vec(c, br(a, b)) == 0
        column = wedge(br(a, b), c) ^ wedge(br(a, c), b) ^ wedge(br(b, c), a)
        columns.append(column)
        jacobi_checked += 1
    rank2 = rank(brackets.values())
    rank3 = rank(columns)
    b2 = len(pairs) - rank2 - rank3
    assert b2 == (d**4 + d**2) // 2
    assert rank2 == n - 2 * d
    return {
        "d": d,
        "deformed": deformed,
        "binary_dimension": n,
        "rank_boundary_2": rank2,
        "rank_boundary_3": rank3,
        "b2": b2,
        "jacobi_basis_triples": jacobi_checked,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    cases = [build(d, deformed) for d in (1, 2, 3) for deformed in (False, True)]
    for d in (1, 2, 3):
        grouped = [c for c in cases if c["d"] == d]
        assert grouped[0]["b2"] == grouped[1]["b2"]
    report = {
        "status": "PASS",
        "scope": "Sparse ordinary CE basis check, not proof for arbitrary d or full Lie-isomorphism test",
        "cases": cases,
    }
    if args.report:
        with args.report.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

"""Replay the three explicit high-class models from coefficient tables only.

No construction or research-directory imports. Read-only unless an exclusive
fresh --report path is supplied. Each underlying check is lossless Boolean
polynomial algebra, not a sample of the exponentially large state space.
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CASES = (
    ("class6_36.json", 6, "36,30,24,14,6,2,0",
     "e1411724b41064ec4f000eda6760841d388d633127548b04a0ab1403105d4c02"),
    ("trace_class7_44.json", 7, "44,36,30,18,12,4,2,0",
     "3f69d1d36bc84d865d20c40a301b46b470de5a102474fbba15b7a778cc4d1352"),
    ("trace_class8_90.json", 8, "90,80,72,52,40,20,12,2,0",
     "a1f4f5631ebf88f32825436b144b5c9cad2a6d42092b0af29b6e4b12a9cbe736"),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    records = []
    for name, expected_class, expected_lcs, expected_hash in CASES:
        process = subprocess.run(
            [sys.executable, "-E", "-X", "utf8", str(HERE / "check_explicit_model.py"),
             "--input", str(HERE / "models" / name),
             "--expected-class", str(expected_class), "--expected-lcs", expected_lcs],
            check=True, capture_output=True, text=True, encoding="utf-8")
        record = json.loads(process.stdout)
        assert record["status"] == "PASS"
        assert record["input_sha256"] == expected_hash
        record["input_file"] = "models/" + name
        records.append(record)
    report = {"status": "PASS", "cases": records,
              "scope": "Exact checks of three explicit models and structural interfaces; "
                       "not a proof of minimum dimension or the all-parameter theorems"}
    if args.report:
        with args.report.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2)
            handle.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

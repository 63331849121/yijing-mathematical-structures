"""Finite ordinary-F4 Engel controls for the top central-cover boundary.

Print only by default or with --no-write. --report requires a new filename;
--output-dir requires a new or empty directory. This checker and its local
helper use only the standard library and read no other input. General
all-rank proofs are separate from these exact finite controls.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
import _ordinary_engel_support as core


def h8_table():
    # a,b,c,u,v,w,z,t; the two independent central classes are retained.
    labels = ['a', 'b', 'c', 'u', 'v', 'w', 'z', 't']
    table = [[0]*8 for _ in range(8)]
    for i, j, k in ((0,1,2), (0,2,3), (1,2,4), (1,3,5),
                    (0,4,5), (0,5,6), (2,3,6), (1,5,7), (2,4,7)):
        table[i][j] = table[j][i] = 1 << k
    return table, labels


def generated_from(table, indices):
    pivots = {i: 1 << i for i in indices}
    while True:
        old = list(pivots.values())
        count = len(old)
        for i, u in enumerate(old):
            for v in old[i+1:]:
                core.insert(pivots, core.bracket(table, u, v))
        if len(pivots) == count:
            return len(pivots)


def second_derived(table):
    derived = core.lower(table)[1]
    second = {}
    for a in derived:
        for b in derived:
            core.insert(second, core.bracket(table, a, b))
    central = all(not core.bracket(table, a, 1 << i)
                  for a in second.values() for i in range(len(table)))
    return len(second), central


def all_h8_F4_inputs(table):
    # Packed F4 coefficients use two bits, with omega=2 and omega^2=3.
    n = 8
    low = sum(1 << (2*i) for i in range(n))
    spread = [sum(1 << (2*i) for i in core.bits(mask)) for mask in range(1 << n)]

    def omega(v):
        lo, hi = v & low, (v >> 1) & low
        return hi | ((lo ^ hi) << 1)

    def apply(v, scaled):
        out = 0
        for i in range(n):
            out ^= scaled[i][(v >> (2*i)) & 3]
        return out

    assert all(table[i][j] == 0 for i in (6,7) for j in range(n))
    cubes = []
    for state in range(4**6):
        x = [(state >> (2*j)) & 3 for j in range(6)]
        cols = []
        for i in range(n):
            col = 0
            for j in range(6):
                # Each spread digit is 0 or 1, so scalar multiplication
                # by 0,1,omega,omega^2 creates no cross-digit carries.
                col ^= x[j] * spread[table[i][j]]
            cols.append(col)
        scaled = [(0, c, omega(c), c ^ omega(c)) for c in cols]
        cube = tuple(apply(apply(c, scaled), scaled) for c in cols)
        assert not any(cube)
        cubes.append(cube)
    values = 0
    for state in range(4**8):
        # The last two input coordinates are verified central. Cache
        # repeated adjoint operators, but enumerate every central fibre.
        cube = cubes[state & ((1 << 12)-1)]
        for value in cube:
            assert value == 0
            values += 1
    assert values == 65536*8
    return {'all_F4_inputs': 65536, 'basis_y_per_input': 8,
            'ad_cube_basis_values': values,
            'distinct_adjoint_inputs_recomputed': 4096,
            'central_input_fibre_size': 16,
            'scope': 'All F4 states and all eight basis y; repeated central fibres reuse their independently computed identical adjoint.'}


def h8_control():
    table, labels = h8_table()
    full = core.ordinary_ce_control(2, table, labels)
    assert full['lower_F4_dimensions_including_zero'] == [8,6,5,3,2,0]
    expected = {'CE_C2_dimension': 28, 'CE_constraint_rank': 19,
                'CE_H2_dimension': 3, 'full_F4_cubic_coefficients_checked': 960,
                'combined_CE_Engel_constraint_rank': 22,
                'Engel_cocycle_dimension': 6, 'CE_coboundary_dimension': 6,
                'Engel_extension_class_dimension': 0, 'top_restriction_rank': 0}
    for key, value in expected.items():
        assert full[key] == value
    assert generated_from(table, [0,1]) == 8
    assert second_derived(table) == (2, True)
    padded = [r+[0] for r in table] + [[0]*9]
    assert generated_from(padded, [0,1,8]) == 9
    assert [len(t) for t in core.lower(padded)] == [9,6,5,3,2,0]
    report = {key: full[key] for key in expected}
    report.update({'F4_dimension': 8, 'ordinary_generator_rank': 2, 'class': 5,
                   'lower_F4_dimensions_including_zero': [8,6,5,3,2,0],
                   'second_derived_dimension': 2, 'second_derived_is_central': True,
                   'exact_F4_input_check': all_h8_F4_inputs(table),
                   'rank_three_central_padding': {'F4_dimension': 9, 'rank': 3, 'class': 5},
                   'scope': 'One explicit two-generator object and its full ordinary-Engel central boundary; the finite-target universal assertion has a written proof.'})
    return report


def natural_top_control(d, summary, certificate):
    table, labels = core.make_H(d)
    indices = {label: i for i, label in enumerate(labels)}
    pairindex = {tuple(sorted((indices[a],indices[b]))): p
                 for p, (a,b) in enumerate(certificate['cochain_coordinate_pairs'])}
    top = []
    for i in range(d):
        choices = []
        for j in range(d):
            if i == j:
                continue
            v = table[i][j]
            for k in range(d):
                if k != j:
                    v = core.bracket(table, v, 1 << k)
            choices.append(v)
        assert choices[0] and len(set(choices)) == 1
        top.append(choices[0])
    independent = {}
    for v in top:
        core.insert(independent, v)
    assert len(independent) == d

    def matrix(z):
        result = []
        for v in top:
            row = []
            for j in range(d):
                value = 0
                for i in core.bits(v):
                    p = pairindex.get(tuple(sorted((i,j))))
                    if p is not None:
                        value ^= (z >> p) & 1
                row.append(value)
            result.append(row)
        assert all(result[i][j] == result[j][i] for i in range(d) for j in range(d))
        return result

    matrix_span = {}
    for z in certificate['cochain_kernel_basis_hex']:
        b = matrix(int(z,16))
        core.insert(matrix_span, sum(b[i][j] << (d*i+j)
                                     for i in range(d) for j in range(d)))
    assert len(matrix_span) == d*(d+1)//2
    witness = int(summary['witness']['cochain_hex'],16)
    ext = [r+[0] for r in table] + [[0]*(len(table)+1)]
    for pair, p in pairindex.items():
        if (witness >> p) & 1:
            i,j = pair
            ext[i][j] ^= 1 << len(table)
            ext[j][i] ^= 1 << len(table)
    assert second_derived(ext) == (1, True)
    return {'top_basis_independent_of_partner': True,
            'top_F4_dimension': d,
            'all_kernel_pairings_symmetric': True,
            'symmetric_pairing_space_dimension': len(matrix_span),
            'chosen_witness_top_matrix': matrix(witness),
            'witness_second_derived_dimension': 1,
            'witness_second_derived_is_central': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--report', type=Path)
    group.add_argument('--output-dir', type=Path)
    group.add_argument('--no-write', action='store_true')
    args = parser.parse_args()
    if args.report and args.report.exists():
        parser.error('--report must name a new file')
    if args.output_dir and args.output_dir.exists():
        if not args.output_dir.is_dir() or any(args.output_dir.iterdir()):
            parser.error('--output-dir must be new or empty')
    start = time.monotonic()
    cases = []
    for d, expected in ((4,(55,332,626,322,1896,10)),
                        (5,(139,2465,8690,2450,31900,15))):
        summary, certificate = core.graded_control(d, start+290)
        actual = (summary['H_F4_dimension'], summary['cochain_variable_count'],
                  summary['CE_rows'], summary['CE_rank'],
                  summary['full_F4_cubic_coefficient_rows'], summary['top_restriction_rank'])
        assert actual == expected
        assert summary['combined_rank'] == summary['CE_rank']
        assert summary['allowed_graded_cocycle_dimension'] == d*(d+1)//2
        assert summary['witness']['class'] == d+2
        summary['natural_top'] = natural_top_control(d,summary,certificate)
        encoded = json.dumps(certificate,sort_keys=True,separators=(',',':')).encode('utf-8')
        summary['reconstructed_matrix_certificate_sha256'] = hashlib.sha256(encoded).hexdigest()
        cases.append(summary)
    report = {'status': 'PASS', 'ordinary_rank_two_boundary': h8_control(),
              'graded_top_cases': cases,
              'scope': 'Exact finite ordinary-F4 controls at two generators and d=4,5 only. General top-cover and centre-by-metabelian theorems have written proofs; no all-rank inference or proof-assistant formalization.',
              'seconds': round(time.monotonic()-start,3)}
    target = args.report
    if args.output_dir:
        args.output_dir.mkdir(parents=True,exist_ok=True)
        target = args.output_dir/'ordinary_top_cover.json'
    if target:
        with target.open('x',encoding='utf-8') as out:
            json.dump(report,out,ensure_ascii=False,indent=2)
            out.write('\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()

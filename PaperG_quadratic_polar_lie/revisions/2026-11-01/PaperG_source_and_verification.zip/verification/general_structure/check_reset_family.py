"""Independent exact Boolean controls for the reset family and trace subfamily.

No imports from PaperG model or linear-algebra helpers. No state enumeration.
Reports and optional explicit model tables are created exclusively.
"""
import argparse
import itertools
import json
from pathlib import Path


def mul(a,b):
    out=0
    for _ in range(2):
        if b&1: out^=a
        b>>=1; a<<=1
        if a&4: a^=7
    return out


def basis(vectors):
    p={}
    for v in vectors:
        while v:
            i=v.bit_length()-1
            if i in p: v^=p[i]
            else: p[i]=v; break
    return list(p.values())


def kern(cols):
    p={}; out=[]
    for i,v in enumerate(cols):
        lab=1<<i
        while v:
            j=v.bit_length()-1
            if j in p:
                vv,ll=p[j];v^=vv;lab^=ll
            else:p[j]=v,lab;break
        if not v:out.append(lab)
    return out


def evaluate(mat,x,y):
    out=0
    while x:
        i=(x&-x).bit_length()-1;x&=x-1;yy=y
        while yy:
            j=(yy&-yy).bit_length()-1;yy&=yy-1;out^=mat[i][j]
    return out


def product(p,q):
    out=set()
    for a in p:
        for b in q:out.symmetric_difference_update((a|b,))
    return out


def compose(polys):
    result=[]
    for p in polys:
        out=set()
        for m in p:
            term={0}
            for i in range(len(polys)):
                if m>>i&1:term=product(term,polys[i])
            out.symmetric_difference_update(term)
        result.append(out)
    return result


def family(m,sub):
    N=(1<<m)-1; ext=1 if sub else 2
    names=(["a"] if sub else ["a","b"])+[
        letter+"_"+str(s) for letter in ("U","V","W") for s in range(1,N+1)]
    n=2*len(names)
    def rmul(u,v):
        out=[0]*N
        for A in range(1,N+1):
            for B in range(1,N+1):
                if not A&B:out[(A|B)-1]^=mul(u[A-1],v[B-1])
        return out
    def f(x):
        cs=[(x>>(2*i))&3 for i in range(len(names))]
        a=cs[0]; b=(a^mul(a,a)) if sub else cs[1]
        u,v,w=[cs[ext+i*N:ext+(i+1)*N] for i in range(3)]
        uv,uw,vw=rmul(u,v),rmul(u,w),rmul(v,w)
        out=[mul(2,a)]
        if not sub:out.append(mul(2,b)^mul(a,a))
        out += [mul(2,u[i])^mul(a,v[i])^mul(b,w[i])^uv[i] for i in range(N)]
        out += [mul(2,v[i])^mul(a,w[i])^uw[i] for i in range(N)]
        out += [mul(2,w[i])^vw[i] for i in range(N)]
        return sum(c<<(2*i) for i,c in enumerate(out))
    bs=[1<<i for i in range(n)]
    lin=[f(e) for e in bs]
    quad={e|v:f(e^v)^f(e)^f(v) for e,v in itertools.combinations(bs,2)}
    quad={mask:v for mask,v in quad.items() if v}
    B=[[0]*n for _ in range(n)]
    for i,j in itertools.combinations(range(n),2):
        B[i][j]=B[j][i]=quad.get((1<<i)|(1<<j),0)
    bfun=lambda x,y:evaluate(B,x,y)
    # Degree <=2 follows directly from the ring formula; these are all its
    # coefficients, followed by a LOSSLESS Boolean composition check.
    ps=[set() for _ in range(n)]
    for mask,val in list(zip(bs,lin))+list(quad.items()):
        for i in range(n):
            if val>>i&1:ps[i].add(mask)
    f2=compose(ps)
    for i in range(n):
        f2[i].symmetric_difference_update(ps[i]);f2[i].symmetric_difference_update((1<<i,))
    assert not any(f2)
    triples=0
    for x,y,z in itertools.combinations(bs,3):
        assert bfun(x,bfun(y,z))^bfun(y,bfun(z,x))^bfun(z,bfun(x,y))==0
        triples+=1
    gamma=[bs]
    while gamma[-1]:gamma.append(basis(bfun(x,y) for x in bs for y in gamma[-1]))
    assert len(gamma)-1==2*m+1
    derived=[bs]
    while derived[-1]:derived.append(basis(bfun(x,y) for x in derived[-1] for y in derived[-1]))
    expected_d=m+1 if sub else m+2
    assert (n-len(gamma[1]))//2==expected_d
    center=kern([sum(B[i][j]<<(n*j) for j in range(n)) for i in range(n)])
    top=1<<(2*(ext+N-1))
    assert set(basis(center))==set((top,top<<1))
    assert set(basis(gamma[-2]))==set((top,top<<1))
    # Exact achieving word W1,x,x,W2,x,...,Wm,x.
    x=1; value=1<<(2*(ext+2*N))
    value=bfun(bfun(value,x),x)
    for i in range(1,m):
        wi=1<<(2*(ext+2*N+(1<<i)-1))
        value=bfun(bfun(value,wi),x)
    assert value==top
    # Full center is a scalar orbit plane, so any nonzero stable ideal kills it.
    assert f(top)==top<<1 and f(top<<1)==top^(top<<1)
    model={"binary_dimension":n,"parameter_m":m,"trace_subfamily":sub,
           "F4_coordinate_order":names,"linear_coefficients":lin,
           "quadratic_coefficients":{str(k):v for k,v in quad.items()},
           "lower_central_dimensions":[len(v) for v in gamma],
           "nilpotency_class":2*m+1,"point_generator_rank":expected_d}
    result={"m":m,"trace_subfamily":sub,"binary_dimension":n,
            "full_Boolean_f2_identity":True,"Jacobi_basis_triples":triples,
            "lower_central_dimensions":model["lower_central_dimensions"],
            "derived_dimensions":[len(v) for v in derived],
            "point_generator_rank":expected_d,"center_dimension":2,
            "top_class_achieving_word":True,"top_center_is_f_orbit_plane":True,
            "nonzero_vector_quadratic_coefficients":len(quad)}
    return result,model


def main():
    p=argparse.ArgumentParser();p.add_argument("--report",type=Path)
    p.add_argument("--model-dir",type=Path)
    args=p.parse_args();cases=[]
    for sub in (False,True):
        for m in (1,2,3):
            result,model=family(m,sub);cases.append(result)
            if args.model_dir:
                name="independent_reset_"+("trace_" if sub else "ambient_")+str(m)+".json"
                with (args.model_dir/name).open("x",encoding="utf-8") as out:
                    json.dump(model,out,indent=2);out.write("\n")
    report={"status":"PASS","scope":"independent exact low-m controls; no state enumeration", "cases":cases}
    if args.report:
        with args.report.open("x",encoding="utf-8") as out:
            json.dump(report,out,indent=2);out.write("\n")
    print(json.dumps(report,indent=2))


if __name__=="__main__":main()

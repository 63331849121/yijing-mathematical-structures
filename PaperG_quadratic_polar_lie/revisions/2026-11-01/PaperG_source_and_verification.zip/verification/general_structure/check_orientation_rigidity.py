"""Finite linear-space controls for the orientation proof.

Default read-only, --report exclusive new JSON. No enumeration of all
vectorial quadratic maps or all spread orientations is needed.
"""
import argparse
import itertools
import json
from pathlib import Path


def rank(rows):
    pivots = {}
    for row in rows:
        while row:
            p = row.bit_length() - 1
            if p in pivots:
                row ^= pivots[p]
            else:
                pivots[p] = row
                break
    return len(pivots)


def parallel_space(n):
    monomials = [1 << i for i in range(n)] + [sum(1 << i for i in pair)
        for pair in itertools.combinations(range(n), 2)]
    width = len(monomials)
    rows = []
    for x in range(1 << n):
        evaluations = sum((1 << j) for j, mask in enumerate(monomials) if x & mask == mask)
        for i, j in itertools.combinations(range(n), 2):
            row = ((evaluations << (i * width)) if x >> j & 1 else 0)
            row ^= ((evaluations << (j * width)) if x >> i & 1 else 0)
            rows.append(row)
    nullity = n * width - rank(rows)
    assert nullity == n + 1
    return {"dimension": n, "quadratic_parallel_space_dimension": nullity}


def scalar_omega(x, n):
    out = 0
    for i in range(n // 2):
        value = (x >> (2 * i)) & 3
        mapped = [0, 2, 3, 1][value]
        out ^= mapped << (2 * i)
    return out


def orientation_space(n):
    plane_of = {}
    for x in range(1, 1 << n):
        if x in plane_of:
            continue
        fx = scalar_omega(x, n)
        p = len(set(plane_of.values()))
        for y in (x, fx, x ^ fx):
            plane_of[y] = p
    plane_count = len(set(plane_of.values()))
    high_degree_constraints = []
    for coord in range(n):
        values = [0] + [(1 << plane_of[x]) if x >> coord & 1 else 0
                        for x in range(1, 1 << n)]
        for i in range(n):
            for mask in range(1 << n):
                if mask >> i & 1:
                    values[mask] ^= values[mask ^ (1 << i)]
        high_degree_constraints.extend(values[mask] for mask in range(1 << n)
                                       if mask.bit_count() > 2)
    nullity = plane_count - rank(high_degree_constraints)
    assert nullity == 1
    return {"dimension": n, "spread_planes": plane_count,
            "quadratic_orientation_space_dimension": nullity,
            "quadratic_orientations": 2}


def noninvertible_arrows():
    # All 256 binary-linear maps F2^4 -> F2^2, including rank-one maps.
    def target_f(x):
        return scalar_omega(x, 2)

    def wedge(left, right):
        return ((left & 1) * ((right >> 1) & 1)) ^ (((left >> 1) & 1) * (right & 1))

    compatible = forward = reverse = 0
    for encoded in range(256):
        columns = [(encoded >> (2 * i)) & 3 for i in range(4)]

        def apply(x):
            out = 0
            for i in range(4):
                if x >> i & 1:
                    out ^= columns[i]
            return out

        fw = all(apply(scalar_omega(x, 4)) == target_f(apply(x)) for x in range(16))
        rv = all(apply(scalar_omega(x, 4)) == target_f(target_f(apply(x))) for x in range(16))
        plucker = all(wedge(apply(x), apply(scalar_omega(x, 4))) ==
                      wedge(apply(x), target_f(apply(x))) for x in range(16))
        assert plucker == (fw or rv)
        if encoded:
            assert not (fw and rv)
        compatible += plucker
        forward += fw
        reverse += rv
    assert (compatible, forward, reverse) == (31, 16, 16)
    return {"source_dimension": 4, "target_dimension": 2, "linear_maps_checked": 256,
            "compatible_arrows": compatible, "forward": forward, "reverse": reverse,
            "overlap": "zero map only"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    report = {"status": "PASS", "scope": "Finite linear-space checks; the accompanying coordinate proof covers all dimensions",
              "parallel_cases": [parallel_space(n) for n in range(2, 8)],
              "orientation_cases": [orientation_space(n) for n in (2, 4, 6, 8)],
              "noninvertible_linear_arrows": noninvertible_arrows()}
    if args.report:
        with args.report.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

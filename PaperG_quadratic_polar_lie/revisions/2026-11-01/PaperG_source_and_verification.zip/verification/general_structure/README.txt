General-structure controls
==========================

These ten programs are included by ../run_all.py. All use only the
Python standard library, make no network requests, and import nothing
from the development/research directory. Each is read-only by default;
--report creates a new JSON file exclusively and refuses to overwrite one.

1. check_explicit_models.py authenticates and independently checks the
   supplied 36/44/90-dimensional coefficient tables. It calls the generic
   check_explicit_model.py, which can also take another compatible JSON:

   python check_explicit_model.py --input models/trace_class7_44.json --expected-class 7 --expected-lcs 44,36,30,18,12,4,2,0

   Polynomial composition is lossless in the Boolean ring x_i^2=x_i;
   Jacobi is checked on every basis triple. The checker reconstructs
   lower/upper/derived series, canonical J and the restricted square on
   L'/(L' intersect Z), and the canonical matrix-kernel interfaces.
   These models prove the displayed explicit dimension upper bounds.
   They do not establish minimality or the universal nilpotence theorem.

2. check_derived_factor_counterexample.py locally constructs the
   22-dimensional metabelian class-four model. It checks f^2=f+I by exact
   Boolean polynomial composition, all 1540 Jacobi basis triples, and
   the lower series 22,14,8,2,0. rank(B)=14 and rank(B,D)=16 prove that
   D cannot factor linearly through the whole derived space. An explicit
   four-pair cycle has B=0 but a nonzero central D value. This is distinct
   from the reduced-derived structure theorem.

3. check_reset_family.py independently constructs ambient and binary
   trace models at m=1,2,3. It checks full coefficient composition,
   Jacobi, the actual lower/derived series, intrinsic generator rank,
   center, and an explicit word attaining the predicted class. The
   all-m family and dimension bounds use the written proof.

4. check_quadratic_invariants.py solves the actual Boolean degree-two
   invariance equations for the 14/16-dimensional chain and independent
   18-dimensional seed; it checks that all invariants factor through
   the abelianization. No ordinary-CE matrix is used. This supports the
   all-object fixed-sector theorem, rather than proving it by a census.

5. check_free_binary_ce.py independently builds ordinary binary CE
   boundary maps and checks Jacobi, ranks, and b2=(d^4+d^2)/2 for d=1,2,3,
   for both ordinary and deformed brackets. The arbitrary-rank formula
   follows from the manuscript's Hopf/Kunneth argument, not these tests.

6. check_orientation_rigidity.py computes small parallel-map spaces,
   quadratic orientation spaces for the scalar spreads in dimensions
   2,4,6,8, and all 256 binary-linear arrows F2^4 -> F2^2. It includes
   noninvertible arrows and their unique forward/reverse sign away from
   the zero map. The general rigidity assertion is a written proof.

7. check_normal_center.py rebuilds truth tables and their full Boolean
   Mobius transforms in dimensions 4,6,8. It compares every geometric
   normal line with an independently computed Lie center and iterates
   the quotients. A regulus-switched spread with two normal lines whose
   union with zero is not a subspace is a negative orientability control.
   No new enumeration of the 131044 PG(5,2) spread classes is claimed.

The original seven-prefix F16 certificate remains a statement about the
quadratic central-extension space of that specified quotient: H_g=0.
It does not imply that every 16-dimensional model is terminal, or replace
the general finite-stem theorem with a finite rank experiment.

Source attributions and bounded priority-search scope are summarized in
SOURCE_ATTRIBUTION.txt. Publisher PDFs and development logs are excluded.
No new Lean/proof-assistant formalization is included or claimed.

8. check_global_stability_interfaces.py checks all Boolean coefficients of
   ad_z^3(L' )=0 on an authenticated 48-dimensional model and replays the
   independent 22-dimensional nonfactorization cycle. These are finite
   controls of the newly proved general interfaces, not substitutes for
   the global stability proof.

9. check_rank_class_bridge.py reconstructs a genuine two-generator
   ordinary F4-3-Engel input from an authenticated embedded F16 table,
   then independently builds its adjoint and restricted envelope. It
   checks every envelope fourth power and every input of the binary
   point-generated subsolution, including scalar saturation and the
   exact class and generator-rank transfer. Finite commuting quotient
   algebras and integer consequences of the quartic bound are separate
   controls. The all-rank comparison is proved in the manuscript.

10. check_ordinary_top_cover.py and its local helper reconstruct the
    ordinary rank-two endpoint and the complete homogeneous top-weight
    CE/Engel conditions for the universal metabelian objects at d=4,5.
    The checks include all F4 inputs of the eight-dimensional endpoint,
    top symmetry and completeness, generator rank, class-raising models,
    and their central second derived ideals. The determinant-twisted
    all-rank cohomology formula and the sharp centre-by-metabelian law
    are algebraic theorems in the paper, not conclusions of this census.

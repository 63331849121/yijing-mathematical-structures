"""Independent small exact controls for the normal-element/center bridge.

No imports from PaperG constructors, Lie helpers, or dimension helpers.
Default mode is read-only; --report creates a NEW JSON file exclusively.
These finite controls support the abstract proof and are not its premise.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def mul(a: int, b: int) -> int:
    p = 0
    for _ in range(2):
        if b & 1:
            p ^= a
        b >>= 1
        a <<= 1
        if a & 4:
            a ^= 7
    return p


def unpack(x: int, k: int) -> list[int]:
    return [(x >> (2*i)) & 3 for i in range(k)]


def pack(v: list[int]) -> int:
    return sum(a << (2*i) for i, a in enumerate(v))


def scalar(x: int, a: int, k: int) -> int:
    return pack([mul(a, t) for t in unpack(x, k)])


def basis(vectors: list[int]) -> list[int]:
    pivots = {}
    for v in vectors:
        while v:
            p = v.bit_length()-1
            if p in pivots:
                v ^= pivots[p]
            else:
                pivots[p] = v
                break
    return [pivots[p] for p in sorted(pivots, reverse=True)]


def span(vectors: list[int]) -> set[int]:
    answer = {0}
    for v in basis(vectors):
        answer |= {x ^ v for x in tuple(answer)}
    return answer


def spread(table: list[int]) -> list[frozenset[int]]:
    return sorted({frozenset((x, table[x], x ^ table[x]))
                   for x in range(1, len(table))}, key=lambda t: sorted(t))


def check_spread(n: int, lines: list[frozenset[int]]) -> None:
    seen = set()
    for line in lines:
        assert len(line) == 3 and 0 not in line
        a, b, c = line
        assert a ^ b ^ c == 0
        assert not seen.intersection(line)
        seen.update(line)
    assert seen == set(range(1, 1 << n))


def normal_lines(lines: list[frozenset[int]]) -> list[frozenset[int]]:
    result = []
    for line in lines:
        ok = True
        for other in lines:
            if line == other:
                continue
            solid = span(list(line | other))
            assert len(solid) == 16
            for candidate in lines:
                if candidate.intersection(solid) and not candidate.issubset(solid):
                    ok = False
                    break
            if not ok:
                break
        if ok:
            result.append(line)
    return result


def center(n: int, table: list[int]) -> set[int]:
    e = [1 << i for i in range(n)]
    return {x for x in range(1 << n)
            if all((table[x ^ y] ^ table[x] ^ table[y]) == 0 for y in e)}


def quotient(n: int, table: list[int], z: set[int]) -> tuple[int, list[int]]:
    zb = basis(list(z))
    assert span(zb) == z
    pivot = {v.bit_length()-1 for v in zb}
    free = [i for i in range(n) if i not in pivot]

    def reduce(x: int) -> int:
        for v in zb:
            if x & (1 << (v.bit_length()-1)):
                x ^= v
        return x

    def encode(x: int) -> int:
        x = reduce(x)
        return sum(((x >> i) & 1) << j for j, i in enumerate(free))

    def lift(x: int) -> int:
        return sum(((x >> j) & 1) << i for j, i in enumerate(free))

    result = [encode(table[lift(x)]) for x in range(1 << len(free))]
    for x in range(1 << n):
        assert encode(table[x]) == result[encode(x)]
    return len(free), result


def check_solution(n: int, fn) -> dict:
    table = [fn(x) for x in range(1 << n)]
    assert table[0] == 0
    assert all(table[table[x]] == table[x] ^ x for x in range(1 << n))
    # Full Mobius transform verifies degree <=2 independently of the formulas.
    anf = table.copy()
    for i in range(n):
        for mask in range(1 << n):
            if mask & (1 << i):
                anf[mask] ^= anf[mask ^ (1 << i)]
    assert all(not value or mask.bit_count() <= 2
               for mask, value in enumerate(anf))
    reverse = [table[x] ^ x for x in range(1 << n)]
    assert all((table[x ^ y] ^ table[x] ^ table[y]) ==
               (reverse[x ^ y] ^ reverse[x] ^ reverse[y])
               for x in range(1 << n) for y in range(1 << n))
    stages = []
    qn, qt = n, table
    while qn:
        lines = spread(qt)
        check_spread(qn, lines)
        normals = normal_lines(lines)
        normal_union = {0}.union(*normals)
        actual_center = center(qn, qt)
        assert normal_union == actual_center
        zdim = len(basis(list(actual_center)))
        assert zdim > 0 and zdim % 2 == 0
        assert len(normals) == ((1 << zdim)-1)//3
        stages.append({"quotient_dimension": qn,
                       "normal_count": len(normals), "center_dimension": zdim})
        qn, qt = quotient(qn, qt, actual_center)
    return {"dimension": n, "quadratic_degree": max(
        (mask.bit_count() for mask, value in enumerate(anf) if value), default=0),
        "normal_reduction": stages,
        "upper_central_dimensions": [0] + [n - a["quotient_dimension"] +
            a["center_dimension"] for a in stages]}


def linear4(x: int) -> int:
    return scalar(x, 2, 2)


def central6(x: int) -> int:
    a, b, z = unpack(x, 3)
    return pack([mul(2, a), mul(2, b), mul(2, z) ^ mul(a, b)])


def noncompatible8(x: int) -> int:
    a, b, y, z = unpack(x, 4)
    return pack([mul(2, a), mul(2, b),
                 mul(2, y) ^ mul(a, z) ^ mul(mul(a, a), b),
                 mul(2, z) ^ mul(a, b)])


def switched6() -> dict:
    # Classical opposite-regulus replacement inside F4^2 x {0}.
    original = spread([scalar(x, 2, 3) for x in range(64)])
    removed = {frozenset(scalar(v, a, 3) for a in (1, 2, 3))
               for v in (1, 4, 5)}
    added = {frozenset((a, a << 2, a ^ (a << 2))) for a in (1, 2, 3)}
    assert len(removed) == 3 and len(added) == 3
    assert set().union(*removed) == set().union(*added)
    switched = sorted((set(original) - removed) | added, key=lambda t: sorted(t))
    check_spread(6, switched)
    normals = normal_lines(switched)
    assert len(normals) == 2
    union = {0}.union(*normals)
    assert len(union) == 7
    assert span(list(union)) != union
    return {"dimension": 6, "spread_lines": len(switched),
            "normal_count": len(normals), "normal_lines": [sorted(t) for t in normals],
            "normal_union_is_subspace": False,
            "excluded_by_normal_center_necessary_condition": True}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    cases = {"linear4": check_solution(4, linear4),
             "central6": check_solution(6, central6),
             "noncompatible8": check_solution(8, noncompatible8)}
    assert cases["central6"]["upper_central_dimensions"] == [0, 2, 6]
    assert cases["noncompatible8"]["upper_central_dimensions"] == [0, 2, 4, 8]
    # The abelianization projection gives positive and negative Plucker arrows.
    for target_sign in (0, 1):
        target = lambda x: linear4(x) ^ (x if target_sign else 0)
        for x in range(64):
            tx, tfx = x & 15, central6(x) & 15
            assert tfx == (target(tx) ^ (tx if target_sign else 0))
        for x in range(64):
            for y in range(64):
                b = central6(x ^ y) ^ central6(x) ^ central6(y)
                assert b & 15 == 0  # target polar is zero for either sign
    report = {"status": "PASS", "scope": "small exact finite controls, not general proof",
              "quadratic_solutions": cases, "regulus_switch_negative_control": switched6(),
              "both_sign_linear_arrows_are_lie_homomorphisms": True}
    if args.report:
        with args.report.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()

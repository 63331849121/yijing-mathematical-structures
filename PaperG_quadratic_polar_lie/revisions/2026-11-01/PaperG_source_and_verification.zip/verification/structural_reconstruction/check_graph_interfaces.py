"""Independent finite graph-category controls; default read-only.

The class-two C model is tested over genuine F4 coefficients.
--report exclusively creates a new JSON report.
"""
import argparse
import json
from pathlib import Path


def mul(a,b):
    value=(a if b&1 else 0)^((a<<1) if b&2 else 0)
    return value^7 if value&4 else value


def decode(value):
    return [(value>>(2*i))&3 for i in range(3)]


def encode(values):
    return sum(value<<(2*i) for i,value in enumerate(values))


def scalar(value):
    return encode([mul(2,x) for x in decode(value)])


def f(value):
    a,b,c=decode(value)
    return encode([mul(2,a),mul(2,b),mul(2,c)^mul(a,b)])


def hidden_aut(value):
    a,b,c=decode(value)
    return encode([a,b,c^mul(mul(a,b),mul(a,b))])


def b_operator(value):
    return encode([0,0,mul(decode(value)[2],decode(value)[2])])


def a_operator(value):
    return value^b_operator(scalar(value))


def pair(left,right):
    return left|(right<<6)


def unpair(value):
    return value&63,value>>6


def ambient_j(value):
    left,right=unpair(value)
    return pair(right,left^right)


def ambient_t(value):
    left,right=unpair(value)
    return pair(a_operator(left)^b_operator(right),
                b_operator(left)^a_operator(right)^b_operator(right))


def rank(vectors):
    pivots={}
    for vector in vectors:
        while vector:
            bit=vector.bit_length()-1
            if bit in pivots: vector^=pivots[bit]
            else:
                pivots[bit]=vector
                break
    return len(pivots)


def old_bracket(left,right):
    a,b,c=decode(left)
    aa,bb,cc=decode(right)
    return encode([0,0,mul(a,bb)^mul(aa,b)])


def product_bracket(left,right):
    x,u=unpair(left);y,v=unpair(right)
    return pair(old_bracket(x,y),old_bracket(u,v))


def nonmetabelian_addition_obstruction():
    def model14(value):
        a,b,c,d,e,h,r=[(value>>(2*i))&3 for i in range(7)]
        return encode([mul(2,a),mul(2,b),mul(2,c)^mul(a,b),
                       mul(2,d)^mul(a,c)^mul(mul(a,a),b),
                       mul(2,e)^mul(b,c)^mul(a,mul(b,b)),
                       mul(2,h)^mul(a,e)^mul(b,d),
                       mul(2,r)^mul(a,mul(c,c))^mul(mul(a,a),e)^mul(a,h)^mul(c,d)])
    def bracket14(left,right):
        return model14(left^right)^model14(left)^model14(right)
    def addition(left,right):
        polar=bracket14(left,right)
        return left^right^polar^bracket14(left^right,polar)
    a,b,c,r=1,4,16,4096
    assert addition(a,b)==a^b^c
    assert addition(a,addition(a,b))==b^r
    associator=addition(addition(a,a),b)^addition(a,addition(a,b))
    assert associator==r
    return dict(status='PASS',binary_dimension=14,
                formula='x+y+B(x,y)+B(x+y,B(x,y))',
                witness=['a','a','b'],associator='r',packed_associator=associator,
                consequence='The metabelian double-addition formula is not associative in this nonmetabelian model')


def mendelsohn_medial_obstruction():
    def n8(value):
        a,b,y,z=[(value>>(2*i))&3 for i in range(4)]
        return encode([mul(2,a),mul(2,b),mul(2,y)^mul(a,z)^mul(mul(a,a),b),mul(2,z)^mul(a,b)])
    def star(left,right):return left^n8(left^right)
    a,b=1,4
    defect=star(star(0,a),star(b,0))^star(star(0,b),star(a,0))
    assert defect==16
    return dict(status='PASS',binary_dimension=8,operation='x*y=x+f(x+y)',
                medial_test_quadruple=['0','a','b','0'],medial_defect='y',packed_defect=defect)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    graph={pair(x,f(x)) for x in range(64)}
    carrier={pair(x,f(x)^encode([0,0,w])) for x in range(64) for w in range(4)}
    wspace={encode([0,0,w]) for w in range(4)}
    assert rank(graph)==8 and len(carrier)==256
    assert all(pair(x,y) in carrier for x in wspace for y in wspace)
    assert all(ambient_j(value) in graph for value in graph)
    assert all(ambient_j(value) in carrier for value in carrier)
    assert all(ambient_t(ambient_t(value))==value for value in range(4096))
    assert all(ambient_j(ambient_t(value))==ambient_t(ambient_j(value)) for value in range(4096))
    assert {ambient_t(value) for value in graph}==graph
    for value in range(64):
        assert hidden_aut(hidden_aut(value))==value
        assert hidden_aut(f(value))==f(hidden_aut(value))
        assert ambient_t(pair(value,f(value)))==pair(hidden_aut(value),f(hidden_aut(value)))
    nonlinearity=[]
    for exponent in range(3):
        def candidate(value):
            for _ in range(exponent): value=f(value)
            return hidden_aut(value)
        witness=None
        for left in range(64):
            for right in range(64):
                defect=candidate(left^right)^candidate(left)^candidate(right)
                if defect:
                    witness=dict(X=decode(left),Y=decode(right),defect=decode(defect))
                    break
            if witness:break
        assert witness is not None
        nonlinearity.append(dict(composite='h o f^'+str(exponent),witness=witness))
    restricted_carrier={pair(w,f(w)) for w in wspace}
    quotient_kernel={value for value in carrier if all(part in wspace for part in unpair(value))}
    assert rank(restricted_carrier)==2 and rank(quotient_kernel)==4
    x=pair(encode([1,0,0]),f(encode([1,0,0])))
    y=pair(encode([0,1,0]),f(encode([0,1,0])))
    bracket=product_bracket(x,y)
    centroid_defect=product_bracket(ambient_j(x),y)^ambient_j(bracket)
    deformed=(product_bracket(ambient_j(x),y)^product_bracket(x,ambient_j(y))^ambient_j(bracket))
    torsion=product_bracket(ambient_j(x),ambient_j(y))^ambient_j(deformed)
    assert centroid_defect==pair(encode([0,0,1]),encode([0,0,3]))
    assert torsion==centroid_defect
    for direction in range(1,64):
        four={0,direction,f(direction),direction^f(direction)}
        assert len(four)==4
        assert all(f(point^direction)^f(point)==f(direction) for point in four)
    report=dict(status='PASS',field='F4: omega=2, omega^2=3',model='C(a,b,c)=(omega a,omega b,omega c+ab)',
                graph_size=len(graph),binary_graph_span_rank=rank(graph),carrier_size=len(carrier),
                ambient_J_T_commutation_checks=4096,ambient_T_involution_checks=4096,
                graph_auto_h='(a,b,c+(ab)^2)',not_linear_even_mod_canonical_C3=nonlinearity,
                subobject_carrier_binary_dimension=2,quotient_kernel_binary_dimension=4,
                coordinatewise_Lie_J_centroid_defect=[decode(z) for z in unpair(centroid_defect)],
                coordinatewise_Lie_J_Nijenhuis_torsion=[decode(z) for z in unpair(torsion)],
                four_point_derivative_fibers_checked=63,
                nonmetabelian_double_addition=nonmetabelian_addition_obstruction(),
                mendelsohn_medial_counterexample=mendelsohn_medial_obstruction(),
                scope='Finite graph/projection/CCZ-interface controls; no claim resolving general D CE closedness')
    if args.report:
        with args.report.open('x',encoding='utf-8') as stream:
            json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps(report))


if __name__=='__main__':main()

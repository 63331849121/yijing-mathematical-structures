"""Exact state-observation controls for f14. Run with python -B.
No original files are read at run time or modified. Default read-only;
--report exclusively creates a new JSON report.
"""
from collections import Counter
import argparse
import json
import platform
from pathlib import Path

MUL=((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
OMEGA=2

def mul(a,b): return MUL[a][b]
def sq(a): return MUL[a][a]
def unpack(x): return [(x>>(2*i))&3 for i in range(7)]
def pack(x): return sum(a<<(2*i) for i,a in enumerate(x))
def corrections(x):
    a,b,c,d,e,h,r=x
    return (0,0,mul(a,b),mul(a,c)^mul(sq(a),b),
            mul(b,c)^mul(a,sq(b)),mul(a,e)^mul(b,d),
            mul(a,sq(c))^mul(sq(a),e)^mul(a,h)^mul(c,d))
def f14(x):
    xx=unpack(x)
    return pack([mul(OMEGA,t)^q for t,q in zip(xx,corrections(xx))])
def H(x): return sum(((x>>(2*i))&1)<<i for i in range(7))
def observation(x): return H(x)|(H(f14(x))<<7)
def decode(z):
    u,v=z&127,z>>7
    xx=[0]*7
    for i in range(7):
        qi=corrections(xx)[i]
        ui=(u>>i)&1
        vi=((v>>i)&1)^(qi&1)
        xx[i]=ui|(vi<<1)
    return pack(xx)
def J(z):
    u,v=z&127,z>>7
    return v|((u^v)<<7)
def polar(x,y): return f14(x^y)^f14(x)^f14(y)

def basis2(vectors):
    piv={}
    for x in vectors:
        while x:
            j=x.bit_length()-1
            if j in piv: x^=piv[j]
            else:
                piv[j]=x
                break
    return list(piv.values())
def rank2(vectors): return len(basis2(vectors))

def whole_hull_observation(x):
    return H(x&16383)|(H(x>>14)<<7)
def H12(x):
    positions=(1,3,4,5,6,7,8,9,10,11,12,13)
    return sum(((x>>p)&1)<<i for i,p in enumerate(positions))
def whole_hull_observation12(x):
    return H12(x&16383)|(H12(x>>14)<<12)

def controls():
    size=1<<14
    observed=[observation(x) for x in range(size)]
    assert len(set(observed))==size
    assert set(observed)==set(range(size))
    for x,y in enumerate(observed):
        assert decode(y)==x
        fx=f14(x)
        assert f14(fx)==fx^x
        assert f14(f14(fx))==x
        assert observation(fx)==J(y)
        assert H(f14(fx))==H(fx)^H(x)
    for y in range(size):
        assert observation(decode(y))==y

    basis=[1<<i for i in range(14)]
    kernelH=[x for x in range(size) if H(x)==0]
    assert len(kernelH)==128
    ranks=Counter()
    for k in kernelH[1:]:
        columns=[H(polar(x,k)) for x in basis]
        r=rank2(columns)
        assert rank2(columns+[H(f14(k))])==r+1
        ranks[r]+=1
    assert not any(H(f14(k))==0 for k in kernelH[1:])

    # Canonical C3/F4 graph hull; no assumption that f14 is F4-linear.
    graph_basis=basis2(x|(f14(x)<<14) for x in range(size))
    assert len(graph_basis)==24
    image_basis=basis2(whole_hull_observation(x) for x in graph_basis)
    assert len(image_basis)==14
    assert rank2(whole_hull_observation12(x) for x in graph_basis)==24
    # Five explicit F4-independent kernel generators (R acts as (x,y)->(y,x+y)).
    hidden_derived=[1<<(2*i+1) for i in range(2,7)]
    kernel_generators=[]
    for w in hidden_derived:
        v=w<<14
        Rv=w|(w<<14)
        kernel_generators.extend((v,Rv))
        assert whole_hull_observation(v)==whole_hull_observation(Rv)==0
    assert rank2(kernel_generators)==10
    assert rank2(graph_basis+kernel_generators)==24

    # Determine the inverse Boolean degree without relying on a degree estimate.
    inverse=[decode(y) for y in range(size)]
    anf=inverse[:]
    for i in range(14):
        for y in range(size):
            if y&(1<<i): anf[y]^=anf[y^(1<<i)]
    inverse_degrees=[max((mask.bit_count() for mask,c in enumerate(anf) if c&(1<<i)),default=0)
                     for i in range(14)]
    report={
      'status':'PASS',
      'python_version':platform.python_version(),
      'dependencies':'Python standard library only',
      'field_encoding':'a=u+omega*v represented by u+2*v; omega=2, omega^2=3',
      'H_binary_columns':[2*i for i in range(7)],
      'minimum_m':7,
      'all_state_count':size,
      'distinct_observations':len(set(observed)),
      'decoder_and_intertwining_all_states':'PASS',
      'kernel_H_binary_dimension':7,
      'all_nonzero_kernel_collision_criteria_checked':len(kernelH)-1,
      'collision_linear_image_rank_distribution':dict(sorted(ranks.items())),
      'whole_graph_hull_binary_dimension':24,
      'whole_graph_hull_F4_dimension':12,
      'H_induced_hull_F4_rank':len(image_basis)//2,
      'H_induced_hull_F4_kernel_dimension':(len(graph_basis)-len(image_basis))//2,
      'H12_induced_hull_F4_rank':12,
      'inverse_observation_coordinate_Boolean_degrees':inverse_degrees,
      'scope':'All 16384 states and all 127 nonzero kernel directions checked; general existence proof is in the companion text.'
    }
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    result=controls()
    if args.report:
        with args.report.open('x',encoding='utf8') as stream:
            json.dump(result,stream,indent=2)
            stream.write('\n')
    print(json.dumps(result,indent=2))

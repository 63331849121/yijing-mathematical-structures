"""Small obstruction calibration: the ten-bit free-class-three rank-two base.
Reuses only the independently written 4/6-bit CE interface; no 14-bit code.
Default read-only; --report exclusively creates a new JSON file.
"""
from pathlib import Path
import importlib.util
import argparse,json

SOURCE=Path(__file__).resolve().with_name('check_cohomology_rotation.py')
spec=importlib.util.spec_from_file_location('small_rotation_interface',SOURCE)
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
M=core.M


def make_ten(kind):
    def g(value):
        a,b,c,d,e=[(value>>(2*j))&3 for j in range(5)]
        out=(M[2][a],M[2][b],M[2][c]^M[a][b],
             M[2][d]^M[a][c]^M[M[a][a]][b],
             M[2][e]^M[b][c]^M[a][M[b][b]])
        return sum(v<<(2*j) for j,v in enumerate(out))
    return 10,g


def controls():
    core.make_model=make_ten
    result=core.control('free_class3_rank2')
    n,g=make_ten(None);size=1<<n
    masks=[1<<i for i in range(n)]+[(1<<i)|(1<<j) for i,j in core.combinations(range(n),2)]
    composed=[core.anf([int((g(x)&mask)==mask) for x in range(size)],n) for mask in masks]
    invrows=[[composed[j][a]^int(a==masks[j]) for j in range(len(masks))] for a in range(size)]
    invariants=core.gf_kernel(invrows,len(masks))
    linear_invrows=[[composed[j][a]^int(a==masks[j]) for j in range(n)] for a in range(size)]
    linear_invariants=core.gf_kernel(linear_invrows,n)
    result['quadratic_invariants_I_g']={'zero_constant_degree_at_most_two_dimension_F4':len(invariants),
                                         'linear_invariant_dimension_F4':len(linear_invariants)}
    assert not linear_invariants
    assert result['eigenspace_dimensions_F4']['one']==len(invariants)
    return {'status':'PASS','field':'F4=F2[omega]/(omega^2+omega+1)',
            'scope':'Ten-bit/1024-point base only, with 45 scalar alternating cochains. No 14-dimensional code/data.',
            'dependencies':'Python standard library only; sibling check_cohomology_rotation.py',
            'model':result}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report',type=Path);a=p.parse_args()
    result=controls()
    if a.report:
        with a.report.open('x',encoding='utf8') as out:out.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

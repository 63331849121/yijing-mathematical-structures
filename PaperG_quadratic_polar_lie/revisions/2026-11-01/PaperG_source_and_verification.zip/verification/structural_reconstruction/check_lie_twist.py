"""Independent exhaustive control of the intrinsic characteristic-two twist.

This six-dimensional binary Lie algebra need not be equipped with an f.
Its derived ideal is the full four-dimensional square-zero ring module;
its nilpotency class is four. Written general proofs are separate.
Default is read-only. --report exclusively creates a new output file.
"""
import argparse
import json
from itertools import product
from pathlib import Path
import platform


def action(u, z):
    out = 0
    for i in range(2):
        if u & (1 << i):
            for mask in range(4):
                if z & (1 << mask) and not mask & (1 << i):
                    out ^= 1 << (mask | (1 << i))
    return out


def bracket(x, y):
    u, v = x & 3, y & 3
    z, t = x >> 2, y >> 2
    coefficient = ((u & 1) * ((v >> 1) & 1)) ^ (((u >> 1) & 1) * (v & 1))
    return (action(u, t) ^ action(v, z) ^ coefficient) << 2


def controls():
    size = 64
    basis = [1 << i for i in range(6)]
    b = [[bracket(x, y) for y in range(size)] for x in range(size)]
    c = [[b[x][y] ^ b[x ^ y][b[x][y]] for y in range(size)] for x in range(size)]
    plus = [[x ^ y ^ c[x][y] for y in range(size)] for x in range(size)]
    assert b[2][b[1][b[2][1]]] != 0  # A nonzero commutator of length four.
    for x, y in product(range(size), repeat=2):
        assert plus[x][y] == plus[y][x]
        assert plus[x][x] == 0 and plus[x][0] == x
        assert c[x][x] == 0
        c_again = c[x][y] ^ c[plus[x][y]][c[x][y]]
        assert c_again == b[x][y]
        assert plus[plus[x][y]][c_again] == x ^ y
    for x, y, z in product(range(size), repeat=3):
        assert plus[plus[x][y]][z] == plus[x][plus[y][z]]
        assert c[plus[x][y]][z] == plus[c[x][z]][c[y][z]]
        assert c[x][c[y][z]] ^ c[y][c[z][x]] ^ c[z][c[x][y]] == 0
        assert b[x][b[y][z]] ^ b[y][b[z][x]] ^ b[z][b[x][y]] == 0
    for x in range(size):
        for w in range(0, size, 4):
            assert b[x][b[x][w]] == 0
    return {
        'status': 'PASS', 'python_version': platform.python_version(),
        'dependencies': 'Python standard library only',
        'model': 'U=F2^2, W=F2[t1,t2]/(t1^2,t2^2), [e1,e2]=1_W',
        'binary_dimension': 6, 'polar_nilpotency_class': 4,
        'all_pairs_checked': size**2, 'all_triples_checked': size**3,
        'verified': ['original Jacobi', 'new elementary abelian addition',
                     'new bracket bilinearity for new addition', 'new Jacobi',
                     'twist squared restores both old addition and old bracket',
                     '(ad x)^2 kills the derived ideal'],
        'limitation': 'Finite exact control; the all-parameter theorem requires the written proof.'
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    result = controls()
    if args.report:
        with args.report.open('x', encoding='utf8') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
    print(json.dumps(result, indent=2))

"""Sparse F4 polynomial and small basis-Lie controls for the 18-bit seed.

No full 2^18 point enumeration and no 14-dimensional code/data are used.
Default read-only; --report exclusively creates a new JSON file.
"""
from itertools import combinations
from pathlib import Path
import argparse,json


def fm(a,b):
    a0,a1,b0,b1=a&1,a>>1,b&1,b>>1
    return ((a0*b0)^(a1*b1))|(((a0*b1)^(a1*b0)^(a1*b1))<<1)
M=[[fm(a,b) for b in range(4)] for a in range(4)]
N=9;zero=(0,)*N
def add(*args):
    out={}
    for p in args:
        for a,c in p.items():
            out[a]=out.get(a,0)^c
            if not out[a]:del out[a]
    return out
def scale(c,p):return {a:M[c][v] for a,v in p.items() if M[c][v]}
def mul(p,q):
    out={}
    for a,ca in p.items():
        for b,cb in q.items():
            e=tuple(0 if x+y==0 else 1+(x+y-1)%3 for x,y in zip(a,b))
            out[e]=out.get(e,0)^M[ca][cb]
            if not out[e]:del out[e]
    return out
def square(p):return mul(p,p)
X=[]
for j in range(N):
    a=[0]*N;a[j]=1;X.append({tuple(a):1})
a,b,c,z,w,v,h,k,r=X
G=[scale(2,p) for p in X]
G[3]=add(G[3],mul(a,b));G[4]=add(G[4],mul(a,c));G[5]=add(G[5],mul(b,c))
G[6]=add(G[6],mul(a,v),mul(c,z))
G[7]=add(G[7],mul(a,w),mul(square(a),c))
G[8]=add(G[8],mul(z,w),mul(a,h),mul(b,k),mul(square(a),v))


def compose(p,images):
    powers=[]
    for q in images:powers.append([{zero:1},q,square(q),mul(square(q),q)])
    out={}
    for mon,coef in p.items():
        term={zero:coef}
        for j,e in enumerate(mon):
            if e:term=mul(term,powers[j][e])
        out=add(out,term)
    return out
def evalp(p,point):
    ans=0
    for mon,coef in p.items():
        value=coef
        for x,e in zip(point,mon):
            for _ in range(e):value=M[value][x]
        ans^=value
    return ans
def f(value):
    point=[(value>>(2*j))&3 for j in range(N)]
    return sum(evalp(p,point)<<(2*j) for j,p in enumerate(G))
def span(vectors):
    piv={}
    for value in vectors:
        while value:
            j=value.bit_length()-1
            if j in piv:value^=piv[j]
            else:piv[j]=value;break
    return list(piv.values())


def controls():
    defects=[add(compose(p,G),p,x) for p,x in zip(G,X)]
    assert not any(defects)
    degrees=[max(sum(e.bit_count() for e in mon) for mon in p) for p in G]
    assert degrees==[1,1,1,2,2,2,2,2,2]
    n=18
    B=[[f((1<<i)^(1<<j))^f(1<<i)^f(1<<j) for j in range(n)] for i in range(n)]
    def br(x,y):
        out=0
        for i in range(n):
            if x>>i&1:
                for j in range(n):
                    if y>>j&1:out^=B[i][j]
        return out
    for i in range(n):
        assert B[i][i]==0
        for j in range(n):
            for ell in range(n):
                assert br(1<<i,B[j][ell])^br(1<<j,B[ell][i])^br(1<<ell,B[i][j])==0
    layers=[list(1<<i for i in range(n))]
    while layers[-1]:
        layers.append(span(br(1<<i,x) for i in range(n) for x in layers[-1]))
        assert len(layers)<=6
    dims=[len(x) for x in layers]
    assert dims==[18,12,6,2,0]
    W=layers[1]
    second=span(br(x,y) for x,y in combinations(W,2))
    assert len(second)==2
    aa,bb,cc,zz,ww,vv,hh,kk,rr=[1<<(2*j) for j in range(N)]
    assert br(zz,ww)==rr
    assert br(aa,br(aa,br(bb,cc)))==rr
    def C(x,y):
        q=br(x,y)
        return q^br(x^y,q)
    def star(x,y):return x^y^C(x,y)
    associator=star(star(aa,bb),cc)^star(aa,star(bb,cc))
    assert associator==rr
    return {'status':'PASS','field':'F4=F2[omega]/(omega^2+omega+1)',
            'scope':'Sparse nine-variable polynomial identity and 18 binary basis-Lie checks; no full point enumeration, no 14-dimensional data.',
            'dependencies':'Python standard library only',
            'coordinate_names':['a','b','c','z','w','v','h','k','r'],
            'f_squared_minus_f_minus_Id_sparse_defects':[len(p) for p in defects],
            'binary_coordinate_degrees':degrees,
            'lower_central_binary_dimensions':dims,'second_derived_binary_dimension':len(second),
            'bracket_z_w_equals_r':True,'ad_a_squared_bracket_b_c_equals_r':True,
            'uncorrected_twist_associator_a_b_c_equals_r':True,
            'jacobi_basis_triples_checked':n**3}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report',type=Path);a=p.parse_args()
    result=controls()
    if a.report:
        with a.report.open('x',encoding='utf8') as out:out.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

"""Exact controls for the explicit hidden-linearization interfaces.

The general filtration theorem is proved separately.  This control exhausts
the 16-dimensional published chain model, verifies its inverse, and computes
reduced Boolean degrees by a vector-valued Mobius transform.
Default writes nothing; --report exclusively creates a new JSON path.
"""
import argparse
import json
import platform
from pathlib import Path


def mul(a, b):
    a0, a1, b0, b1 = a & 1, a >> 1, b & 1, b >> 1
    return ((a0*b0) ^ (a1*b1)) | (((a0*b1) ^ (a1*b0) ^ (a1*b1)) << 1)


M = [[mul(a, b) for b in range(4)] for a in range(4)]
S = [M[a][a] for a in range(4)]


def add(x, y):
    return tuple(a ^ b for a, b in zip(x, y))


def J(x):
    return tuple(M[2][a] for a in x)


def q(x):
    a, b, c, d, e, h, r, s = x
    return (0, 0, M[a][b], M[a][c] ^ M[S[a]][b],
            M[b][c] ^ M[a][S[b]], M[a][e] ^ M[b][d],
            M[a][S[c]] ^ M[S[a]][e] ^ M[a][h] ^ M[c][d],
            M[b][S[c]] ^ M[S[b]][d] ^ M[b][h] ^ M[c][e])


def f(x):
    return add(J(x), q(x))


def H(x):
    return add(x, q(x))


def G(x):
    a, b, c, d, e, h, r, s = x
    return (a, b, c ^ M[a][b], d ^ M[a][c], e ^ M[b][c],
            h ^ M[a][e] ^ M[b][d],
            r ^ M[a][h] ^ M[c][d] ^ M[M[S[a]][a]][S[b]],
            s ^ M[b][h] ^ M[c][e] ^ M[S[a]][M[S[b]][b]])


def decode(value):
    return tuple((value >> (2*j)) & 3 for j in range(8))


def encode(x):
    return sum(a << (2*j) for j, a in enumerate(x))


def anf(values):
    out = values.copy()
    for bit in range(16):
        step = 1 << bit
        for mask in range(1 << 16):
            if mask & step:
                out[mask] ^= out[mask ^ step]
    return out


def prefix_degrees(coefficients):
    result = {}
    for coords in range(2, 9):
        mask_limit = 1 << (2*coords)
        output_mask = mask_limit-1
        result[str(2*coords)] = max(mask.bit_count() for mask in range(mask_limit)
                                   if coefficients[mask] & output_mask)
    return result


def controls():
    hv, gv = [], []
    for value in range(1 << 16):
        x = decode(value)
        fx, hx, gx = f(x), H(x), G(x)
        assert f(fx) == add(fx, x)
        assert H(fx) == J(hx)
        assert G(hx) == x
        assert H(gx) == x
        hv.append(encode(hx))
        gv.append(encode(gx))
    forward = prefix_degrees(anf(hv))
    inverse = prefix_degrees(anf(gv))
    assert list(forward.values()) == [1, 2, 2, 2, 2, 2, 2]
    assert list(inverse.values()) == [1, 2, 2, 2, 2, 3, 3]
    # The class-three prefix is metabelian, yet H is not an involution.
    witness = (1, 1, 0, 0, 0, 0, 0, 0)
    assert H(H(witness))[3] == 1
    # A mismatched linear J makes the average identically zero already
    # for a one-dimensional F4 vector space: f=omega^2 and J=omega.
    assert all(M[3][a] ^ M[3][a] == 0 for a in range(4))
    return {'status': 'PASS', 'field': 'F4=F2[omega]/(omega^2+omega+1)',
            'python_version': platform.python_version(),
            'dependencies': 'Python standard library only',
            'scope': 'Exhaustive chain-model controls, not a substitute for the general filtration proof.',
            'domain_dimension_binary': 16, 'domain_points_checked': 1 << 16,
            'identities_per_point': ['f^2=f+Id', 'H f=J H', 'G H=Id', 'H G=Id'],
            'forward_degree_by_binary_prefix_dimension': forward,
            'inverse_degree_by_binary_prefix_dimension': inverse,
            'metabelian_noninvolution_witness': {'input_F4_coordinates': witness,
                                               'H_squared_F4_coordinates': H(H(witness))},
            'mismatched_J_zero_average_control': True}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    result = controls()
    if args.report:
        with args.report.open('x', encoding='utf8') as stream:
            stream.write(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))

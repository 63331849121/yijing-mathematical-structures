"""Finite controls for the canonical graph and full-morphism interfaces.
Default read-only; --report exclusively creates a report. Standard library.
"""
from itertools import product
from pathlib import Path
import argparse
import json


def mul(a,b):
    a0,a1,b0,b1=a&1,a>>1,b&1,b>>1
    return ((a0*b0)^(a1*b1))|(((a0*b1)^(a1*b0)^(a1*b1))<<1)
M=[[mul(a,b) for b in range(4)] for a in range(4)]
S=[M[a][a] for a in range(4)]
def add(x,y):return tuple(a^b for a,b in zip(x,y))
def f(x):
    a,b,c,d=x
    return (M[2][a],M[2][b],M[2][c]^M[a][b],
            M[2][d]^M[a][c]^M[S[a]][b])
def H(x):
    a,b,c,d=x
    return (a,b,c^M[a][b],d^M[a][c]^M[S[a]][b])
def G(x):
    a,b,c,d=x
    return (a,b,c^M[a][b],d^M[a][c])
def B(x,y):return add(add(f(add(x,y)),f(x)),f(y))
def C(x,y):
    b=B(x,y)
    return add(b,B(add(x,y),b))
def star(x,y):return add(add(x,y),C(x,y))
def lie(x,y):
    a,b,c,d=x;aa,bb,cc,dd=y
    return (0,0,M[a][bb]^M[aa][b],M[a][cc]^M[aa][c])
def tf(x,alpha):
    a,b,c,d=x
    return (a,b,c^M[alpha][a],d^M[alpha][S[a]])
def tl(x,alpha):
    a,b,c,d=x
    return (a,b,c^M[alpha][a],d)
def rank(cols):
    piv={}
    for v in cols:
        while v:
            p=v.bit_length()-1
            if p in piv:v^=piv[p]
            else:piv[p]=v;break
    return len(piv)
def enc(x):return sum(v<<(2*j) for j,v in enumerate(x))


def controls():
    domain=list(product(range(4),repeat=4))
    for x in domain:
        assert G(H(x))==x and H(G(x))==x
        for alpha in range(4):
            assert tf(f(x),alpha)==f(tf(x,alpha))
            assert H(tf(x,alpha))==tl(H(x),alpha)
            for beta in range(4):
                assert tf(tf(x,alpha),beta)==tf(x,alpha^beta)
        # Proper quotient onto the six-dimensional chain prefix.
        a,b,c,d=x
        fc=(M[2][a],M[2][b],M[2][c]^M[a][b])
        hc=(a,b,c^M[a][b])
        assert f(x)[:3]==fc and H(x)[:3]==hc
        for y in domain:
            assert H(star(x,y))==add(H(x),H(y))
            assert C(x,y)==lie(H(x),H(y))
            z=star(x,y);w=C(x,y)
            assert star(star(z,w),C(z,w))==add(x,y)
    # The W inclusion is a proper intertwining embedding from an abelian source.
    for u,v in product(range(4),repeat=2):
        image=(0,0,u,v)
        assert f(image)==(0,0,M[2][u],M[2][v]) and H(image)==image
    # Joint-projection separation is independent of all other graph axioms.
    gamma=[(a,b,M[S[a]][S[b]]) for a,b in product(range(4),repeat=2)]
    assert all((M[2][a],M[2][b],M[2][z]) in gamma for a,b,z in gamma)
    assert rank([enc(x) for x in gamma])==6
    assert rank([enc((a,b,M[2][a],M[2][b])) for a,b in product(range(4),repeat=2)])==4
    return {'status':'PASS','field':'F4=F2[omega]/(omega^2+omega+1)',
            'scope':'One eight-dimensional model and the explicit six-dimensional relaxed-graph counterexample; general claims are proved separately.',
            'dependencies':'Python standard library only','N8_points':len(domain),
            'N8_ordered_pairs':len(domain)**2,
            'checks':['canonical addition transport','canonical bracket transport',
                      'inverse addition recovery','nontrivial Frobenius morphism naturality',
                      'morphism composition','proper quotient','proper subobject'],
            'graph_counterexample':{'section_points':16,'graph_span_dimension':6,
                                    'canonical_induced_linear_map_envelope_dimension':4,
                                    'joint_projection_kernel_dimension':2}}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report',type=Path);a=p.parse_args()
    result=controls()
    if a.report:
        with a.report.open('x',encoding='utf8') as out:out.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

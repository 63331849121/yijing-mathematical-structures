"""Independent exact-coordinate controls for the complete Aut(f14) derivation.

The proof of completeness is in aut_f14_derivation.txt. This program verifies
the lifting operator and representative coordinate identities, not the large
group by enumeration. Run with python -B; no output files are written.
"""
from itertools import product, combinations
import random
import argparse
import json
import platform
from pathlib import Path

MUL = ((0,0,0,0),(0,1,2,3),(0,2,3,1),(0,3,1,2))
INV = (0,1,3,2)
OMEGA = 2

def add(*xs):
    ans = 0
    for x in xs:
        ans ^= x
    return ans

def m(x,y): return MUL[x][y]
def sq(x): return MUL[x][x]
def radd(*xs): return tuple(add(*(v[i] for v in xs)) for i in range(4))
def scale(a,x): return tuple(m(a,v) for v in x)
def rmul(x,y):
    z = [0]*4
    for i,a in enumerate(x):
        for j,b in enumerate(y):
            if not i&j:
                z[i|j] ^= m(a,b)
    return tuple(z)

ONE, T1, T2 = (1,0,0,0), (0,1,0,0), (0,0,1,0)

def f12(x):
    a,b,c,d,e,h = x
    return (m(OMEGA,a),m(OMEGA,b),add(m(OMEGA,c),m(a,b)),
            add(m(OMEGA,d),m(a,c),m(sq(a),b)),
            add(m(OMEGA,e),m(b,c),m(a,sq(b))),
            add(m(OMEGA,h),m(a,e),m(b,d)))

def cocycle_A(x):
    a,b,c,d,e,h = x
    return add(m(a,sq(c)),m(sq(a),e),m(a,h),m(c,d))

def cocycle_B(x):
    a,b,c,d,e,h = x
    return add(m(b,sq(c)),m(sq(b),d),m(b,h),m(c,e))

def f16_packed(v):
    x=tuple((v>>(2*i))&3 for i in range(8))
    y=(*f12(x[:6]),add(m(OMEGA,x[6]),cocycle_A(x[:6])),
       add(m(OMEGA,x[7]),cocycle_B(x[:6])))
    return sum(a<<(2*i) for i,a in enumerate(y))

def polar16(v,w):
    return f16_packed(v^w)^f16_packed(v)^f16_packed(w)

def basis2(vectors):
    piv={}
    for v in vectors:
        while v:
            j=v.bit_length()-1
            if j in piv: v^=piv[j]
            else:
                piv[j]=v
                break
    return list(piv.values())

def ia12(u,v):
    unit = radd(ONE,rmul(T1,v),rmul(T2,u))
    def phi(x):
        a,b,*w = x
        y = radd(rmul(unit,w),scale(a,u),scale(b,v),
                 scale(sq(a),rmul(T1,u)),scale(sq(b),rmul(T2,v)))
        return (a,b,*y)
    return phi

def diagonal(alpha,delta):
    def phi(x):
        a,b,c,d,e,h=x
        return (m(alpha,a),m(delta,b),m(m(alpha,delta),c),
                m(m(sq(alpha),delta),d),m(m(alpha,sq(delta)),e),
                m(m(sq(alpha),sq(delta)),h))
    return phi

def lower_shear(t):
    def phi(x):
        a,b,c,d,e,h=x
        return (a,add(b,m(t,a)),add(c,m(t,sq(a))),d,add(e,m(t,d)),h)
    return phi

def upper_shear(t):
    def phi(x):
        a,b,c,d,e,h=x
        return (add(a,m(t,b)),b,add(c,m(t,sq(b))),add(d,m(t,e)),e,h)
    return phi

def triangular14(alpha,gamma,eta):
    def phi(y):
        a,b,c,d,e,h,r=y
        return (m(alpha,a),add(m(gamma,a),m(eta,b)),
                add(m(m(alpha,eta),c),m(m(alpha,gamma),sq(a))),
                m(m(sq(alpha),eta),d),
                add(m(m(alpha,sq(eta)),e),m(m(m(alpha,eta),gamma),d)),
                m(m(sq(alpha),sq(eta)),h),
                add(m(sq(eta),r),m(sq(gamma),sq(a))))
    return phi

def monomials(x): return tuple(x)+tuple(sq(a) for a in x)
def teval(coeff,x): return add(*(m(a,b) for a,b in zip(coeff,monomials(x))))

bits=[]
for j in range(12):
    x=[0]*6
    x[j//2] = 1 if j%2==0 else OMEGA
    bits.append(tuple(x))
samples = bits + [tuple(a^b for a,b in zip(bits[i],bits[j]))
                  for i,j in combinations(range(12),2)]

def pack(v): return sum(a<<(2*i) for i,a in enumerate(v))
def packed_scale(a,v,length):
    if a==0: return 0
    if a==1: return v
    even=sum(1<<(2*i) for i in range(length))
    lo,hi=v&even,(v>>1)&even
    w=hi^((lo^hi)<<1)
    return w if a==2 else w^v

piv={}
for j in range(12):
    coeff=tuple(int(i==j) for i in range(12))
    column=pack(add(teval(coeff,f12(x)),m(OMEGA,teval(coeff,x))) for x in samples)
    payload=1<<(2*j)
    while column:
        i=((column&-column).bit_length()-1)//2
        c=(column>>(2*i))&3
        if i in piv:
            row,data=piv[i]
            column ^= packed_scale(c,row,len(samples))
            payload ^= packed_scale(c,data,12)
        else:
            piv[i]=(packed_scale(INV[c],column,len(samples)),packed_scale(INV[c],payload,12))
            break
assert len(piv)==10

def solve_lift(phi,lam):
    column=pack(add(cocycle_A(phi(x)),m(lam,cocycle_A(x))) for x in samples)
    payload=0
    while column:
        i=((column&-column).bit_length()-1)//2
        c=(column>>(2*i))&3
        assert i in piv, 'The claimed quotient automorphism does not stabilize [A].'
        row,data=piv[i]
        column ^= packed_scale(c,row,len(samples))
        payload ^= packed_scale(c,data,12)
    return tuple((payload>>(2*j))&3 for j in range(12))

def controls():
    rng=random.Random(20261031)
    all_x=list(product(range(4),repeat=6))
    count=0
    # Exact binary Lie-series computation needed by the IA-action proof.
    binary_basis16=[1<<i for i in range(16)]
    gamma=binary_basis16[:]
    lower_dims=[16]
    fifth=None
    for depth in range(2,7):
        gamma=basis2(polar16(x,y) for x in binary_basis16 for y in gamma)
        lower_dims.append(len(gamma))
        if depth==5: fifth=gamma[:]
    assert lower_dims==[16,12,10,6,4,0]
    assert len(basis2(fifth+[1<<i for i in range(12,16)]))==4
    # Every diagonal and lower shear is a quotient automorphism preserving [A].
    quotient_controls=[]
    for alpha,delta in product((1,2,3),repeat=2):
        quotient_controls.append((diagonal(alpha,delta),sq(delta)))
    for t in range(4):
        quotient_controls.append((lower_shear(t),1))
    # Independent IA choices span the entire kernel in the algebraic proof.
    for _ in range(24):
        u=tuple(rng.randrange(4) for _ in range(4))
        v=tuple(rng.randrange(4) for _ in range(4))
        quotient_controls.append((ia12(u,v),1))
    for phi,lam in quotient_controls:
        coeff=solve_lift(phi,lam)
        for x in all_x:
            assert phi(f12(x))==f12(phi(x))
            assert add(teval(coeff,f12(x)),m(OMEGA,teval(coeff,x))) == add(cocycle_A(phi(x)),m(lam,cocycle_A(x)))
        count+=1
    # Explicit upper-shear pullback on the two extension classes.
    for t in range(4):
        phi=upper_shear(t)
        for x in all_x:
            a,b,*_=x
            assert cocycle_A(phi(x))==add(cocycle_A(x),m(t,cocycle_B(x)),m(sq(t),m(a,b)),m(m(sq(t),t),sq(b)))
            assert cocycle_B(phi(x))==add(cocycle_B(x),m(sq(t),sq(b)))
    # Composition law of the auxiliary IA group, checked on original f12 coordinates.
    for _ in range(24):
        u,v,up,vp=(tuple(rng.randrange(4) for _ in range(4)) for _ in range(4))
        unit=radd(ONE,rmul(T1,v),rmul(T2,u))
        u2,v2=radd(u,rmul(unit,up)),radd(v,rmul(unit,vp))
        f,g,h=ia12(u,v),ia12(up,vp),ia12(u2,v2)
        for _ in range(32):
            x=tuple(rng.randrange(4) for _ in range(6))
            assert f(g(x))==h(x)
    # All 36 triangular quotient matrices have the stated simultaneous lift;
    # its group law is checked for every pair on a full binary basis.
    parabolic=list(product((1,2,3),range(4),(1,2,3)))
    basis14=[]
    for j in range(14):
        x=[0]*7;x[j//2]=1 if j%2==0 else OMEGA
        basis14.append(tuple(x))
    for alpha,gamma,eta in parabolic:
        lift=triangular14(alpha,gamma,eta)
        for x in all_x:
            y=lift((*x,0));py=y[:6]
            assert y[6]==m(sq(gamma),sq(x[0]))
            assert py==lift((*x,1))[:6]
            assert py==diagonal(alpha,eta)(lower_shear(m(gamma,INV[eta]))(x))
            assert add(cocycle_A(py),m(sq(eta),cocycle_A(x)))==m(sq(gamma),sq(x[0]))
    for alpha,gamma,eta in parabolic:
        f=triangular14(alpha,gamma,eta)
        for ap,gp,ep in parabolic:
            g=triangular14(ap,gp,ep)
            h=triangular14(m(alpha,ap),add(m(gamma,ap),m(eta,gp)),m(eta,ep))
            for x in basis14:
                assert f(g(x))==h(x)
    order12=180*4**8
    stabilizer=order12//5
    order14=16*stabilizer
    return {'status':'PASS',
           'python_version':platform.python_version(),
           'dependencies':'Python standard library only',
           'delta_F4_rank':len(piv),'delta_F4_kernel_dimension':12-len(piv),
           'exact_F16_lower_central_dimensions':lower_dims,
           'exact_F16_gamma5_is_last_two_F4_coordinates':True,
           'all_input_points_per_lift':len(all_x),'lift_coordinate_controls':count,
           'H12_all_scalar_shear_identities':4*len(all_x),
           'parabolic_section_all_pairs_on_binary_basis':len(parabolic)**2*len(basis14),
           'Aut_f12_order':order12,'projective_stabilizer_order':stabilizer,
           'Aut_f14_order':order14,'scope':'Complete group order follows from the proof; coordinate controls are finite validations.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    result=controls()
    if args.report:
        with args.report.open('x',encoding='utf8') as stream:
            json.dump(result,stream,indent=2)
            stream.write('\n')
    print(json.dumps(result,indent=2))

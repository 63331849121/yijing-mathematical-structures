Exact verification materials for PaperG
======================================

Tested environment: CPython 3.14.6, SymPy 1.14.0, Windows.
Required: Python >=3.10. check_chain_rank_certificates.py and
critical_refinement/check_critical_staircase.py use SymPy; the remaining
controls use the standard library. The tested dependency is pinned in
requirements.txt. No publisher PDFs are redistributed.

Unified replay, from the source-project directory:
  python verification/run_all.py --output-dir ../PaperG_replay

The destination must be new or empty. All 50 programs run in an isolated
copy. The supplied JSON files are hashed before and after, and are never
overwritten. The runner continues after a failure, collects all failures,
and returns exit code 1 if any check fails. Individual stdout/stderr logs,
fresh JSON reports and replay_summary.json are kept in the destination.
Omit --output-dir to create verification_runs/<timestamp>. To discard
all runner output after printing the summary, use:
  python verification/run_all.py --no-write

The report records the tested Python and SymPy versions, source JSON
SHA256 hashes, each program's exit code and scope, and total program_count.
The definitive program list is PROGRAMS in run_all.py. Every newer checker
accepts --report with a fresh filename and creates that file exclusively.
Legacy individual programs can write beside themselves; use the unified
runner to keep those writes in its isolated copy.

What is certified
-----------------

The seven chain_rank_certificates input records cover binary quotient
sizes n=4,6,8,10,12,14,16. The independent rank checker authenticates the
manifest, reconstructs all equations, proves both rank bounds, and imports
no generator code. Exact SymPy DomainMatrix elimination over GF(2) gives:
  ranks: 14,30,58,92,132,184,244
  quadratic extension quotient F4 dimensions: 1,2,1,1,2,1,0
It explicitly asserts
  dim_F4(H_g)=(dim_F2(E_g)-rank_F2(delta))/2
and compares this dimension with the named quotient representatives.
The n=16 full-rank result is H_g=0 for that specified chain prefix and
quadratic central-extension problem. It is not a universal terminality
claim for all sixteen-dimensional objects or a later high-dimensional model.

The root-level interface/transcription/canonical-family/cohomology/orbit
programs tie the coordinate tables to the original certificates, binary
degree bounds, exact small CE ranks, 1/2/7 low-class orbits and mass checks.
Where explicitly stated, checking every input of weight at most four is
lossless because the Boolean identity has degree at most four. Deterministic
random conjugacy/composition controls are labelled as samples, not proofs.

The remaining folders support the written structural and counting proofs:

  mu_extremizers/: universal modules, actual coordinate actions, the
    complete 4^9 class-five partition into 11 orbits, and automorphism
    interfaces. Sampled actions are labelled in reports.

  fixed_surplus/, surplus_transition/, critical_constant/,
  critical_window/, action_cohomology/, critical_refinement/:
    independent module and ordinary-CE systems, exact small orbit and
    stabilizer sums, finite-field action comparisons, socle/generation
    and negative controls, and symbolic/integer exponent inequalities.
    No finite range is used to infer a general asymptotic, threshold,
    concentration, or generic indecomposability theorem. F8/F16 ordinary
    Lie comparisons are not silently treated as binary orbit maps.

  structural_reconstruction/: nine portable standard-library controls
    for canonical/graph interfaces, the metabelian twist, hidden
    linearization, cohomology rotation and its stable domain, an
    eighteen-dimensional nonmetabelian seed, the fourteen-dimensional
    automorphism lift equations, and all 16384 states of the optimal
    two-frame decoder. Selected lift controls and exact complement
    products support the separate completeness argument; they do not
    enumerate the entire 37748736-element automorphism group.

  general_structure/: ten portable standard-library controls for
    explicit high-class coefficient models, the whole-derived-factor
    obstruction, reset/trace constructions, first integrals, free binary
    CE ranks, orientation rigidity, the normal-center bridge, and the
    global-stability interfaces, rank--class bridge, and ordinary Engel
    top central covers. The last control checks all 65536 F4 inputs of
    the eight-dimensional rank-two model and the complete weight c+1
    CE/cubic systems at ordinary ranks four and five. Its local helper
    reconstructs raw Jacobi modules without external inputs.
    See general_structure/README.txt for precise per-program scope.
    Its generic coefficient verifier checks the complete Boolean
    composition and structural interfaces without construction imports.

General proofs and source scope
-------------------------------

The global nilpotence and quadratic-stability theorems, canonical restricted
derived quotients, the quartic class bound, same-point-rank Engel comparison,
the general symmetric top cover and centre-by-metabelian class boundary,
all-parameter class and dimension bounds,
fixed-sector rigidity, finite stem-tower termination, categorical
reconstruction and asymptotic laws are mathematical proofs in the paper.
These finite controls check their stated interfaces and specified models;
they are not substitutes for those proofs or proofs of global originality.
The package includes no new Lean/proof-assistant formalization.

general_structure/SOURCE_ATTRIBUTION.txt summarizes the verified scope of
Premet, Traustason, restricted-current/quadratic-map, ordinary Hopf/Kunneth,
and spread-classification inputs. The earlier source_audit/ directory
records related attribution evidence. Third-party originals and internal
research/development logs are intentionally excluded from this package.

# Paper F v4.0

**Four-zero tail-palindromic polynomials over F2: reciprocity and transformation boundaries**  
Wencong Huang and Baohua Li  
24-page revision, 22 November 2026.

Version 4.0 adds the root-ratio and root-product criteria, fixed-phase label bounds, and the B-family extension and closed-orbit results. Section 5 explains how the verified primitive witnesses give sparse feedback recurrences. The existence questions are in Section 6.

## Manuscript and proof materials

- **PaperF_fourzero.pdf** and **PaperF_fourzero.tex** are the manuscript and its LaTeX source.
- **verify_root_pairs.py** checks the signed power sums, the root-ratio and root-product tests, and the two order examples in Appendix A.3.
- **verification/B_family/** contains the quadratic- and cubic-extension checkers for Appendix C.
- **verification/root_power/** contains the cubic and quintic certificates and their independent checkers for Appendix B.
- **verification/primitivity/** contains the complete counts at even degrees 6–200, the first-witness certificates through degree 300, and the input data for the arithmetic replay. The two summary tables are supplied as CSV files.
- **verification/independent/** contains a second implementation of selected root-pair and B-family checks using FLINT.
- **provenance/PaperF_v3.0_data_and_code.zip** preserves the original data and code archive from the [version 3.0 deposit](https://doi.org/10.5281/zenodo.23880299). The original license notices accompany the inherited materials.

The quadratic transform classifications and the cubic and quintic root-power classifications apply across all their stated parameters. The B-family extension results describe factors in the specified extensions. The root-pair criterion applies to individual candidates in degrees twice an odd prime. The two infinite irreducibility questions and conjecture C4 are stated in Section 6.

## Reproduction

Use a working copy with Python assertions enabled. Python 3.14.6 was used for the release checks. The cubic B-family checker uses SymPy 1.14.0. The primitivity replay and the independent FLINT checker use python-flint 0.9.0 with FLINT 3.6.0. The remaining commands use the standard library.

Run from the package root.

~~~text
python -B verify_root_pairs.py
python -B verification/B_family/verify_quadratic_extension.py
python -B verification/B_family/verify_cubic_extension.py
python -B verification/root_power/check_cubic_formal.py
python -B verification/root_power/check_quintic_classification.py
python -B verification/root_power/check_quintic_branches.py
python -B verification/root_power/check_certificate_lattice.py
python -B verification/primitivity/verify_primitivity.py --data verification/primitivity/inputs --out ../paperf-primitivity-replay
python -B verification/independent/recheck_with_flint.py
~~~

The LaTeX source is self-contained. The supplied PDF was built with Tectonic 0.16.9. SHA256SUMS.txt binds the manuscript, source, data, and checkers.

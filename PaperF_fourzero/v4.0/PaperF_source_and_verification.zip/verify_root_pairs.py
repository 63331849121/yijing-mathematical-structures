"""Independent finite checks for the local Paper F revision. Run with Python 3."""
from functools import lru_cache
from itertools import combinations
from math import gcd, isqrt


def require(condition, context):
    if not condition:
        raise ArithmeticError(str(context))


# The bit in position r is the coefficient of degree r over F_2.
def remainder(a, divisor):
    while a.bit_length() >= divisor.bit_length():
        a ^= divisor << (a.bit_length() - divisor.bit_length())
    return a


def exact_quotient(a, divisor):
    require(divisor != 0, "zero divisor")
    quotient = 0
    while a.bit_length() >= divisor.bit_length():
        shift = a.bit_length() - divisor.bit_length()
        quotient |= 1 << shift
        a ^= divisor << shift
    require(a == 0, "inexact polynomial division")
    return quotient


def multiply(a, b):
    product = 0
    while b:
        lowest_bit = b & -b
        product ^= a << (lowest_bit.bit_length() - 1)
        b ^= lowest_bit
    return product


def poly_gcd(a, b):
    while b:
        a, b = b, remainder(a, b)
    return a


def power_mod(a, exponent, modulus):
    result = 1
    while exponent:
        if exponent & 1:
            result = remainder(multiply(result, a), modulus)
        a = remainder(multiply(a, a), modulus)
        exponent >>= 1
    return result


@lru_cache(None)
def prime_divisors(value):
    primes = []
    for d in range(2, isqrt(value) + 1):
        if value % d == 0:
            primes.append(d)
            while value % d == 0:
                value //= d
    if value > 1:
        primes.append(value)
    return primes


def candidate(n, i, j):
    polynomial = (1 << (n + 1)) - 1
    for r in (i, j, n - 1 - i, n - 1 - j):
        polynomial ^= 1 << r
    return polynomial


def irreducible(f):
    n = f.bit_length() - 1
    if power_mod(2, 1 << n, f) != 2:
        return False
    return all(poly_gcd(f, power_mod(2, 1 << (n // r), f) ^ 2) == 1
               for r in prime_divisors(n))


def root_order(f):
    """Call only after checking irreducibility in even degree."""
    n = f.bit_length() - 1
    require(n % 2 == 0, "even degree required")
    q = 1 << (n // 2)
    order = q * q - 1
    for prime in prime_divisors(q - 1) + prime_divisors(q + 1):
        while order % prime == 0 and power_mod(2, order // prime, f) == 1:
            order //= prime
    return order


def companion_trace(f, exponent):
    """Trace of multiplication by x^exponent in F_2[x]/(f)."""
    base = 2 if exponent > 0 else f >> 1  # x*(f >> 1) = 1 mod f.
    column = power_mod(base, abs(exponent), f)
    trace = 0
    for r in range(f.bit_length() - 1):
        trace ^= (column >> r) & 1
        column = remainder(column << 1, f)
    return trace


def logarithmic_coefficient(prefix, degree):
    """Coefficient of z^degree in z*C'(z)/C(z), by low-to-high division."""
    numerator = sum((prefix & (1 << r)) for r in range(1, degree + 1, 2))
    for r in range(degree):
        if (numerator >> r) & 1:
            numerator ^= prefix << r
    return (numerator >> degree) & 1


def check_prefixes():
    # A last hole at j >= 10 contributes zero through degree 9.
    entries = [(1, 3, 9), (2, 4, -9), (2, 5, 9), (2, 6, -9),
               (2, 7, 9), (2, 8, 9), (2, 10, -9)]
    for i, j, m in entries:
        shift = int(m > 0)
        prefix = ((1 << 10) - 1) ^ (1 << (i + shift)) ^ (1 << (j + shift))
        require(logarithmic_coefficient(prefix, 9) == 1, (i, j, m))
    prefix = ((1 << 16) - 1) ^ (1 << 2) ^ (1 << 9)
    for extra in (0, 1 << 12):
        require(logarithmic_coefficient(prefix ^ extra, 15) == 1, ("j=9", extra))
    print("All nine stable or boundary prefixes give the stated signed sums.")


def check_signed_table():
    checked = 0
    for p in (3, 5, 7, 11, 13, 17, 19, 23, 29, 31):
        for i, j in combinations(range(1, p), 2):
            f = candidate(2 * p, i, j)
            checked += 1
            pos, neg = (companion_trace(f, m) for m in (3, -3))
            if p == 3:
                require(pos == 1, (p, i, j))
                continue
            holes = {i, j}
            h1, h2, h3 = (int(r in holes) for r in (1, 2, 3))
            require(pos == 1 ^ h1 ^ h2, (p, i, j, 3))
            require(neg == 1 ^ h3 ^ ((1 ^ h1) & h2), (p, i, j, -3))
            if pos or neg:
                continue
            require((i, j) == (1, 3) or (i == 2 and j >= 4), (p, i, j))
            if (p, i, j) == (7, 2, 5):
                require(remainder(f, 0b111) == 0, "missing quadratic factor")
                continue
            if i == 1:
                witness = 9
            elif p == 7:
                witness = {4: 15, 6: 9}[j]
            else:
                witness = {4: -9, 5: 9, 6: -9, 7: 9, 8: 9, 9: -15}.get(j, -9)
            require(companion_trace(f, witness) == 1, (p, i, j, witness))
    print(f"Signed trace table: {checked} candidates, all odd primes 3 <= p <= 31.")


def determinant(matrix):
    """Fraction-free elimination over F_2[Y]. Row swaps preserve signs here."""
    size = len(matrix)
    previous = 1
    for k in range(size - 1):
        row = next((r for r in range(k, size) if matrix[r][k]), None)
        if row is None:
            return 0
        matrix[k], matrix[row] = matrix[row], matrix[k]
        pivot = matrix[k][k]
        for i in range(k + 1, size):
            for j in range(k + 1, size):
                numerator = multiply(pivot, matrix[i][j]) ^ multiply(matrix[i][k], matrix[k][j])
                matrix[i][j] = exact_quotient(numerator, previous)
        previous = pivot
    return matrix[-1][-1]


def pair_resultant(f, *, ratios):
    """Norm of f(Yx) or x^n f(Y/x) in F_2[Y][x]/(f). Includes all root pairs."""
    n = f.bit_length() - 1
    matrix = [[0] * n for _ in range(n)]
    powers = [remainder(1 << k, f) for k in range(2 * n)]
    for exponent in range(n + 1):
        if not (f >> exponent) & 1:
            continue
        x_power = exponent if ratios else n - exponent
        for column in range(n):
            reduced = powers[column + x_power]
            for row in range(n):
                if (reduced >> row) & 1:
                    matrix[row][column] ^= 1 << exponent
    result = determinant(matrix)
    require(result.bit_length() - 1 == n * n and result & 1, ("resultant", n))
    return result


def generator_polynomial(order):
    """Roots of exact odd order, removing each proper prime-index subgroup."""
    result = (1 << order) ^ 1
    for prime in prime_divisors(order):
        subgroup = (1 << (order // prime)) ^ 1
        result = exact_quotient(result, poly_gcd(result, subgroup))
    return result


def check_pair_tests(p):
    q, n = 1 << p, 2 * p
    theta = exact_quotient((1 << (q + 1)) ^ 1, 0b1001)
    gen_t = generator_polynomial(q + 1)
    gen_k = generator_polynomial(q - 1)
    total = irreducible_count = full_ratio_count = primitive_count = 0
    for i, j in combinations(range(1, p), 2):
        f = candidate(n, i, j)
        ratios = pair_resultant(f, ratios=True)
        products = pair_resultant(f, ratios=False)
        weak_factor = poly_gcd(ratios, theta)
        weak_ratio = weak_factor != 1
        full_ratio = poly_gcd(ratios, gen_t) != 1
        full_product = poly_gcd(products, gen_k) != 1
        is_irreducible = irreducible(f)
        order = root_order(f) if is_irreducible else 0
        require(weak_ratio == is_irreducible, (n, i, j, "irreducibility"))
        require((full_ratio and full_product) == (order == q * q - 1), (n, i, j, "primitivity"))
        if is_irreducible:
            product_factor = poly_gcd(products, (1 << (q - 1)) ^ 1)
            require(weak_factor.bit_length() == n + 1 and irreducible(weak_factor),
                    (n, i, j, "single ratio orbit"))
            require(product_factor.bit_length() == p + 1 and irreducible(product_factor),
                    (n, i, j, "single product orbit"))
            ratio_order = order // gcd(order, q - 1)
            product_order = order // gcd(order, q + 1)
            require(full_ratio == (ratio_order == q + 1), (n, i, j, "ratio order"))
            require(full_product == (product_order == q - 1), (n, i, j, "product order"))
            if (n, i, j) == (10, 3, 4):
                require((order, ratio_order, product_order) == (341, 11, 31), "degree 10 example")
        total += 1
        irreducible_count += is_irreducible
        full_ratio_count += full_ratio
        primitive_count += full_ratio and full_product
    print(f"{n:2d} {total:10d} {irreducible_count:11d} {full_ratio_count:10d} {primitive_count:9d}",
          flush=True)


def check_degree_58():
    n, i, j = 58, 15, 18
    q = 1 << 29
    f = candidate(n, i, j)
    require(irreducible(f), "degree 58 irreducibility")
    order = root_order(f)
    require(order == (q * q - 1) // 1103, "degree 58 root order")
    for exponent, expected in ((q - 1, q + 1), (q + 1, (q - 1) // 1103)):
        image = power_mod(2, exponent, f)
        require(power_mod(image, expected, f) == 1, "power containment")
        for prime in prime_divisors(expected):
            require(power_mod(image, expected // prime, f) != 1, ("proper order", prime))
    print(f"n=58 (15,18): root order {order}, ratio order {q + 1}, product order {(q - 1) // 1103}.")


if __name__ == "__main__":
    check_prefixes()
    check_signed_table()
    print(" n candidates irreducibles full-ratio primitive")
    for half_degree in (3, 5, 7, 11):
        check_pair_tests(half_degree)
    check_degree_58()

"""Verify the cubic-extension certificates in the B-family orbit note."""

from pathlib import Path
from runpy import run_path

from sympy import Poly, symbols


OPS = run_path(str(Path(__file__).with_name("verify_quadratic_extension.py")))
multiply = OPS["multiply"]
square = OPS["square"]
remainder = OPS["remainder"]
pullback = OPS["quadratic_pullback"]
descent_and_original = OPS["descent_and_original"]


def mask(poly):
    return sum(
        1 << exponent
        for (exponent,), coefficient in poly.terms()
        if int(coefficient) & 1
    )


def candidate_polynomials():
    b, a = symbols("b a")
    b, a = (Poly(v, b, a, modulus=2) for v in (b, a))
    s = a * a + a
    u = b * b + b
    denominator = (a + b) * (a + 1) * (b + 1)
    numerator = (a * b * (s * s + s) + a * s) * (a + 1) * (b + 1) + a * b * (a + b)
    numerator2 = numerator + (s + u) * denominator
    forbidden = (a, b, a + 1, b + 1, a + b, a + b + 1)

    def strip_forbidden(poly):
        for factor in forbidden:
            while poly.rem(factor).is_zero:
                poly = poly.exquo(factor)
        return poly

    def relation(t, x_numerator):
        equation = (
            (t * t + t) * x_numerator**2
            + (t * t + 1) * x_numerator * denominator
            + t * t * denominator**2
        )
        return strip_forbidden(equation)

    first = relation(a, numerator)
    for phase, expected in (
        (0, [(1, 7), (1, 22), (3, 3), (6, 2), (14, 1), (14, 1), (14, 1), (18, 1), (18, 1)]),
        (1, [(1, 8), (1, 24), (6, 1), (6, 2), (27, 1), (51, 1)]),
    ):
        eliminant = first.resultant(relation(a + b + phase, numerator2))
        assert eliminant.degree() == 128
        factors = eliminant.factor_list()[1]
        assert sorted((factor.degree(), multiplicity) for factor, multiplicity in factors) == expected
        print(f"Cubic phase {phase}: resultant factor degrees and multiplicities {expected}")
        for factor, _ in factors:
            if factor.degree() % 9 == 0:
                yield factor.degree(), mask(factor)


def field_operations(modulus):
    degree = modulus.bit_length() - 1

    def times(x, y):
        return remainder(multiply(x, y), modulus)

    def squared(x):
        return remainder(square(x), modulus)

    def inverse(x):
        assert x != 0
        result = 1
        for _ in range(degree - 1):
            x = squared(x)
            result = times(result, x)
        return result

    def partial_trace(x, k):
        result = 0
        for _ in range(k):
            result ^= x
            x = squared(x)
        return result

    def frobenius(x, k):
        for _ in range(k):
            x = squared(x)
        return x

    return times, squared, inverse, partial_trace, frobenius


def minimal_polynomial(x, degree, squared, times):
    coefficients = [1]
    conjugate = x
    for _ in range(degree):
        updated = [0] * (len(coefficients) + 1)
        for index, coefficient in enumerate(coefficients):
            updated[index] ^= times(coefficient, conjugate)
            updated[index + 1] ^= coefficient
        coefficients = updated
        conjugate = squared(conjugate)
    assert conjugate == x and set(coefficients) <= {0, 1}
    return sum(coefficient << i for i, coefficient in enumerate(coefficients))


def check_phases():
    candidates = sorted(candidate_polynomials())
    assert candidates == [(18, 0x4FB89), (18, 0x5C03D), (27, 0xD01DFEB)]
    accepted = {}
    t = 2
    for degree, modulus in candidates:
        times, squared, inverse, partial_trace, frobenius = field_operations(modulus)
        for k in ((12, 24) if degree == 18 else (18, 36)):
            tq = frobenius(t, k)
            w = 1 ^ inverse(t)
            wq = 1 ^ inverse(tq)
            s = squared(t) ^ t
            x = times(squared(s) ^ times(wq, s) ^ inverse(w) ^ inverse(wq), inverse(w ^ wq))
            lt = partial_trace(x, k)
            relation = times(w, squared(x)) ^ times(squared(w), x) ^ 1
            print(
                f"t modulus = {modulus:#x}, k = {k}, x = {x:#x}, "
                f"L_k(x) = {lt:#x}, cleared relation = {relation:#x}"
            )
            if lt == t and relation == 0:
                assert x != 0
                assert frobenius(x, k) == x ^ s
                reciprocal = minimal_polynomial(x, degree, squared, times)
                accepted[k] = int(f"{reciprocal:0{degree + 1}b}"[::-1], 2)
    assert accepted == {24: 0x412B1, 12: 0x55ABF}
    X = symbols("X")
    for k, h_mask in sorted(accepted.items()):
        f_mask = pullback(h_mask)
        poly = Poly(sum(X**i for i in range(f_mask.bit_length()) if (f_mask >> i) & 1), X, modulus=2)
        factors = sorted((mask(p), e) for p, e in poly.factor_list()[1])
        expected = [(0x52AF3, 1), (0x56EF3, 1)] if k == 24 else [(0x1475B0A6D9, 1)]
        assert factors == expected
        print(f"k = {k} mod 36: h factor {h_mask:#x}, f factors {[hex(p) for p, _ in factors]}")


def check_remaining_obstruction():
    h_small, _ = descent_and_original(2)
    assert h_small == 0x37
    X = symbols("X")
    poly = Poly(sum(X**i for i in range(6) if (h_small >> i) & 1), X, modulus=2)
    assert poly.is_irreducible
    times, squared, _, partial_trace, frobenius = field_operations(0x3B)
    x = 2

    def evaluate(k):
        return times(7, frobenius(x, k)) ^ times(3, partial_trace(x, k) ^ 4)

    assert evaluate(2) == evaluate(72) == evaluate(432) == 0
    assert partial_trace(x, 10) == 0
    assert frobenius(x, 5) == x
    print("The degree-5 factor 0x37 persists at k = 72 mod 360.")


if __name__ == "__main__":
    check_phases()
    check_remaining_obstruction()

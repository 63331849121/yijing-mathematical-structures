"""Replay the finite certificates for the B-family quadratic-extension note.

An integer encodes a polynomial over F_2, with bit i equal to [X**i].
"""
from math import lcm

X = 2
A = 0x7
G6 = 0x61
P12_RECIPROCAL = 0x18FB
P12 = 0x1BE3


def remainder(poly, divisor):
    while poly.bit_length() >= divisor.bit_length():
        poly ^= divisor << (poly.bit_length() - divisor.bit_length())
    return poly


def gcd(left, right):
    while right:
        left, right = right, remainder(left, right)
    return left


def square(poly):
    result = 0
    while poly:
        term = poly & -poly
        result |= 1 << (2 * (term.bit_length() - 1))
        poly ^= term
    return result


def multiply(left, right):
    result = 0
    while right:
        term = right & -right
        result ^= left << (term.bit_length() - 1)
        right ^= term
    return result


def frobenius_x(exponent, modulus):
    result = X
    for _ in range(exponent):
        result = remainder(square(result), modulus)
    return result


def descent_and_original(k):
    q = 1 << k
    high_terms = 1 << q
    for index in range(2, k):
        high_terms ^= 1 << (q - (1 << index) + 1)
    descent = A ^ high_terms ^ (high_terms << 1)
    original = ((1 << (2 * q + 3)) - 1) ^ (
        (1 << 3) ^ (1 << q) ^ (1 << (q + 1)) ^ (1 << (2 * q - 2))
    )
    return descent, original


def quadratic_pullback(poly):
    degree = poly.bit_length() - 1
    power = 1
    result = 0
    for i in range(degree, -1, -1):
        if (poly >> i) & 1:
            result ^= power << (2 * i)
        power ^= power << 1
    return result


def check_seed():
    # Any proper factor of a reducible sextic has a factor of degree <= 3.
    for exponent in (2, 3):
        residue = frobenius_x(exponent, G6) ^ X
        assert gcd(G6, residue) == 1
        print(f"G6: X^(2^{exponent}) + X remainder = {residue:#x}")

    # Degree-12 Rabin test and evaluation of F_R in the reciprocal field.
    modulus = P12_RECIPROCAL
    assert frobenius_x(12, modulus) == X
    for exponent in (4, 6):
        residue = frobenius_x(exponent, modulus) ^ X
        assert gcd(modulus, residue) == 1
        print(f"P12*: X^(2^{exponent}) + X remainder = {residue:#x}")

    reciprocal = int(f"{P12:013b}"[::-1], 2)
    assert reciprocal == modulus
    first_period = (
        0x0002, 0x0016, 0x0076, 0x0736, 0x0E89, 0x0731,
        0x0000, 0x03CE, 0x0C21, 0x0118, 0x06A5, 0x0D37,
    )
    partial_trace = 0
    x_to_q = X
    for k in range(24):
        result = remainder(
            multiply(A, x_to_q) ^ multiply(3, partial_trace ^ 4), modulus
        )
        expected = first_period[k % 12] ^ (3 if k >= 12 else 0)
        assert result == expected
        if k in (6, 18):
            assert x_to_q == 0xAF1
            assert partial_trace == (0x31B if k == 6 else 0x31A)
        partial_trace ^= x_to_q
        x_to_q = remainder(square(x_to_q), modulus)
    assert partial_trace == 0 and x_to_q == X
    print("P12*: F_R vanishes in exactly one class, k = 6 mod 24.")

    for factor, prime_quotients, expected_mask in (
        (A, (2,), 0x19),
        (P12, (8, 12), 0x1E7412D),
    ):
        pulled = quadratic_pullback(factor)
        assert pulled == expected_mask
        degree = pulled.bit_length() - 1
        assert degree == 2 * (factor.bit_length() - 1)
        assert frobenius_x(degree, pulled) == X
        for exponent in prime_quotients:
            assert gcd(pulled, frobenius_x(exponent, pulled) ^ X) == 1
        print(f"Pullback factor of degree {degree}: {pulled:#x}")


def check_original_polynomials():
    for k in range(2, 12):
        descent, original = descent_and_original(k)
        expected = A if k % 4 == 3 else P12 if k % 24 == 6 else 1
        assert gcd(descent, frobenius_x(2 * k, descent) ^ X) == expected
        assert gcd(original, frobenius_x(2 * k, original) ^ X) == 1
        if expected != 1:
            exponent = 2 if expected == A else 1
            for poly, factor in (
                (descent, expected),
                (original, quadratic_pullback(expected)),
            ):
                factor_power = factor if exponent == 1 else square(factor)
                assert remainder(poly, factor_power) == 0
                assert remainder(poly, multiply(factor_power, factor)) != 0
        print(f"R={k + 1:2d}: gcd(h_R, X^(q^2)+X)={expected:#x}; gcd(f_R, X^(q^2)+X)=1")

    cutoff = 4
    k = lcm(*range(1, cutoff + 1)) // 2
    descent, original = descent_and_original(k)
    for degree in range(1, cutoff + 1):
        assert gcd(original, frobenius_x(degree, original) ^ X) == 1
    assert gcd(descent, frobenius_x(12, descent) ^ X) == P12
    print(f"R={k + 1}: f_R has no factors of degree <= {cutoff}; h_R contains P12.")


if __name__ == "__main__":
    check_seed()
    check_original_polynomials()

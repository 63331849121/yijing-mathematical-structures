"""Independent audit of the 24-page Paper F draft, using python-flint 0.9.0."""

from itertools import combinations
from math import gcd

from flint import fmpz_mod_poly_ctx, fq_default_ctx, fq_default_poly_ctx, nmod_mpoly_ctx, nmod_poly


def binary_poly(mask):
    return nmod_poly([(mask >> i) & 1 for i in range(mask.bit_length())], 2)


def mask(poly):
    return sum(int(coefficient) << i for i, coefficient in enumerate(poly.coeffs()))


X = binary_poly(2)
ONE = binary_poly(1)


def to_univariate(poly):
    terms = poly.to_dict()
    assert all(first == 0 for first, _ in terms)
    return binary_poly(sum(int(coefficient) << second for (_, second), coefficient in terms.items()))


def four_zero_mask(n, i, j):
    return ((1 << (n + 1)) - 1) - sum(1 << t for t in (i, j, n - 1 - i, n - 1 - j))


def prime_divisors(n):
    primes = []
    divisor = 2
    while divisor * divisor <= n:
        if n % divisor == 0:
            primes.append(divisor)
            while n % divisor == 0:
                n //= divisor
        divisor += 1
    if n > 1:
        primes.append(n)
    return primes


def irreducible(poly):
    degree = poly.degree()
    if degree < 1 or X.pow_mod(1 << degree, poly) != X % poly:
        return False
    return all(
        poly.gcd(X.pow_mod(1 << (degree // p), poly) + X) == ONE
        for p in prime_divisors(degree)
    )


def exact_order(poly, n):
    original = n
    assert X.pow_mod(original, poly) == ONE
    for prime in prime_divisors(original):
        while n % prime == 0 and X.pow_mod(n // prime, poly) == ONE:
            n //= prime
    return n


def check_root_pairs():
    x, y = nmod_mpoly_ctx.get(("x", "y"), 2).gens()
    for p in (3, 5, 7, 11, 13, 17):
        n = 2 * p
        q = 1 << p
        cases = irreducibles = primitives = 0
        for i, j in combinations(range(1, p), 2):
            bitmask = four_zero_mask(n, i, j)
            f = binary_poly(bitmask)
            support = [a for a in range(n + 1) if (bitmask >> a) & 1]
            fx = sum(x**a for a in support)
            ratio_res = to_univariate(fx.resultant(sum(x**a * y**a for a in support), "x"))
            assert ratio_res.degree() == n * n and ratio_res[0] == 1
            d = ratio_res.gcd(X.pow_mod(q + 1, ratio_res) + ONE)
            ratio_gcd = d // d.gcd(X**3 + ONE)
            is_irred = irreducible(f)
            assert (ratio_gcd != ONE) == is_irred
            cases += 1
            if not is_irred:
                continue
            irreducibles += 1
            product_res = to_univariate(fx.resultant(sum(x**(n-a) * y**a for a in support), "x"))
            assert product_res.degree() == n * n and product_res[0] == 1
            product_gcd = product_res.gcd(X.pow_mod(q - 1, product_res) + ONE)
            assert ratio_gcd.degree() == n and irreducible(ratio_gcd)
            assert product_gcd.degree() == p and irreducible(product_gcd)
            order = exact_order(f, q * q - 1)
            assert exact_order(ratio_gcd, q + 1) == order // gcd(order, q - 1)
            assert exact_order(product_gcd, q - 1) == order // gcd(order, q + 1)
            if order == q * q - 1:
                primitives += 1
        print(f"p={p}: {cases} ratio tests, {irreducibles} irreducible, {primitives} primitive", flush=True)


def descent_mod(k, divisor):
    q = 1 << k
    powers = X.pow_mod(q, divisor)
    for j in range(2, k):
        powers += X.pow_mod(q - (1 << j) + 1, divisor)
    return (binary_poly(7) + (X + ONE) * powers) % divisor


def check_quadratic():
    a = binary_poly(7)
    p = binary_poly(0x1BE3)
    assert irreducible(p)
    for k in range(24, 48):
        assert (not descent_mod(k, a*a)) == (k % 4 == 3)
        assert (not descent_mod(k, a)) == (k % 4 == 3)
        assert descent_mod(k, a**3)
        assert (not descent_mod(k, p)) == (k % 24 == 6)
        assert descent_mod(k, p*p)
    for k in range(2, 12):
        q = 1 << k
        # This modulus is larger than the descending polynomial.
        h = descent_mod(k, X**(q + 2))
        f = binary_poly(four_zero_mask(2*q + 2, 3, q))
        expected = a if k % 4 == 3 else p if k % 24 == 6 else ONE
        assert h.gcd(X.pow_mod(1 << (2*k), h) + X) == expected
        assert f.gcd(X.pow_mod(1 << (2*k), f) + X) == ONE
    print("Quadratic: all 24 descent phases and both gcds for R=3,...,12", flush=True)


def check_cubic():
    b, a = nmod_mpoly_ctx.get(("b", "a"), 2).gens()
    s, u = a*a + a, b*b + b
    denom = (a+b) * (a+1) * (b+1)
    num = (a*b*(s*s+s) + a*s) * (a+1) * (b+1) + a*b*(a+b)
    num2 = num + (s+u)*denom

    def equation(t, g):
        poly = (t*t+t)*g*g + (t*t+1)*g*denom + t*t*denom*denom
        for linear in (a, b, a+1, b+1, a+b, a+b+1):
            quotient, remainder = divmod(poly, linear)
            while not remainder:
                poly = quotient
                quotient, remainder = divmod(poly, linear)
        return poly

    first = equation(a, num)
    candidate_masks = set()
    for c, expected_degrees in (
        (0, [(1, 7), (1, 22), (3, 3), (6, 2), (14, 1), (14, 1), (14, 1), (18, 1), (18, 1)]),
        (1, [(1, 8), (1, 24), (6, 1), (6, 2), (27, 1), (51, 1)]),
    ):
        resultant = to_univariate(first.resultant(equation(a+b+c, num2), "b"))
        leading, factors = resultant.factor()
        assert leading == 1 and resultant.degree() == 128
        assert sorted((f.degree(), power) for f, power in factors) == expected_degrees
        reconstructed = ONE
        for f, power in factors:
            assert irreducible(f)
            reconstructed *= f**power
            if f.degree() % 9 == 0:
                candidate_masks.add(mask(f))
        assert reconstructed == resultant
        print(f"Cubic c={c}: {mask(resultant):#x}", flush=True)
        print(f"Cubic c={c} factors: {sorted((hex(mask(f)), power) for f, power in factors)}", flush=True)

    assert candidate_masks == {0x4FB89, 0x5C03D, 0xD01DFEB}
    passed = {}
    for candidate in sorted(candidate_masks):
        d = candidate.bit_length() - 1
        modulus = fmpz_mod_poly_ctx(2)([int(c) for c in binary_poly(candidate).coeffs()])
        field = fq_default_ctx(modulus=modulus)
        t = field.gen()
        polys = fq_default_poly_ctx(field)
        # Solve the quadratic in the field directly, without the inverse formula.
        quadratic = polys([t*t, t*t+1, t*t+t])
        roots = [-f[0] for f, _ in quadratic.factor()[1] if f.degree() == 1]
        for k in range(2*d):
            if k % gcd(24, 2*d) or d // gcd(d, k) != 3:
                continue
            hits = []
            for x in roots:
                trace, current = field(0), x
                for _ in range(k):
                    trace += current
                    current *= current
                if trace == t:
                    assert current + x == t*t+t
                    factor = polys([1])
                    for i in range(d):
                        factor *= polys([1 / (x**(1 << i)), 1])
                    coeffs = [int(factor[i]) for i in range(d+1)]
                    h_factor = nmod_poly(coeffs, 2)
                    assert irreducible(h_factor)
                    representative = next(r for r in range(24, 217, 24) if r % (2*d) == k)
                    assert not descent_mod(representative, h_factor)
                    hits.append(mask(h_factor))
            print(f"Cubic t={candidate:#x}, k={k} mod {2*d}: {hits}", flush=True)
            if hits:
                passed[(candidate, k)] = hits

    assert passed == {(0x4FB89, 24): [0x412B1], (0x5C03D, 12): [0x55ABF]}
    for h_mask, f_mask, expected in (
        (0x412B1, 0x105A535905, [0x52AF3, 0x56EF3]),
        (0x55ABF, 0x1475B0A6D9, [0x1475B0A6D9]),
    ):
        h = binary_poly(h_mask)
        pullback = sum(h[i] * X**(2*i) * (X+ONE)**(h.degree()-i) for i in range(h.degree()+1))
        assert mask(pullback) == f_mask
        assert sorted(mask(f) for f, power in pullback.factor()[1] if power == 1) == expected
        assert all(irreducible(binary_poly(f)) for f in expected)
    print("Cubic: six phase checks via direct quadratic factorization and both pullbacks passed.", flush=True)


if __name__ == "__main__":
    check_quadratic()
    check_cubic()
    check_root_pairs()

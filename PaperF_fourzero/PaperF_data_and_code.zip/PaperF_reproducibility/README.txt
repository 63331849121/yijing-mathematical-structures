Paper F data and reproducibility programs

This optional companion contains mathematical tables, original inputs,
candidate verdicts, order-factorization records, first-witness residues,
structural verification programs and their recorded outputs.
The manuscript source is included because the coefficient-quotient checker
reads it. The submission manuscript PDF is supplied in the separate
two-file submission package.

Complete counts cover all 161700 candidates at 98 even degrees 6--200,
with 2663 primitive polynomials. First witnesses cover 148 even degrees
6--300; degrees 202--300 are prefix checks rather than complete counts.

Use Python 3.10 or later. The arithmetic audit additionally requires
python-flint==0.9.0, as recorded in requirements.txt. From this directory:

python verification/primitivity/verify_primitivity.py --data verification/primitivity/inputs --out rerun_primitivity
python verification/translation/verify_translation.py --out rerun_translation
python verification/b_descent/verify_b_descent.py
python verification/rational_transform/verify_independent.py
python verification/coset_spectrum/audit_coset_spectrum.py
python verification/reciprocal_screen/audit_final.py

The structural programs use standard Python. Programs without an output
option write their results beside the program; use a working copy to retain
the supplied records. Embedded historical source hashes identify the inputs
used when those records were produced. The included manuscript has subsequent
editorial changes. SHA256SUMS.txt identifies the files supplied in this package.

The published data archive is https://doi.org/10.5281/zenodo.23766722 .
See LICENSES.txt and LICENSE-code-MIT.txt for reuse terms.

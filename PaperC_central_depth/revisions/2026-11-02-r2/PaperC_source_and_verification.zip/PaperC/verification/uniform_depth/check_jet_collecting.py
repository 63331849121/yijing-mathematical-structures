"""One minimal free-Lie control of the symbolic Frobenius-jet lemma.

This uses only fixed-anchor partial Engel identities and M_s=0.
Z is NOT required to be Engel. No old word engine is imported.
It is a sanity check of a general proof, not a finite-start certificate.
"""
from pathlib import Path
from itertools import product
from collections import Counter
import json
import time

HERE = Path(__file__).resolve().parent


def bits(v):
    while v:
        b = v & -v
        yield b.bit_length() - 1
        v ^= b


def insert(rows, v):
    while v:
        k = v.bit_length() - 1
        if k not in rows:
            rows[k] = v
            return True
        v ^= rows[k]
    return False


def reduce(rows, v):
    answer = 0
    while v:
        k = v.bit_length() - 1
        if k in rows:
            v ^= rows[k]
        else:
            answer ^= 1 << k
            v ^= 1 << k
    return answer


class PartialDepthLie:
    def __init__(self, cap=(4, 3), depth=2, partial=True):
        self.cap, self.depth, self.partial = cap, depth, partial
        self.maximum = sum(cap)
        self.words = {0: [()]}
        self.ix = {0: {(): 0}}
        for g in range(1, self.maximum + 1):
            ws = []
            for w in self.words[g - 1]:
                counts = Counter(w)
                for a in range(len(cap)):
                    if counts[a] < cap[a]:
                        ws.append(w + (a,))
            self.words[g] = ws
            self.ix[g] = {w: i for i, w in enumerate(ws)}
        self.letters = [1 << self.ix[1][(i,)] for i in range(len(cap))]
        self.lie, self.relations = {}, {0: {}}
        self.M = {j: {} for j in range(depth + 1)}

    def multiply(self, a, ga, b, gb):
        answer = 0
        target = self.ix[ga + gb]
        for ia in bits(a):
            for ib in bits(b):
                k = target.get(self.words[ga][ia] + self.words[gb][ib])
                if k is not None:
                    answer ^= 1 << k
        return answer

    def bracket(self, a, ga, b, gb):
        return self.multiply(a, ga, b, gb) ^ self.multiply(b, gb, a, ga)

    def iterated(self, first, *tail):
        a, ga = first
        for b, gb in tail:
            a, ga = self.bracket(a, ga, b, gb), ga + gb
        return a

    def subspace(self, values, relations):
        rows = {}
        for v in values:
            insert(rows, reduce(relations, v))
        return list(rows.values())

    def run(self):
        started = time.monotonic()
        for g in range(1, self.maximum + 1):
            rel = {}
            for row in self.relations[g - 1].values():
                for letter in self.letters:
                    insert(rel, self.bracket(row, g - 1, letter, 1))
            if self.partial:
                # Only X (letter 0), never Z, is the repeated anchor.
                x = (self.letters[0], 1)
                for p in range(1, g - 2):
                    h = g - p - 2
                    for a in self.lie.get(p, []):
                        for b in self.lie.get(h, []):
                            v = (a, p)
                            u = (b, h)
                            identity = (self.iterated(v, x, x, u)
                                        ^ self.iterated(v, x, u, x)
                                        ^ self.iterated(v, u, x, x))
                            insert(rel, identity)
            m0 = []
            for p in range(2, g - 1):
                for a in self.lie.get(p, []):
                    for b in self.lie.get(g - p, []):
                        m0.append(self.bracket(a, p, b, g - p))
            current = {0: self.subspace(m0, rel)}
            for j in range(1, self.depth + 1):
                values = []
                for p in range(1, g):
                    for a in self.M[j - 1].get(p, []):
                        for b in self.lie.get(g - p, []):
                            values.append(self.bracket(a, p, b, g - p))
                current[j] = self.subspace(values, rel)
            for row in current[self.depth]:
                insert(rel, row)
            self.relations[g] = rel
            for j, values in current.items():
                self.M[j][g] = self.subspace(values, rel)
            if g == 1:
                candidates = self.letters
            else:
                candidates = [self.bracket(a, g - 1, b, 1)
                              for a in self.lie[g - 1] for b in self.letters]
            self.lie[g] = self.subspace(candidates, rel)
        return dict(cap=self.cap, depth=self.depth,
                    fixed_anchor_partial_engel=self.partial,
                    Z_cube_imposed=False,
                    target_dimension=len(self.lie[self.maximum]),
                    target_associative_coordinates=len(self.words[self.maximum]),
                    seconds=round(time.monotonic() - started, 3))


def formal_pair_identity():
    def bracket(a, b):
        ans = set()
        for x, y in product(a, b):
            for w in (x + y, y + x):
                if w in ans:
                    ans.remove(w)
                else:
                    ans.add(w)
        return ans
    def word(*args):
        ans = {(args[0],)}
        for a in args[1:]:
            ans = bracket(ans, {(a,)})
        return ans
    pair = bracket(word('c', 'x'), word('d', 'x'))
    e21 = (word('c', 'x', 'x', 'd')
           ^ word('c', 'x', 'd', 'x')
           ^ word('c', 'd', 'x', 'x'))
    assert not (pair ^ e21 ^ word('c', 'd', 'x', 'x'))
    return True


def main():
    assert formal_pair_identity()
    good = PartialDepthLie(partial=True).run()
    negative = PartialDepthLie(partial=False).run()
    # r=1, n=4, s=p=2: cutoff n(s-2)+p=2, so m=3 is zero.
    assert good['target_dimension'] == 0, good
    assert negative['target_dimension'] > 0, negative
    report = dict(status='PASS', free_associative_pair_identity=True,
                  frobenius_jet_boundary_control=good,
                  no_partial_engel_negative_control=negative,
                  scope='One bounded control of the general jet proof; not a new rank/depth table. Only Lie-ideal closure is used, not a stronger associative ideal closure.')
    (HERE/'jet_collecting_controls.json').write_text(
        json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()

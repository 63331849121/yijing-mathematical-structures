Additional controls and exact endpoint material for the revised Paper C
=====================================================================
check_jet_collecting.py: one fixed-anchor auxiliary free-Lie boundary,
the negative control, and a formal collecting identity. The 35 coordinates
are a sanity control, not a finite input to arbitrary-depth stability.

check_witt_current.py: exact cyclic-support generation, all-factor M
filtrations, center and endpoint truncation controls of the symbolic law.
state19_operators.json is an archived operator transcription control.

check_affine_current_symmetry.py: a literal affine-frame automorphism check.
check_cubic_boundary_witness.py: actual Lie-word root coefficients.
verify_rank9_depth6.py: independent 597-dimensional endpoint-table audit.
check_graph_packing.py: 49 literal graph-center constructions.

The corresponding general proofs are in appendices B, C, D and H.
The exact low-depth upper starts keep their existing finite certificates.
Run the project-level verification/run_replay.py for an isolated copy.
The current fresh report has 16 PASS invocations in
verification/replay/merge_2026-11-02/SPLIT_REPLAY.json.
The unchanged extended endpoint systems retain their original report
scope; this revision does not claim they were all recomputed.

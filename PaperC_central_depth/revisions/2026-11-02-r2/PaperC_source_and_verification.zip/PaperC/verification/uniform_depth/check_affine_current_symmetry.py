"""Literal q4 control of the new affine-frame automorphism."""
from pathlib import Path
from itertools import combinations
import json
from check_witt_current import coeff
HERE=Path(__file__).resolve().parent
def bits(v):
    while v:
        low=v&-v;yield low.bit_length()-1;v^=low
def basis(vals):
    p={}
    for v in vals:
        while v:
            k=v.bit_length()-1
            if k not in p:p[k]=v;break
            v^=p[k]
    return list(p.values())
def main():
    q=4;Q=q-1;m=7
    keys=[(0,Q)]+[(S,j) for S in range(1,1<<m) for j in range(-1,2*q-2) if (S.bit_count()+j)%Q==0]
    ix={v:i for i,v in enumerate(keys)};N=len(keys)
    def one(a,b):
        S,i=keys[a];T,j=keys[b]
        if S&T or not coeff(i,j):return 0
        target=(S|T,i+j)
        return 1<<ix[target] if target in ix else 0
    def br(a,b):
        out=0
        for i in bits(a):
            for j in bits(b):out^=one(i,j)
        return out
    phi=[]
    for i,(S,j) in enumerate(keys):
        value=1<<i
        if not S&1 and j>=Q:value^=1<<ix[S|1,j-q]
        phi.append(value)
    def transform(v):
        out=0
        for i in bits(v):out^=phi[i]
        return out
    assert all(transform(v)==1<<i for i,v in enumerate(phi))
    checked=0
    for i,j in combinations(range(N),2):
        assert transform(one(i,j))==br(phi[i],phi[j]);checked+=1
    gens=[(1<<ix[0,Q])^(1<<ix[1,-1])]+[1<<ix[1<<i,-1] for i in range(1,m)]
    generated=basis(gens);cursor=0
    while cursor<len(generated):
        generated=basis(generated+[br(generated[cursor],g) for g in gens]);cursor+=1
    expected=basis(phi[i] for i,(S,j) in enumerate(keys) if not S&1)
    assert len(basis(expected+generated))==len(expected)==len(generated)
    lower=[];V=generated
    while V:
        lower.append(len(V));V=basis(br(v,g) for v in V for g in gens)
    der=basis(br(a,b) for a in generated for b in generated)
    V=basis(br(a,b) for a in der for b in der);M=[]
    while V:
        M.append(len(V));V=basis(br(v,g) for v in V for g in gens)
    rec=dict(status='PASS',q=q,m=m,dimension=N,automorphism_bracket_pairs=checked,
        involution=True,hyperplane_subalgebra_dimension=len(generated),
        hyperplane_rank=len(generated)-len(der),hyperplane_class=len(lower),
        hyperplane_depth=len(M),lower=lower+[0],M=M+[0],
        scope='Literal current-frame control; arbitrary parameters follow from the divided-power coordinate substitution.')
    (HERE/'affine_current_symmetry_controls.json').write_text(json.dumps(rec,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(rec))
if __name__=='__main__':main()

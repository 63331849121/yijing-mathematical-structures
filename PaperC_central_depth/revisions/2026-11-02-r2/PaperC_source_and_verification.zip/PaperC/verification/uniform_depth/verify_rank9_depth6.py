# Adapted from the archived literal-table checker, changing expected depth to six.
"""Literal bracket-table audit; no imports from any model constructor.
Checks Jacobi, complete F4 cubic operator coefficients, generation,
lower central series, exact second-derived depth, and the displayed word.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from functools import lru_cache
import json,time,hashlib,sys
HERE=Path(__file__).resolve().parent
def support(v):
    while v:
        low=v&-v;yield low.bit_length()-1;v^=low
def basis(values):
    piv={}
    for value in values:
        while value:
            k=value.bit_length()-1
            if k not in piv:piv[k]=value;break
            value^=piv[k]
    return list(piv.values())
def main(filename='rank9_depth6_model.json'):
    start=time.monotonic();path=HERE/filename
    raw=json.loads(path.read_text());t=raw['table'];n=len(t);L=raw['operator_dimension'];M=n-L
    multi=[tuple(x) for x in raw['multis']];grades=raw['grades'];rank=raw['ordinary_rank']
    cap=tuple(raw.get('cap',(3,2,1,1,1,1,1)))
    def allowed(*ms):return all(sum(v[i] for v in ms)<=cap[i] for i in range(rank))
    def bracket(a,b):
        value=0
        for i in support(a):
            for j in support(b):value^=t[i][j]
        return value
    for i in range(n):
        assert t[i][i]==0
        for j in range(i):
            assert t[i][j]==t[j][i]
            for k in support(t[i][j]):
                assert grades[k]==grades[i]+grades[j]
                assert multi[k]==tuple(a+b for a,b in zip(multi[i],multi[j]))
            if not allowed(multi[i],multi[j]):assert not t[i][j]
    ce=0;maxgrade=max(grades)
    upto={g:[i for i in range(n) if grades[i]<=g] for g in range(maxgrade+1)}
    for i,j in combinations(range(n),2):
        remaining=maxgrade-grades[i]-grades[j]
        if remaining<1 or not allowed(multi[i],multi[j]):continue
        for k in upto[remaining]:
            if k<=j or not allowed(multi[i],multi[j],multi[k]):continue
            assert not(bracket(t[i][j],1<<k)^bracket(t[j][k],1<<i)^bracket(t[k][i],1<<j)),('Jacobi',i,j,k)
            ce+=1
    print(json.dumps({'Jacobi_passed':True,'nontrivial_basis_triples':ce}),flush=True)
    # Independently reconstruct the abelian module and its action operators.
    assert all(not t[i][j] for i in range(L,n) for j in range(L,n))
    assert all(not (t[i][j]>>L) for i in range(L) for j in range(L))
    assert all(not (t[i][j]&((1<<L)-1)) for i in range(L) for j in range(L,n))
    mask=(1<<M)-1
    mats=[sum((t[i][L+j]>>L)<<(M*j) for j in range(M)) for i in range(L)]
    def apply(a,v):
        out=0
        for i in support(v):out^=(a>>(M*i))&mask
        return out
    @lru_cache(maxsize=16000)
    def product(a,b):return sum(apply(a,(b>>(M*j))&mask)<<(M*j) for j in range(M))
    @lru_cache(None)
    def action(v):
        out=0
        for i in support(v):out^=mats[i]
        return out
    cube=0
    for i,j,k in combinations_with_replacement(range(L),3):
        if not allowed(multi[i],multi[j],multi[k]):continue
        a,b,c=mats[i],mats[j],mats[k]
        if i==k:v=product(product(a,a),a)
        elif i==j:
            v=action(bracket(t[k][i],1<<i))^product(a,product(c,a))
        elif j==k:
            v=action(bracket(t[i][j],1<<j))^product(b,product(a,b))
        else:v=product(a,action(t[j][k]))^product(b,action(t[k][i]))^product(c,action(t[i][j]))
        assert not v,('Nonzero cubic coefficient',i,j,k)
        cube+=1
    # All cubic coefficients vanish on the whole scalar extension to F4.
    print(json.dumps({'full_operator_cube_coefficients_passed':cube}),flush=True)
    generators=[1<<i for i in raw['old_generator_basis_indices']]+[raw['new_generator']]
    generated=basis(generators);cursor=0
    while cursor<len(generated):
        old=len(generated)
        generated=basis(generated+[bracket(generated[cursor],g) for g in generators]);cursor+=1
    assert len(generated)==n
    # Faithfulness is literal: L was defined as these distinct operators.
    assert len(basis(mats))==L
    # Jacobi + faithful cube-zero action prove L is 3-Engel; the semidirect
    # cubic criterion then proves the WHOLE table is ordinary three-Engel.
    first=basis(t[i][j] for i,j in combinations(range(n),2));assert n-len(first)==rank
    second=basis(bracket(a,b) for a,b in combinations(first,2))
    def act(sub):return basis(bracket(a,g) for a in sub for g in generators)
    lower=[];sub=[1<<i for i in range(n)];lower_spaces=[]
    while sub:
        lower.append(len(sub));lower_spaces.append(sub);sub=act(sub);assert len(lower)<20
    lower.append(0)
    depths=[];spaces=[];sub=second
    while sub:
        depths.append(len(sub));spaces.append(sub);sub=act(sub);assert len(depths)<10
    depths.append(0)
    assert len(lower)-1==rank+3,lower
    assert len(depths)-1==6,depths
    word=raw['new_generator']
    for i in raw['nonzero_word_new_then_old']:word=bracket(word,1<<i)
    assert word==raw['nonzero_word_value'] and word
    def contained(a,b):return len(basis(a+b))==len(basis(b))
    classes=[]
    for s in range(1,7):
        ideal=spaces[s] if s<len(spaces) else []
        cls=max((i+1 for i,v in enumerate(lower_spaces) if not contained(v,ideal)),default=0)
        classes.append(cls)
    out={'status':'PASS','source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
         'dimension_k':n,'ordinary_generator_rank':rank,'operator_dimension_k':L,'abelian_module_dimension_k':M,
         'all_Jacobi_basis_triples_with_nonzero_allowed_weight':ce,'complete_operator_cube_coefficients':cube,
         'generated_dimension_k':len(generated),'class':len(lower)-1,'lower_central_dimensions':lower,
         'second_derived_depth':len(depths)-1,'second_derived_depth_dimensions':depths,
         'classes_of_quotients_by_M1_through_M6':classes,
         'nonzero_word':'[y,'+','.join('x'+str(i) for i in raw['nonzero_word_new_then_old'])+']',
         'seconds':time.monotonic()-start,
         'scope':'Actual literal finite ordinary Lie algebra over every characteristic-two field. Complete coefficient checks, not binary point samples; no universal completeness claim needed for the lower witness.'}
    (HERE/f'rank{rank}_depth6_independent_controls.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out),flush=True)
if __name__=='__main__':main(sys.argv[1] if len(sys.argv)>1 else 'rank9_depth6_model.json')

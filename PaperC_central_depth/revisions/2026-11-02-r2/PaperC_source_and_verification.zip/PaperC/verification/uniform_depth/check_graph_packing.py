"""Literal finite controls of the graph-quotient packing theorem."""
from pathlib import Path
from itertools import combinations, combinations_with_replacement, permutations
import json
HERE=Path(__file__).resolve().parent

def support(v):
    while v:
        low=v & -v
        yield low.bit_length()-1
        v ^= low

def basis(values):
    piv={}
    for v in values:
        while v:
            k=v.bit_length()-1
            if k not in piv:
                piv[k]=v
                break
            v ^= piv[k]
    return list(piv.values())

def orientation(n,edges,p):
    matched={}
    def augment(e,seen):
        for v in edges[e]:
            for slot in range(p):
                key=(v,slot)
                if key in seen:
                    continue
                seen.add(key)
                if key not in matched or augment(matched[key],seen):
                    matched[key]=e
                    return True
        return False
    if not all(augment(e,set()) for e in range(len(edges))):
        return None
    return {e:key for key,e in matched.items()}

def check(n,edges,name):
    densities=[(sum((S>>a&1) and (S>>b&1) for a,b in edges),S.bit_count()) for S in range(1,1<<n)]
    p=max((e+v-1)//v for e,v in densities)
    orient=orientation(n,edges,p)
    assert orient is not None and orientation(n,edges,p-1) is None
    qdim=n+4*len(edges)
    N=qdim+p
    table=[[0]*N for _ in range(N)]
    grade=[1]*n+[g for _ in edges for g in (2,3,3,4)]+[5]*p
    def put(i,j,v):
        table[i][j] ^= 1<<v
        table[j][i] ^= 1<<v
    for e,(a,b) in enumerate(edges):
        c,u,v,w=(n+4*e+i for i in range(4))
        put(a,b,c)
        put(c,a,u)
        put(c,b,v)
        put(u,b,w)
        put(v,a,w)
        end,slot=orient[e]
        put(end,w,qdim+slot)
        put(c,u if end==a else v,qdim+slot)
    def br(a,b):
        out=0
        for i in support(a):
            for j in support(b):
                out ^= table[i][j]
        return out
    for i in range(N):
        assert table[i][i]==0
        for j in range(i):
            assert table[i][j]==table[j][i]
            assert all(grade[k]==grade[i]+grade[j] for k in support(table[i][j]))
    jacobi=0
    for i,j,k in combinations(range(N),3):
        if grade[i]+grade[j]+grade[k]>5:
            continue
        assert not (br(table[i][j],1<<k)^br(table[j][k],1<<i)^br(table[k][i],1<<j))
        jacobi+=1
    # Full formal cube coefficients of the adjoint pencil, on every basis vector.
    cubics=0
    for i,j,k in combinations_with_replacement(range(N),3):
        degree=grade[i]+grade[j]+grade[k]
        if degree>4:
            continue
        orders=set(permutations((i,j,k)))
        for a in range(N):
            if grade[a]+degree>5:
                continue
            value=0
            for x,y,z in orders:
                value ^= br(br(table[a][x],1<<y),1<<z)
            assert not value,('Engel',name,a,i,j,k)
            cubics+=1
    ad_rank=len(basis(sum(table[i][j]<<(N*j) for j in range(N)) for i in range(N)))
    assert N-ad_rank==p
    derived=basis(table[i][j] for i,j in combinations(range(N),2))
    second=basis(br(a,b) for a,b in combinations(derived,2))
    assert len(second)==p and all(v>>qdim for v in second)
    generators=[1<<i for i in range(n)]
    generated=basis(generators)
    cursor=0
    while cursor<len(generated):
        generated=basis(generated+[br(generated[cursor],g) for g in generators])
        cursor+=1
    assert len(generated)==N and N-len(derived)==n
    lower=[]
    sub=[1<<i for i in range(N)]
    while sub:
        lower.append(len(sub))
        sub=basis(br(a,g) for a in sub for g in generators)
    assert len(lower)==5
    return dict(name=name,vertices=n,edges=len(edges),quotient_dimension=qdim,
        least_center=p,global_Hom_lower_bound=(len(edges)+n-1)//n,
        extension_dimension=N,Jacobi_cases=jacobi,formal_Engel_coefficients=cubics,
        lower_central_dimensions=lower+[0],second_derived_dimension=len(second))

def main():
    cases=[]
    for n in range(2,5):
        potential=list(combinations(range(n),2))
        for mask in range(1,1<<len(potential)):
            edges=[e for i,e in enumerate(potential) if mask>>i&1]
            if len(set(sum((list(e) for e in edges),[])))!=n:
                continue
            cases.append(check(n,edges,f'all_n{n}_mask{mask}'))
    cases.append(check(5,[(i,(i+1)%5) for i in range(5)],'C5'))
    cases.append(check(6,[(i,j) for i in range(3) for j in range(3,6)],'K3_3'))
    cases.append(check(8,list(combinations(range(4),2))+[(4,5),(6,7)],'K4_plus_two_edges'))
    out=dict(status='PASS',scope='All labelled simple graphs without isolates through four vertices, plus three structural controls. General proof is separate.',cases=cases)
    (HERE/'graph_packing_controls.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status='PASS',cases=len(cases),selected=cases[-3:])))

if __name__=='__main__':
    main()

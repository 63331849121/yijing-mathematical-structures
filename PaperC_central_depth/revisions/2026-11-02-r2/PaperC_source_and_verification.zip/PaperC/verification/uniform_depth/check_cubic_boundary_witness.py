"""Word-level controls for the uniform cubic quotient; no free-module table."""
from pathlib import Path
import json
from check_witt_current import coeff
HERE=Path(__file__).resolve().parent
def toggle(poly,word):
    if word in poly:poly.remove(word)
    else:poly.add(word)
def verify(q,s=None):
    if s is None:s=q+1
    assert q+1<=s<=2*q
    Q=q-1;m0=2*q-1;extra=s-q-1;m=q+s-2
    R=[(1,)*a+(0,)+(1,)*(Q-a) for a in range(q)]
    F=set()
    for a in R:
        for b in R:
            for c in ((0,1),(1,0)):toggle(F,(0,)+a+b+c)
    assert len(F)==2*q*q
    derivative=set()
    for word in F:
        for i,letter in enumerate(word):
            if letter==1:toggle(derivative,word[:i]+(0,)+word[i+1:])
    assert not derivative
    if q==4:
        old=json.loads((HERE/'state19_operators.json').read_text(encoding='utf-8'))
        top=next(s for s in old['states'] if s['weight']==[4,7])
        assert F=={tuple('XZ'.index(c) for c in word) for word in top['dual_words']}
    # Uniform Lie witness for the distinct residual cubic weight.
    W=[0,1,1]+list(range(2,q+1))+[2]+list(range(q+1,m0+1))+[0]+list(range(m0+1,m+1))
    def evaluate(word):
        idx=Q if not word[0] else -1
        seen={word[0]} if word[0] else set()
        for a in word[1:]:
            j=Q if not a else -1
            if a in seen or not (-1<=idx+j<=2*q-3) or not coeff(idx,j):return 0
            if a:seen.add(a)
            idx+=j
        return int(idx==2*q-3-extra and len(seen)==m)
    first=[i for i,a in enumerate(W) if a==1];second=[i for i,a in enumerate(W) if a==2]
    terms=[]
    for i in first:
        for j in second:
            word=W[:];word[i]=word[j]=0
            terms.append(evaluate(word))
    assert terms==[0,0,0,1]
    d=m+1
    return dict(q=q,s=s,status='PASS',base_top_functional_words=len(F),base_deficient_support_derivative=0,
        distinct_residual_word=W,root_coefficient_terms=terms,cubic_quotient_dimension=(d+2)*(d+1)*d//6)
if __name__=='__main__':
    rec=dict(status='PASS',cases=[verify(4),verify(8),verify(4,8)],scope='Initial and terminal Frobenius-block controls of uniform word identities; all-depth proof is in 08.')
    (HERE/'cubic_boundary_word_controls.json').write_text(json.dumps(rec,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(rec))

"""Small exact controls of the current-model formulas, without support expansion."""
from pathlib import Path
from math import comb
import json
from itertools import combinations
HERE=Path(__file__).resolve().parent
def coeff(i,j):
    n=i+j+1
    if n<0:return 0
    def C(a):return comb(n,a)%2 if 0<=a<=n else 0
    return C(i+1)^C(j+1)
def check(q,m):
    Q=q-1
    keys=[(0,Q)]+[(b,j) for b in range(1,m+1) for j in range(-1,2*q-2) if (b+j)%Q==0]
    keyset=set(keys)
    x=(0,Q);z=(1,-1)
    def br(a,b):
        target=(a[0]+b[0],a[1]+b[1])
        return target if target in keyset and coeff(a[1],b[1]) else None
    def degrees(a):
        b,j=a
        return 1 if not b else b+(b+j)//Q
    gen={x,z}
    while True:
        new=gen|{v for a in gen for b in (x,z) if (v:=br(a,b)) is not None}
        if new==gen:break
        gen=new
    assert gen==keyset
    first={v for a in keys for b in keys if (v:=br(a,b)) is not None}
    second={v for a in first for b in first if (v:=br(a,b)) is not None}
    assert first=={a for a in keys if degrees(a)>=2}
    assert second=={a for a in keys if degrees(a)>=q+3}
    # At every step use all factors, not only the next weight in a proposed formula.
    M=second;rec=[]
    while M:
        r=len(rec)
        assert M=={a for a in keys if degrees(a)>=q+3+r}
        rec.append(sorted(map(list,M)))
        M={v for a in M for b in keys if (v:=br(a,b)) is not None}
    fullclass=max(map(degrees,keys))
    assert fullclass==m+(m-1)//Q+2
    assert len(rec)==max(0,fullclass-q-2)
    def dim(A):return sum(1 if b==0 else comb(m,b) for b,j in A)
    center={a for a in keys if br(a,x) is None and br(a,z) is None}
    assert dim(center)==1
    boundary_s=8 if (q,m)==(4,10) else max(1,len(rec))
    killed={a for a in keys if degrees(a)>=q+boundary_s+3}
    quotient_center={a for a in keys if a not in killed and
        (br(a,x) is None or br(a,x) in killed) and
        (br(a,z) is None or br(a,z) in killed)}
    assert dim(quotient_center)==1
    return dict(q=q,m=m,status='PASS',coefficient_lines=len(keys),ordinary_rank=m+1,
        dimension=dim(keys),class_=fullclass,central_depth=len(rec),center_dimension=dim(center),
        tested_depth_cutoff=boundary_s,quotient_center_dimension=dim(quotient_center),
        quotient_class=max(degrees(a) for a in keys if a not in killed),
        M_dimensions=[dim([tuple(k) for k in row]) for row in rec]+[0])
def mixed_obstacle():
    # One necessary test of replacing the single Mersenne anchor by two anchors.
    q=4;m=5;seeds=[(0,1),(0,3),(1,-1)]
    def br(a,b):
        target=(a[0]+b[0],a[1]+b[1])
        return target if target[0]<=m and -1<=target[1]<=5 and coeff(a[1],b[1]) else None
    keys=set(seeds)
    while True:
        new=keys|{v for a in keys for b in seeds if (v:=br(a,b)) is not None}
        if new==keys:break
        keys=new
    lower=[];V=keys
    while V:
        lower.append(V);V={v for a in V for b in seeds if (v:=br(a,b)) is not None}
    first={v for a in keys for b in keys if (v:=br(a,b)) is not None}
    second={v for a in first for b in first if (v:=br(a,b)) is not None}
    assert second==lower[4]
    M=second;depth=0
    while M:
        depth+=1;M={v for a in M for b in seeds if (v:=br(a,b)) is not None}
    dimension=sum(comb(m,b) for b,j in keys)
    rank=dimension-sum(comb(m,b) for b,j in first)
    assert (dimension,rank,len(lower),depth)==(221,7,13,9)
    return dict(status='COMPLETED_OBSTACLE',dimension=dimension,ordinary_rank=rank,class_=len(lower),
        central_depth=depth,second_derived_equals_gamma5=True,depth5_quotient_class=9,
        interpretation='This two-anchor Witt candidate does not supply the rank-seven class-ten depth-five boundary; do not extend a table along this route.')

if __name__=='__main__':
    # Independently identify the original 19-state module with adjoint currents.
    old=json.loads((HERE/'state19_operators.json').read_text(encoding='utf-8'))
    q=4;Q=q-1
    keys=[(s['weight'][1],s['weight'][0]*Q-s['weight'][1]-1) for s in old['states']]
    ix={v:i for i,v in enumerate(keys)}
    for letter,delta in enumerate(((0,Q),(1,-1))):
        for i,(b,j) in enumerate(keys):
            target=(b+delta[0],j+delta[1])
            expected=(1<<ix[target]) if target in ix and coeff(j,delta[1]) else 0
            assert old['actions'][letter][i]==expected
    # Classical boundary, both previous q4 models, and one new phase beyond them.
    rec=dict(status='PASS',old_19_state_current_identification=True,cases=[check(2,3),check(4,7),check(4,8),check(4,10)],mixed_anchor_obstacle=mixed_obstacle(),
        scope='All-factor filtration/generation controls of a two-parameter theorem. No free Lie or large labelled bracket tables.')
    (HERE/'witt_current_controls.json').write_text(json.dumps(rec,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(rec))

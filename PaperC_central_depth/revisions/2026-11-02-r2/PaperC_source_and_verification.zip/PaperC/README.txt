Independent revised Paper C / 40 pages / 2 November 2026
=======================================================
Read PaperG_central_depth.pdf. The actual main document remains
PaperG_central_depth.tex in this directory. All supporting TeX files,
references and required verification materials are included.

Compile with a standard XeLaTeX installation (two runs), or Tectonic,
using build.ps1. The private author-cache helper is not part of the
portable package. No proof source from another manuscript is required.

New main results: every central-depth stable start a_s exists,
s+floor_power2(s-1)<=a_s<=7s+ceil_power2(s)-9<=9s-11 (s>=3);
a_s=Theta(s), R(d)=Theta(d); exact current depth/class laws;
uniform symmetric-cube quotients; exact endpoint and center results.
These are ordinary statements in char 2, |k|>2. They impose no Q R=0
condition and assert no optimal unrestricted e(d) bound.

Proof roles and provenance: PROOF_CERTIFICATE_MAP.json/.txt,
DEPENDENCIES.json and MERGE_REPORT.txt. The package distinguishes
general symbolic proofs, finite endpoint inputs, and sanity controls.

Fresh core replay (16 tasks):
  python verification/run_replay.py --output-dir replay_new
Additional unchanged endpoint systems:
  python verification/run_replay.py --extended-only --output-dir replay_extended_new
Do not overwrite prior replay directories. The runner copies inputs
to an isolated temporary folder and collects all failures.

Authors: Wencong Huang; Baohua Li (in this order).
Version: 2026-11-02-r2. Version DOI: https://doi.org/10.5281/zenodo.23882658
Fixed GitHub release: https://github.com/63331849121/yijing-mathematical-structures/releases/tag/paperC-v2026.11.02-r2
The source snapshot is frozen before upload; the public record and
separate publication receipt verify registration and file checksums.

The earlier 28-page version at doi:10.5281/zenodo.23874234 remains
solely authored by Baohua Li. Earlier files and releases are preserved.

"""Explicit free-Lie-cubic action check for the rank-seven critical layer.
No inference of isomorphism from a dimension or character coincidence.
"""
from pathlib import Path
from itertools import combinations,permutations
import sys,json
sys.dont_write_bytecode=True
from anonymous_singleton_probe import Anonymous
from tangent_cubic_module import red
HERE=Path(__file__).resolve().parent
def xor(a,b):return a.symmetric_difference(b)
def multiply(a,b):
    out=set()
    for u in a:
        for v in b:
            w=u+v
            if w in out:out.remove(w)
            else:out.add(w)
    return out
def br(a,b):return xor(multiply(a,b),multiply(b,a))
def cubic(a,b,c):return br(br({(a,)},{(b,)}),{(c,)})
def replacements(terms,p,q,k):
    out=[]
    for word in terms:
        positions=[i for i,a in enumerate(word) if a==p]
        for sub in combinations(positions,k):
            w=list(word)
            for i in sub:w[i]=q
            out.append(w)
    return out
def main():
    s1=Anonymous((3,2,4),5,50);r1=s1.run();assert r1['critical_dimension']==1
    s2=Anonymous((2,2,2,3),5,50);r2=s2.run();assert r2['critical_dimension']==2
    f=[i for i in range(len(s1.words[9])) if i not in s1.ideals[9]];assert len(f)==1
    word=[];seen=0
    for x in s1.words[9][f[0]]:
        if x<2:word.append(x)
        else:word.append(2+seen);seen+=1
    P2=replacements([word],0,2,1)
    swapped=[[{1:2,2:1}.get(a,a) for a in word]]
    P1=replacements(swapped,0,1,1)
    def raw_distinct(terms):
        v=0
        for w in terms:v^=1<<s2.ix[9][tuple(a if a<3 else 3 for a in w)]
        return red(s2.ideals[9],v)
    b1,b2=raw_distinct(P1),raw_distinct(P2);assert b1 and b2 and b1!=b2
    lookup={0:0,b1:1,b2:2,b1^b2:3}
    def actual(terms):
        if not terms:return 0
        counts=[terms[0].count(i) for i in range(6)]
        if any(c==0 for c in counts):return 0
        anchors=sorted((i for i,c in enumerate(counts) if c>1),key=lambda i:(-counts[i],i))
        shape=tuple(counts[i] for i in anchors)
        if shape==(4,):return 0  # Separately checked pure profile.
        amap={a:i for i,a in enumerate(anchors)}
        if shape==(3,2):
            val=0
            for w in terms:val^=1<<s1.ix[9][tuple(amap.get(a,2) for a in w)]
            rem=red(s1.ideals[9],val);assert rem.bit_count()<=1;return int(bool(rem))
        assert shape==(2,2,2),shape
        renamed=[[amap.get(a,3) for a in w] for w in terms]
        return lookup[raw_distinct(renamed)]
    def expected(poly):
        p=set()
        for w in poly:
            w=tuple(w)
            if w in p:p.remove(w)
            else:p.add(w)
        if not p:return 0
        counts=[next(iter(p)).count(i) for i in range(6)]
        active=sorted((i for i,c in enumerate(counts) if c),key=lambda i:(-counts[i],i))
        shape=tuple(counts[i] for i in active)
        if shape==(2,1):assert p==cubic(active[0],active[1],active[0]);return 1
        assert shape==(1,1,1),shape
        a,b,c=active;v1=cubic(a,b,c);v2=cubic(a,c,b)
        return {frozenset(v1):1,frozenset(v2):2,frozenset(xor(v1,v2)):3}[frozenset(p)]
    sources=([word],P1,P2);templates=(cubic(0,1,0),cubic(0,1,2),cubic(0,2,1))
    bad=[];roots=0;perms=0
    for kind,(terms,poly) in enumerate(zip(sources,templates)):
        residual=[next(iter(poly)).count(i) for i in range(6)]
        for p in range(6):
            for q in range(6):
                if p==q:continue
                for k in range(1,residual[p]+1):
                    a=actual(replacements(terms,p,q,k));b=expected(replacements(poly,p,q,k));roots+=1
                    if a!=b:bad.append({'kind':kind,'p':p,'q':q,'power':k,'actual':a,'expected':b})
        for perm in permutations(range(6)):
            a=actual([[perm[i] for i in w] for w in terms]);b=expected([[perm[i] for i in w] for w in poly]);perms+=1
            if a!=b:bad.append({'kind':kind,'perm':perm,'actual':a,'expected':b})
    out={'status':'PASS' if not bad else 'ACTION_MISMATCH','rank':7,'dimension':112,
         'critical_weight_dimensions':[0,1,2],'root_coefficients_checked':roots,'permutation_checks':perms,
         'distinct_basis_independent':True,'mismatches':bad[:12],
         'scope':'Explicit root coefficients and permutation orbit types match det(U) tensor Lie^3(U); diagonals follow from multigrading, singleton symmetries cover the unchanged y.'}
    (HERE/'rank7_cubic_module_actions.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
if __name__=='__main__':main()

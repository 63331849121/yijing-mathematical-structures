"""Same tangent module using generator recurrences for ideal actions.
The slow implementation is retained for independent dimension controls.
"""
from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
from tangent_cubic_module import Tangent
HERE=Path(__file__).resolve().parent
class Fast(Tangent):
    def __init__(self,*args,**kw):
        super().__init__(*args,**kw)
        self.left_ideals={j:{} for j in range(self.depth or 0)}
    def depth_relations(self,g,piv):
        if self.depth is None:return {},{}
        letters=self.lie.get(1,[]) if g>1 else []
        M={};V={};J={}
        vals=[]
        for p in range(2,g-1):
            q=g-p
            for ma,a in self.lie.get(p,[]):
                for mb,b in self.lie.get(q,[]):
                    if self.combine(ma,mb) is not None:vals.append(self.bracket(a,p,b,q))
        M[0]=self.subspace(vals,g,piv)
        for j in range(1,self.depth):
            vals=[]
            for ma,a in self.derived2[j-1].get(g-1,[]):
                for mb,b in letters:
                    if self.combine(ma,mb) is not None:vals.append(self.bracket(a,g-1,b,1))
            M[j]=self.subspace(vals,g,piv)
        for j in range(self.depth):
            vals=[v for _,v in M[j]]
            for ma,a in letters:
                for mb,b in self.left_ideals[j].get(g-1,[]):
                    if self.combine(ma,mb) is not None:vals.append(self.multiply(a,1,b,g-1))
            J[j]=self.subspace(vals,g,piv);self.left_ideals[j][g]=J[j]
        vals=[]
        previous=self.module_depth[0].get(g-1,[])+self.lie.get(g-1,[]) if g>=3 else []
        for ma,a in letters:
            for mb,b in previous:
                if self.combine(ma,mb) is not None:vals.append(self.multiply(a,1,b,g-1))
        V[0]=self.subspace(vals,g,piv)
        for j in range(1,self.depth+1):
            vals=[v for _,v in J[j-1]]
            for ma,a in self.module_depth[j-1].get(g-1,[]):
                for mb,b in letters:
                    if self.combine(ma,mb) is not None:vals.append(self.multiply(a,g-1,b,1))
            V[j]=self.subspace(vals,g,piv)
        return M,V

if __name__=='__main__':
    cap=tuple(map(int,sys.argv[1].split(','))) if len(sys.argv)>1 else (2,2,2,1,1,1)
    depth=int(sys.argv[2]) if len(sys.argv)>2 else 5
    try:
        solver=Fast(cap,depth,100);result=solver.run()
        original=HERE/('tangent_'+'_'.join(map(str,cap))+f'_depth{depth}_initial_solver.json')
        if original.exists():
            old=json.loads(original.read_text());assert old['component_dimensions']==result['component_dimensions']
            assert [(x['full_relation_rank'],x['Lie_operator_image_dimension']) for x in old['cases']]==[(x['full_relation_rank'],x['Lie_operator_image_dimension']) for x in result['cases']]
            print(json.dumps({'independent_depth_recurrence_agrees':True,'cap':cap}),flush=True)
    except TimeoutError as e:
        print(json.dumps({'status':'BOUNDED_BUDGET_STOP','cap':cap,'reason':str(e)}),flush=True)

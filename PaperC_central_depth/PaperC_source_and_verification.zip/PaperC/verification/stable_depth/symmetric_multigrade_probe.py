"""Exact S3 equivariance across different lower multidegrees.

Different multidegrees are replicated by isomorphisms, NOT identified.
Only the final critical weight is additionally quotiented as justified
by the archived exterior theorem (or the completed rank8 control).
"""
from pathlib import Path
from itertools import permutations,combinations_with_replacement
from collections import defaultdict
import json,sys,time
sys.dont_write_bytecode=True
import tangent_cubic_module as core
from tangent_cubic_module import add,red,bits
from anonymous_singleton_probe import Anonymous
from probe_sixth_exterior_top import canonical,CanonicalIndex
HERE=Path(__file__).resolve().parent
OUT=HERE/'sixth_exterior_probe'
PERMS=list(permutations(range(3)))

def representative(m):return tuple(sorted(m[:3],reverse=True))+(m[3],)
def permute_multi(m,p):
    a=[0,0,0,m[3]]
    for i in range(3):a[p[i]]=m[i]
    return tuple(a)
def permute_word(w,p):return tuple(p[i] if i<3 else 3 for i in w)

class SymmetryPacked(Anonymous):
    def __init__(self,m,depth,seconds):
        super().__init__((2,2,2,m),depth,seconds)
        self.blocks={0:{(0,0,0,0):[(0,0,1,(0,0,0,0))]}}
        for g in range(1,self.maximum+1):
            by=defaultdict(list)
            for w,multi in zip(self.words[g],self.multis[g]):by[multi].append(w)
            reps=sorted({representative(multi) for multi in by})
            ws=[];ms=[];blocks={}
            for rep in reps:
                base=sorted(by[rep]);base_start=len(ws);record=[]
                targets=sorted({permute_multi(rep,p) for p in PERMS})
                targets.remove(rep);targets.insert(0,rep)
                for target in targets:
                    p=next(p for p in PERMS if permute_multi(rep,p)==target)
                    start=len(ws);ws.extend(permute_word(w,p) for w in base)
                    ms.extend([target]*len(base));record.append((base_start,start,len(base),target))
                blocks[rep]=record
            assert len(ws)==len(self.words[g]) and len(set(ws))==len(ws)
            self.words[g]=ws;self.multis[g]=ms;self.ix[g]={w:i for i,w in enumerate(ws)}
            self.blocks[g]=blocks
        g=self.maximum;full=len(self.words[g]);ws=sorted({canonical(w) for w in self.words[g]})
        assert full==len(ws)*6
        self.words[g]=ws;self.multis[g]=[self.cap]*len(ws)
        self.ix[g]=CanonicalIndex({w:i for i,w in enumerate(ws)})
        self.blocks[g]={self.cap:[(0,0,len(ws),self.cap)]}
        self.coordinate_control={'original_top_coordinates':full,'top_orbits':len(ws),
           'lower_multidegrees_identified':False,'lower_multidegrees_replicated_equivariantly':True}

    def is_rep(self,m):return m==representative(m)
    def allowed_product(self,ma,mb):
        m=self.combine(ma,mb)
        return m is not None and self.is_rep(m)
    def depth_relations(self,g,piv):
        """Fast recurrence, skipping nonrepresentative TARGETS before products.

        The old components remain complete; no domain component is erased.
        M0 unordered pairs also avoid computing both equal Lie brackets.
        """
        letters=self.lie.get(1,[]) if g>1 else []
        M={};V={};J={};vals=[]
        for p in range(2,g-1):
            q=g-p
            if p>q:continue
            for i,(ma,a) in enumerate(self.lie.get(p,[])):
                for j,(mb,b) in enumerate(self.lie.get(q,[])):
                    if p==q and i>=j:continue
                    if self.allowed_product(ma,mb):vals.append(self.bracket(a,p,b,q))
        M[0]=self.subspace(vals,g,piv)
        for j in range(1,self.depth):
            vals=[]
            for ma,a in self.derived2[j-1].get(g-1,[]):
                for mb,b in letters:
                    if self.allowed_product(ma,mb):vals.append(self.bracket(a,g-1,b,1))
            M[j]=self.subspace(vals,g,piv)
        for j in range(self.depth):
            vals=[v for _,v in M[j]]
            for ma,a in letters:
                for mb,b in self.left_ideals[j].get(g-1,[]):
                    if self.allowed_product(ma,mb):vals.append(self.multiply(a,1,b,g-1))
            J[j]=self.subspace(vals,g,piv);self.left_ideals[j][g]=J[j]
        vals=[]
        previous=(self.module_depth[0].get(g-1,[])+self.lie.get(g-1,[])) if g>=3 else []
        for ma,a in letters:
            for mb,b in previous:
                if self.allowed_product(ma,mb):vals.append(self.multiply(a,1,b,g-1))
        V[0]=self.subspace(vals,g,piv)
        for j in range(1,self.depth+1):
            vals=[v for _,v in J[j-1]]
            for ma,a in self.module_depth[j-1].get(g-1,[]):
                for mb,b in letters:
                    if self.allowed_product(ma,mb):vals.append(self.multiply(a,g-1,b,1))
            V[j]=self.subspace(vals,g,piv)
        return M,V
    def subspace(self,vals,g,piv):
        out={}
        for v in vals:
            if v and self.is_rep(self.multis[g][v.bit_length()-1]):add(out,red(piv,v))
        return self.entries(out,g)
    def expand_piv(self,piv,g):
        out={}
        for p,v in piv.items():
            m=self.multis[g][p]
            assert self.is_rep(m)
            for first,start,size,target in self.blocks[g][m]:
                shift=start-first
                assert (v>>first)<(1<<size)
                out[p+shift]=v<<shift
        return out
    def expand_entries(self,entries,g):
        out=[]
        for m,v in entries:
            assert self.is_rep(m)
            for first,start,size,target in self.blocks[g][m]:out.append((target,v<<(start-first)))
        return out
    def on_degree(self,g,rec):
        (OUT/'packed_progress.json').write_text(json.dumps({'status':'RUNNING','degree':g,'record':rec,
          'coordinate_control':self.coordinate_control},indent=2)+'\n')

    def run(self):
        for g in range(1,self.maximum+1):
            piv={};cube_count=0
            for row in self.ideals[g-1].values():
                mr=self.multis[g-1][row.bit_length()-1]
                for i in range(self.d):
                    mi=tuple(int(j==i) for j in range(self.d));m=self.combine(mr,mi)
                    if m is None or not self.is_rep(m):continue
                    letter=1<<self.ix[1][(i,)]
                    add(piv,self.multiply(row,g-1,letter,1));add(piv,self.multiply(letter,1,row,g-1))
            for degrees in combinations_with_replacement(range(1,g-1),3):
                if sum(degrees)!=g:continue
                p,q,r=degrees
                for i,(mi,a) in enumerate(self.lie.get(p,[])):
                    for j,(mj,b) in enumerate(self.lie.get(q,[])):
                        if p==q and j<i:continue
                        mm=self.combine(mi,mj)
                        if mm is None:continue
                        for k,(mk,c) in enumerate(self.lie.get(r,[])):
                            if q==r and k<j:continue
                            m=self.combine(mm,mk)
                            if m is None or not self.is_rep(m):continue
                            if not self.allow_cube(((p,i,mi),(q,j,mj),(r,k,mk))):continue
                            val=0;items=((p,i,a),(q,j,b),(r,k,c))
                            for order in set(permutations(items)):
                                (ga,_,aa),(gb,_,bb),(gc,_,cc)=order
                                val^=self.multiply(self.multiply(aa,ga,bb,gb),ga+gb,cc,gc)
                            add(piv,val);cube_count+=1
                self.budget()
            cubic_rank=len(self.expand_piv(piv,g))
            M,V=self.depth_relations(g,piv)
            for _,row in V[self.depth]:add(piv,row)
            for j,entries in M.items():
                self.derived2[j][g]=self.expand_entries(self.subspace((v for _,v in entries),g,piv),g)
            for j,entries in V.items():
                self.module_depth[j][g]=self.expand_entries(self.subspace((v for _,v in entries),g,piv),g)
            for j in range(self.depth):
                # Fast's intermediate left ideals are also needed in later grades.
                self.left_ideals[j][g]=self.expand_entries(self.subspace((v for _,v in self.left_ideals[j][g]),g,piv),g)
            piv=self.expand_piv(piv,g);self.ideals[g]=piv
            self.assoc[g]=[(m,1<<i) for i,m in enumerate(self.multis[g]) if i not in piv]
            vals=[]
            if g==1:vals=[1<<self.ix[1][(i,)] for i in range(self.d)]
            else:
                for ma,a in self.lie.get(g-1,[]):
                    for i in range(self.d):
                        mi=tuple(int(j==i) for j in range(self.d));m=self.combine(ma,mi)
                        if m is not None and self.is_rep(m):vals.append(self.bracket(a,g-1,1<<self.ix[1][(i,)],1))
            lp=self.subspace(vals,g,piv);self.lie[g]=self.expand_entries(lp,g)
            rec={'old_degree':g,'free_words':len(self.words[g]),'cubic_relation_rank':cubic_rank,
                'full_relation_rank':len(piv),'associative_dimension':len(self.assoc[g]),
                'Lie_operator_image_dimension':len(self.lie[g]),'cube_coefficients_checked_in_representatives':cube_count,
                'depth_rows_added':len(piv)-cubic_rank,'seconds':time.monotonic()-self.started}
            self.records.append(rec);print(json.dumps(rec),flush=True);self.on_degree(g,rec);self.budget()
        out={'status':'EXACT_SYMMETRY_PACKED_TOP_COMPLETE','cap':self.cap,'depth':self.depth,
             'critical_dimension':len(self.assoc[self.maximum]),'coordinate_control':self.coordinate_control,
             'cases':self.records,'seconds':time.monotonic()-self.started}
        (OUT/('packed_'+'_'.join(map(str,self.cap))+f'_depth{self.depth}.json')).write_text(json.dumps(out,indent=2)+'\n')
        return out

def main(m,depth,seconds):
    OUT.mkdir(exist_ok=True);solver=SymmetryPacked(m,depth,seconds);result=solver.run()
    if m==4 and depth==5:
        old=json.loads((OUT/'top_s3_m4_depth5.json').read_text())
        for a,b in zip(old['cases'],result['cases']):
            for k in ('free_words','full_relation_rank','associative_dimension','Lie_operator_image_dimension'):
                assert a[k]==b[k],(a['old_degree'],k,a[k],b[k])
        assert result['critical_dimension']==1
        result['nonzero_control']='PASS: all grade dimensions equal the completed nonpacked solver'
    result['status']='PASS'
    name=f'packed_m{m}_depth{depth}_controls.json'
    (OUT/name).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'}),flush=True)

if __name__=='__main__':
    m=int(sys.argv[1]);depth=int(sys.argv[2]);seconds=float(sys.argv[3])
    try:main(m,depth,seconds)
    except TimeoutError as e:print(json.dumps({'status':'BOUNDED_BUDGET_STOP','m':m,'depth':depth,'reason':str(e)}),flush=True)

"""Critical profiles after a proved singleton-symmetry reduction.
Any interpretation as the COMPLETE critical component still requires
the separate symmetry/quotient identification proof and rank audit.
"""
from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
from anonymous_singleton_probe import Anonymous
HERE=Path(__file__).resolve().parent
def main(anchors,m):
    cap=tuple(anchors)+(m,);solver=Anonymous(cap,5,110);result=solver.run()
    d=len(anchors)+m+1
    out={'status':'PROFILE_COMPUTATION_COMPLETE','anchors':anchors,'singletons':m,'ordinary_rank':d,
         'critical_degree':sum(anchors)+m+1,'critical_dimension':result['critical_dimension'],
         'cases':result['cases'],'scope':'Anonymous coefficient quotient; complete critical interpretation uses the singleton-symmetry proof, not this numerical table alone.'}
    name='anonymous_profile_'+'_'.join(map(str,anchors))+'_m'+str(m)+'.json'
    (HERE/name).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='cases'}),flush=True)
if __name__=='__main__':
    anchors=tuple(map(int,sys.argv[1].split(',')));m=int(sys.argv[2])
    try:main(anchors,m)
    except TimeoutError as e:print(json.dumps({'status':'BOUNDED_BUDGET_STOP','anchors':anchors,'singletons':m,'reason':str(e)}),flush=True)

"""Opposite word-order replay of the fixed final upper-bound matrix.
The all-factor recurrence already independently agrees through degree10;
this replay completes the same degree11 rank with generator recurrences.
Shared arithmetic is disclosed; no claim of complete formal independence.
"""
from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
from anonymous_singleton_probe import Anonymous
HERE=Path(__file__).resolve().parent
class Reversed(Anonymous):
    def __init__(self):
        super().__init__((2,2,2,5),5,300)
        for g in self.words:
            self.words[g].reverse();self.multis[g].reverse();self.ix[g]={w:i for i,w in enumerate(self.words[g])}
    def on_degree(self,g,record):
        (HERE/'last_profile_replay_progress.json').write_text(json.dumps({'status':'RUNNING','degree':g,'cases':self.records},indent=2)+'\n')
def main():
    s=Reversed();r=s.run();assert r['critical_dimension']==0
    out={'status':'PASS','cap':[2,2,2,5],'critical_dimension':0,'cases':r['cases'],
         'coordinate_order':'reversed','depth_constraints':'generator recurrences; all-factor recurrence independently agrees through degree10',
         'scope':'Opposite-pivot finite rank replay with shared word arithmetic; general identification is separately proved.'}
    (HERE/'anonymous_start_replay_2_2_2_5.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='cases'}),flush=True)
if __name__=='__main__':main()

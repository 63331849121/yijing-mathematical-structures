"""Bounded top-degree S3 reduction, conditional on the archived cubic proof.

Only the very top (2,2,2,m) weight is collapsed. Lower degrees are untouched.
The remaining identical anchor permutations are valid at depth6/rank10
after the repeat-profile vanishes; this is not a generic solver shortcut.
"""
from pathlib import Path
from collections import Counter
import json,sys,time
sys.dont_write_bytecode=True
import tangent_cubic_module as core
from anonymous_singleton_probe import Anonymous
HERE=Path(__file__).resolve().parent
OUT=HERE/'sixth_exterior_probe'
OUT.mkdir(exist_ok=True)
core.HERE=OUT

def canonical(word):
    labels={};result=[]
    for a in word:
        if a==3:result.append(3)
        else:
            if a not in labels:labels[a]=len(labels)
            result.append(labels[a])
    return tuple(result)

class CanonicalIndex(dict):
    def get(self,key,default=None):
        return super().get(canonical(key),default)

class ExteriorTop(Anonymous):
    def __init__(self,m,depth,seconds):
        super().__init__((2,2,2,m),depth,seconds)
        g=self.maximum
        full=len(self.words[g]);ws=sorted({canonical(w) for w in self.words[g]})
        assert len(ws)*6==full
        self.words[g]=ws
        self.ix[g]=CanonicalIndex({w:i for i,w in enumerate(ws)})
        self.multis[g]=[self.cap]*len(ws)
        self.coordinate_control={'original_top_coordinates':full,
                                 'top_anchor_permutation_orbits':len(ws),
                                 'only_top_collapsed':True}
    def on_degree(self,g,rec):
        (OUT/'progress.json').write_text(json.dumps({'status':'RUNNING','degree':g,'record':rec,
              'coordinate_control':self.coordinate_control},indent=2)+'\n')

def main(m,depth,seconds):
    solver=ExteriorTop(m,depth,seconds)
    result=solver.run()
    out={'status':'BOUNDED_TOP_QUOTIENT_COMPLETE','m':m,'depth':depth,
         'critical_dimension':result['critical_dimension'],
         'coordinate_control':solver.coordinate_control,
         'cases':result['cases'],
         'scope':'For depth6/rank10 use full support and the exterior-only theorem; the completed depth5/rank8 control uses its already verified one-dimensional Sym3 weight. This top quotient is not imposed in lower degrees.'}
    name=f'top_s3_m{m}_depth{depth}.json'
    if m==5 and depth==5:
        baseline=json.loads((HERE/'anonymous_start_replay_2_2_2_5.json').read_text())
        out['baseline_status']=baseline['status']
        assert result['critical_dimension']==0
        out['control']='Completed fifth-depth zero remains zero after top collapse; not sufficient alone to prove validity at a new depth.'
    if m==4 and depth==5:
        assert result['critical_dimension']==1
        out['control']='PASS: preserves the known nonzero rank8 Sym3 distinct-weight line, whose anchor S3 action is trivial.'
    (OUT/name).write_text(json.dumps(out,indent=2)+'\n')
    (OUT/'progress.json').write_text(json.dumps({'status':'COMPLETE','result':name,'critical_dimension':result['critical_dimension']},indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='cases'}),flush=True)

if __name__=='__main__':
    m=int(sys.argv[1]) if len(sys.argv)>1 else 6
    depth=int(sys.argv[2]) if len(sys.argv)>2 else 6
    seconds=float(sys.argv[3]) if len(sys.argv)>3 else 180
    try:main(m,depth,seconds)
    except TimeoutError as exc:
        out={'status':'BOUNDED_BUDGET_STOP','m':m,'depth':depth,'reason':str(exc)}
        (OUT/f'top_s3_m{m}_depth{depth}_stop.json').write_text(json.dumps(out,indent=2)+'\n')
        print(json.dumps(out),flush=True)

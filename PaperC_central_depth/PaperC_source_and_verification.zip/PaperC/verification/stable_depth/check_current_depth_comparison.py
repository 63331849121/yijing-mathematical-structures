"""Literal current brackets, independent of the tangent-module constructors."""
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent

def main():
    records=[]
    for m in range(1,8):
        basis=[('x',0)]+[(a,I) for I in range(1,1<<m) for a in 'UVW']
        idx={b:i for i,b in enumerate(basis)}
        weights=[1]+[2*I.bit_count()+{'U':1,'V':0,'W':-1}[a] for a,I in basis[1:]]
        def bracket(i,j):
            a,I=basis[i];b,J=basis[j]
            if a=='x':
                return None if b in ('x','U') else idx[({'V':'U','W':'V'}[b],J)]
            if b=='x':return bracket(j,i)
            if I&J or a==b:return None
            c={frozenset('UV'):'U',frozenset('UW'):'V',frozenset('VW'):'W'}[frozenset((a,b))]
            return idx[(c,I|J)]
        gens=[0]+[idx[('W',1<<i)] for i in range(m)]
        def action(left,right):
            return {k for i in left for j in right if (k:=bracket(i,j)) is not None}
        all_basis=set(range(len(basis)))
        deriv=action(all_basis,all_basis)
        M=action(deriv,deriv)
        depths=[]
        for s in range(13):
            j=s//2
            minima=({'U':j+2,'V':j+3,'W':j+3} if s%2==0
                    else {'U':j+3,'V':j+3,'W':j+4})
            predicted={i for i,(a,I) in enumerate(basis) if a!='x' and I.bit_count()>=minima[a]}
            assert M==predicted,(m,s,'depth subspace')
            if s%2==0:
                next2=action(action(M,gens),gens)
                assert action(M,deriv)==next2,(m,s,'sharp derived-action depth')
                if m>=s//2+3:
                    next3=action(next2,gens)
                    I=(1<<(s//2+2))-1;t=s//2+2
                    v=idx[('U',I)];a=0;b=idx[('W',1<<t)]
                    ab=bracket(a,b);error=bracket(v,ab)
                    assert error in next2 and error not in next3
                    assert bracket(v,a) is None
                    assert bracket(bracket(v,b),a)==error
            quotient_class=max(weights[i] for i in all_basis-M)
            assert quotient_class==min(2*m+1,s+4),(m,s,quotient_class)
            # Exact lower central series in the quotient, rather than weights alone.
            lc=all_basis-M;c=0
            while lc:
                c+=1;lc=action(lc,gens)-M
                assert c<=2*m+2
            assert c==quotient_class,(m,s,'lower central')
            depths.append({'depth':s,'M_dimension':len(M),'quotient_class':c})
            M=action(M,gens)
        records.append({'m':m,'rank':m+1,'dimension':len(basis),'cases':depths})
    out={'status':'PASS','scope':'Exact classical current subspaces and quotient classes; no novelty asserted.',
         'tested_m':list(range(1,8)),'tested_depths':list(range(13)),'records':records}
    (HERE/'classical_current_depth_comparison.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':'PASS','models':len(records),'subspace_and_class_cases':91}))

if __name__=='__main__':main()

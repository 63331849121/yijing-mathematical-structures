Stable fifth/sixth depths and cubic representations
Standard-library CPython3.12 or later. Commands from this directory:
  python verify_compressed_depth5_witness.py rank7_fifth_depth_compressed_model.json
  python verify_compressed_depth5_witness.py rank8_fifth_depth_coefficient_model.json
  python check_rank7_cubic_module_actions.py
  python check_rank8_cubic_module_actions.py
  python check_current_depth_comparison.py
  python probe_anonymous_profile.py 4 7
  python probe_anonymous_profile.py 3,2 6
  python replay_last_profile_fast.py
  python replay_sixth_repeat_profile.py
  python replay_sixth_final.py
The final command is a slower complete reversed-coordinate elimination without
lower-multidegree replication; its baseline rank is13860 after83160 raw top
coordinates are quotiented by the PROVED top anchor symmetry. No such quotient
is imposed at lower degrees. Shared word arithmetic is explicit. The packed
implementation is symmetric_multigrade_probe.py 6 6 900.
The lower-model checker imports no model constructor. It verifies literal tables,
Jacobi, all cubic coefficients, generation and both filtrations.
The cubic-module checks compare actual root/permutation actions, not just dimensions.
Archived arbitrary-rank claims use the symbolic propagation and singleton proofs.
This package is not a proof-assistant formalization or a global-priority certificate.
Use ../run_new_results.py --output-dir NEW_DIR to avoid overwriting supplied reports;
the --slow option additionally reruns all finite stable-start systems.

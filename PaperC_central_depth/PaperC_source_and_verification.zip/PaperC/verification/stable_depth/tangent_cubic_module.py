"""One-new-generator component via a capped cubic associative module.
Independent of the large-rank central-extension prefix constructor.
All constraints are exact homogeneous coefficients; no point sampling.
"""
from pathlib import Path
from itertools import combinations_with_replacement,permutations
from functools import lru_cache
import sys,time,json
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
def bits(v):
    while v:
        b=v&-v;yield b.bit_length()-1;v^=b
def add(piv,v):
    while v:
        p=v.bit_length()-1
        if p not in piv:piv[p]=v;return True
        v^=piv[p]
    return False
def red(piv,v):
    out=0
    while v:
        p=v.bit_length()-1
        if p in piv:v^=piv[p]
        else:out^=1<<p;v^=1<<p
    return out

class Tangent:
    def __init__(self,cap,depth=None,seconds=100):
        self.cap=tuple(cap);self.d=len(cap);self.depth=depth
        self.maximum=sum(cap);self.started=time.monotonic();self.seconds=seconds
        self.words={0:[()]};self.ix={0:{():0}};self.multis={0:[(0,)*self.d]}
        for g in range(1,self.maximum+1):
            ws=[];ms=[]
            for w,m in zip(self.words[g-1],self.multis[g-1]):
                for i in range(self.d):
                    if m[i]>=self.cap[i]:continue
                    t=list(m);t[i]+=1;ws.append(w+(i,));ms.append(tuple(t))
            self.words[g]=ws;self.ix[g]={w:i for i,w in enumerate(ws)};self.multis[g]=ms
        self.ideals={0:{}};self.lie={};self.assoc={0:[((0,)*self.d,1)]}
        self.derived2={j:{} for j in range(depth or 0)}
        self.module_depth={j:{} for j in range((depth or -1)+1)}
        self.records=[]
    def budget(self):
        if time.monotonic()-self.started>self.seconds:raise TimeoutError('Capped tangent-module time budget reached')
    def combine(self,a,b):
        out=tuple(x+y for x,y in zip(a,b))
        return out if all(x<=c for x,c in zip(out,self.cap)) else None
    def multiply(self,a,ga,b,gb):
        if not a or not b:return 0
        if ga==0:return b if a else 0
        if gb==0:return a if b else 0
        out=0;ix=self.ix[ga+gb];wa=self.words[ga];wb=self.words[gb]
        for i in bits(a):
            for j in bits(b):
                k=ix.get(wa[i]+wb[j])
                if k is not None:out^=1<<k
        return out
    def bracket(self,a,ga,b,gb):return self.multiply(a,ga,b,gb)^self.multiply(b,gb,a,ga)
    def entries(self,piv,g):
        return [(self.multis[g][next(bits(v))],v) for v in piv.values()]
    def subspace(self,vals,g,piv):
        out={}
        for v in vals:add(out,red(piv,v))
        return self.entries(out,g)
    def depth_relations(self,g,piv):
        if self.depth is None:return {},{}
        M={};V={}
        # Old second-derived ideals, represented as operators.
        vals=[]
        for p in range(2,g-1):
            q=g-p
            for ma,a in self.lie.get(p,[]):
                for mb,b in self.lie.get(q,[]):
                    if self.combine(ma,mb) is not None:vals.append(self.bracket(a,p,b,q))
        M[0]=self.subspace(vals,g,piv)
        for j in range(1,self.depth):
            vals=[]
            for p in range(1,g):
                q=g-p
                for ma,a in self.derived2[j-1].get(p,[]):
                    for mb,b in self.lie.get(q,[]):
                        if self.combine(ma,mb) is not None:vals.append(self.bracket(a,p,b,q))
            M[j]=self.subspace(vals,g,piv)
        # New-generator part of B'': (M H)H' = A_+ H'.
        vals=[]
        for p in range(1,g-1):
            q=g-p
            for ma,a in self.assoc.get(p,[]):
                for mb,b in self.lie.get(q,[]):
                    if self.combine(ma,mb) is not None:vals.append(self.multiply(a,p,b,q))
        V[0]=self.subspace(vals,g,piv)
        for j in range(1,self.depth+1):
            vals=[]
            for p in range(1,g):
                q=g-p
                for ma,a in self.module_depth[j-1].get(p,[]):
                    for mb,b in self.lie.get(q,[]):
                        if self.combine(ma,mb) is not None:vals.append(self.multiply(a,p,b,q))
            for p in range(g):
                q=g-p
                old=M[j-1] if q==g else self.derived2[j-1].get(q,[])
                for ma,a in self.assoc.get(p,[]):
                    for mb,b in old:
                        if self.combine(ma,mb) is not None:vals.append(self.multiply(a,p,b,q))
            V[j]=self.subspace(vals,g,piv)
        return M,V
    def run(self):
        for g in range(1,self.maximum+1):
            piv={};closure=0;cube_count=0
            for row in self.ideals[g-1].values():
                for i in range(self.d):
                    letter=1<<self.ix[1][(i,)]
                    add(piv,self.multiply(row,g-1,letter,1));add(piv,self.multiply(letter,1,row,g-1));closure+=2
            for degrees in combinations_with_replacement(range(1,g-1),3):
                if sum(degrees)!=g:continue
                p,q,r=degrees
                for i,(mi,a) in enumerate(self.lie.get(p,[])):
                    for j,(mj,b) in enumerate(self.lie.get(q,[])):
                        if p==q and j<i:continue
                        mm=self.combine(mi,mj)
                        if mm is None:continue
                        for k,(mk,c) in enumerate(self.lie.get(r,[])):
                            if q==r and k<j:continue
                            if self.combine(mm,mk) is None:continue
                            if hasattr(self,'allow_cube') and not self.allow_cube(((p,i,mi),(q,j,mj),(r,k,mk))):continue
                            val=0;items=((p,i,a),(q,j,b),(r,k,c))
                            for order in set(permutations(items)):
                                (ga,_,aa),(gb,_,bb),(gc,_,cc)=order
                                val^=self.multiply(self.multiply(aa,ga,bb,gb),ga+gb,cc,gc)
                            add(piv,val);cube_count+=1
                self.budget()
            cubic_rank=len(piv)
            M,V=self.depth_relations(g,piv)
            if self.depth is not None:
                for _,row in V[self.depth]:add(piv,row)
                for j,entries in M.items():self.derived2[j][g]=self.subspace((v for _,v in entries),g,piv)
                for j,entries in V.items():self.module_depth[j][g]=self.subspace((v for _,v in entries),g,piv)
            self.ideals[g]=piv
            self.assoc[g]=[(m,1<<i) for i,m in enumerate(self.multis[g]) if i not in piv]
            lp={}
            if g==1:
                for i in range(self.d):add(lp,red(piv,1<<self.ix[1][(i,)]))
            else:
                for ma,a in self.lie.get(g-1,[]):
                    for i in range(self.d):
                        mi=tuple(int(j==i) for j in range(self.d))
                        if self.combine(ma,mi) is not None:add(lp,red(piv,self.bracket(a,g-1,1<<self.ix[1][(i,)],1)))
            self.lie[g]=self.entries(lp,g)
            rec={'old_degree':g,'free_words':len(self.words[g]),'cubic_relation_rank':cubic_rank,
                 'full_relation_rank':len(piv),'associative_dimension':len(self.assoc[g]),
                 'Lie_operator_image_dimension':len(lp),'cube_coefficients_checked':cube_count,
                 'depth_rows_added':len(piv)-cubic_rank,'seconds':time.monotonic()-self.started}
            self.records.append(rec);print(json.dumps(rec),flush=True)
            if hasattr(self,'on_degree'):self.on_degree(g,rec)
            self.budget()
        dims={}
        for g,entries in self.assoc.items():
            for m,_ in entries:dims[m]=dims.get(m,0)+1
        result={'status':'EXACT_CAPPED_TANGENT_MODULE_COMPLETE','old_rank':self.d,'old_cap':self.cap,
                'central_depth':self.depth,'cases':self.records,'component_dimensions':{'_'.join(map(str,k)):v for k,v in dims.items()},
                'critical_dimension':dims.get(self.cap,0),'seconds':time.monotonic()-self.started,
                'scope':'Universal one-new-generator component, conditional on the separately proved semidirect/module identification. No sampled evaluations.'}
        name='tangent_'+('_'.join(map(str,self.cap)))+('_depth'+str(self.depth) if self.depth else '_ordinary')
        (HERE/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
        return result

if __name__=='__main__':
    cap=tuple(map(int,sys.argv[1].split(','))) if len(sys.argv)>1 else (3,3)
    depth=int(sys.argv[2]) if len(sys.argv)>2 else None
    try:Tangent(cap,depth,100).run()
    except TimeoutError as e:
        rec={'status':'BOUNDED_BUDGET_STOP','cap':cap,'depth':depth,'reason':str(e)}
        (HERE/('tangent_stop_'+'_'.join(map(str,cap))+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)

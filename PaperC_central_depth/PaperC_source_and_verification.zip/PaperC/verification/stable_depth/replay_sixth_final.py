"""Final exterior-profile replay: no lower-multidegree replication.

Uses reversed free-word coordinates. Shared cubic word arithmetic and
the proved generator-depth recurrence are explicitly retained.
"""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
SOURCE=HERE
sys.dont_write_bytecode=True;sys.path.insert(0,str(SOURCE))
import tangent_cubic_module as core
from probe_sixth_exterior_top import ExteriorTop,CanonicalIndex
OUT=HERE/'validation';OUT.mkdir(exist_ok=True);core.HERE=OUT
class Replay(ExteriorTop):
    def __init__(self):
        super().__init__(6,6,900)
        for g in self.words:
            self.words[g]=list(reversed(self.words[g]))
            self.multis[g]=list(reversed(self.multis[g]))
            index={w:i for i,w in enumerate(self.words[g])}
            self.ix[g]=CanonicalIndex(index) if g==self.maximum else index
    def on_degree(self,g,rec):
        (OUT/'sixth_final_progress.json').write_text(json.dumps({'status':'RUNNING','degree':g,'record':rec},indent=2)+'\n')
def main():
    rec=Replay().run()
    old=json.loads((SOURCE/'sixth_exterior_probe/packed_m6_depth6_controls.json').read_text())
    for a,b in zip(rec['cases'],old['cases']):
        for key in ('free_words','full_relation_rank','associative_dimension','Lie_operator_image_dimension'):
            assert a[key]==b[key],(a['old_degree'],key,a[key],b[key])
    assert rec['critical_dimension']==0
    out={'status':'PASS','critical_dimension':0,'coordinate_order':'reversed',
         'lower_multidegree_replication':False,'shared_arithmetic':True,
         'comparison':'All graded dimensions and ranks agree with the packed computation.',
         'cases':rec['cases']}
    (OUT/'sixth_final_replay.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='cases'}),flush=True)
if __name__=='__main__':
    try:main()
    except TimeoutError as e:
        (OUT/'sixth_final_stop.json').write_text(json.dumps({'status':'BOUNDED_BUDGET_STOP','reason':str(e)}))
        raise

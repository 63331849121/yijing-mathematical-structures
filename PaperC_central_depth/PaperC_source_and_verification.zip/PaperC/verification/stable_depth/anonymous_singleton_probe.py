"""Replace arbitrary many commuting singleton labels by a weighted Z.
The algebra is a square-free coefficient construction, NOT a claim that
the anonymous Z itself acts with cube zero. All uses require that distinction.
"""
from pathlib import Path
from collections import Counter
import sys,json,time
sys.dont_write_bytecode=True
from tangent_cubic_module_fast import Fast
HERE=Path(__file__).resolve().parent
class Anonymous(Fast):
    def allow_cube(self,items):
        multiplicities=Counter((g,i) for g,i,m in items)
        return all(not (multiplicities[(g,i)]>=2 and m[-1]>0) for g,i,m in items)

def main(m=4):
    solver=Anonymous((3,2,m),5,85);rec=solver.run()
    out={'status':'ANONYMOUS_COEFFICIENT_PROBE_COMPLETE','singleton_count':m,'old_rank_after_expansion':m+2,
         'ordinary_rank_after_adding_y':m+3,'word_degree_after_adding_y':m+6,
         'critical_dimension':rec['critical_dimension'],'cases':rec['cases'],
         'scope':'A symmetric square-free coefficient quotient. A nonzero value requires the separate coefficient-realization proof or an actual expanded model; zero does not exclude the full nonsymmetric problem.'}
    (HERE/f'anonymous_singletons_m{m}.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='cases'}),flush=True)
if __name__=='__main__':
    try:main(int(sys.argv[1]) if len(sys.argv)>1 else 4)
    except TimeoutError as e:print(json.dumps({'status':'BOUNDED_BUDGET_STOP','reason':str(e)}),flush=True)

"""All-factor depth recurrence and reversed coordinates; shared word arithmetic."""
from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
import tangent_cubic_module as core
from tangent_cubic_module import Tangent
from anonymous_singleton_probe import Anonymous
HERE=Path(__file__).resolve().parent
OUT=HERE/'sixth_exterior_probe'
OUT.mkdir(exist_ok=True);core.HERE=OUT

class SlowRecurrence(Anonymous):
    depth_relations=Tangent.depth_relations
    def __init__(self):
        super().__init__((3,2,7),6,90)
        for g in self.words:
            self.words[g]=list(reversed(self.words[g]))
            self.ix[g]={w:i for i,w in enumerate(self.words[g])}
            self.multis[g]=list(reversed(self.multis[g]))

def main():
    rec=SlowRecurrence().run()
    old=json.loads((HERE/'tangent_3_2_7_depth6.json').read_text())
    assert rec['component_dimensions']==old['component_dimensions']
    for a,b in zip(rec['cases'],old['cases']):
        for k in ('full_relation_rank','associative_dimension','Lie_operator_image_dimension'):
            assert a[k]==b[k],(a['old_degree'],k,a[k],b[k])
    assert rec['critical_dimension']==0
    out={'status':'PASS','critical_dimension':0,'cap':[3,2,7],'depth':6,
      'control':'Reversed words and all-factor depth recurrence agree in every grade and multidegree.',
      'shared':'Word arithmetic and complete cubic coefficient generator are shared.',
      'cases':rec['cases']}
    (OUT/'repeat_profile_independent_recurrence.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='cases'}),flush=True)

if __name__=='__main__':
    try:main()
    except TimeoutError as e:print(json.dumps({'status':'BOUNDED_BUDGET_STOP','reason':str(e)}),flush=True)

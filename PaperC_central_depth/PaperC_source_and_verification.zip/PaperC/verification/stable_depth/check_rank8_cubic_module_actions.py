"""Check all root-group orbit types against symmetric/divided cubic powers.
Weight characters alone are NOT used to assert a module isomorphism.
"""
from pathlib import Path
from itertools import combinations
from math import comb
import sys,json
sys.dont_write_bytecode=True
from anonymous_singleton_probe import Anonymous
from tangent_cubic_module import red
HERE=Path(__file__).resolve().parent
def main():
    caps=((4,6),(3,2,5),(2,2,2,4));solvers=[];bases=[]
    for cap in caps:
        s=Anonymous(cap,5,80);r=s.run();assert r['critical_dimension']==1
        g=sum(cap);free=[i for i in range(len(s.words[g])) if i not in s.ideals[g]];assert len(free)==1
        z=len(cap)-1;word=[];seen=0
        for a in s.words[g][free[0]]:
            if a<z:word.append(a)
            else:word.append(z+seen);seen+=1
        solvers.append(s);bases.append(word)
    checks=[];mismatches={'Sym3':[],'Gamma3':[]}
    for kind,word in enumerate(bases):
        counts=[word.count(i) for i in range(7)];alpha=[x-1 for x in counts]
        for p in range(7):
            for q in range(7):
                if p==q:continue
                positions=[i for i,a in enumerate(word) if a==p]
                for k in range(1,alpha[p]+1):
                    terms=[]
                    for sub in combinations(positions,k):
                        w=word.copy()
                        for pos in sub:w[pos]=q
                        terms.append(w)
                    new=counts.copy();new[p]-=k;new[q]+=k
                    anchors=sorted((i for i,x in enumerate(new) if x>1),key=lambda i:(-new[i],i))
                    shape=tuple(new[i] for i in anchors)
                    out_kind={(4,):0,(3,2):1,(2,2,2):2}[shape];s=solvers[out_kind];z=len(anchors)
                    amap={a:i for i,a in enumerate(anchors)};val=0
                    for w in terms:
                        anon=tuple(amap.get(a,z) for a in w);val^=1<<s.ix[10][anon]
                    rem=red(s.ideals[10],val);assert rem.bit_count()<=1;actual=int(bool(rem))
                    expected={'Sym3':comb(alpha[p],k)%2,'Gamma3':comb(alpha[q]+k,k)%2}
                    item={'source_kind':kind,'p':p,'q':q,'lambda_power':k,'actual':actual,'expected':expected}
                    checks.append(item)
                    for name,v in expected.items():
                        if actual!=v:mismatches[name].append(item)
    matches=[name for name,errs in mismatches.items() if not errs]
    out={'status':'ROOT_ACTION_CHECK_COMPLETE','rank':8,'dimension':120,
         'critical_weight_dimensions':[1,1,1],'checks':len(checks),'matching_cubic_models':matches,
         'mismatch_counts':{name:len(errs) for name,errs in mismatches.items()},
         'first_mismatches':{name:errs[:5] for name,errs in mismatches.items()},
         'basis_old_words':bases,
         'scope':'All scalar coefficients for all elementary-shear orbit types on the three critical weight types, with an unaffected singleton reserved as y. Permutations and diagonal weights require the separate basis-naturality proof.'}
    (HERE/'rank8_cubic_module_root_actions.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out),flush=True)
if __name__=='__main__':main()

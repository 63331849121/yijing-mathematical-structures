from pathlib import Path
import json,time,hashlib
from verify_transfer import Realization,second,action,quotient,map_check
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
SOURCE=HERE.parent/'central_depth/capped_depth4_d5_model.json'
def main():
    start=time.monotonic();raw=json.loads(SOURCE.read_text());h=raw['table'];tables=[h];arrows=[]
    for _ in range(3):
        layer=second(h)
        while True:
            nxt=action(h,layer)
            if not nxt:break
            layer=nxt
        h,keep,project=quotient(h,layer)
        arrows.append((keep,project));tables.append(h)
    assert [len(t) for t in tables]==[178,167,139,118]
    models=[];reports=[]
    for h in tables:
        m=Realization(h,5);models.append(m);reports.append(m.report)
        print(json.dumps(m.report),flush=True)
    maps=[map_check(models[i],models[i+1],*arrows[i]) for i in range(3)]
    out={'status':'PASS','models':reports,'central_maps':maps,'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest()}
    (HERE/'rank5_transfer_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':'PASS','central_maps':maps,'seconds':out['seconds']}),flush=True)
if __name__=='__main__':main()

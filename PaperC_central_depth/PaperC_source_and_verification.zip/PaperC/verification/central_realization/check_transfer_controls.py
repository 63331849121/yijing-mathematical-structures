"""Composition, centre-defect, sharpness, and scope controls; exact arithmetic."""
from pathlib import Path
from itertools import combinations
import json,time
from verify_transfer import Realization,bits,span,quotient,action,second,map_check,SOURCE
HERE=Path(__file__).resolve().parent

def linear(v,images):
    out=0
    for i in bits(v):out^=images[i]
    return out

def induced(high,low,keep,project):
    hn,ln=high.n,low.n;mask=(1<<hn)-1
    ims=[low.coords(sum(project((a>>(hn*j))&mask)<<(ln*k) for k,j in enumerate(keep))) for a in high.matrices]
    def mapped(v):
        a=linear(v&high.mask,ims);b=linear(v>>high.m,ims)
        return a|(b<<low.m)
    images=[low.ycoords(mapped(v)) for v in high.y]
    piv={};ker=[]
    for i,v in enumerate(images):
        used=1<<i
        while v:
            k=v.bit_length()-1
            if k not in piv:piv[k]=(v,used);break
            w,u=piv[k];v^=w;used^=u
        if not v:ker.append(used)
    return images,ker

def main():
    started=time.monotonic();data=json.loads(SOURCE.read_text(encoding='utf-8-sig'))
    E,B,A=[Realization(data[n]['table'],4) for n in ('E','B','A')]
    _,keepAB,pAB=quotient(A.h,[1<<i for i,g in enumerate(data['A']['grades']) if g==7])
    _,keepBE,pBE=quotient(B.h,action(B.h,second(B.h)))
    ab,kab=induced(A,B,keepAB,pAB);be,kbe=induced(B,E,keepBE,pBE)
    ae,kae=induced(A,E,[keepAB[i] for i in keepBE],lambda v:pBE(pAB(v)))
    assert ae==[linear(v,be) for v in ab]
    assert any(A.br(linear(v,A.y),w) for v in kae for w in A.y),'Composite unexpectedly central'
    centre=[]
    for high,low,ker,ordinary_kernel in ((A,B,kab,1),(B,E,kbe,1)):
        zh=high.report['ordinary_centre_dimension_F4'];zl=low.report['ordinary_centre_dimension_F4']
        assert len(ker)==2*(zl-zh+ordinary_kernel)
        assert len(high.y)==2*(high.n-zh)
        centre.append({'source_centre_F4':zh,'target_centre_F4':zl,'ordinary_kernel_F4':ordinary_kernel,'orbit_kernel_F4':len(ker)//2})
    heisenberg=[]
    for r in (2,4,6,10):
        t=[[0]*(r+1) for _ in range(r+1)]
        for i in range(0,r,2):t[i][i+1]=t[i+1][i]=1<<r
        h=Realization(t,r);q,keep,p=quotient(t,[1<<r]);k=Realization(q,r,expected_point_rank=0)
        result=map_check(h,k,keep,p)
        assert result['kernel_dimension_F2']==2*r
        heisenberg.append({'ordinary_rank':r,'ordinary_kernel_F4':1,'orbit_kernel_F4':r,'bound_attained':True})
    # Retaining marks is essential. Replace one adjoint mark A_1 by omega*A_1.
    seeds=[E.coords(a) for a in E.ad[:4]]
    first=seeds[0];seeds[0]=(first<<E.m)
    ys=span(seeds);i=0
    while i<len(ys):
        prev=ys;ys=span(ys+[E.f(ys[i])]+[E.br(ys[i],v) for v in ys]);i+=1
        # span() preserves the existing independent prefix.
        assert ys[:len(prev)]==prev
    marks_change=len(span(ys+E.y))>len(E.y)
    assert len(ys)==len(E.y) and marks_change
    out={'status':'PASS','composition_on_full_binary_basis':True,'composite_central_arrows_need_not_be_central':True,
         'centre_defect_controls':centre,'sharp_kernel_bound_heisenberg_controls':heisenberg,
         'different_F4_mark_same_dimension_different_binary_subsolution':marks_change,
         'non_surjective_adjoint_descent_counterexample':'An abelian line embeds as a noncentral line in the Heisenberg algebra. Source ad is zero and target marked ad is nonzero.',
         'seconds':time.monotonic()-started}
    (HERE/'transfer_controls.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out),flush=True)
if __name__=='__main__':main()

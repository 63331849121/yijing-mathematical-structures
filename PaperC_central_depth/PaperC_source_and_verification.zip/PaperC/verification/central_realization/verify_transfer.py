"""Independent adjoint/square realization and transfer of a central chain.

All arithmetic is exact. F2 structure constants are extended to F4.
The fourth-power condition is checked as a polynomial on the WHOLE
F4 envelope, not by point sampling. No constructor imports are used.
"""
from pathlib import Path
from itertools import combinations
from functools import lru_cache
import json,time,hashlib
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
SOURCE=HERE.parent/'central_depth/rank4_chain_models.json'
def bits(v):
    while v:
        lo=v&-v;yield lo.bit_length()-1;v^=lo
def span(vals):
    p={}
    for v in vals:
        while v:
            k=v.bit_length()-1
            if k not in p:p[k]=v;break
            v^=p[k]
    return list(p.values())
def b2(t,a,b):
    out=0
    for i in bits(a):
        for j in bits(b):out^=t[i][j]
    return out
def action(t,sub):return span(b2(t,v,1<<i) for v in sub for i in range(len(t)))
def series(t,sub):
    out=[]
    while sub:
        out.append(len(sub));sub=action(t,sub)
        assert len(out)<len(t)+1
    return out+[0]
def second(t):
    first=span(t[i][j] for i,j in combinations(range(len(t)),2))
    return span(b2(t,a,b) for a,b in combinations(first,2))
def quotient(t,ker):
    p={}
    for v in ker:
        for k in sorted(p):
            if v>>k&1:v^=p[k]
        if v:p[(v&-v).bit_length()-1]=v
    assert all(not b2(t,v,1<<j) for v in p.values() for j in range(len(t)))
    keep=[i for i in range(len(t)) if i not in p];ix={i:j for j,i in enumerate(keep)}
    def project(v):
        for k in sorted(p):
            if v>>k&1:v^=p[k]
        return sum(1<<ix[k] for k in bits(v))
    return [[project(t[i][j]) for j in keep] for i in keep],keep,project
class Realization:
    def __init__(self,table,rank,expected_point_rank=None):
        self.h=table;self.n=len(table);self.rank=rank;n=self.n;mask=(1<<n)-1
        self.ad=[sum(table[i][j]<<(n*j) for j in range(n)) for i in range(n)]
        def apply(a,v):
            ans=0
            for j in bits(v):ans^=(a>>(n*j))&mask
            return ans
        def product(a,b):return sum(apply(a,(b>>(n*j))&mask)<<(n*j) for j in range(n))
        self.product=product;self.matrices=[];self.piv={}
        def add(v):
            original=v;used=0
            while v:
                k=v.bit_length()-1
                if k not in self.piv:
                    self.piv[k]=(v,used^(1<<len(self.matrices)))
                    self.matrices.append(original);return
                r,c=self.piv[k];v^=r;used^=c
        for a in self.ad:add(a)
        for a in self.ad[:rank]:add(product(a,a))
        def coords(v):
            used=0
            while v:
                k=v.bit_length()-1;assert k in self.piv,'Envelope not closed'
                r,c=self.piv[k];v^=r;used^=c
            return used
        self.coords=coords;self.m=len(self.matrices);m=self.m
        self.t=[[0]*m for _ in range(m)]
        self.squares=[coords(product(a,a)) for a in self.matrices]
        for i,j in combinations(range(m),2):
            self.t[i][j]=self.t[j][i]=coords(product(self.matrices[i],self.matrices[j])^product(self.matrices[j],self.matrices[i]))
        self.mask=(1<<m)-1
        @lru_cache(None)
        def sq(a):
            out=0
            for i in bits(a):
                out^=self.squares[i]
                for j in bits(a&((1<<i)-1)):out^=self.t[i][j]
            return out
        self.sq=sq
        # Exact coefficient check P(P(z))=0 over an arbitrary scalar extension.
        polys=[((i,i),v) for i,v in enumerate(self.squares) if v]
        polys += [((i,j),self.t[i][j]) for i,j in combinations(range(m),2) if self.t[i][j]]
        composed={}
        def put(key,v):
            if not v:return
            composed[key]=composed.get(key,0)^v
            if not composed[key]:del composed[key]
        for mon,v in polys:put(tuple(sorted(mon+mon)),sq(v))
        for (a,v),(b,w) in combinations(polys,2):put(tuple(sorted(a+b)),b2(self.t,v,w))
        assert not composed,'Nonzero full quartic coefficient'
        self.quartic_inputs=len(polys)
        self.quartic_coefficients=len(set(tuple(sorted(a+b)) for a,_ in polys for b,_ in polys)) if len(polys)<250 else None
        self.y=[];yp={}
        def add_y(v):
            while v:
                k=v.bit_length()-1
                if k not in yp:yp[k]=v;self.y.append(v);return
                v^=yp[k]
        for a in self.ad[:rank]:add_y(coords(a))
        index=0
        while index<len(self.y):
            v=self.y[index];add_y(self.f(v))
            for w in list(self.y):add_y(self.br(v,w))
            index+=1
        self.yp=yp;self.yt=[[self.ycoords(self.br(a,b)) for b in self.y] for a in self.y]
        first=span(self.yt[i][j] for i,j in combinations(range(len(self.y)),2))
        lower=series(self.yt,[1<<i for i in range(len(self.y))]);depth=series(self.yt,second(self.yt))
        hdepth=series(table,second(table));hlower=series(table,[1<<i for i in range(n)])
        assert len(lower)==len(hlower)-1
        assert len(depth)-1==max(len(hdepth)-2,0)
        if expected_point_rank is None:expected_point_rank=rank
        assert len(self.y)-len(first)==2*expected_point_rank
        # Independent matrix check of the abstract square coordinates on basis.
        for i,a in enumerate(self.matrices):
            assert product(product(a,a),product(a,a))==0
        # Verify actual subspaces, beyond matching lower-central dimensions.
        def y_element(v):
            out=0
            for i in bits(v):out^=self.y[i]
            return out
        def same_span(a,b):
            sa,sb=span(a),span(b)
            return len(sa)==len(sb)==len(span(sa+sb))
        hfirst=span(table[i][j] for i,j in combinations(range(n),2))
        xd=[]
        for v in hfirst:
            mat=0
            for i in bits(v):mat^=self.ad[i]
            xd.append(coords(mat))
        xd=span(xd)
        assert same_span([y_element(v) for v in first],xd+[v<<m for v in xd]),'Actual derived subspaces differ'
        adrank=len(span(self.ad));zdim=n-adrank
        self.report={'ordinary_dimension_F4':n,'ordinary_centre_dimension_F4':zdim,'ordinary_class':len(hlower)-1,
            'ordinary_second_derived_depth':len(hdepth)-1,'envelope_dimension_F4':m,
            'orbit_dimension_F2':len(self.y),'orbit_point_rank':(len(self.y)-len(first))//2,
            'orbit_class':len(lower)-1,'orbit_second_derived_depth':len(depth)-1,
            'orbit_lower_dimensions':lower,'orbit_second_derived_depth_dimensions':depth,
            'restricted_square_terms':len(polys),'quartic_coefficients_checked':self.quartic_coefficients,
            'full_quartic_polynomial_checked':True,'derived_subspace_equality_checked':True}
    def br(self,v,w):
        a,b=v&self.mask,v>>self.m;c,d=w&self.mask,w>>self.m
        bd=b2(self.t,b,d)
        return (b2(self.t,a,c)^bd)|((b2(self.t,a,d)^b2(self.t,b,c)^bd)<<self.m)
    def f(self,v):
        a,b=v&self.mask,v>>self.m;bs=self.sq(b)
        return (b^self.sq(a)^bs)|((a^b^b2(self.t,a,b)^bs)<<self.m)
    def ycoords(self,v):
        out=0
        for i,y in sorted(enumerate(self.y),key=lambda x:x[1].bit_length(),reverse=True):
            k=y.bit_length()-1
            if v>>k&1:v^=y;out^=1<<i
        assert not v,'Y is not closed'
        return out
    def matrix(self,v):
        out=0
        for i in bits(v):out^=self.matrices[i]
        return out
def map_check(high,low,keep,project):
    hn,ln=high.n,low.n;mask=(1<<hn)-1
    def quotient_matrix(mat):return sum(project((mat>>(hn*j))&mask)<<(ln*k) for k,j in enumerate(keep))
    image=[low.coords(quotient_matrix(a)) for a in high.matrices]
    def mapped(v):
        lo=hi=0
        for i in bits(v&high.mask):lo^=image[i]
        for i in bits(v>>high.m):hi^=image[i]
        return lo|(hi<<low.m)
    maps=[low.ycoords(mapped(v)) for v in high.y];piv={};ker=[]
    for i,v in enumerate(maps):
        used=1<<i
        while v:
            k=v.bit_length()-1
            if k not in piv:piv[k]=(v,used);break
            r,u=piv[k];v^=r;used^=u
        if not v:ker.append(used)
    assert len(piv)==len(low.y),'Not surjective on generated orbit objects'
    for co in ker:
        v=0
        for i in bits(co):v^=high.y[i]
        assert all(not high.br(v,w) for w in high.y)
        # f on this kernel must be the marked scalar omega.
        a,b=v&high.mask,v>>high.m;omega=b|((a^b)<<high.m)
        assert high.f(v)==omega
    for v in high.y:assert mapped(high.f(v))==low.f(mapped(v))
    for i,j in combinations(range(len(high.y)),2):assert mapped(high.br(high.y[i],high.y[j]))==low.br(mapped(high.y[i]),mapped(high.y[j]))
    return {'surjective':True,'kernel_dimension_F2':len(ker),'kernel_central':True,'kernel_square_zero':True,'marked_scalar_intertwining':True}
def main():
    start=time.monotonic();data=json.loads(SOURCE.read_text(encoding='utf-8-sig'))
    models={};records={}
    for name in ('E','B','A'):
        models[name]=Realization(data[name]['table'],4);records[name]=models[name].report
        print(json.dumps({'name':name,**records[name]}),flush=True)
    maps={}
    A,B,E=(data[x]['table'] for x in ('A','B','E'))
    qb,keep,p=quotient(A,[1<<i for i,g in enumerate(data['A']['grades']) if g==7]);assert qb==B
    maps['A_to_B']=map_check(models['A'],models['B'],keep,p)
    qe,keep,p=quotient(B,action(B,second(B)));assert qe==E
    maps['B_to_E']=map_check(models['B'],models['E'],keep,p)
    out={'status':'PASS','models':records,'central_maps':maps,'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
         'scope':'Finite controls of a separately proved general surjective-map transfer theorem; no arbitrary-map functor or full categorical equivalence claimed.'}
    (HERE/'transfer_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':'PASS','central_maps':maps,'seconds':out['seconds']}),flush=True)
if __name__=='__main__':main()

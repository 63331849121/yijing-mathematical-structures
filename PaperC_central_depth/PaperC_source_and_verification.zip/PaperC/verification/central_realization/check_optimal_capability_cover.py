"""Uniform sharp central covers: tournament packing plus top cocycle.
Independently check Jacobi, every F4 Engel coefficient, centre, and orbit output.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement,permutations
import sys,importlib.util,json,re,time,hashlib
sys.dont_write_bytecode=True
from verify_transfer import Realization,bits,span,b2,second,series
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
SUPPORT=HERE.parent/'general_structure/_ordinary_engel_support.py'
spec=importlib.util.spec_from_file_location('readonly_ordinary_support',SUPPORT)
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
def main(d=4):
    started=time.monotonic();t,labels=core.make_H(d);n=len(t);full=(1<<d)-1
    heads={};grades=[1]*d
    for j,label in enumerate(labels[d:],d):
        mat=re.fullmatch(r'a(\d)(\d)(?:\*t\[([1-9]*)\])?',label);assert mat
        a,b=int(mat[1])-1,int(mat[2])-1;s=sum(1<<(int(ch)-1) for ch in (mat[3] or ''))
        heads[j]=(a,b,s);grades.append(2+s.bit_count())
    def theta(*masks):
        used=0
        for s in masks:
            if used&s:return 0
            used|=s
        return int(used==full)
    def top(i,j):
        if i<d and j<d:return 0
        if i<d:i,j=j,i
        a,b,r=heads[i]
        if j<d:return theta(r,1<<b)*int(a==j)^theta(r,1<<a)*int(b==j)
        c,e,s=heads[j]
        return (theta(r,s,1<<a,1<<e)*int(c==b)^theta(r,s,1<<a,1<<c)*int(e==b)^
                theta(r,s,1<<b,1<<e)*int(c==a)^theta(r,s,1<<b,1<<c)*int(e==a))
    h2,_=core.make_H(2);m0=d//2;channels=m0+1
    tournament_size=d if d%2 else d+1;half=(tournament_size-1)//2
    edges=[]
    for tail in range(d):
        targets=[head for head in range(d) if head!=tail and 1<=((head-tail)%tournament_size)<=half]
        assert len(targets)<=m0
        edges.extend((tail,head,c) for c,head in enumerate(targets))
    assert len(edges)==d*(d-1)//2
    assert len({tuple(sorted((a,b))) for a,b,_ in edges})==len(edges)
    projections=[]
    for a,b,c in edges:
        values=[]
        for i in range(n):
            if i<d:v=1 if i==a else 2 if i==b else 0
            else:
                u,vv,s=heads[i]
                if {u,vv}!={a,b} or s&~((1<<a)|(1<<b)):v=0
                else:
                    v=1<<2
                    for k in bits(s):v=b2(h2,v,1<<(0 if k==a else 1))
            values.append(v)
        projections.append((values,c))
    def pair_alpha(v,w):
        out=0
        for i,j in ((0,5),(2,3)):
            out^=((v>>i)&1)*((w>>j)&1)^((v>>j)&1)*((w>>i)&1)
        return out
    alpha=[[0]*n for _ in range(n)]
    for i,j in combinations(range(n),2):
        v=top(i,j)<<m0
        for proj,c in projections:v^=pair_alpha(proj[i],proj[j])<<c
        alpha[i][j]=alpha[j][i]=v
    ext=[row+[0]*channels for row in t]+[[0]*(n+channels) for _ in range(channels)]
    for i,j in combinations(range(n),2):ext[i][j]^=alpha[i][j]<<n;ext[j][i]^=alpha[i][j]<<n
    def cochain(v,j):
        out=0
        for i in bits(v):out^=alpha[i][j]
        return out
    jacobi=0
    for i,j,k in combinations(range(n),3):
        assert not(cochain(t[i][j],k)^cochain(t[j][k],i)^cochain(t[k][i],j));jacobi+=1
    # Full cubic x-coefficients in alpha([y,x,x],x), grouped by weights.
    weights={5,d+2};maxweight=max(weights);triples={}
    for triple in combinations_with_replacement(range(n),3):
        g=sum(grades[i] for i in triple)
        if g<maxweight:triples.setdefault(g,[]).append(triple)
    engel=0
    for y in range(n):
        for degree in weights:
            for tri in triples.get(degree-grades[y],[]):
                value=0
                for i,j,k in set(permutations(tri)):value^=cochain(b2(t,t[y][i],1<<j),k)
                assert not value,('Engel coefficient failed',y,tri,value);engel+=1
    N=len(ext);ad=[sum(ext[i][j]<<(N*j) for j in range(N)) for i in range(N)]
    zdim=N-len(span(ad));dd=second(ext)
    assert zdim==channels==len(dd)
    assert all(not b2(ext,w,1<<i) for w in dd for i in range(N))
    generated=span(1<<i for i in range(d));i=0
    while i<len(generated):
        generated=span(generated+[b2(ext,generated[i],w) for w in generated]);i+=1
    assert len(generated)==N
    model=Realization(ext,d)
    assert model.report['orbit_dimension_F2']==2*n
    assert model.report['orbit_second_derived_depth']==0
    assert model.report['orbit_class']==d+1
    lower_bound=(d*(d+1)//2+d-1)//d
    assert channels==lower_bound
    out={'status':'PASS','rank':d,'ordinary_metabelian_dimension_F4':n,'ordinary_cover_dimension_F4':N,
         'centre_dimension_F4':zdim,'lower_bound_centre_dimension_F4':lower_bound,'second_derived_dimension_F4':len(dd),
         'ordinary_generator_count':d,'all_generator_closure_dimension':len(generated),
         'all_CE_basis_triples_checked':jacobi,'all_relevant_F4_Engel_coefficients_checked':engel,
         'tournament_edges':[list(e) for e in edges],'orbit':model.report,'seconds':time.monotonic()-started,
         'scope':'Exact finite controls at the displayed rank; the all-rank optimality theorem has a separate proof.'}
    (HERE/f'optimal_capability_d{d}.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
    if d in (3,5):
        (HERE/f'optimal_capability_d{d}_model.json').write_text(json.dumps({'table':ext,'grades':grades+[5]*m0+[d+2],'rank':d,'coefficient_dimension':channels},indent=2)+'\n')
if __name__=='__main__':main(int(sys.argv[1]) if len(sys.argv)>1 else 4)

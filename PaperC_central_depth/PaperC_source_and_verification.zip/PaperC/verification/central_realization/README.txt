Optimal central realizations and transfer
Run from this directory with CPython3.12 or later, standard library only:
  python check_optimal_capability_cover.py 3
  python check_optimal_capability_cover.py 4
  python check_optimal_capability_cover.py 5
  python check_transfer_controls.py
The relative paths use the existing sibling central_depth and general_structure
fixtures. Reports are exact finite controls; the arbitrary-rank proof is in
Appendix "Optimal central realizations and transfer of filtrations".
To preserve supplied JSON use ../run_new_results.py with --output-dir.
